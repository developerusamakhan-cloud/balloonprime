<?php
/**
 * 301 redirects for old URLs that Google still shows in search.
 * They only run when the requested URL is a 404, so a page that exists is
 * never redirected. Add more with the vyntic_legacy_redirects filter.
 *
 * @package Vyntic
 */

defined( 'ABSPATH' ) || exit;

/** Old path => new path (both relative to the home URL). */
function vyntic_legacy_redirects() {
	return apply_filters(
		'vyntic_legacy_redirects',
		array(
			'about-vyntic'                                => 'about',
			'portfolio'                                   => 'work',
			'start-a-project'                             => 'contact',
			'cookie-policy'                               => 'privacy-policy',
			'services/e-commerce-development'             => 'services/ecommerce-development',
			'services/website-redesign-revamp'            => 'services/website-redesign',
			'services/website-maintenance-care-plans'     => 'care-plans',
			'core-web-vitals-optimization-for-wordpress'  => 'core-web-vitals-explained',
			'headless-wordpress-vs-traditional-wordpress' => 'services/wordpress-development',
			'how-to-choose-a-woocommerce-development-agency' => 'services/woocommerce-development',
			// Old posts Google would not index. Trash them in WordPress and these take over.
			'local-business-seo'                          => 'local-seo-guide',
			'best-wordpress-architecture-for-scalability' => 'services/wordpress-development',
			'high-converting-landing-page-design'         => 'services/landing-page-design',
			'how-to-migrate-from-shopify-to-wordpress'    => array( 'services/website-migration/shopify-to-wordpress', 'services/website-migration' ),
			'shopify-to-wordpress-migration'              => array( 'services/website-migration/shopify-to-wordpress', 'services/website-migration' ),
			'custom-wordpress-development-services'       => 'services/wordpress-development',
			'wordpress-website-development-2026'          => 'services/wordpress-development',
			'why-avoid-drag-and-drop-page-builders'       => 'services/wordpress-development',
			'woocommerce-vs-shopify-which-e-commerce-platform-actually-wins-in-2026' => 'services/ecommerce-development',
			'wordpress-security-best-practices-how-to-protect-your-site-in-2026'     => 'care-plans',
			'wordpress-speed-optimization-10-proven-tips-that-actually-work-in-2026' => 'services/website-speed-optimization',
			'category/performance'                        => 'services/website-speed-optimization',
		)
	);
}

/** Resolves a target path to a live URL, or '' when nothing is published there. */
function vyntic_redirect_target( $path ) {
	$page = get_page_by_path( $path );
	if ( $page && 'publish' === $page->post_status ) {
		return get_permalink( $page );
	}
	$post_id = url_to_postid( home_url( '/' . $path . '/' ) );
	return $post_id && 'publish' === get_post_status( $post_id ) ? get_permalink( $post_id ) : '';
}

add_action(
	'template_redirect',
	static function () {
		if ( ! is_404() ) {
			return;
		}
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $path, $home . '/' ) ) {
			$path = substr( $path, strlen( $home ) + 1 );
		}
		$path = strtolower( $path );

		$map    = vyntic_legacy_redirects();
		$target = '';
		if ( isset( $map[ $path ] ) ) {
			foreach ( (array) $map[ $path ] as $candidate ) {
				$target = vyntic_redirect_target( $candidate );
				if ( $target ) {
					break;
				}
			}
		} elseif ( preg_match( '#^work/[^/]+$#', $path ) ) {
			// A case study that was renamed or removed: send people to all work.
			$target = vyntic_redirect_target( 'work' );
		} elseif ( preg_match( '#^blog/page/\d+$#', $path ) ) {
			// A blog page number that no longer exists.
			$target = vyntic_redirect_target( 'blog' );
		}
		if ( $target ) {
			wp_safe_redirect( $target, 301, 'Vyntic' );
			exit;
		}
	},
	1
);
