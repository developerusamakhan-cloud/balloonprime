<?php
/**
 * One-time SEO title and description refresh after a theme update.
 *
 * The new values live in inc/data/seo.json. A page is only updated when its
 * Rank Math title or description is empty or still the theme's previous value,
 * so anything you changed by hand in Rank Math is kept.
 *
 * @package Vyntic
 */

defined( 'ABSPATH' ) || exit;

const VYNTIC_SEO_REV = 1;

/** Key => previous title and description written by the theme. */
function vyntic_seo_previous() {
	return array(
		'home' => array( 'Web Design, SEO and AI Search Agency | Vyntic Studio', 'Web design, SEO and AI search agency building fast websites on WordPress, Webflow, Shopify and GoHighLevel. Get your free website audit today.' ),
		'med-spa-seo' => array( 'Med Spa SEO Company | Rank for Treatments Near You', 'Med spa SEO company helping aesthetic clinics rank for Botox, fillers and laser treatments locally, with pages and reviews that bring bookings.' ),
		'post-local-seo-for-dentists' => array( 'Local SEO for Dentists: Get More Patients From Google', 'Local SEO for dentists: how dental clinics rank in Google Maps, earn more reviews and turn local searches into booked appointments.' ),
		'post-dental-website-cost' => array( 'Dental Website Cost in 2026: What Clinics Pay', 'Dental website cost explained: typical price ranges, what drives the cost and which features are worth paying for.' ),
		'post-wix-vs-wordpress' => array( 'Squarespace vs Wix vs WordPress: Which Is Best in 2026?', 'Squarespace vs Wix vs WordPress compared on ease, SEO, speed, cost and growth, with clear advice on which one fits your business in 2026.' ),
	);
}

add_action(
	'admin_init',
	static function () {
		if ( (int) get_option( 'vyntic_seo_rev', 0 ) >= VYNTIC_SEO_REV || ! function_exists( 'vyntic_setup_find' ) ) {
			return;
		}
		$pages = vyntic_setup_pages();
		$done  = 0;
		foreach ( vyntic_seo_previous() as $key => $prev ) {
			if ( empty( $pages[ $key ] ) ) {
				continue;
			}
			$page = vyntic_setup_find( $key );
			if ( ! $page ) {
				continue;
			}
			$new = array(
				'rank_math_title'       => array( $prev[0], $pages[ $key ][4] ),
				'rank_math_description' => array( $prev[1], $pages[ $key ][5] ),
			);
			foreach ( $new as $meta => $pair ) {
				$current = (string) get_post_meta( $page->ID, $meta, true );
				if ( '' === $current || $current === $pair[0] ) {
					update_post_meta( $page->ID, $meta, $pair[1] );
					++$done;
				}
			}
			$kw = (string) get_post_meta( $page->ID, 'rank_math_focus_keyword', true );
			$want = implode( ',', array_map( 'trim', explode( ',', $pages[ $key ][6] ) ) );
			if ( '' === $kw || 0 === strpos( $want, $kw ) ) {
				update_post_meta( $page->ID, 'rank_math_focus_keyword', $want );
			}
		}
		update_option( 'vyntic_seo_rev', VYNTIC_SEO_REV, false );
	}
);
