<?php
/**
 * Keep Google's index clean: tell search engines not to index feeds, the
 * plugin download links and admin-ajax requests, and send empty or
 * email-style author archives to the About page.
 *
 * @package Vyntic
 */

defined( 'ABSPATH' ) || exit;

/** Plugin zip downloads (?vyntic_download=...) are files, not pages. Runs before the Hub serves the file. */
add_action(
	'init',
	static function () {
		if ( ! empty( $_GET['vyntic_download'] ) && ! headers_sent() ) { // phpcs:ignore WordPress.Security.NonceVerification
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}
	},
	0
);

/** admin-ajax.php (for example WP Statistics events) should never appear in search. */
add_action(
	'admin_init',
	static function () {
		if ( wp_doing_ajax() && ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}
	},
	0
);

add_action(
	'template_redirect',
	static function () {
		// RSS feeds stay available for readers, but are not search results.
		if ( is_feed() && ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, follow', true );
			return;
		}
		// Author archives with no posts, or with an email-style username in the URL.
		if ( is_author() ) {
			$user = get_queried_object();
			if ( $user instanceof WP_User ) {
				$emailish = (bool) preg_match( '/(gmail|yahoo|hotmail|outlook|icloud|live)-?com$|@/', $user->user_nicename );
				if ( $emailish || 0 === (int) count_user_posts( $user->ID, 'post', true ) ) {
					$about = function_exists( 'vyntic_page_url' ) ? vyntic_page_url( 'about' ) : '';
					wp_safe_redirect( $about ? $about : home_url( '/' ), 301, 'Vyntic' );
					exit;
				}
			}
		}
	},
	2
);

/** Remove the per-post comment feed links from the page head (fewer feed URLs for Google to find). */
add_filter( 'feed_links_show_comments_feed', '__return_false' );
add_action(
	'after_setup_theme',
	static function () {
		remove_action( 'wp_head', 'feed_links_extra', 3 );
	},
	20
);
