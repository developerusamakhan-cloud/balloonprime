<?php
/**
 * Activation / DB schema / cron.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Creates the prompts and results tables.
 */
class AIVT_Install {

	/**
	 * Prompts table name.
	 *
	 * @return string
	 */
	public static function prompts_table() {
		global $wpdb;
		return $wpdb->prefix . 'aivt_prompts';
	}

	/**
	 * Results table name.
	 *
	 * @return string
	 */
	public static function results_table() {
		global $wpdb;
		return $wpdb->prefix . 'aivt_results';
	}

	/**
	 * Activation hook.
	 */
	public static function activate() {
		self::create_tables();
		if ( false === get_option( AIVT_Settings::OPTION ) ) {
			add_option( AIVT_Settings::OPTION, AIVT_Settings::defaults() );
		}
		AIVT_Runner::reschedule();
	}

	/**
	 * Deactivation hook: stop cron events.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( AIVT_Runner::CRON_HOOK );
		wp_clear_scheduled_hook( AIVT_Runner::QUEUE_HOOK );
	}

	/**
	 * Re-run schema when the DB version changes (covers updates without re-activation).
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'aivt_db_version' ) !== AIVT_DB_VERSION ) {
			self::create_tables();
		}
		self::remove_paid_engines();
	}

	/**
	 * 1.2.0 keeps only engines with a free API key: delete the saved ChatGPT, Claude and Perplexity keys.
	 */
	public static function remove_paid_engines() {
		$saved = get_option( AIVT_Settings::OPTION );
		if ( ! is_array( $saved ) || ! array_intersect_key( $saved, array_flip( array( 'openai_key', 'anthropic_key', 'perplexity_key' ) ) ) ) {
			return;
		}
		foreach ( array( 'openai', 'anthropic', 'perplexity' ) as $old ) {
			unset( $saved[ $old . '_enabled' ], $saved[ $old . '_key' ], $saved[ $old . '_model' ] );
		}
		update_option( AIVT_Settings::OPTION, $saved );
	}

	/**
	 * Create / update the tables using dbDelta.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$prompts = self::prompts_table();
		$results = self::results_table();
		$charset = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$prompts} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			prompt text NOT NULL,
			tag varchar(100) NOT NULL DEFAULT '',
			active tinyint(1) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY active (active)
		) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$results} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			prompt_id bigint(20) unsigned NOT NULL,
			engine varchar(20) NOT NULL,
			model varchar(100) NOT NULL DEFAULT '',
			status varchar(10) NOT NULL DEFAULT 'ok',
			response longtext NULL,
			brand_mentioned tinyint(1) NOT NULL DEFAULT 0,
			brand_position smallint(5) unsigned DEFAULT NULL,
			brand_cited tinyint(1) NOT NULL DEFAULT 0,
			sentiment varchar(10) NOT NULL DEFAULT '',
			sentiment_score decimal(4,2) DEFAULT NULL,
			competitors text NULL,
			citations longtext NULL,
			error text NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY prompt_engine (prompt_id,engine),
			KEY created_at (created_at)
		) {$charset};"
		);

		update_option( 'aivt_db_version', AIVT_DB_VERSION );
	}
}
