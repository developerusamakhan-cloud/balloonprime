<?php
/**
 * Google Gemini with Google Search grounding.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Gemini engine.
 */
class AIVT_Engine_Gemini extends AIVT_Engine {

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'gemini';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'Gemini';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://aistudio.google.com/app/apikey';
	}

	/**
	 * {@inheritDoc}
	 */
	public function note() {
		return __( 'Free key from Google AI Studio. The free tier answers with Google Search up to a daily limit; gemini-2.5-flash has the largest free allowance. On the free tier Google may use prompts to improve its products.', 'vyntic-ai-visibility' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$body = array(
			'contents' => array(
				array(
					'role'  => 'user',
					'parts' => array( array( 'text' => $prompt ) ),
				),
			),
		);
		if ( $web_search ) {
			$body['tools'] = array( array( 'google_search' => new stdClass() ) );
		}

		$url  = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $this->model() ) . ':generateContent';
		$data = $this->post_json( $url, $body, array( 'x-goog-api-key' => $this->api_key() ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$candidate = isset( $data['candidates'][0] ) ? $data['candidates'][0] : array();
		$text      = '';
		foreach ( isset( $candidate['content']['parts'] ) ? (array) $candidate['content']['parts'] : array() as $part ) {
			if ( isset( $part['text'] ) ) {
				$text .= $part['text'];
			}
		}

		// Grounding URIs are Google redirect links; the title holds the real domain.
		$citations = array();
		foreach ( isset( $candidate['groundingMetadata']['groundingChunks'] ) ? (array) $candidate['groundingMetadata']['groundingChunks'] : array() as $chunk ) {
			if ( empty( $chunk['web']['uri'] ) ) {
				continue;
			}
			$title    = isset( $chunk['web']['title'] ) ? $chunk['web']['title'] : '';
			$citation = $this->citation( $chunk['web']['uri'], $title );
			if ( preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/i', $title ) ) {
				$citation['domain'] = AIVT_Settings::host( $title );
			}
			$citations[] = $citation;
		}

		return array(
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ),
			'model'     => isset( $data['modelVersion'] ) ? $data['modelVersion'] : $this->model(),
		);
	}
}
