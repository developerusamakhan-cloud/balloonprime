<?php
/**
 * Plugin settings access.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads and normalises the single `aivt_settings` option.
 */
class AIVT_Settings {

	const OPTION = 'aivt_settings';

	/**
	 * Default values for every setting.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'brand_name'          => get_bloginfo( 'name' ),
			'brand_aliases'       => '',
			'brand_domain'        => self::host( home_url() ),
			'brand_description'   => get_bloginfo( 'description' ),
			'competitors'         => '',
			'gemini_enabled'      => 0,
			'gemini_key'          => '',
			'gemini_model'        => 'gemini-2.5-flash',
			'groq_enabled'        => 0,
			'groq_key'            => '',
			'groq_model'          => 'openai/gpt-oss-120b',
			'schedule'            => 'weekly',
			'retention_days'      => 180,
			'llms_txt_enabled'    => 0,
			'llms_txt_intro'      => '',
			'delete_on_uninstall' => 0,
		);
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * Single setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Lower-case host without "www.".
	 *
	 * @param string $url URL or bare domain.
	 * @return string
	 */
	public static function host( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( ! preg_match( '#^[a-z][a-z0-9+.-]*://#i', $url ) ) {
			$url = 'https://' . $url;
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		$host = strtolower( (string) $host );
		return preg_replace( '/^www\./', '', $host );
	}

	/**
	 * Brand name plus aliases.
	 *
	 * @return string[]
	 */
	public static function brand_terms() {
		$terms   = array( self::get( 'brand_name' ) );
		$aliases = explode( ',', (string) self::get( 'brand_aliases' ) );
		$terms   = array_merge( $terms, $aliases );
		$terms   = array_filter( array_map( 'trim', $terms ), 'strlen' );
		return array_values( array_unique( $terms ) );
	}

	/**
	 * Competitors parsed from "Name | domain.com" lines.
	 *
	 * @return array[] Each: name, domain.
	 */
	public static function competitors() {
		$out   = array();
		$lines = preg_split( '/\r\n|\r|\n/', (string) self::get( 'competitors' ) );
		foreach ( $lines as $line ) {
			$parts = array_map( 'trim', explode( '|', $line ) );
			if ( '' === $parts[0] ) {
				continue;
			}
			$out[] = array(
				'name'   => $parts[0],
				'domain' => isset( $parts[1] ) ? self::host( $parts[1] ) : '',
			);
		}
		return $out;
	}

	/**
	 * Sanitize callback for register_setting().
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input    = is_array( $input ) ? wp_unslash( $input ) : array();
		$defaults = self::defaults();
		$current  = self::all();
		$out      = array();

		$text_fields = array( 'brand_name', 'brand_aliases', 'gemini_model', 'groq_model' );
		foreach ( $text_fields as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : $defaults[ $key ];
			if ( '' === $out[ $key ] && false !== strpos( $key, '_model' ) ) {
				$out[ $key ] = $defaults[ $key ];
			}
		}

		$textarea_fields = array( 'brand_description', 'competitors', 'llms_txt_intro' );
		foreach ( $textarea_fields as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) ? sanitize_textarea_field( $input[ $key ] ) : $defaults[ $key ];
		}

		$out['brand_domain'] = isset( $input['brand_domain'] ) ? self::host( sanitize_text_field( $input['brand_domain'] ) ) : $defaults['brand_domain'];

		// Keys are shown masked; an empty field keeps the saved key.
		foreach ( AIVT_Engine::ids() as $engine ) {
			$key          = $engine . '_key';
			$value        = isset( $input[ $key ] ) ? trim( sanitize_text_field( $input[ $key ] ) ) : '';
			$out[ $key ]  = '' === $value ? $current[ $key ] : $value;
			if ( ! empty( $input[ $engine . '_clear_key' ] ) ) {
				$out[ $key ] = '';
			}
			$out[ $engine . '_enabled' ] = empty( $input[ $engine . '_enabled' ] ) ? 0 : 1;
		}

		$out['schedule']            = isset( $input['schedule'] ) && in_array( $input['schedule'], array( 'off', 'daily', 'weekly' ), true ) ? $input['schedule'] : 'weekly';
		$out['retention_days']      = isset( $input['retention_days'] ) ? min( 3650, max( 7, absint( $input['retention_days'] ) ) ) : $defaults['retention_days'];
		$out['llms_txt_enabled']    = empty( $input['llms_txt_enabled'] ) ? 0 : 1;
		$out['delete_on_uninstall'] = empty( $input['delete_on_uninstall'] ) ? 0 : 1;

		return $out;
	}
}
