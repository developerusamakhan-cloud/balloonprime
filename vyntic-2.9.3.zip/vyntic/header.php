<?php
/**
 * Site header.
 *
 * @package Vyntic
 */

$vyntic_minimal = is_page_template( 'page-templates/landing.php' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'vyntic' ); ?></a>

<header class="site-header<?php echo $vyntic_minimal ? ' site-header--minimal' : ''; ?>" data-header>
	<div class="wrap site-header__inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() && get_theme_mod( 'vyntic_use_custom_logo', false ) ) : ?>
				<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'brand__logo', 'alt' => get_bloginfo( 'name' ) ) ); ?>
			<?php else : ?>
				<img class="brand__logo" src="<?php echo esc_url( vyntic_img( 'brand/logo.svg' ) ); ?>" alt="<?php bloginfo( 'name' ); ?>" width="339" height="124">
			<?php endif; ?>
		</a>

		<?php if ( ! $vyntic_minimal ) : ?>
			<nav class="nav" id="site-nav" aria-label="<?php esc_attr_e( 'Main', 'vyntic' ); ?>" data-nav data-lenis-prevent>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'nav__list',
						'depth'          => 2,
						'fallback_cb'    => 'vyntic_menu_fallback',
					)
				);
				?>
				<a class="btn btn--primary nav__cta" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
			</nav>
			<button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false" data-nav-toggle>
				<span class="nav-toggle__open"><?php echo vyntic_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="nav-toggle__close"><?php echo vyntic_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'vyntic' ); ?></span>
			</button>
		<?php else : ?>
			<a class="btn btn--primary" href="#contact-form"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
		<?php endif; ?>
	</div>
</header>

<main id="main" class="site-main" tabindex="-1">
