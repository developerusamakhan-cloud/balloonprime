/* Vyntic AI Planner */
(function () {
	'use strict';
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	document.querySelectorAll('[data-vap]').forEach(function (app) {
		var form = app.querySelector('[data-vap-form]');
		var p1 = app.querySelector('[data-step="1"]');
		var p2 = app.querySelector('[data-step="2"]');
		var loading = app.querySelector('[data-vap-loading]');
		var statusEl = app.querySelector('[data-vap-status]');
		var result = app.querySelector('[data-vap-result]');
		var errorEl = app.querySelector('[data-vap-error]');
		var dots = app.querySelectorAll('[data-step-dot]');
		var started = Date.now();
		var timer = null;
		var steps = ['Reading about your business…', 'Choosing the sections that win enquiries…', 'Writing your headline…', 'Adding a quick win for speed and SEO…'];

		function show(el, on) { el.hidden = !on; }
		function step(n) {
			dots.forEach(function (d) { d.classList.toggle('is-on', parseInt(d.getAttribute('data-step-dot'), 10) <= n); });
		}
		function error(msg) {
			errorEl.textContent = msg || '';
			show(errorEl, !!msg);
		}

		app.querySelector('[data-next]').addEventListener('click', function () {
			var biz = form.business.value.trim();
			if (biz.length < 8) {
				error('Tell us a little more about your business, for example "family dental clinic in Leeds".');
				form.business.focus();
				return;
			}
			error('');
			show(p1, false); show(p2, true); step(2);
			form.email.focus();
		});

		app.querySelector('[data-back]').addEventListener('click', function () {
			error(''); show(p2, false); show(p1, true); step(1);
		});

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var email = form.email.value.trim();
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { error('Please enter a valid email so we can send your plan.'); form.email.focus(); return; }
			if (!form.consent.checked) { error('Please tick the box so we can email you your plan.'); return; }
			error('');
			var goal = form.querySelector('input[name="goal"]:checked');
			show(form, false); show(loading, true); step(3);
			var k = 0; statusEl.textContent = steps[0];
			timer = setInterval(function () { k = (k + 1) % steps.length; statusEl.textContent = steps[k]; }, 1700);

			var payload = {
				business: form.business.value,
				goal: goal ? goal.value : '',
				name: form.name.value,
				email: email,
				consent: form.consent.checked ? 1 : 0,
				hp: form.hp.value,
				elapsed: Math.round((Date.now() - started) / 1000),
				page: window.location.href,
				nonce: app.getAttribute('data-nonce')
			};
			function send() {
				return fetch(app.getAttribute('data-endpoint'), {
					method: 'POST',
					credentials: 'omit',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				}).then(function (r) {
					return r.json().then(function (d) { return { ok: r.ok, d: d }; });
				});
			}
			// An old (cached or long-open) page has an expired token: get a fresh one and retry once.
			send().then(function (out) {
				if (out.ok || !out.d || out.d.code !== 'vap_nonce' || !app.getAttribute('data-token-url')) { return out; }
				return fetch(app.getAttribute('data-token-url'), { credentials: 'omit', cache: 'no-store' })
					.then(function (r) { return r.json(); })
					.then(function (t) {
						if (!t || !t.token) { return out; }
						app.setAttribute('data-nonce', t.token);
						payload.nonce = t.token;
						return send();
					}, function () { return out; });
			}).then(function (out) {
				clearInterval(timer);
				show(loading, false);
				if (!out.ok) {
					show(form, true); show(p1, false); show(p2, true); step(2);
					error((out.d && out.d.message) || 'Something went wrong. Please try again.');
					return;
				}
				render(out.d);
			}).catch(function () {
				clearInterval(timer);
				show(loading, false); show(form, true); step(2);
				error('Connection problem. Please check your internet and try again.');
			});
		});

		function render(d) {
			var set = function (f, v) { var el = app.querySelector('[data-f="' + f + '"]'); if (el) el.textContent = v || ''; return el; };
			var n = 0;
			set('headline', d.headline).style.setProperty('--k', n++);
			set('subheadline', d.subheadline).style.setProperty('--k', n++);
			var ol = app.querySelector('[data-f="sections"]'); ol.innerHTML = '';
			(d.sections || []).forEach(function (s) {
				var li = document.createElement('li'); var b = document.createElement('strong'); var sp = document.createElement('span');
				b.textContent = s.name; sp.textContent = s.why; li.appendChild(b); li.appendChild(sp);
				li.style.setProperty('--k', n++); ol.appendChild(li);
			});
			var ul = app.querySelector('[data-f="features"]'); ul.innerHTML = '';
			(d.features || []).forEach(function (f) { var li = document.createElement('li'); li.textContent = f; ul.appendChild(li); });
			set('quick_win', d.quick_win);
			show(app.querySelector('[data-vap-sent]'), !!d.emailed);

			var build = app.querySelector('[data-vap-build]');
			try {
				var summary = 'My AI homepage plan: ' + d.headline + '\nSections: ' + (d.sections || []).map(function (s) { return s.name; }).join(', ') + '\n\n';
				sessionStorage.setItem('vyntic_plan', summary);
			} catch (e) {}
			build.setAttribute('href', app.getAttribute('data-contact'));

			app.classList.toggle('vap-animate', !reduce);
			show(result, true);
			result.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'nearest' });
		}

		app.querySelector('[data-vap-again]').addEventListener('click', function () {
			show(result, false); show(form, true); show(p2, false); show(p1, true); step(1);
			form.business.value = ''; form.business.focus();
			started = Date.now();
		});
	});
})();
