<?php
/**
 * Shortcode: [vyntic_planner theme="dark"] (theme: dark or light).
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'vap', VAP_URL . 'assets/planner.css', array(), VAP_VERSION );
	wp_register_script( 'vap', VAP_URL . 'assets/planner.js', array(), VAP_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

add_shortcode( 'vyntic_planner', function ( $atts ) {
	$atts = shortcode_atts( array( 'theme' => 'dark' ), $atts, 'vyntic_planner' );
	wp_enqueue_style( 'vap' );
	wp_enqueue_script( 'vap' );

	$goals   = apply_filters( 'vap_goals', array( 'More enquiries', 'Online bookings', 'Sell products online', 'Look more trustworthy' ) );
	$privacy = vap_opt( 'privacy_url' ) ? vap_opt( 'privacy_url' ) : get_privacy_policy_url();
	$cta     = vap_opt( 'cta_url' ) ? vap_opt( 'cta_url' ) : home_url( '/contact/' );
	$uid     = wp_unique_id( 'vap-' );
	$ready   = vap_provider_ready( vap_opt( 'provider' ) ) || ( vap_opt( 'fallback' ) && ( vap_provider_ready( 'gemini' ) || vap_provider_ready( 'openai' ) ) );

	if ( ! $ready && ! has_filter( 'vap_pre_generate' ) ) {
		return current_user_can( 'manage_options' )
			? '<p class="vap-admin-note">' . esc_html__( 'AI Planner: add a free Gemini API key in AI Planner, Settings to switch the planner on. Visitors do not see this note.', 'vyntic-ai-planner' ) . '</p>'
			: '';
	}

	ob_start();
	?>
	<div class="vap vap--<?php echo esc_attr( 'light' === $atts['theme'] ? 'light' : 'dark' ); ?>" data-vap data-endpoint="<?php echo esc_url( rest_url( 'vap/v1/plan' ) ); ?>" data-nonce="<?php echo esc_attr( vap_form_token() ); ?>" data-token-url="<?php echo esc_url( rest_url( 'vap/v1/token' ) ); ?>" data-contact="<?php echo esc_url( $cta ); ?>">
		<ol class="vap-steps" aria-hidden="true">
			<li class="is-on" data-step-dot="1"><span>1</span><?php esc_html_e( 'Your business', 'vyntic-ai-planner' ); ?></li>
			<li data-step-dot="2"><span>2</span><?php esc_html_e( 'Where to send it', 'vyntic-ai-planner' ); ?></li>
			<li data-step-dot="3"><span>3</span><?php esc_html_e( 'Your plan', 'vyntic-ai-planner' ); ?></li>
		</ol>

		<form class="vap-form" data-vap-form novalidate>
			<div class="vap-panel" data-step="1">
				<label class="vap-label" for="<?php echo esc_attr( $uid ); ?>-biz"><?php esc_html_e( 'What does your business do, and where?', 'vyntic-ai-planner' ); ?></label>
				<textarea id="<?php echo esc_attr( $uid ); ?>-biz" name="business" rows="3" maxlength="500" required placeholder="<?php esc_attr_e( 'e.g. Family dental clinic in Leeds with two dentists and a hygienist', 'vyntic-ai-planner' ); ?>"></textarea>
				<fieldset class="vap-goals">
					<legend class="vap-label"><?php esc_html_e( 'Main goal', 'vyntic-ai-planner' ); ?></legend>
					<?php foreach ( $goals as $i => $g ) : ?>
						<label class="vap-goal"><input type="radio" name="goal" value="<?php echo esc_attr( $g ); ?>" <?php checked( 0, $i ); ?>><span><?php echo esc_html( $g ); ?></span></label>
					<?php endforeach; ?>
				</fieldset>
				<button type="button" class="vap-btn vap-btn--primary" data-next><?php esc_html_e( 'Next', 'vyntic-ai-planner' ); ?></button>
			</div>

			<div class="vap-panel" data-step="2" hidden>
				<p class="vap-intro"><?php esc_html_e( 'Almost there. Where should we send your plan? You will also see it here straight away.', 'vyntic-ai-planner' ); ?></p>
				<div class="vap-row">
					<div>
						<label class="vap-label" for="<?php echo esc_attr( $uid ); ?>-name"><?php esc_html_e( 'First name', 'vyntic-ai-planner' ); ?> <em><?php esc_html_e( 'optional', 'vyntic-ai-planner' ); ?></em></label>
						<input id="<?php echo esc_attr( $uid ); ?>-name" name="name" type="text" autocomplete="given-name">
					</div>
					<div>
						<label class="vap-label" for="<?php echo esc_attr( $uid ); ?>-email"><?php esc_html_e( 'Email', 'vyntic-ai-planner' ); ?></label>
						<input id="<?php echo esc_attr( $uid ); ?>-email" name="email" type="email" autocomplete="email" required placeholder="you@company.com">
					</div>
				</div>
				<label class="vap-consent">
					<input type="checkbox" name="consent" value="1" required>
					<span>
						<?php echo esc_html( vap_opt( 'consent_text' ) ); ?>
						<?php if ( $privacy ) : ?><a href="<?php echo esc_url( $privacy ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Privacy policy', 'vyntic-ai-planner' ); ?></a><?php endif; ?>
					</span>
				</label>
				<input type="text" name="hp" class="vap-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
				<div class="vap-actions">
					<button type="button" class="vap-btn vap-btn--ghost" data-back><?php esc_html_e( 'Back', 'vyntic-ai-planner' ); ?></button>
					<button type="submit" class="vap-btn vap-btn--primary"><?php esc_html_e( 'Plan my homepage', 'vyntic-ai-planner' ); ?></button>
				</div>
				<p class="vap-fine"><?php esc_html_e( 'Free. Written by AI, so treat it as a starting point.', 'vyntic-ai-planner' ); ?></p>
			</div>
		</form>

		<div class="vap-loading" data-vap-loading hidden aria-live="polite">
			<span class="vap-orb" aria-hidden="true"></span>
			<p data-vap-status><?php esc_html_e( 'Reading about your business…', 'vyntic-ai-planner' ); ?></p>
			<div class="vap-skeleton" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
		</div>

		<div class="vap-result" data-vap-result hidden aria-live="polite">
			<div class="vap-plan">
				<div class="vap-plan__bar"><i></i><i></i><i></i><span><?php esc_html_e( 'Your homepage, planned', 'vyntic-ai-planner' ); ?></span></div>
				<div class="vap-plan__body">
					<h3 class="vap-plan__headline" data-f="headline"></h3>
					<p class="vap-plan__sub" data-f="subheadline"></p>
					<ol class="vap-plan__sections" data-f="sections"></ol>
					<p class="vap-label vap-label--dark"><?php esc_html_e( 'Must-have features', 'vyntic-ai-planner' ); ?></p>
					<ul class="vap-plan__features" data-f="features"></ul>
					<p class="vap-plan__tip"><strong><?php esc_html_e( 'Quick win:', 'vyntic-ai-planner' ); ?></strong> <span data-f="quick_win"></span></p>
				</div>
			</div>
			<p class="vap-sent" data-vap-sent hidden><?php esc_html_e( 'A copy is on its way to your inbox.', 'vyntic-ai-planner' ); ?></p>
			<div class="vap-actions">
				<a class="vap-btn vap-btn--primary" href="<?php echo esc_url( $cta ); ?>" data-vap-build><?php echo esc_html( vap_opt( 'cta_label' ) ); ?></a>
				<button type="button" class="vap-btn vap-btn--ghost" data-vap-again><?php esc_html_e( 'Plan another', 'vyntic-ai-planner' ); ?></button>
			</div>
		</div>

		<p class="vap-error" data-vap-error hidden role="alert"></p>
	</div>
	<?php
	return ob_get_clean();
} );
