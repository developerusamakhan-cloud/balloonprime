<?php
/**
 * AI providers. All calls run on the server, so API keys never reach the browser.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate text with the main provider, then the backup if it fails.
 *
 * @param string $system System instruction.
 * @param string $prompt User prompt.
 * @return string|WP_Error
 */
function vap_generate( $system, $prompt ) {
	// Lets tests or other plugins supply an answer.
	$pre = apply_filters( 'vap_pre_generate', null, $system, $prompt );
	if ( null !== $pre ) {
		return $pre;
	}

	$main  = vap_opt( 'provider' );
	$order = array( $main );
	if ( vap_opt( 'fallback' ) ) {
		foreach ( array( 'gemini', 'openai', 'wp' ) as $p ) {
			if ( $p !== $main ) {
				$order[] = $p;
			}
		}
	}

	$errors = array();
	foreach ( $order as $provider ) {
		if ( ! vap_provider_ready( $provider ) ) {
			continue;
		}
		$fn  = 'vap_call_' . $provider;
		$res = $fn( $system, $prompt );
		if ( ! is_wp_error( $res ) && '' !== trim( (string) $res ) ) {
			return $res;
		}
		$errors[] = vap_provider_label( $provider ) . ': ' . ( is_wp_error( $res ) ? $res->get_error_message() : __( 'empty answer', 'vyntic-ai-planner' ) );
	}
	if ( ! $errors ) {
		return new WP_Error( 'vap_no_provider', __( 'No AI provider is set up yet. Add an API key under AI Planner, Settings.', 'vyntic-ai-planner' ) );
	}
	// Show every provider's error, so the real cause is not hidden behind the last one.
	return new WP_Error( 'vap_failed', implode( ' | ', $errors ) );
}

/** Human name of a provider. */
function vap_provider_label( $provider ) {
	$labels = array(
		'gemini' => 'Gemini',
		'openai' => __( 'Backup API', 'vyntic-ai-planner' ),
		'wp'     => __( 'WordPress AI Client', 'vyntic-ai-planner' ),
	);
	return isset( $labels[ $provider ] ) ? $labels[ $provider ] : $provider;
}

/** Whether a provider has what it needs. */
function vap_provider_ready( $provider ) {
	switch ( $provider ) {
		case 'gemini':
			return (bool) vap_opt( 'gemini_key' );
		case 'openai':
			return vap_opt( 'oa_key' ) && vap_opt( 'oa_base' ) && vap_opt( 'oa_model' );
		case 'wp':
			return vap_wp_ai_ready();
	}
	return false;
}

/** Friendly error from an HTTP response. */
function vap_http_error( $res, $name ) {
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	$msg  = '';
	if ( isset( $body['error']['message'] ) ) {
		$msg = $body['error']['message'];
	} elseif ( isset( $body['message'] ) ) {
		$msg = $body['message'];
	}
	if ( 429 === (int) $code ) {
		$msg = __( 'free limit reached for now', 'vyntic-ai-planner' ) . ( $msg ? ' (' . $msg . ')' : '' );
	}
	/* translators: 1: provider, 2: HTTP code, 3: message */
	return new WP_Error( 'vap_http', sprintf( __( '%1$s error %2$s: %3$s', 'vyntic-ai-planner' ), $name, $code, wp_strip_all_tags( $msg ) ), array( 'status' => $code ) );
}

/**
 * Whether the WordPress AI Client has a provider set up (Settings, Connectors).
 * WordPress 7 always has the function, even when nothing is connected.
 */
function vap_wp_ai_ready() {
	if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
		return false;
	}
	try {
		$b = wp_ai_client_prompt( 'Test' );
		if ( is_callable( array( $b, 'is_supported_for_text_generation' ) ) ) {
			return (bool) $b->is_supported_for_text_generation();
		}
	} catch ( \Throwable $e ) {
		return false;
	}
	return 'wp' === vap_opt( 'provider' );
}

/**
 * Google Gemini (Google AI Studio key, free tier on Flash models).
 * Tries the key in the header, then as ?key= (needed by some newer "AQ." keys),
 * then the Vertex AI express endpoint, which also accepts "AQ." keys.
 */
function vap_call_gemini( $system, $prompt ) {
	$key   = trim( (string) vap_opt( 'gemini_key' ) );
	$model = rawurlencode( preg_replace( '#^models/#', '', trim( (string) vap_opt( 'gemini_model' ) ) ) );
	$body  = wp_json_encode(
		array(
			'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
			'contents'          => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $prompt ) ) ) ),
			'generationConfig'  => array(
				'temperature'      => 0.7,
				'maxOutputTokens'  => 4096,
				'responseMimeType' => 'application/json',
			),
		)
	);
	$gl       = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';
	$attempts = array(
		array( $gl, array( 'x-goog-api-key' => $key ) ),
		array( add_query_arg( 'key', rawurlencode( $key ), $gl ), array() ),
	);
	if ( 0 === strpos( $key, 'AQ.' ) ) {
		$attempts[] = array( add_query_arg( 'key', rawurlencode( $key ), 'https://aiplatform.googleapis.com/v1/publishers/google/models/' . $model . ':generateContent' ), array() );
	}

	$first = null;
	foreach ( $attempts as $a ) {
		$res  = wp_remote_post(
			$a[0],
			array(
				'timeout' => 45,
				'headers' => array( 'Content-Type' => 'application/json' ) + $a[1],
				'body'    => $body,
			)
		);
		$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
		if ( 200 === $code ) {
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			$text = '';
			if ( ! empty( $data['candidates'][0]['content']['parts'] ) ) {
				foreach ( $data['candidates'][0]['content']['parts'] as $part ) {
					if ( isset( $part['text'] ) && empty( $part['thought'] ) ) {
						$text .= $part['text'];
					}
				}
			}
			return $text ? $text : new WP_Error( 'vap_empty', __( 'Gemini returned no text.', 'vyntic-ai-planner' ) );
		}
		if ( null === $first ) {
			$first = vap_http_error( $res, 'Gemini' );
		}
		// Only a rejected key is worth another way of sending it. Limits, bad model names and
		// network errors come back the same every time.
		if ( ! in_array( $code, array( 400, 401, 403 ), true ) ) {
			break;
		}
	}
	if ( is_wp_error( $first ) && false !== strpos( $first->get_error_message(), 'OAuth 2' ) ) {
		return new WP_Error( 'vap_http', __( 'Gemini did not accept this key. In Google AI Studio open "Get API key", click "Create API key", copy the whole key and paste it again. Check the Gemini API is enabled for that project.', 'vyntic-ai-planner' ) . ' (' . $first->get_error_message() . ')' );
	}
	return $first;
}

/** Any OpenAI-compatible chat API (Groq, OpenRouter, OpenAI, Together and more). */
function vap_call_openai( $system, $prompt ) {
	$payload = array(
		'model'           => vap_opt( 'oa_model' ),
		'temperature'     => 0.7,
		'max_tokens'      => 1500,
		'messages'        => array(
			array( 'role' => 'system', 'content' => $system ),
			array( 'role' => 'user', 'content' => $prompt ),
		),
		'response_format' => array( 'type' => 'json_object' ),
	);
	$args = array(
		'timeout' => 45,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . vap_opt( 'oa_key' ),
			'HTTP-Referer'  => home_url( '/' ),
			'X-Title'       => get_bloginfo( 'name' ),
		),
	);
	$url  = trailingslashit( vap_opt( 'oa_base' ) ) . 'chat/completions';
	$res  = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );

	// Some models do not support JSON mode. Retry once without it.
	if ( ! is_wp_error( $res ) && 400 === (int) wp_remote_retrieve_response_code( $res ) ) {
		unset( $payload['response_format'] );
		$res = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );
	}
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return vap_http_error( $res, 'API' );
	}
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	return isset( $body['choices'][0]['message']['content'] ) ? (string) $body['choices'][0]['message']['content'] : new WP_Error( 'vap_empty', __( 'The API returned no text.', 'vyntic-ai-planner' ) );
}

/** WordPress AI Client (WordPress 7.0+, provider set in Settings, Connectors). */
function vap_call_wp( $system, $prompt ) {
	try {
		$builder = wp_ai_client_prompt( $prompt );
		if ( is_callable( array( $builder, 'using_system_instruction' ) ) ) {
			$builder = $builder->using_system_instruction( $system );
		} else {
			$builder = wp_ai_client_prompt( $system . "\n\n" . $prompt );
		}
		if ( is_callable( array( $builder, 'using_max_tokens' ) ) ) {
			$builder = $builder->using_max_tokens( 1500 );
		}
		$text = $builder->generate_text();
		return is_string( $text ) ? $text : ( is_wp_error( $text ) ? $text : new WP_Error( 'vap_empty', 'Empty answer' ) );
	} catch ( \Throwable $e ) {
		return new WP_Error( 'vap_wp_ai', $e->getMessage() );
	}
}

/**
 * Pull the JSON object out of a model answer.
 *
 * @param string $text Raw answer.
 * @return array|null
 */
function vap_parse_json( $text ) {
	$text  = trim( preg_replace( '/^```(?:json)?|```$/m', '', (string) $text ) );
	$start = strpos( $text, '{' );
	$end   = strrpos( $text, '}' );
	if ( false === $start || false === $end ) {
		return null;
	}
	$data = json_decode( substr( $text, $start, $end - $start + 1 ), true );
	return is_array( $data ) ? $data : null;
}
