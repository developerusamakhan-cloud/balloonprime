# Vyntic WordPress theme

Custom, builder-free theme for Vyntic Studio.

## Install
1. WordPress → Appearance → Themes → Add New → Upload Theme → choose `vyntic.zip` → Activate.
2. Settings → Permalinks → click Save once (makes the /work/project-name/ URLs work).

## Page templates
Create a page, then pick a template in the editor sidebar (Page → Template):

| Template        | Use for                                   | Suggested slug          |
|-----------------|-------------------------------------------|-------------------------|
| Home            | Homepage (set in Settings → Reading)      | home                    |
| Services        | All services overview                      | services                |
| Service detail  | One page per service                       | see list below          |
| Work            | Portfolio with filters                     | work                    |
| About           | Studio story, facts, principles            | about                   |
| Care plans      | Maintenance plans and prices               | care-plans              |
| Contact         | Inquiry form + contact details             | contact                 |
| Landing page    | Ad campaigns (no menu, form on the page)   | anything                |
| Full width      | Build your own layout with blocks          | anything                |
| Free audit      | Your audit tool page                       | free-audit              |

Service rows link automatically when a page exists with these slugs:
`wordpress-development`, `ecommerce-development`, `landing-pages`,
`website-redesign`, `wordpress-migration`, `care-plans`.

On every template except Home, text you type in the page editor appears as an extra section,
and the page **Excerpt** becomes the intro text under the title.

## Editing content
- **Appearance → Customize → Vyntic options**: hero headline, score, Core Web Vitals values,
  CTA text and link, email, phone, WhatsApp, social links, form recipient.
- **Work** (dashboard menu): case studies, see above. Group them with Project types
  to get filter buttons on the Work page.
- **inc/content.php**: services, process steps, principles, tech stack, care plans, FAQ.
  **Care plan prices are placeholders – change them before launch.**
- **Appearance → Menus**: assign Main menu, Footer menu and Legal links.
- Per-page overrides (ACF Pro or custom fields): `hero_title`, `hero_text`, `hero_score`,
  `cta_title`, `cta_text`.

## Contact form
Works without a plugin. Emails go to the address in Customize → Contact and social.
Install an SMTP plugin (e.g. WP Mail SMTP) so messages don't land in spam.

## Colours
Appearance → Customize → Vyntic options → Colours. Five palettes: Signal, Violet Pulse,
Aurora, Tide and Ember. The Customizer preview shows each one live before you publish.

## Moving from an old theme
The Home template ignores the Home page's editor content. If other pages still show
old shortcodes like `[hero_visual_fixed]`, open those pages and delete the old content.

## Homepage sections (1.3)
Hero → tools strip → "Is your website costing you money?" → services → numbers band →
recent work → free audit → page builder comparison → process → client quotes → blog → FAQ → CTA.

- Edit the warning signs, numbers and comparison rows in `inc/content.php`
  (`vyntic_problems()`, `vyntic_stats()`, `vyntic_comparison()`).
- **Client quotes** come from the Quote fields of your case studies. The section stays
  hidden until at least one project has a quote, so nothing is invented.
- All motion respects the visitor's "reduce motion" setting.

## 1.4: case studies use your existing "work" post type
The old "project" post type is gone. The theme now uses `work`, the post type that already
holds your case studies (`/wp-admin/edit.php?post_type=work`). If a plugin already registers
`work`, the theme leaves it alone and only adds the "Case study details" box.

Old ACF fields still show: every field is read from the theme's own key first, then from ACF.
If your old field names differ, map them once in a child theme or snippet:

    add_filter( 'vyntic_work_field_map', function () {
        return array(
            'project_result'      => 'your_old_result_field',
            'project_score_after' => 'your_old_score_field',
        );
    } );

## 1.4: AI website planner (homepage)
Visitors describe their business and get a homepage plan (headline, 5 sections,
3 features, one quick win). Needs WordPress 7.0+ with a provider connected in
Settings → Connectors (you already connected Anthropic). The theme never sees your key.
Limits: 5 plans per visitor per hour, 150 per day for the whole site
(filters `vyntic_ai_per_visitor`, `vyntic_ai_daily_cap`). Turn it off in
Customize → Vyntic options → AI planner. "Build this with Vyntic" carries the plan
into the contact form message.

## 1.4: new services
"AI search visibility" (page slug `ai-search-visibility`) and
"AI assistants and automations" (slug `ai-integrations`). Remove them from
`vyntic_services()` in inc/content.php if you do not offer them.

## 1.6: local SEO pages
- **Location (local SEO)** template: one page per country, e.g. "Web design and SEO in Germany".
  Add custom fields `location_city` and `location_region`, write an Excerpt and some
  unique local content. The page gets city-specific headings, FAQ, and Service + FAQ schema.
- **Locations (all areas)** template: a page listing every location page.
- Location pages appear automatically in the footer "Locations" column (first 12),
  with an "All locations" link to the Locations page.
- Tip: only create pages for places you really serve, and write different content on each,
  or Google treats them as duplicates.

## 1.6: other changes
- Hero: "Websites that" + rotating endings (Customize → Home hero), service pills,
  Google and AI-answer cards.
- Header is transparent over the first section and turns solid on scroll.
- Services: each row shows an illustrated preview screen that follows the cursor.
- Statement: key phrases in [[double brackets]] get a highlighter sweep; add your own
  image in Customize → Home hero → Statement image URL.
- New "lens" cursor that inverts colours, stretches with movement, shows labels on cards.
- Big footer: CTA, services, locations, studio, resources, contact (address and hours
  in Customize → Contact and social), giant outlined wordmark.

## 1.7
- **Reviews** (dashboard menu): add each client review with name, text, rating,
  role and company, source and an optional photo. Tick "Show larger" for a highlight.
  With 4+ reviews the homepage wall scrolls gently; the average rating is calculated
  automatically. Only publish real reviews.
- **Inquiry form**: services and budget as tap chips, phone, website, timeline, consent.
  Used on the homepage ("Start a project", #contact), Contact and Location pages.
- **Platforms** section replaces the page builder comparison: WordPress, Webflow, Shopify,
  WooCommerce, Wix, Squarespace (edit in `vyntic_platforms()`).
- Services and copy are platform neutral. 10 FAQ questions.
- New numbers strip; numbers removed from the statement section.
- Blog cards never put text over images.
- Removed: Clutch link, the closing CTA band (the footer already has one).

## 1.8
- New logo in the site colours (spruce and coral), built in: header uses
  `assets/img/brand/logo.svg`, footer uses `logo-light.svg`, favicon uses `mark-app.svg`
  (only if no Site Icon is set). To show an uploaded logo instead, tick
  "Use the uploaded logo" in Customize → Site Identity.
- Home blog: one row of three cards and a "Read all articles" button.
- Footer: CTA with "Book a call" and "Get a free audit", brand row, then six columns:
  Services, Quick links, Industries, Locations, Legal, Contact, and a giant "Vyntic Studio".
  Legal shows the Legal menu if set, otherwise your privacy policy and pages with the slugs
  cookie-policy, terms (or terms-of-service) and refund-policy.
- Platforms: added GoHighLevel.

## 1.9: ready-made Phase 1 pages
New page templates with the full copy already written (edit it in `inc/data/landing.json`):

| Template | Page to create | Parent | URL |
|---|---|---|---|
| Service: Website design and development | Website design and development | Services | /services/web-design/ |
| Service: Local SEO | Local SEO | Services | /services/local-seo/ |
| Service: SEO services | SEO services | Services | /services/seo-services/ |
| Service: AI search visibility | AI search visibility | Services | /services/ai-search-visibility/ |
| Service: GoHighLevel setup and automations | GoHighLevel setup and automations | Services | /services/gohighlevel/ |
| Service: Online stores | Online stores | Services | /services/ecommerce-development/ |
| Industries (hub) | Industries | none | /industries/ |
| Industry: Dental clinics | Dental clinics | Industries | /industries/dental-website-design/ |
| Industry: Law firms | Law firms | Industries | /industries/law-firm-website-design/ |
| Industry: Roofing companies | Roofing companies | Industries | /industries/roofing-website-design/ |
| Industry: Med spas and aesthetic clinics | Med spas and aesthetic clinics | Industries | /industries/med-spa-website-design/ |
| Reviews | Reviews | none | /reviews/ |

Each page includes: hero, problems, what you get, how it works, recent work, reviews,
free audit, FAQ (with FAQ schema), related services and the inquiry form.
Optional per page: Excerpt replaces the intro, Featured image replaces the artwork,
editor content appears after "What you get". SEO title and meta: see the sitemap spreadsheet.

## 2.0: Tools → Vyntic setup
Three buttons, run in order:
1. **Create missing pages**: every Phase 1 page with the right template, parent and URL (drafts unless "Publish now" is ticked).
2. **Add long-form content**: writes 750 to 1,000 words per service and industry page into the editor,
   with an image, H2s, internal links to related pages, one outside reference link and an FAQ section,
   so Rank Math can analyse it. Only empty pages are filled unless "Overwrite" is ticked.
3. **Fill Rank Math SEO**: SEO title, meta description and focus keywords (primary first) for 20 pages.
Content lives in `inc/data/articles.json`, SEO fields in `inc/data/seo.json`.

## 2.2: the full 60-page site
Tools → Vyntic setup now builds 57 of the 60 sitemap pages (the 3 legal pages need your own legal text):
- 22 service, platform and industry pages (each with its own template)
- Locations hub, 4 country pages and 5 city pages (city pages always start as drafts:
  add a real local client, review or project before publishing)
- 15 blog posts with categories, excerpts, FAQs and internal links
- Rank Math title, description and focus keywords for all 57
Blog posts need Settings → Permalinks set to "Post name" so URLs look like /local-seo-guide/.
Also improved: 404 page, single post (audit call-to-action box, fallback image),
single case study (more case studies + inquiry form), Work page, location breadcrumbs
and city lists, platform cards that link to their pages.

## 2.3
- Service, industry, platform, location and main pages show their content straight from the theme
  (inc/data/articles.json), with a contents list and full-width layout. Page editors can stay empty.
  Rank Math still analyses this content (the theme passes it to Rank Math in the editor).
  Tools, Vyntic setup, step 2 with Overwrite ticked clears old copies from page editors.
- New Wix and Squarespace platform pages.
- Internal linking: posts link to related services, services list related guides,
  case studies link to the services and guides that match them (inc/links.php).
- Blog: no search bar on the overview; posts use the full width, show breadcrumbs,
  real author names with job titles and initials avatars, and end with the free audit form.
- Authors: Users, Profile has Job title, Photo URL and "Hide from team". Step 3 of
  Vyntic setup spreads posts across your Authors.
- About: your page content plus a team grid built from your users.
- World map with a pin for every published Location page (contact, about, locations and homepage).
- Cookie banner linking to /cookie-policy/, with optional Google Consent Mode (Customize, Contact and social).
- Footer lists every published sitemap page in 8 columns.
- Breadcrumbs sit above every page title; breadcrumbs pasted inside page content are hidden.

## 2.4
- Locations are now 10 countries: USA, United Kingdom, Canada, Australia, Germany, France,
  Netherlands, Singapore, United Arab Emirates and New Zealand. Each has its own page content
  and Rank Math fields. The 5 city pages (New York, Houston, London, Toronto, Sydney) were removed.
- World map, locations hub and footer show the 10 countries in that order, with full country names.
  City pages left over from older versions are hidden from the map and hub; delete them in Pages.
- Tools, Vyntic setup, step 1 creates the 6 new country pages. Step 4 fills their SEO fields.
- Footer: six link columns in one row, legal links next to the copyright line.

## 2.5
- Main menu: a down arrow shows on items with a submenu (desktop). The mobile menu lists submenus open.
- Footer: GoHighLevel moved from Services to Platforms.
- Privacy policy and Refund policy pages: Tools, Vyntic setup, step 1 creates them as drafts with
  starter text (step 2 with Overwrite replaces WordPress's sample privacy text). Check the text with
  your advisor, then publish. Published pages appear next to the copyright line in the footer.

## 2.6
- Every service, platform, industry, location and hub page, and every blog post, now has at least
  1,100 words of content, with more internal links between services, industries, countries and guides.
- Tools, Vyntic setup: the "Words in editor" column is now "Words on page". Theme pages count the
  content the theme shows; posts and editor pages count the editor.
- Pages update automatically. To update the 15 blog posts, run step 2 with Overwrite ticked
  (this replaces the post text in the editor, so re-apply any manual edits afterwards).

## 2.7
- New cookie panel: Essential (always on), Analytics and Marketing switches, with Accept all,
  Essential only and Save choices. Analytics and Marketing start switched off, as consent rules require.
  Google Consent Mode now updates analytics and ads storage separately from the visitor's choices.

## 2.8
- Inquiries menu in the dashboard: every contact and free audit form entry is saved, with an unread
  count, a New label, a details view, Reply by email and Export CSV.
- Inquiries → Settings: notification emails, which contact form fields to show, budget and timeline
  options, button text, the thank-you message, an optional auto-reply and automatic deletion of old entries.
- The contact form now sends without reloading and shows a thank-you card (the page reloads and shows
  the same card when JavaScript is off).
- FAQ sections in guides, location pages, care plans and blog posts open as accordions.
- Cookie panel on mobile: Accept all on its own row, Essential only and Save choices side by side.

## 2.8.1
- Footer: Sitemap link next to the legal links (Rank Math's sitemap when active, otherwise WordPress's).
- About page team: three people per row, and the account named like the site (e.g. "Vyntic Studio") is hidden.

## 2.8.2
- Desktop submenus widen to fit their longest item, so every item stays on one line.
