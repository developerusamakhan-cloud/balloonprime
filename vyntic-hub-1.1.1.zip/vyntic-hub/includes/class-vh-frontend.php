<?php
/**
 * Public pages: the [vyntic_plugins] grid and each plugin's own page at
 * /plugins/{slug}/ in the style of a WordPress.org plugin page (header with
 * download button, Details / Installation / FAQ / Changelog tabs and a
 * sidebar with versions and requirements), with structured data.
 *
 * Works inside any theme because it only adds to the normal page content.
 * A theme that calls add_theme_support( 'vyntic-hub' ) gets the plugin name
 * as the page H1 inside the header and should not print its own title.
 *
 * @package VynticHub
 */

defined( 'ABSPATH' ) || exit;

class VH_Frontend {

	public static function init() {
		add_shortcode( 'vyntic_plugins', array( __CLASS__, 'shortcode_grid' ) );
		add_filter( 'the_content', array( __CLASS__, 'safe_single_content' ), 20 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 5 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'rank_math/frontend/description', array( __CLASS__, 'seo_description' ) );
		add_filter( 'rank_math/frontend/title', array( __CLASS__, 'seo_title' ) );
		add_filter( 'wpseo_metadesc', array( __CLASS__, 'seo_description' ) );
	}

	public static function assets() {
		wp_register_style( 'vh-front', VH_URL . 'assets/css/front.css', array(), VH_VERSION );
		wp_register_script( 'vh-front', VH_URL . 'assets/js/front.js', array(), VH_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
		if ( is_singular( VH_Plugins::TYPE ) ) {
			wp_enqueue_style( 'vh-front' );
			wp_enqueue_script( 'vh-front' );
		}
	}

	private static function icon_html( $item, $class = 'vh-p-icon', $size = 72 ) {
		if ( ! empty( $item['icon'] ) ) {
			return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $item['icon'] ) . '" alt="' . esc_attr( $item['name'] ) . '" width="' . (int) $size . '" height="' . (int) $size . '" loading="lazy">';
		}
		return '<span class="' . esc_attr( $class ) . ' vh-p-icon-ph" aria-hidden="true"><svg viewBox="0 0 108 108"><polygon points="2,12 30,12 62,96 34,96" fill="#ffffff"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>';
	}

	private static function date( $mysql ) {
		return $mysql ? mysql2date( get_option( 'date_format' ), $mysql ) : '';
	}

	/**
	 * [vyntic_plugins] grid of all published plugins.
	 */
	public static function shortcode_grid( $atts = array() ) {
		wp_enqueue_style( 'vh-front' );
		$items = VH_API::catalog();
		if ( ! $items ) {
			return '<p class="vh-p-empty">' . esc_html__( 'Plugins are coming soon.', 'vyntic-hub' ) . '</p>';
		}
		$download = VH_Settings::get( 'show_download' );
		$html     = '<div class="vh-p-grid">';
		foreach ( $items as $item ) {
			$html .= '<article class="vh-p-card">'
				. '<div class="vh-p-card-head">' . self::icon_html( $item ) . '<div>'
				. '<h3><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a></h3>'
				. '<p class="vh-p-card-by">' . esc_html__( 'By', 'vyntic-hub' ) . ' ' . esc_html( VH_Settings::get( 'brand' ) ) . '</p></div></div>'
				. '<p class="vh-p-card-desc">' . esc_html( $item['short_description'] ) . '</p>'
				. '<ul class="vh-p-card-meta">'
				. '<li><span>' . esc_html__( 'Version', 'vyntic-hub' ) . '</span>' . esc_html( $item['version'] ) . '</li>'
				. '<li><span>' . esc_html__( 'Updated', 'vyntic-hub' ) . '</span>' . esc_html( self::date( $item['updated'] ) ) . '</li>'
				. ( $item['requires'] ? '<li><span>WordPress</span>' . esc_html( $item['requires'] ) . '+</li>' : '' )
				. '</ul>'
				. '<div class="vh-p-card-foot">'
				. ( $download ? '<a class="vh-p-btn" href="' . esc_url( $item['package'] ) . '" rel="nofollow">' . esc_html__( 'Download', 'vyntic-hub' ) . '</a>' : '' )
				. '<a class="vh-p-btn vh-p-btn--ghost" href="' . esc_url( $item['url'] ) . '">' . esc_html__( 'Details', 'vyntic-hub' ) . '</a>'
				. '</div></article>';
		}
		return $html . '</div>';
	}

	/**
	 * Builds the plugin page, but never takes the site down: if anything fails,
	 * visitors get the description with a download button and admins see why.
	 */
	public static function safe_single_content( $content ) {
		try {
			return self::single_content( $content );
		} catch ( \Throwable $e ) {
			$post = get_post();
			$item = null;
			try {
				$item = $post ? VH_Plugins::item( $post ) : null;
			} catch ( \Throwable $ignored ) {
				$item = null;
			}
			$html = '';
			if ( current_user_can( 'manage_options' ) ) {
				$html .= '<div style="margin:0 0 20px;padding:14px 18px;border-radius:12px;background:#fdecea;color:#7a1d17;font-size:14px"><strong>Vyntic Hub (only admins see this):</strong> '
					. esc_html( $e->getMessage() ) . ' <code>' . esc_html( basename( $e->getFile() ) . ':' . $e->getLine() ) . '</code></div>';
			}
			if ( $item && VH_Settings::get( 'show_download' ) ) {
				$html .= '<p><a class="vh-p-btn" href="' . esc_url( $item['package'] ) . '" rel="nofollow">' . esc_html__( 'Download', 'vyntic-hub' ) . ' ' . esc_html( $item['version'] ) . '</a></p>';
			}
			return $html . $content;
		}
	}

	/**
	 * Builds the whole plugin page around the description.
	 */
	public static function single_content( $content ) {
		if ( ! is_singular( VH_Plugins::TYPE ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$post = get_post();
		$item = $post ? VH_Plugins::item( $post ) : null;
		if ( ! $item ) {
			return $content;
		}
		$readme   = VH_Plugins::readme( $post->ID );
		$releases = VH_Plugins::releases( $post->ID );
		$brand    = VH_Settings::get( 'brand' );
		$support  = get_post_meta( $post->ID, '_vh_support', true );
		$support  = $support ? $support : home_url( '/contact/' );

		// Tabs: only the ones that have content.
		$details = '' !== trim( wp_strip_all_tags( $content ) ) ? $content : wp_kses_post( $readme['description'] );
		$tabs    = array( 'details' => array( __( 'Details', 'vyntic-hub' ), $details ) );
		$install = $readme['installation'] ? $readme['installation'] : '<ol><li>' . esc_html__( 'Download the zip file with the button on this page.', 'vyntic-hub' ) . '</li><li>' . esc_html__( 'In WordPress go to Plugins, Add New, Upload Plugin and choose the zip.', 'vyntic-hub' ) . '</li><li>' . esc_html__( 'Activate it. Future updates arrive automatically in your dashboard.', 'vyntic-hub' ) . '</li></ol>';
		$tabs['installation'] = array( __( 'Installation', 'vyntic-hub' ), wp_kses_post( $install ) );
		if ( $readme['faq'] ) {
			$faq = '<div class="vh-faq">';
			foreach ( $readme['faq'] as $i => $f ) {
				$faq .= '<details class="vh-faq-item"' . ( 0 === $i ? ' open' : '' ) . '><summary><h3>' . esc_html( $f['q'] ) . '</h3></summary><div class="vh-faq-a">' . wp_kses_post( $f['a'] ) . '</div></details>';
			}
			$tabs['faq'] = array( __( 'FAQ', 'vyntic-hub' ), $faq . '</div>' );
		}
		$changelog = self::changelog_html( $readme, $releases );
		if ( $changelog ) {
			$tabs['changelog'] = array( __( 'Changelog', 'vyntic-hub' ), $changelog );
		}
		if ( $readme['other'] ) {
			$dev = '';
			foreach ( $readme['other'] as $title => $body ) {
				$dev .= '<h3>' . esc_html( $title ) . '</h3>' . wp_kses_post( $body );
			}
			$tabs['developers'] = array( __( 'Developers', 'vyntic-hub' ), $dev );
		}

		$h1   = current_theme_supports( 'vyntic-hub' ) ? 'h1' : 'p';
		$size = size_format( $item['size'] );
		$head = '<header class="vh-pl-head"' . ( $item['banner'] ? ' style="--vh-banner:url(' . esc_url( $item['banner'] ) . ')"' : '' ) . '><div class="vh-pl-head-in">'
			. self::icon_html( $item, 'vh-pl-icon', 128 )
			. '<div class="vh-pl-title"><' . $h1 . ' class="vh-pl-name">' . esc_html( $item['name'] ) . '</' . $h1 . '>'
			. '<p class="vh-pl-short">' . esc_html( $item['short_description'] ) . '</p>'
			. '<p class="vh-pl-by">' . esc_html__( 'By', 'vyntic-hub' ) . ' <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( $brand ) . '</a></p></div>';
		if ( VH_Settings::get( 'show_download' ) ) {
			$head .= '<div class="vh-pl-cta"><a class="vh-p-btn vh-p-btn--lg" href="' . esc_url( $item['package'] ) . '" rel="nofollow">' . esc_html__( 'Download', 'vyntic-hub' ) . '</a>'
				. '<span>' . esc_html( sprintf( /* translators: 1: version, 2: size */ __( 'Version %1$s · %2$s · Free', 'vyntic-hub' ), $item['version'], $size ) ) . '</span></div>';
		}
		$head .= '</div></header>';

		$nav = '<nav class="vh-pl-tabs" aria-label="' . esc_attr__( 'Plugin information', 'vyntic-hub' ) . '">';
		foreach ( $tabs as $key => $tab ) {
			$nav .= '<a href="#' . esc_attr( $key ) . '" data-vh-tab="' . esc_attr( $key ) . '">' . esc_html( $tab[0] ) . ( 'faq' === $key ? ' <span>' . count( $readme['faq'] ) . '</span>' : '' ) . '</a>';
		}
		$nav .= '</nav>';

		$main = '<div class="vh-pl-main">';
		foreach ( $tabs as $key => $tab ) {
			$main .= '<section class="vh-pl-panel" id="' . esc_attr( $key ) . '" data-vh-panel="' . esc_attr( $key ) . '"><h2>' . esc_html( $tab[0] ) . '</h2>' . $tab[1] . '</section>';
		}
		$main .= '</div>';

		$meta = array(
			__( 'Version', 'vyntic-hub' )          => $item['version'],
			__( 'Last updated', 'vyntic-hub' )     => self::date( $item['updated'] ),
			__( 'WordPress version', 'vyntic-hub' ) => $item['requires'] ? sprintf( /* translators: %s: version */ __( '%s or higher', 'vyntic-hub' ), $item['requires'] ) : '',
			__( 'Tested up to', 'vyntic-hub' )     => $item['tested'],
			__( 'PHP version', 'vyntic-hub' )      => $item['requires_php'] ? sprintf( /* translators: %s: version */ __( '%s or higher', 'vyntic-hub' ), $item['requires_php'] ) : '',
			__( 'File size', 'vyntic-hub' )        => $size,
			__( 'Price', 'vyntic-hub' )            => __( 'Free', 'vyntic-hub' ),
		);
		if ( VH_Settings::get( 'show_installs' ) ) {
			$count = VH_Sites::active_count( $item['slug'] );
			if ( $count ) {
				$meta[ __( 'Active installations', 'vyntic-hub' ) ] = number_format_i18n( $count );
			}
		}
		$side = '<aside class="vh-pl-side"><div class="vh-pl-box"><dl class="vh-pl-meta">';
		foreach ( $meta as $label => $value ) {
			if ( '' !== (string) $value ) {
				$side .= '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd></div>';
			}
		}
		$side .= '</dl>';
		if ( VH_Settings::get( 'show_download' ) ) {
			$side .= '<a class="vh-p-btn vh-p-btn--block" href="' . esc_url( $item['package'] ) . '" rel="nofollow">' . esc_html__( 'Download', 'vyntic-hub' ) . '</a>';
		}
		$side .= '</div>';
		if ( $readme['tags'] ) {
			$side .= '<div class="vh-pl-box"><h3>' . esc_html__( 'Tags', 'vyntic-hub' ) . '</h3><ul class="vh-pl-tags">';
			foreach ( $readme['tags'] as $tag ) {
				$side .= '<li>' . esc_html( $tag ) . '</li>';
			}
			$side .= '</ul></div>';
		}
		$side .= '<div class="vh-pl-box vh-pl-help"><h3>' . esc_html__( 'Automatic updates', 'vyntic-hub' ) . '</h3><p>' . esc_html__( 'New versions appear in Dashboard, Updates like any other plugin, with auto-update support.', 'vyntic-hub' ) . '</p>'
			. '<h3>' . esc_html__( 'Need help?', 'vyntic-hub' ) . '</h3><p>' . esc_html__( 'Questions, a bug or a feature request? Our team answers within one working day.', 'vyntic-hub' ) . '</p>'
			. '<a class="vh-p-btn vh-p-btn--ghost vh-p-btn--block" href="' . esc_url( $support ) . '">' . esc_html__( 'Contact support', 'vyntic-hub' ) . '</a></div></aside>';

		return '<div class="vh-pl">' . $head . $nav . '<div class="vh-pl-layout">' . $main . $side . '</div></div>';
	}

	/**
	 * Every version from the readme, with release dates where the hub has them.
	 */
	private static function changelog_html( array $readme, array $releases ) {
		$html = '';
		if ( $readme['changelog'] ) {
			foreach ( $readme['changelog'] as $version => $body ) {
				$date  = isset( $releases[ $version ] ) ? self::date( $releases[ $version ]['date'] ) : '';
				$html .= '<div class="vh-cl"><h3>' . esc_html( $version ) . ( $date ? ' <span>' . esc_html( $date ) . '</span>' : '' ) . '</h3>' . wp_kses_post( $body ) . '</div>';
			}
			return $html;
		}
		foreach ( array_slice( $releases, 0, 20 ) as $release ) {
			if ( '' === trim( $release['changelog'] ) ) {
				continue;
			}
			$html .= '<div class="vh-cl"><h3>' . esc_html( $release['version'] ) . ' <span>' . esc_html( self::date( $release['date'] ) ) . '</span></h3>' . wpautop( esc_html( $release['changelog'] ) ) . '</div>';
		}
		return $html;
	}

	/**
	 * Structured data: SoftwareApplication and FAQPage. Plus a meta description
	 * when no SEO plugin provides one.
	 */
	public static function head() {
		if ( ! is_singular( VH_Plugins::TYPE ) ) {
			return;
		}
		try {
			self::head_output();
		} catch ( \Throwable $e ) {
			echo "<!-- Vyntic Hub: structured data skipped -->\n";
		}
	}

	private static function head_output() {
		$post = get_queried_object();
		$item = $post instanceof WP_Post ? VH_Plugins::item( $post ) : null;
		if ( ! $item ) {
			return;
		}
		$readme = VH_Plugins::readme( $post->ID );
		$schema = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'SoftwareApplication',
			'name'                => $item['name'],
			'description'         => $item['short_description'],
			'url'                 => $item['url'],
			'applicationCategory' => 'DeveloperApplication',
			'applicationSubCategory' => 'WordPress plugin',
			'operatingSystem'     => 'WordPress',
			'softwareVersion'     => $item['version'],
			'dateModified'        => mysql2date( 'c', $item['updated'] ),
			'downloadUrl'         => $item['package'],
			'fileSize'            => size_format( $item['size'] ),
			'offers'              => array(
				'@type'         => 'Offer',
				'price'         => '0',
				'priceCurrency' => 'USD',
			),
			'author'              => array(
				'@type' => 'Organization',
				'name'  => VH_Settings::get( 'brand' ),
				'url'   => home_url( '/' ),
			),
		);
		if ( $item['requires'] ) {
			$schema['softwareRequirements'] = 'WordPress ' . $item['requires'] . '+' . ( $item['requires_php'] ? ', PHP ' . $item['requires_php'] . '+' : '' );
		}
		if ( $item['icon'] ) {
			$schema['image'] = $item['icon'];
		}
		$graph = array( $schema );
		if ( $readme['faq'] ) {
			$graph[] = array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => array_map(
					static function ( $f ) {
						return array(
							'@type'          => 'Question',
							'name'           => $f['q'],
							'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['text'] ),
						);
					},
					$readme['faq']
				),
			);
		}
		foreach ( $graph as $g ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $g, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
		}

		$has_seo_plugin = defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\\Load' );
		if ( ! $has_seo_plugin && $item['short_description'] ) {
			echo '<meta name="description" content="' . esc_attr( wp_trim_words( $item['short_description'], 30, '' ) ) . '">' . "\n";
		}
	}

	/**
	 * Rank Math / Yoast: use the short description when no description was set.
	 */
	public static function seo_description( $desc ) {
		if ( '' !== trim( (string) $desc ) || ! is_singular( VH_Plugins::TYPE ) ) {
			return $desc;
		}
		$item = VH_Plugins::item( get_queried_object() );
		return $item ? wp_trim_words( $item['short_description'], 28, '' ) : $desc;
	}

	/**
	 * Rank Math: "Name: Free WordPress Plugin | Site" unless a title was set.
	 */
	public static function seo_title( $title ) {
		if ( ! is_singular( VH_Plugins::TYPE ) || get_post_meta( get_queried_object_id(), 'rank_math_title', true ) ) {
			return $title;
		}
		/* translators: 1: plugin name, 2: brand */
		return sprintf( __( '%1$s: Free WordPress Plugin | %2$s', 'vyntic-hub' ), get_the_title( get_queried_object_id() ), VH_Settings::get( 'brand' ) );
	}
}
