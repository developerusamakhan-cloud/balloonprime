<?php
/**
 * Branded HTML emails for the audit report.
 *
 * Built with tables and inline styles so they display the same in Gmail, Outlook and
 * Apple Mail. No hidden text and no external stylesheets, which spam filters penalise.
 * Brand fonts are used when installed on the reader's device, otherwise a clean system font.
 * Every email also gets a plain-text version (see *_text()).
 */

if ( ! defined( 'ABSPATH' ) && PHP_SAPI !== 'cli' ) {
	exit;
}

class VSA_Email {

	const INK     = '#0f2b2e';
	const SOFT    = '#4a6266';
	const MIST    = '#eef3f1';
	const LINE    = '#d5e0dd';
	const ON_DARK = '#d3e2df';
	const PASS    = '#0e9f6a';
	const WARN    = '#c77c00';
	const FAIL    = '#d6322e';

	const HEAD = "'Bricolage Grotesque','Segoe UI',Helvetica,Arial,sans-serif";
	const BODY = "Figtree,'Segoe UI',Helvetica,Arial,sans-serif";

	protected static function e( $s ) {
		return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' );
	}

	protected static function band( $score ) {
		return $score >= 80 ? self::PASS : ( $score >= 55 ? self::WARN : self::FAIL );
	}

	protected static function verdict( $score ) {
		if ( $score >= 90 ) {
			return 'Excellent';
		}
		if ( $score >= 80 ) {
			return 'Good, with room to grow';
		}
		if ( $score >= 70 ) {
			return 'Fair';
		}
		if ( $score >= 55 ) {
			return 'Underperforming';
		}
		return 'Losing you customers';
	}

	/**
	 * Outer layout: grey page, white card, dark header with logo, footer.
	 *
	 * @param string $preheader Hidden preview text shown in the inbox list.
	 * @param string $content   Inner HTML rows.
	 * @param array  $o         brand, accent, logo_url, website, footer.
	 */
	protected static function layout( $preheader, $content, array $o ) {
		$site  = $o['website'] ? preg_replace( '#^https?://#', '', rtrim( $o['website'], '/' ) ) : '';
		$logo  = $o['logo_url']
			? '<img src="' . self::e( $o['logo_url'] ) . '" width="132" alt="' . self::e( $o['brand'] ) . '" style="display:block;width:132px;max-width:132px;height:auto;border:0">'
			: '<span style="font-family:' . self::HEAD . ';font-size:22px;font-weight:800;color:#ffffff">' . self::e( $o['brand'] ) . '</span>';
		return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light only"><title>' . self::e( $o['brand'] ) . '</title>'
			. '<style>body{margin:0;padding:0}a{color:' . self::e( $o['accent'] ) . '}@media (max-width:620px){.vsa-pad{padding-left:22px!important;padding-right:22px!important}.vsa-score{font-size:56px!important}.vsa-stack{display:block!important;width:100%!important}}</style></head>'
			. '<body style="margin:0;padding:0;background:' . self::MIST . '">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . self::MIST . '"><tr><td align="center" style="padding:28px 12px">'
			. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:22px;overflow:hidden;border:1px solid ' . self::LINE . '">'
			// Header.
			. '<tr><td class="vsa-pad" style="background:' . self::INK . ';padding:26px 36px">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
			. '<td style="vertical-align:middle">' . $logo . '</td>'
			. '<td align="right" style="vertical-align:middle;font-family:' . self::BODY . ';font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:' . self::e( $o['accent_soft'] ) . '">Website audit</td>'
			. '</tr></table></td></tr>'
			. '<tr><td style="height:4px;line-height:4px;font-size:0;background:' . self::e( $o['accent'] ) . '">&nbsp;</td></tr>'
			. $content
			// Footer.
			. '<tr><td class="vsa-pad" style="padding:22px 36px 30px;border-top:1px solid ' . self::LINE . ';font-family:' . self::BODY . ';font-size:12px;line-height:1.6;color:' . self::SOFT . '">'
			. '<strong style="color:' . self::INK . '">' . self::e( $o['brand'] ) . '</strong>'
			. ( $site ? ' &middot; <a href="' . self::e( $o['website'] ) . '" style="color:' . self::e( $o['accent'] ) . ';text-decoration:none">' . self::e( $site ) . '</a>' : '' )
			. ( $o['footer'] ? '<br>' . self::e( $o['footer'] ) : '' )
			. '</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/** Pill button that works in Outlook too. */
	protected static function button( $label, $url, $bg, $fg ) {
		return '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td style="border-radius:999px;background:' . self::e( $bg ) . '">'
			. '<a href="' . self::e( $url ) . '" style="display:inline-block;padding:15px 30px;font-family:' . self::BODY . ';font-size:16px;font-weight:700;color:' . self::e( $fg ) . ';text-decoration:none;border-radius:999px">' . self::e( $label ) . ' &rarr;</a>'
			. '</td></tr></table>';
	}

	/**
	 * Email sent to the visitor with their report.
	 *
	 * @param array $data  Audit data { meta, score }.
	 * @param array $o     brand, accent, accent_soft, on_accent, logo_url, website, booking_url, contact_email, links.
	 */
	public static function lead_html( array $data, array $o ) {
		$score = $data['score'];
		$host  = $data['meta']['host'];
		$band  = self::band( $score['overall'] );
		$h     = self::HEAD;
		$b     = self::BODY;
		$rows  = '';

		// Intro and score card.
		$rows .= '<tr><td class="vsa-pad" style="padding:34px 36px 8px">'
			. '<p style="margin:0 0 6px;font-family:' . $b . ';font-size:15px;color:' . self::SOFT . '">Hi there,</p>'
			. '<h1 style="margin:0 0 10px;font-family:' . $h . ';font-size:28px;line-height:1.2;font-weight:800;color:' . self::INK . '">Your audit of ' . self::e( $host ) . ' is ready</h1>'
			. '<p style="margin:0;font-family:' . $b . ';font-size:15px;line-height:1.6;color:' . self::SOFT . '">We checked your homepage for speed, SEO, lead conversion, security and mobile. '
			. ( empty( $o['download_url'] ) ? 'The full report is attached as a PDF.' : 'Download the full PDF report with the button below.' ) . '</p>'
			. ( empty( $o['download_url'] ) ? '' : '<div style="margin-top:18px">' . self::button( 'Download your PDF report', $o['download_url'], $o['accent'], $o['on_accent'] ) . '</div>' )
			. '</td></tr>';

		$counts = '';
		foreach ( array( 'fail' => array( 'critical', self::FAIL ), 'warn' => array( 'need work', self::WARN ), 'pass' => array( 'passed', self::PASS ) ) as $k => $c ) {
			$counts .= '<td style="padding:0 16px 0 0;font-family:' . $b . ';font-size:14px;color:' . self::INK . ';white-space:nowrap">'
				. '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:' . $c[1] . ';margin-right:6px"></span>'
				. '<strong>' . (int) $score['counts'][ $k ] . '</strong> ' . $c[0] . '</td>';
		}
		$rows .= '<tr><td class="vsa-pad" style="padding:22px 36px 6px">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . self::MIST . ';border-radius:18px"><tr><td style="padding:24px 26px">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
			. '<td class="vsa-stack" style="vertical-align:middle;width:150px">'
			. '<span class="vsa-score" style="font-family:' . $h . ';font-size:64px;line-height:1;font-weight:800;color:' . $band . '">' . (int) $score['overall'] . '</span>'
			. '<span style="font-family:' . $b . ';font-size:16px;color:' . self::SOFT . '"> / 100</span></td>'
			. '<td class="vsa-stack" style="vertical-align:middle;padding-top:4px">'
			. '<span style="display:inline-block;padding:5px 12px;border-radius:999px;background:' . $band . ';font-family:' . $b . ';font-size:12px;font-weight:700;letter-spacing:.5px;color:#ffffff">GRADE ' . self::e( $score['grade'] ) . '</span>'
			. '<p style="margin:8px 0 0;font-family:' . $h . ';font-size:20px;font-weight:800;color:' . self::INK . '">' . self::e( self::verdict( $score['overall'] ) ) . '</p>'
			. '</td></tr></table>'
			. '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin-top:16px"><tr>' . $counts . '</tr></table>'
			. '</td></tr></table></td></tr>';

		// Scores by area.
		$bars = '';
		foreach ( $score['categories'] as $cat ) {
			if ( null === $cat['score'] ) {
				continue;
			}
			$w     = max( 3, min( 100, (int) $cat['score'] ) );
			$bars .= '<tr>'
				. '<td style="padding:7px 12px 7px 0;font-family:' . $b . ';font-size:14px;color:' . self::INK . ';white-space:nowrap">' . self::e( $cat['label'] ) . '</td>'
				. '<td width="55%" style="padding:7px 0">'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . self::LINE . ';border-radius:8px"><tr>'
				. '<td width="' . $w . '%" style="height:8px;line-height:8px;font-size:0;background:' . self::band( $cat['score'] ) . ';border-radius:8px">&nbsp;</td>'
				. ( $w < 100 ? '<td style="height:8px;line-height:8px;font-size:0">&nbsp;</td>' : '' )
				. '</tr></table></td>'
				. '<td align="right" style="padding:7px 0 7px 12px;font-family:' . $b . ';font-size:14px;font-weight:700;color:' . self::INK . '">' . (int) $cat['score'] . '</td>'
				. '</tr>';
		}
		if ( $bars ) {
			$rows .= '<tr><td class="vsa-pad" style="padding:24px 36px 4px">'
				. '<h2 style="margin:0 0 8px;font-family:' . $h . ';font-size:19px;font-weight:800;color:' . self::INK . '">Scores by area</h2>'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $bars . '</table>'
				. '</td></tr>';
		}

		// Fix these first.
		$items = '';
		$n     = 1;
		foreach ( array_slice( $score['priorities'], 0, 3 ) as $c ) {
			$col    = 'fail' === $c['status'] ? self::FAIL : self::WARN;
			$items .= '<tr>'
				. '<td style="vertical-align:top;width:40px;padding:0 0 18px">'
				. '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" style="width:28px;height:28px;border-radius:50%;background:' . $col . ';font-family:' . $b . ';font-size:13px;font-weight:700;color:#ffffff">' . $n . '</td></tr></table></td>'
				. '<td style="vertical-align:top;padding:2px 0 18px">'
				. '<p style="margin:0 0 3px;font-family:' . $b . ';font-size:15px;font-weight:700;color:' . self::INK . '">' . self::e( $c['title'] ) . '</p>'
				. '<p style="margin:0;font-family:' . $b . ';font-size:14px;line-height:1.55;color:' . self::SOFT . '">' . self::e( $c['finding'] ) . '</p>'
				. '</td></tr>';
			$n++;
		}
		if ( $items ) {
			$rows .= '<tr><td class="vsa-pad" style="padding:26px 36px 6px">'
				. '<h2 style="margin:0 0 14px;font-family:' . $h . ';font-size:19px;font-weight:800;color:' . self::INK . '">Fix these first</h2>'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $items . '</table>'
				. '</td></tr>';
		}

		// Call to action panel.
		if ( $o['booking_url'] ) {
			$issues = (int) $score['counts']['fail'] + (int) $score['counts']['warn'];
			$rows  .= '<tr><td class="vsa-pad" style="padding:10px 36px 8px">'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . self::INK . ';border-radius:18px"><tr><td style="padding:28px 28px 30px">'
				. '<h2 style="margin:0 0 8px;font-family:' . $h . ';font-size:22px;line-height:1.25;font-weight:800;color:#ffffff">Want these ' . ( $issues ? $issues . ' issues ' : '' ) . 'fixed?</h2>'
				. '<p style="margin:0 0 20px;font-family:' . $b . ';font-size:15px;line-height:1.6;color:' . self::ON_DARK . '">Book a free 15-minute call. We will walk you through the fixes that bring in the most enquiries, with a clear, fixed quote.</p>'
				. self::button( 'Book a free call', $o['booking_url'], $o['accent'], $o['on_accent'] )
				. '<p style="margin:16px 0 0;font-family:' . $b . ';font-size:13px;color:' . self::ON_DARK . '">Or simply reply to this email.</p>'
				. '</td></tr></table></td></tr>';
		}

		// Helpful guides.
		$guides = '';
		foreach ( array_slice( isset( $o['links']['guides'] ) ? $o['links']['guides'] : array(), 0, 3 ) as $g ) {
			$guides .= '<tr><td style="padding:0 0 10px">'
				. '<a href="' . self::e( $g[1] ) . '" style="display:block;padding:14px 16px;border:1px solid ' . self::LINE . ';border-radius:12px;font-family:' . $b . ';font-size:15px;font-weight:700;color:' . self::INK . ';text-decoration:none">'
				. self::e( $g[0] ) . ' <span style="color:' . self::e( $o['accent'] ) . '">&rarr;</span></a></td></tr>';
		}
		if ( $guides ) {
			$rows .= '<tr><td class="vsa-pad" style="padding:22px 36px 18px">'
				. '<h2 style="margin:0 0 12px;font-family:' . $h . ';font-size:19px;font-weight:800;color:' . self::INK . '">Free guides to help you</h2>'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $guides . '</table>'
				. '</td></tr>';
		}

		// Sign-off.
		$rows .= '<tr><td class="vsa-pad" style="padding:6px 36px 28px;font-family:' . $b . ';font-size:15px;line-height:1.6;color:' . self::INK . '">'
			. 'Best wishes,<br><strong>The ' . self::e( $o['brand'] ) . ' team</strong></td></tr>';

		$o['footer'] = 'You are receiving this because you requested a free website audit for ' . $host . '. We do not add you to any mailing list.';
		return self::layout( sprintf( '%s scored %d/100. Here are the fixes that matter most.', $host, $score['overall'] ), $rows, $o );
	}

	/** Notification email for the studio when a new lead arrives. */
	public static function owner_html( $lead, array $data, array $o, $admin_url ) {
		$score = $data['score'];
		$b     = self::BODY;
		$list  = array(
			'Email'       => '<a href="mailto:' . self::e( $lead->email ) . '" style="color:' . self::e( $o['accent'] ) . '">' . self::e( $lead->email ) . '</a>',
			'Website'     => '<a href="' . self::e( $data['meta']['final_url'] ) . '" style="color:' . self::e( $o['accent'] ) . '">' . self::e( $data['meta']['final_url'] ) . '</a>',
			'Score'       => '<strong style="color:' . self::band( $score['overall'] ) . '">' . (int) $score['overall'] . '/100</strong> (grade ' . self::e( $score['grade'] ) . ')',
			'Issues'      => (int) $score['counts']['fail'] . ' critical, ' . (int) $score['counts']['warn'] . ' need work',
			'Technology'  => self::e( implode( ', ', $data['meta']['technologies'] ) ),
			'Top problem' => ! empty( $score['priorities'][0] ) ? self::e( $score['priorities'][0]['title'] ) : '-',
		);
		$rows = '';
		foreach ( $list as $k => $v ) {
			$rows .= '<tr><td style="padding:9px 14px 9px 0;border-bottom:1px solid ' . self::LINE . ';font-family:' . $b . ';font-size:14px;color:' . self::SOFT . ';white-space:nowrap;vertical-align:top">' . $k . '</td>'
				. '<td style="padding:9px 0;border-bottom:1px solid ' . self::LINE . ';font-family:' . $b . ';font-size:14px;color:' . self::INK . '">' . $v . '</td></tr>';
		}
		$content = '<tr><td class="vsa-pad" style="padding:32px 36px 12px">'
			. '<h1 style="margin:0 0 16px;font-family:' . self::HEAD . ';font-size:24px;font-weight:800;color:' . self::INK . '">New audit lead</h1>'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $rows . '</table>'
			. '</td></tr>'
			. '<tr><td class="vsa-pad" style="padding:18px 36px 30px">' . self::button( 'View all audit leads', $admin_url, $o['accent'], $o['on_accent'] ) . '</td></tr>';
		$o['footer'] = 'The report PDF is attached. Reply to this email to reach the lead directly.';
		return self::layout( sprintf( 'New lead: %s scored %d/100', $data['meta']['host'], $score['overall'] ), $content, $o );
	}

	/** Plain-text version of the visitor email (sent alongside the HTML). */
	public static function lead_text( array $data, array $o ) {
		$score = $data['score'];
		$host  = $data['meta']['host'];
		$t     = "Hi there,\n\nYour website audit of {$host} is ready.\n\n";
		$t    .= sprintf( "Score: %d/100 (grade %s, %s)\n%d critical, %d need work, %d passed\n\n", $score['overall'], $score['grade'], strtolower( self::verdict( $score['overall'] ) ), $score['counts']['fail'], $score['counts']['warn'], $score['counts']['pass'] );
		$t    .= empty( $o['download_url'] ) ? "The full report is attached as a PDF.\n\n" : 'Download the full PDF report: ' . $o['download_url'] . "\n\n";
		if ( ! empty( $score['priorities'] ) ) {
			$t .= "Fix these first:\n";
			$n  = 1;
			foreach ( array_slice( $score['priorities'], 0, 3 ) as $c ) {
				$t .= $n++ . '. ' . $c['title'] . ': ' . $c['finding'] . "\n";
			}
			$t .= "\n";
		}
		if ( ! empty( $o['booking_url'] ) ) {
			$t .= 'Book a free call to fix these: ' . $o['booking_url'] . "\nOr simply reply to this email.\n\n";
		}
		foreach ( array_slice( isset( $o['links']['guides'] ) ? $o['links']['guides'] : array(), 0, 3 ) as $g ) {
			$t .= '- ' . $g[0] . ': ' . $g[1] . "\n";
		}
		$t .= "\nBest wishes,\nThe " . $o['brand'] . " team\n" . ( $o['website'] ? $o['website'] . "\n" : '' );
		$t .= "\nYou are receiving this because you requested a free website audit for {$host}.\n";
		return $t;
	}

	/** Plain-text version of the owner notification. */
	public static function owner_text( $lead, array $data, $admin_url ) {
		$score = $data['score'];
		return "New audit lead\n\n"
			. 'Email: ' . $lead->email . "\n"
			. 'Website: ' . $data['meta']['final_url'] . "\n"
			. sprintf( "Score: %d/100 (grade %s)\n", $score['overall'], $score['grade'] )
			. sprintf( "Issues: %d critical, %d need work\n", $score['counts']['fail'], $score['counts']['warn'] )
			. 'Top problem: ' . ( ! empty( $score['priorities'][0] ) ? $score['priorities'][0]['title'] : '-' ) . "\n\n"
			. 'All audit leads: ' . $admin_url . "\n";
	}
}
