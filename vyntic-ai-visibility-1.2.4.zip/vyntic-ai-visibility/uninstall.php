<?php
/**
 * Uninstall: only removes data when the "Delete all data" setting is enabled.
 *
 * @package AIVisibilityTracker
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

wp_clear_scheduled_hook( 'aivt_scheduled_run' );
wp_clear_scheduled_hook( 'aivt_process_queue' );

$aivt_settings = get_option( 'aivt_settings', array() );

if ( ! empty( $aivt_settings['delete_on_uninstall'] ) ) {
	global $wpdb;
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aivt_prompts" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aivt_results" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( array( 'aivt_settings', 'aivt_db_version', 'aivt_queue', 'aivt_last_run', 'aivt_engine_status' ) as $aivt_option ) {
		delete_option( $aivt_option );
	}
	delete_transient( 'aivt_robots_txt' );
}
