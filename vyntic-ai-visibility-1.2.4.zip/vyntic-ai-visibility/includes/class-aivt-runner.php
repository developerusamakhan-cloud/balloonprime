<?php
/**
 * Runs prompt checks: one at a time from the admin, or as a background queue on a schedule.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check runner and WP-Cron scheduling.
 */
class AIVT_Runner {

	const CRON_HOOK  = 'aivt_scheduled_run';
	const QUEUE_HOOK = 'aivt_process_queue';
	const QUEUE_OPT  = 'aivt_queue';

	/**
	 * Jobs handled per background tick (each can take up to a minute).
	 */
	const BATCH = 3;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'start_queue' ) );
		add_action( self::QUEUE_HOOK, array( __CLASS__, 'process_queue' ) );
		add_action( 'update_option_' . AIVT_Settings::OPTION, array( __CLASS__, 'reschedule' ), 10, 0 );
		add_action( 'add_option_' . AIVT_Settings::OPTION, array( __CLASS__, 'reschedule' ), 10, 0 );
	}

	/**
	 * Adds a weekly interval (WordPress only ships hourly / twice daily / daily).
	 *
	 * @param array $schedules Schedules.
	 * @return array
	 */
	public static function cron_schedules( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( 'Once weekly', 'vyntic-ai-visibility' ),
			);
		}
		return $schedules;
	}

	/**
	 * Match the cron event to the schedule setting.
	 */
	public static function reschedule() {
		$schedule = AIVT_Settings::get( 'schedule' );
		$current  = wp_get_schedule( self::CRON_HOOK );

		if ( 'off' === $schedule ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			return;
		}
		if ( $current !== $schedule ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			wp_schedule_event( time() + HOUR_IN_SECONDS, $schedule, self::CRON_HOOK );
		}
	}

	/**
	 * Every active prompt × ready engine.
	 *
	 * @return array[] Each: prompt_id, engine.
	 */
	public static function jobs() {
		$jobs    = array();
		$engines = array_keys( AIVT_Engine::active() );
		foreach ( AIVT_Repository::prompts( true ) as $prompt ) {
			foreach ( $engines as $engine ) {
				$jobs[] = array(
					'prompt_id' => (int) $prompt->id,
					'engine'    => $engine,
				);
			}
		}
		return $jobs;
	}

	/**
	 * Ask one engine one prompt and store the analysed answer.
	 *
	 * @param int    $prompt_id Prompt ID.
	 * @param string $engine_id Engine ID.
	 * @return array|WP_Error Stored row values.
	 */
	public static function run_job( $prompt_id, $engine_id ) {
		$prompt = AIVT_Repository::prompt( $prompt_id );
		$engine = AIVT_Engine::make( $engine_id );
		if ( ! $prompt || ! $engine || ! $engine->is_ready() ) {
			return new WP_Error( 'aivt_job', __( 'Unknown prompt or engine not configured.', 'vyntic-ai-visibility' ) );
		}

		$answer = $engine->ask( $prompt->prompt, true );

		if ( ! is_wp_error( $answer ) || 'aivt_busy' !== $answer->get_error_code() ) {
			AIVT_Engine::set_status( $engine_id, ! is_wp_error( $answer ), is_wp_error( $answer ) ? $answer->get_error_message() : '', is_wp_error( $answer ) ? 0 : count( $answer['citations'] ) );
		}

		if ( is_wp_error( $answer ) ) {
			AIVT_Repository::add_result(
				array(
					'prompt_id' => $prompt->id,
					'engine'    => $engine_id,
					'model'     => $engine->model(),
					'status'    => 'error',
					'error'     => $answer->get_error_message(),
				)
			);
			return $answer;
		}

		$row = array_merge(
			array(
				'prompt_id' => (int) $prompt->id,
				'engine'    => $engine_id,
				'model'     => $answer['model'],
				'status'    => 'ok',
				'response'  => $answer['text'],
				'citations' => $answer['citations'],
			),
			AIVT_Analyzer::analyze( $answer['text'], $answer['citations'] )
		);

		AIVT_Repository::add_result( $row );
		return $row;
	}

	/**
	 * Scheduled run: queue every job and start processing in the background.
	 */
	public static function start_queue() {
		AIVT_Repository::purge( AIVT_Settings::get( 'retention_days' ) );

		$jobs = self::jobs();
		if ( ! $jobs ) {
			return;
		}
		update_option( self::QUEUE_OPT, $jobs, false );
		if ( ! wp_next_scheduled( self::QUEUE_HOOK ) ) {
			wp_schedule_single_event( time(), self::QUEUE_HOOK );
		}
	}

	/**
	 * Background tick: run a small batch, then schedule the next tick.
	 */
	public static function process_queue() {
		$queue = get_option( self::QUEUE_OPT, array() );
		if ( ! is_array( $queue ) || ! $queue ) {
			delete_option( self::QUEUE_OPT );
			return;
		}

		$batch = array_splice( $queue, 0, self::BATCH );
		update_option( self::QUEUE_OPT, $queue, false );

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		foreach ( $batch as $job ) {
			self::run_job( $job['prompt_id'], $job['engine'] );
		}

		if ( $queue ) {
			wp_schedule_single_event( time() + 30, self::QUEUE_HOOK );
		} else {
			delete_option( self::QUEUE_OPT );
			update_option( 'aivt_last_run', time(), false );
		}
	}

	/**
	 * Jobs still waiting in the background queue.
	 *
	 * @return int
	 */
	public static function queued() {
		$queue = get_option( self::QUEUE_OPT, array() );
		return is_array( $queue ) ? count( $queue ) : 0;
	}
}
