<?php
/**
 * Base class for AI answer engines.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * An AI assistant the plugin can ask questions. Only engines with a free API key are included.
 */
abstract class AIVT_Engine {

	/**
	 * Request timeout in seconds (web search answers can be slow).
	 */
	const TIMEOUT = 120;

	/**
	 * Engine ID => class.
	 *
	 * @return array
	 */
	public static function registry() {
		return array(
			'gemini' => 'AIVT_Engine_Gemini',
			'groq'   => 'AIVT_Engine_Groq',
		);
	}

	/**
	 * All engine IDs.
	 *
	 * @return string[]
	 */
	public static function ids() {
		return array_keys( self::registry() );
	}

	/**
	 * Engine instance.
	 *
	 * @param string $id Engine ID.
	 * @return AIVT_Engine|null
	 */
	public static function make( $id ) {
		$registry = self::registry();
		return isset( $registry[ $id ] ) ? new $registry[ $id ]() : null;
	}

	/**
	 * Engines that are enabled and have an API key.
	 *
	 * @return AIVT_Engine[] Keyed by ID.
	 */
	public static function active() {
		$out = array();
		foreach ( self::ids() as $id ) {
			$engine = self::make( $id );
			if ( $engine->is_ready() ) {
				$out[ $id ] = $engine;
			}
		}
		return $out;
	}

	/**
	 * Human label for an engine ID.
	 *
	 * @param string $id Engine ID.
	 * @return string
	 */
	public static function label_for( $id ) {
		// Engines removed in 1.2.0 still label their saved answers.
		$retired = array(
			'openai'     => 'ChatGPT',
			'anthropic'  => 'Claude',
			'perplexity' => 'Perplexity',
		);
		$engine  = self::make( $id );
		if ( $engine ) {
			return $engine->label();
		}
		return isset( $retired[ $id ] ) ? $retired[ $id ] : $id;
	}

	/**
	 * Engine ID.
	 *
	 * @return string
	 */
	abstract public function id();

	/**
	 * Display name, e.g. "Gemini".
	 *
	 * @return string
	 */
	abstract public function label();

	/**
	 * Where to create an API key.
	 *
	 * @return string
	 */
	abstract public function key_url();

	/**
	 * Short note shown under the engine in Settings (free tier limits).
	 *
	 * @return string
	 */
	public function note() {
		return '';
	}

	/**
	 * Whether this engine searches the web before answering.
	 *
	 * @return bool
	 */
	public function searches() {
		return true;
	}

	/**
	 * Ask a question.
	 *
	 * @param string $prompt     Question.
	 * @param bool   $web_search Let the engine search the web (like the consumer app does).
	 * @return array|WP_Error text, citations (url, title, domain), model.
	 */
	abstract public function ask( $prompt, $web_search = true );

	/**
	 * Key and model typed in Settings but not saved yet (used by the connection test).
	 *
	 * @var array
	 */
	protected $override = array();

	/**
	 * Use a key or model other than the saved one.
	 *
	 * @param string $key   API key, '' keeps the saved key.
	 * @param string $model Model, '' keeps the saved model.
	 */
	public function set_override( $key, $model ) {
		$this->override = array_filter(
			array(
				'key'   => (string) $key,
				'model' => (string) $model,
			),
			'strlen'
		);
	}

	/**
	 * API key from settings.
	 *
	 * @return string
	 */
	public function api_key() {
		return isset( $this->override['key'] ) ? $this->override['key'] : (string) AIVT_Settings::get( $this->id() . '_key', '' );
	}

	/**
	 * Model from settings.
	 *
	 * @return string
	 */
	public function model() {
		return isset( $this->override['model'] ) ? $this->override['model'] : (string) AIVT_Settings::get( $this->id() . '_model', '' );
	}

	/**
	 * Result of the last connection test or check, per engine.
	 *
	 * @param string $id Engine ID.
	 * @return array ok, time, message, sources ('' when never tested).
	 */
	public static function status( $id ) {
		$all = get_option( 'aivt_engine_status', array() );
		return isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : array();
	}

	/**
	 * Save the result of a test or check.
	 *
	 * @param string $id      Engine ID.
	 * @param bool   $ok      Worked.
	 * @param string $message Error, or a short note.
	 * @param int    $sources Web sources found.
	 */
	public static function set_status( $id, $ok, $message = '', $sources = 0 ) {
		$all        = get_option( 'aivt_engine_status', array() );
		$all        = is_array( $all ) ? $all : array();
		$all[ $id ] = array(
			'ok'      => (bool) $ok,
			'time'    => time(),
			'message' => wp_strip_all_tags( (string) $message ),
			'sources' => (int) $sources,
		);
		update_option( 'aivt_engine_status', $all, false );
	}

	/**
	 * Enabled and configured.
	 *
	 * @return bool
	 */
	public function is_ready() {
		return AIVT_Settings::get( $this->id() . '_enabled' ) && '' !== $this->api_key();
	}

	/**
	 * POST JSON and decode the reply.
	 *
	 * @param string $url     Endpoint.
	 * @param array  $body    Request body.
	 * @param array  $headers Extra headers.
	 * @return array|WP_Error Decoded JSON.
	 */
	protected function post_json( $url, array $body, array $headers ) {
		// Busy or briefly unavailable servers usually recover within seconds: try up to 3 times.
		$waits = array( 2, 6 );
		for ( $attempt = 0; ; $attempt++ ) {
			$response = wp_remote_post(
				$url,
				array(
					'timeout' => self::TIMEOUT,
					'headers' => array_merge( array( 'Content-Type' => 'application/json' ), $headers ),
					'body'    => wp_json_encode( $body ),
				)
			);
			$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			if ( ! in_array( $code, array( 429, 500, 502, 503, 504 ), true ) || ! isset( $waits[ $attempt ] ) ) {
				break;
			}
			$wait = (int) wp_remote_retrieve_header( $response, 'retry-after' );
			if ( 429 === $code && $wait > 10 ) {
				break; // A long rate limit or a used-up daily quota: retrying now will not help.
			}
			sleep( $wait > 0 ? $wait : $waits[ $attempt ] );
		}

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( in_array( $code, array( 500, 502, 503, 504 ), true ) ) {
			/* translators: 1: engine name, 2: HTTP status */
			return new WP_Error( 'aivt_busy', sprintf( __( '%1$s is busy right now (HTTP %2$d), so the plugin tried 3 times. This is on the provider\'s side, not a problem with your key. Try again in a few minutes; scheduled checks run again on their own.', 'vyntic-ai-visibility' ), $this->label(), $code ) );
		}

		if ( $code < 200 || $code >= 300 ) {
			$message = '';
			if ( is_array( $data ) && isset( $data['error'] ) ) {
				$message = is_array( $data['error'] ) ? ( isset( $data['error']['message'] ) ? $data['error']['message'] : wp_json_encode( $data['error'] ) ) : (string) $data['error'];
			}
			/* translators: 1: engine name, 2: HTTP status, 3: error message */
			return new WP_Error( 'aivt_http', sprintf( __( '%1$s API error (HTTP %2$d): %3$s', 'vyntic-ai-visibility' ), $this->label(), $code, $message ? $message : wp_remote_retrieve_body( $response ) ) );
		}

		if ( ! is_array( $data ) ) {
			/* translators: %s: engine name */
			return new WP_Error( 'aivt_json', sprintf( __( '%s returned an invalid response.', 'vyntic-ai-visibility' ), $this->label() ) );
		}

		return $data;
	}

	/**
	 * Build one citation entry, de-duplicated by URL later.
	 *
	 * @param string $url   URL.
	 * @param string $title Title.
	 * @return array
	 */
	protected function citation( $url, $title = '' ) {
		return array(
			'url'    => esc_url_raw( $url ),
			'title'  => sanitize_text_field( $title ),
			'domain' => AIVT_Settings::host( $url ),
		);
	}

	/**
	 * Remove duplicate / empty citations.
	 *
	 * @param array $citations Citations.
	 * @return array
	 */
	protected function unique_citations( array $citations ) {
		$seen = array();
		$out  = array();
		foreach ( $citations as $c ) {
			if ( empty( $c['url'] ) || isset( $seen[ $c['url'] ] ) ) {
				continue;
			}
			$seen[ $c['url'] ] = true;
			$out[]             = $c;
		}
		return $out;
	}
}
