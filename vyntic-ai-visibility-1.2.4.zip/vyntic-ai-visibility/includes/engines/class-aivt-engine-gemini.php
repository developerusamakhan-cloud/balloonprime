<?php
/**
 * Google Gemini with Google Search grounding.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Gemini engine.
 */
class AIVT_Engine_Gemini extends AIVT_Engine {

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'gemini';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'Gemini';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://aistudio.google.com/app/apikey';
	}

	/**
	 * {@inheritDoc}
	 */
	public function note() {
		return __( 'Free key from Google AI Studio. On the free tier Gemini answers from what it already knows, which shows whether Gemini knows and recommends your business. Answers with Google Search need a paid Gemini API project (it includes 5,000 free searches a month). On the free tier Google may use prompts to improve its products.', 'vyntic-ai-visibility' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function searches() {
		return (bool) AIVT_Settings::get( 'gemini_search' );
	}

	/**
	 * One generateContent call with the current model.
	 *
	 * @param array $body Request body.
	 * @return array|WP_Error
	 */
	private function generate( array $body ) {
		$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $this->model() ) . ':generateContent';
		return $this->post_json( $url, $body, array( 'x-goog-api-key' => $this->api_key() ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$body = array(
			'contents' => array(
				array(
					'role'  => 'user',
					'parts' => array( array( 'text' => $prompt ) ),
				),
			),
		);
		if ( $web_search && $this->searches() ) {
			$body['tools'] = array( array( 'google_search' => new stdClass() ) );
		}

		$data = $this->generate( $body );
		// Google retires models and names the replacement in the error: switch to it once and remember it.
		if ( is_wp_error( $data ) && preg_match( '#no longer available.*?use models/([a-z0-9.\-]+)#is', $data->get_error_message(), $m ) && $m[1] !== $this->model() ) {
			$this->set_override( '', $m[1] );
			$data = $this->generate( $body );
			if ( ! is_wp_error( $data ) ) {
				$settings                 = get_option( AIVT_Settings::OPTION, array() );
				$settings['gemini_model'] = $m[1];
				update_option( AIVT_Settings::OPTION, $settings );
			}
		}
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$candidate = isset( $data['candidates'][0] ) ? $data['candidates'][0] : array();
		$text      = '';
		foreach ( isset( $candidate['content']['parts'] ) ? (array) $candidate['content']['parts'] : array() as $part ) {
			if ( isset( $part['text'] ) ) {
				$text .= $part['text'];
			}
		}

		// Grounding URIs are Google redirect links; the title holds the real domain.
		$citations = array();
		foreach ( isset( $candidate['groundingMetadata']['groundingChunks'] ) ? (array) $candidate['groundingMetadata']['groundingChunks'] : array() as $chunk ) {
			if ( empty( $chunk['web']['uri'] ) ) {
				continue;
			}
			$title    = isset( $chunk['web']['title'] ) ? $chunk['web']['title'] : '';
			$citation = $this->citation( $chunk['web']['uri'], $title );
			if ( preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/i', $title ) ) {
				$citation['domain'] = AIVT_Settings::host( $title );
			}
			$citations[] = $citation;
		}

		return array(
			'searched'  => isset( $body['tools'] ),
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ),
			'model'     => isset( $data['modelVersion'] ) ? $data['modelVersion'] : $this->model(),
		);
	}
}
