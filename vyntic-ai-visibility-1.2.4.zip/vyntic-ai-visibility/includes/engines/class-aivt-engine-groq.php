<?php
/**
 * GPT-OSS on Groq with built-in browser search (free API key, rate limited).
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Groq engine.
 */
class AIVT_Engine_Groq extends AIVT_Engine {

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'groq';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'GPT-OSS (Groq)';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://console.groq.com/keys';
	}

	/**
	 * {@inheritDoc}
	 */
	public function note() {
		return __( 'Free key from GroqCloud. Runs the open GPT-OSS model with built-in browser search. The free tier is rate limited, so a big prompt list may need a second run for prompts that hit the limit.', 'vyntic-ai-visibility' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$body = array(
			'model'    => $this->model(),
			'messages' => array(
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
		);
		if ( $web_search ) {
			$body['tools'] = array( array( 'type' => 'browser_search' ) );
		}

		$data = $this->post_json( 'https://api.groq.com/openai/v1/chat/completions', $body, array( 'Authorization' => 'Bearer ' . $this->api_key() ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$message = isset( $data['choices'][0]['message'] ) ? (array) $data['choices'][0]['message'] : array();
		$text    = isset( $message['content'] ) ? (string) $message['content'] : '';
		// Browser search leaves source markers such as 【3†L12-L18】 in the answer.
		$text = trim( preg_replace( '/[ \t]*【[^】]*】/u', '', $text ) );

		$citations = array();
		foreach ( isset( $message['executed_tools'] ) ? (array) $message['executed_tools'] : array() as $tool ) {
			$results = isset( $tool['search_results'] ) ? $tool['search_results'] : array();
			if ( isset( $results['results'] ) ) {
				$results = $results['results'];
			}
			foreach ( (array) $results as $result ) {
				if ( ! empty( $result['url'] ) ) {
					$citations[] = $this->citation( $result['url'], isset( $result['title'] ) ? $result['title'] : '' );
				}
			}
		}

		// Links written in the answer itself count as citations too.
		if ( preg_match_all( '#\[([^\]]*)\]\((https?://[^)\s]+)\)|(?<![\w/])(https?://[^\s<>()\]"\']+)#', $text, $links, PREG_SET_ORDER ) ) {
			foreach ( $links as $link ) {
				$url         = ! empty( $link[2] ) ? $link[2] : rtrim( $link[3], '.,;:' );
				$citations[] = $this->citation( $url, isset( $link[1] ) ? $link[1] : '' );
			}
		}

		return array(
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ),
			'model'     => isset( $data['model'] ) ? $data['model'] : $this->model(),
		);
	}
}
