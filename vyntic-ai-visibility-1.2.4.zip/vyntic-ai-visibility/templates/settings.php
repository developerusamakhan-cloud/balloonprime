<?php
/**
 * Settings view.
 *
 * @package AIVisibilityTracker
 *
 * @var array $s Settings.
 */

defined( 'ABSPATH' ) || exit;

$aivt_opt = AIVT_Settings::OPTION;
?>
<div class="wrap aivt-wrap">
	<div class="aivt-header">
		<div>
			<h1><?php esc_html_e( 'AI Visibility Settings', 'vyntic-ai-visibility' ); ?></h1>
			<p class="aivt-muted"><?php esc_html_e( 'Tell the plugin who you are, connect a free AI engine and choose how often to check.', 'vyntic-ai-visibility' ); ?></p>
		</div>
	</div>
	<?php settings_errors(); ?>

	<form method="post" action="options.php" class="aivt-settings">
		<?php settings_fields( 'aivt_settings_group' ); ?>

		<section class="aivt-card">
			<div class="aivt-card-intro">
				<h2><span class="aivt-step">1</span><?php esc_html_e( 'Your brand', 'vyntic-ai-visibility' ); ?></h2>
				<p class="aivt-muted"><?php esc_html_e( 'Used to spot your business, your website and your competitors in AI answers.', 'vyntic-ai-visibility' ); ?></p>
			</div>
			<div class="aivt-fields aivt-fields--3">
				<div class="aivt-field">
					<label for="aivt-brand-name"><?php esc_html_e( 'Brand name', 'vyntic-ai-visibility' ); ?></label>
					<input type="text" id="aivt-brand-name" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_name]" value="<?php echo esc_attr( $s['brand_name'] ); ?>" required>
				</div>
				<div class="aivt-field">
					<label for="aivt-aliases"><?php esc_html_e( 'Other names', 'vyntic-ai-visibility' ); ?></label>
					<input type="text" id="aivt-aliases" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_aliases]" value="<?php echo esc_attr( $s['brand_aliases'] ); ?>">
					<p class="aivt-help"><?php esc_html_e( 'Other spellings, comma separated.', 'vyntic-ai-visibility' ); ?></p>
				</div>
				<div class="aivt-field">
					<label for="aivt-domain"><?php esc_html_e( 'Website domain', 'vyntic-ai-visibility' ); ?></label>
					<input type="text" id="aivt-domain" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_domain]" value="<?php echo esc_attr( $s['brand_domain'] ); ?>" placeholder="example.com">
					<p class="aivt-help"><?php esc_html_e( 'Shows when AI links to your site.', 'vyntic-ai-visibility' ); ?></p>
				</div>
			</div>
			<div class="aivt-fields aivt-fields--2">
				<div class="aivt-field">
					<label for="aivt-desc"><?php esc_html_e( 'What you do', 'vyntic-ai-visibility' ); ?></label>
					<textarea id="aivt-desc" rows="4" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_description]"><?php echo esc_textarea( $s['brand_description'] ); ?></textarea>
					<p class="aivt-help"><?php esc_html_e( 'One or two sentences: services, location, audience. Used for prompt ideas and llms.txt.', 'vyntic-ai-visibility' ); ?></p>
				</div>
				<div class="aivt-field">
					<label for="aivt-competitors"><?php esc_html_e( 'Competitors', 'vyntic-ai-visibility' ); ?></label>
					<textarea id="aivt-competitors" class="code" rows="4" name="<?php echo esc_attr( $aivt_opt ); ?>[competitors]" placeholder="Competitor One | competitorone.com&#10;Competitor Two | competitortwo.com"><?php echo esc_textarea( $s['competitors'] ); ?></textarea>
					<p class="aivt-help"><?php esc_html_e( 'One per line: Name | domain.com (domain optional).', 'vyntic-ai-visibility' ); ?></p>
				</div>
			</div>
		</section>

		<section class="aivt-card" id="aivt-engines">
			<div class="aivt-card-intro">
				<h2><span class="aivt-step">2</span><?php esc_html_e( 'AI engines', 'vyntic-ai-visibility' ); ?></h2>
				<p class="aivt-muted"><?php esc_html_e( 'Both use free API keys. Turn on one or both, paste the key and click Test connection.', 'vyntic-ai-visibility' ); ?></p>
			</div>
			<div class="aivt-engines">
				<?php foreach ( AIVT_Engine::ids() as $aivt_id ) : ?>
					<?php
					$aivt_engine = AIVT_Engine::make( $aivt_id );
					$aivt_key    = $s[ $aivt_id . '_key' ];
					?>
					<div class="aivt-engine-card" data-engine="<?php echo esc_attr( $aivt_id ); ?>">
						<div class="aivt-engine-head">
							<span class="aivt-engine is-<?php echo esc_attr( $aivt_id ); ?>"><?php echo esc_html( $aivt_engine->label() ); ?></span>
							<label class="aivt-switch">
								<input type="checkbox" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_enabled]' ); ?>" value="1" <?php checked( $s[ $aivt_id . '_enabled' ] ); ?>>
								<span><em class="is-off"><?php esc_html_e( 'Off', 'vyntic-ai-visibility' ); ?></em><em class="is-on"><?php esc_html_e( 'On', 'vyntic-ai-visibility' ); ?></em></span>
							</label>
						</div>

						<div class="aivt-field">
							<label for="aivt-key-<?php echo esc_attr( $aivt_id ); ?>">
								<?php esc_html_e( 'API key', 'vyntic-ai-visibility' ); ?>
								<a href="<?php echo esc_url( $aivt_engine->key_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get a free key', 'vyntic-ai-visibility' ); ?> &#8599;</a>
							</label>
							<?php if ( $aivt_key ) : ?>
								<div class="aivt-keybox">
									<span class="aivt-keybox-icon" aria-hidden="true"><span class="dashicons dashicons-lock"></span></span>
									<span class="aivt-keybox-text">
										<strong class="aivt-keybox-saved"><?php esc_html_e( 'Key saved', 'vyntic-ai-visibility' ); ?></strong>
										<strong class="aivt-keybox-removing"><?php esc_html_e( 'Key will be removed when you save', 'vyntic-ai-visibility' ); ?></strong>
										<code>&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;<?php echo esc_html( substr( $aivt_key, -4 ) ); ?></code>
									</span>
									<span class="aivt-keybox-actions">
										<button type="button" class="button aivt-key-change"><?php esc_html_e( 'Change', 'vyntic-ai-visibility' ); ?></button>
										<label class="button aivt-key-remove"><input type="checkbox" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_clear_key]' ); ?>" value="1"><span class="aivt-key-remove-on"><?php esc_html_e( 'Remove', 'vyntic-ai-visibility' ); ?></span><span class="aivt-key-remove-off"><?php esc_html_e( 'Keep', 'vyntic-ai-visibility' ); ?></span></label>
									</span>
								</div>
							<?php endif; ?>
							<input type="password" id="aivt-key-<?php echo esc_attr( $aivt_id ); ?>" class="aivt-key" autocomplete="new-password" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_key]' ); ?>" value="" placeholder="<?php echo $aivt_key ? esc_attr__( 'Paste a new key to replace the saved one', 'vyntic-ai-visibility' ) : esc_attr__( 'Paste your API key', 'vyntic-ai-visibility' ); ?>" <?php echo $aivt_key ? 'hidden' : ''; ?>>
						</div>

						<div class="aivt-field">
							<label for="aivt-model-<?php echo esc_attr( $aivt_id ); ?>"><?php esc_html_e( 'Model', 'vyntic-ai-visibility' ); ?></label>
							<input type="text" id="aivt-model-<?php echo esc_attr( $aivt_id ); ?>" class="aivt-model code" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_model]' ); ?>" value="<?php echo esc_attr( $s[ $aivt_id . '_model' ] ); ?>">
						</div>

						<?php if ( 'gemini' === $aivt_id ) : ?>
							<label class="aivt-check"><input type="checkbox" name="<?php echo esc_attr( $aivt_opt . '[gemini_search]' ); ?>" value="1" <?php checked( $s['gemini_search'] ); ?>> <?php esc_html_e( 'Answer with Google Search (paid Gemini API project only)', 'vyntic-ai-visibility' ); ?></label>
						<?php endif; ?>

						<?php if ( $aivt_engine->note() ) : ?>
							<p class="aivt-help"><?php echo esc_html( $aivt_engine->note() ); ?></p>
						<?php endif; ?>

						<div class="aivt-engine-foot">
							<button type="button" class="button aivt-test-engine" data-engine="<?php echo esc_attr( $aivt_id ); ?>"><?php esc_html_e( 'Test connection', 'vyntic-ai-visibility' ); ?></button>
							<?php echo AIVT_Admin::status_badge( $aivt_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						</div>
						<div class="aivt-test-result" hidden></div>
					</div>
				<?php endforeach; ?>
			</div>
			<p class="aivt-help"><?php esc_html_e( 'Leave a key field empty to keep the saved key. Keys are stored only in your WordPress database and sent only to that AI provider.', 'vyntic-ai-visibility' ); ?></p>
		</section>

		<div class="aivt-grid-2">
			<section class="aivt-card">
				<div class="aivt-card-intro">
					<h2><span class="aivt-step">3</span><?php esc_html_e( 'Automatic checks', 'vyntic-ai-visibility' ); ?></h2>
					<p class="aivt-muted"><?php esc_html_e( 'Requests per run = prompts × engines turned on. Weekly stays well inside the free limits.', 'vyntic-ai-visibility' ); ?></p>
				</div>
				<div class="aivt-fields aivt-fields--2">
					<div class="aivt-field">
						<label for="aivt-schedule"><?php esc_html_e( 'Run checks', 'vyntic-ai-visibility' ); ?></label>
						<select id="aivt-schedule" name="<?php echo esc_attr( $aivt_opt ); ?>[schedule]">
							<option value="weekly" <?php selected( $s['schedule'], 'weekly' ); ?>><?php esc_html_e( 'Weekly (recommended)', 'vyntic-ai-visibility' ); ?></option>
							<option value="daily" <?php selected( $s['schedule'], 'daily' ); ?>><?php esc_html_e( 'Daily', 'vyntic-ai-visibility' ); ?></option>
							<option value="off" <?php selected( $s['schedule'], 'off' ); ?>><?php esc_html_e( 'Manually only', 'vyntic-ai-visibility' ); ?></option>
						</select>
					</div>
					<div class="aivt-field">
						<label for="aivt-retention"><?php esc_html_e( 'Keep history for (days)', 'vyntic-ai-visibility' ); ?></label>
						<input type="number" id="aivt-retention" min="7" max="3650" name="<?php echo esc_attr( $aivt_opt ); ?>[retention_days]" value="<?php echo (int) $s['retention_days']; ?>">
					</div>
				</div>
			</section>

			<section class="aivt-card" id="aivt-llms">
				<div class="aivt-card-intro">
					<h2><span class="aivt-step">4</span>llms.txt</h2>
					<p class="aivt-muted"><?php esc_html_e( 'A short summary of your site that AI tools can read.', 'vyntic-ai-visibility' ); ?></p>
				</div>
				<label class="aivt-check"><input type="checkbox" name="<?php echo esc_attr( $aivt_opt ); ?>[llms_txt_enabled]" value="1" <?php checked( $s['llms_txt_enabled'] ); ?>> <?php esc_html_e( 'Serve /llms.txt, built from your pages, products and posts', 'vyntic-ai-visibility' ); ?></label>
				<div class="aivt-field">
					<label for="aivt-llms-intro"><?php esc_html_e( 'Extra information (optional)', 'vyntic-ai-visibility' ); ?></label>
					<textarea id="aivt-llms-intro" rows="3" name="<?php echo esc_attr( $aivt_opt ); ?>[llms_txt_intro]" placeholder="<?php esc_attr_e( 'Key facts, service areas, contact details', 'vyntic-ai-visibility' ); ?>"><?php echo esc_textarea( $s['llms_txt_intro'] ); ?></textarea>
				</div>
			</section>
		</div>

		<div class="aivt-savebar">
			<label class="aivt-check aivt-help"><input type="checkbox" name="<?php echo esc_attr( $aivt_opt ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'] ); ?>> <?php esc_html_e( 'Delete all prompts, results and settings when the plugin is deleted', 'vyntic-ai-visibility' ); ?></label>
			<?php submit_button( __( 'Save settings', 'vyntic-ai-visibility' ), 'primary', 'submit', false ); ?>
		</div>
	</form>
</div>
