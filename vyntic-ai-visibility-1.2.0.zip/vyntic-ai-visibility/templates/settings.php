<?php
/**
 * Settings view.
 *
 * @package AIVisibilityTracker
 *
 * @var array $s Settings.
 */

defined( 'ABSPATH' ) || exit;

$aivt_opt = AIVT_Settings::OPTION;
?>
<div class="wrap aivt-wrap">
	<h1><?php esc_html_e( 'AI Visibility Settings', 'vyntic-ai-visibility' ); ?></h1>
	<?php settings_errors(); ?>

	<form method="post" action="options.php">
		<?php settings_fields( 'aivt_settings_group' ); ?>

		<div class="aivt-card">
			<h2><?php esc_html_e( 'Your brand', 'vyntic-ai-visibility' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="aivt-brand-name"><?php esc_html_e( 'Brand name', 'vyntic-ai-visibility' ); ?></label></th>
					<td><input type="text" id="aivt-brand-name" class="regular-text" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_name]" value="<?php echo esc_attr( $s['brand_name'] ); ?>" required></td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-aliases"><?php esc_html_e( 'Other names', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<input type="text" id="aivt-aliases" class="regular-text" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_aliases]" value="<?php echo esc_attr( $s['brand_aliases'] ); ?>">
						<p class="description"><?php esc_html_e( 'Comma separated spellings, abbreviations or product names that also count as a mention.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-domain"><?php esc_html_e( 'Website domain', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<input type="text" id="aivt-domain" class="regular-text" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_domain]" value="<?php echo esc_attr( $s['brand_domain'] ); ?>" placeholder="example.com">
						<p class="description"><?php esc_html_e( 'Used to detect when AI cites (links to) your website.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-desc"><?php esc_html_e( 'What you do', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<textarea id="aivt-desc" class="large-text" rows="3" name="<?php echo esc_attr( $aivt_opt ); ?>[brand_description]"><?php echo esc_textarea( $s['brand_description'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One or two sentences: products/services, location, audience. Used for prompt suggestions and llms.txt.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-competitors"><?php esc_html_e( 'Competitors', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<textarea id="aivt-competitors" class="large-text code" rows="5" name="<?php echo esc_attr( $aivt_opt ); ?>[competitors]" placeholder="Competitor One | competitorone.com&#10;Competitor Two | competitortwo.com"><?php echo esc_textarea( $s['competitors'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line: Name | domain.com (domain optional). Used for share of voice and position.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="aivt-card" id="aivt-engines">
			<h2><?php esc_html_e( 'AI engines', 'vyntic-ai-visibility' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Both engines work with free API keys, so tracking costs nothing within their free limits. The plugin calls the AI providers directly from your server, and each engine searches the web before it answers, so you see the kind of answers your customers see. Use one engine or both.', 'vyntic-ai-visibility' ); ?></p>
			<table class="form-table" role="presentation">
				<?php foreach ( AIVT_Engine::ids() as $aivt_id ) : ?>
					<?php
					$aivt_engine = AIVT_Engine::make( $aivt_id );
					$aivt_key    = $s[ $aivt_id . '_key' ];
					?>
					<tr>
						<th scope="row"><?php echo esc_html( $aivt_engine->label() ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_enabled]' ); ?>" value="1" <?php checked( $s[ $aivt_id . '_enabled' ] ); ?>> <?php esc_html_e( 'Enabled', 'vyntic-ai-visibility' ); ?></label>
							<p>
								<input type="password" class="regular-text" autocomplete="new-password" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_key]' ); ?>" value="" placeholder="<?php echo $aivt_key ? esc_attr( '••••••••' . substr( $aivt_key, -4 ) ) : esc_attr__( 'API key', 'vyntic-ai-visibility' ); ?>">
								<a href="<?php echo esc_url( $aivt_engine->key_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get a free key', 'vyntic-ai-visibility' ); ?></a>
								<?php if ( $aivt_key ) : ?>
									<label class="aivt-clear-key"><input type="checkbox" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_clear_key]' ); ?>" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-ai-visibility' ); ?></label>
								<?php endif; ?>
							</p>
							<?php if ( $aivt_engine->note() ) : ?>
								<p class="description"><?php echo esc_html( $aivt_engine->note() ); ?></p>
							<?php endif; ?>
							<p>
								<label><?php esc_html_e( 'Model', 'vyntic-ai-visibility' ); ?>
									<input type="text" class="regular-text code" name="<?php echo esc_attr( $aivt_opt . '[' . $aivt_id . '_model]' ); ?>" value="<?php echo esc_attr( $s[ $aivt_id . '_model' ] ); ?>">
								</label>
							</p>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p class="description"><?php esc_html_e( 'Leave a key field empty to keep the saved key. Keys are stored in your WordPress database.', 'vyntic-ai-visibility' ); ?></p>
		</div>

		<div class="aivt-card">
			<h2><?php esc_html_e( 'Automatic checks', 'vyntic-ai-visibility' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="aivt-schedule"><?php esc_html_e( 'Run checks', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<select id="aivt-schedule" name="<?php echo esc_attr( $aivt_opt ); ?>[schedule]">
							<option value="weekly" <?php selected( $s['schedule'], 'weekly' ); ?>><?php esc_html_e( 'Weekly (recommended)', 'vyntic-ai-visibility' ); ?></option>
							<option value="daily" <?php selected( $s['schedule'], 'daily' ); ?>><?php esc_html_e( 'Daily', 'vyntic-ai-visibility' ); ?></option>
							<option value="off" <?php selected( $s['schedule'], 'off' ); ?>><?php esc_html_e( 'Manually only', 'vyntic-ai-visibility' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Runs in the background with WP-Cron. Requests per run = prompts × enabled engines. Weekly keeps you well inside the free limits.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-retention"><?php esc_html_e( 'Keep history for', 'vyntic-ai-visibility' ); ?></label></th>
					<td><input type="number" id="aivt-retention" min="7" max="3650" class="small-text" name="<?php echo esc_attr( $aivt_opt ); ?>[retention_days]" value="<?php echo (int) $s['retention_days']; ?>"> <?php esc_html_e( 'days', 'vyntic-ai-visibility' ); ?></td>
				</tr>
			</table>
		</div>

		<div class="aivt-card" id="aivt-llms">
			<h2>llms.txt</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Serve /llms.txt', 'vyntic-ai-visibility' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $aivt_opt ); ?>[llms_txt_enabled]" value="1" <?php checked( $s['llms_txt_enabled'] ); ?>> <?php esc_html_e( 'Generate llms.txt automatically from your pages, products and posts', 'vyntic-ai-visibility' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><label for="aivt-llms-intro"><?php esc_html_e( 'Extra information', 'vyntic-ai-visibility' ); ?></label></th>
					<td>
						<textarea id="aivt-llms-intro" class="large-text" rows="4" name="<?php echo esc_attr( $aivt_opt ); ?>[llms_txt_intro]"><?php echo esc_textarea( $s['llms_txt_intro'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Optional paragraph added under the summary: key facts, service areas, contact details.', 'vyntic-ai-visibility' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="aivt-card">
			<h2><?php esc_html_e( 'Data', 'vyntic-ai-visibility' ); ?></h2>
			<label><input type="checkbox" name="<?php echo esc_attr( $aivt_opt ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'] ); ?>> <?php esc_html_e( 'Delete all prompts, results and settings when the plugin is deleted', 'vyntic-ai-visibility' ); ?></label>
		</div>

		<?php submit_button(); ?>
	</form>
</div>
