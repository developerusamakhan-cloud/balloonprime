<?php
/**
 * Base class for AI answer engines.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * An AI assistant the plugin can ask questions. Only engines with a free API key are included.
 */
abstract class AIVT_Engine {

	/**
	 * Request timeout in seconds (web search answers can be slow).
	 */
	const TIMEOUT = 120;

	/**
	 * Engine ID => class.
	 *
	 * @return array
	 */
	public static function registry() {
		return array(
			'gemini' => 'AIVT_Engine_Gemini',
			'groq'   => 'AIVT_Engine_Groq',
		);
	}

	/**
	 * All engine IDs.
	 *
	 * @return string[]
	 */
	public static function ids() {
		return array_keys( self::registry() );
	}

	/**
	 * Engine instance.
	 *
	 * @param string $id Engine ID.
	 * @return AIVT_Engine|null
	 */
	public static function make( $id ) {
		$registry = self::registry();
		return isset( $registry[ $id ] ) ? new $registry[ $id ]() : null;
	}

	/**
	 * Engines that are enabled and have an API key.
	 *
	 * @return AIVT_Engine[] Keyed by ID.
	 */
	public static function active() {
		$out = array();
		foreach ( self::ids() as $id ) {
			$engine = self::make( $id );
			if ( $engine->is_ready() ) {
				$out[ $id ] = $engine;
			}
		}
		return $out;
	}

	/**
	 * Human label for an engine ID.
	 *
	 * @param string $id Engine ID.
	 * @return string
	 */
	public static function label_for( $id ) {
		// Engines removed in 1.2.0 still label their saved answers.
		$retired = array(
			'openai'     => 'ChatGPT',
			'anthropic'  => 'Claude',
			'perplexity' => 'Perplexity',
		);
		$engine  = self::make( $id );
		if ( $engine ) {
			return $engine->label();
		}
		return isset( $retired[ $id ] ) ? $retired[ $id ] : $id;
	}

	/**
	 * Engine ID.
	 *
	 * @return string
	 */
	abstract public function id();

	/**
	 * Display name, e.g. "Gemini".
	 *
	 * @return string
	 */
	abstract public function label();

	/**
	 * Where to create an API key.
	 *
	 * @return string
	 */
	abstract public function key_url();

	/**
	 * Short note shown under the engine in Settings (free tier limits).
	 *
	 * @return string
	 */
	public function note() {
		return '';
	}

	/**
	 * Ask a question.
	 *
	 * @param string $prompt     Question.
	 * @param bool   $web_search Let the engine search the web (like the consumer app does).
	 * @return array|WP_Error text, citations (url, title, domain), model.
	 */
	abstract public function ask( $prompt, $web_search = true );

	/**
	 * API key from settings.
	 *
	 * @return string
	 */
	public function api_key() {
		return (string) AIVT_Settings::get( $this->id() . '_key', '' );
	}

	/**
	 * Model from settings.
	 *
	 * @return string
	 */
	public function model() {
		return (string) AIVT_Settings::get( $this->id() . '_model', '' );
	}

	/**
	 * Enabled and configured.
	 *
	 * @return bool
	 */
	public function is_ready() {
		return AIVT_Settings::get( $this->id() . '_enabled' ) && '' !== $this->api_key();
	}

	/**
	 * POST JSON and decode the reply.
	 *
	 * @param string $url     Endpoint.
	 * @param array  $body    Request body.
	 * @param array  $headers Extra headers.
	 * @return array|WP_Error Decoded JSON.
	 */
	protected function post_json( $url, array $body, array $headers ) {
		$response = wp_remote_post(
			$url,
			array(
				'timeout' => self::TIMEOUT,
				'headers' => array_merge( array( 'Content-Type' => 'application/json' ), $headers ),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = '';
			if ( is_array( $data ) && isset( $data['error'] ) ) {
				$message = is_array( $data['error'] ) ? ( isset( $data['error']['message'] ) ? $data['error']['message'] : wp_json_encode( $data['error'] ) ) : (string) $data['error'];
			}
			/* translators: 1: engine name, 2: HTTP status, 3: error message */
			return new WP_Error( 'aivt_http', sprintf( __( '%1$s API error (HTTP %2$d): %3$s', 'vyntic-ai-visibility' ), $this->label(), $code, $message ? $message : wp_remote_retrieve_body( $response ) ) );
		}

		if ( ! is_array( $data ) ) {
			/* translators: %s: engine name */
			return new WP_Error( 'aivt_json', sprintf( __( '%s returned an invalid response.', 'vyntic-ai-visibility' ), $this->label() ) );
		}

		return $data;
	}

	/**
	 * Build one citation entry, de-duplicated by URL later.
	 *
	 * @param string $url   URL.
	 * @param string $title Title.
	 * @return array
	 */
	protected function citation( $url, $title = '' ) {
		return array(
			'url'    => esc_url_raw( $url ),
			'title'  => sanitize_text_field( $title ),
			'domain' => AIVT_Settings::host( $url ),
		);
	}

	/**
	 * Remove duplicate / empty citations.
	 *
	 * @param array $citations Citations.
	 * @return array
	 */
	protected function unique_citations( array $citations ) {
		$seen = array();
		$out  = array();
		foreach ( $citations as $c ) {
			if ( empty( $c['url'] ) || isset( $seen[ $c['url'] ] ) ) {
				continue;
			}
			$seen[ $c['url'] ] = true;
			$out[]             = $c;
		}
		return $out;
	}
}
