<?php
/**
 * Plugin Name:       Vyntic AI Visibility
 * Plugin URI:        https://vyntic.studio/plugins/vyntic-ai-visibility/
 * Description:       See how often AI assistants mention and cite your business. Tracks brand mentions, citations, sentiment and competitor share of voice, checks AI crawlers in robots.txt and builds an llms.txt file. Free, with free Gemini and Groq API keys.
 * Version:           1.2.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vyntic Studio
 * Author URI:        https://vyntic.studio/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vyntic-ai-visibility
 * Domain Path:       /languages
 *
 * @package VynticAIVisibility
 */

defined( 'ABSPATH' ) || exit;

// The older "AI Visibility Tracker" uses the same code. Running both would clash, so stop here until it is deactivated.
if ( class_exists( 'AIVT_Admin' ) ) {
	add_action(
		'admin_notices',
		static function () {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Vyntic AI Visibility replaces "AI Visibility Tracker". Deactivate and delete the old plugin; your prompts, results and settings carry over.', 'vyntic-ai-visibility' ) . '</p></div>';
		}
	);
	return;
}

define( 'AIVT_VERSION', '1.2.0' );
define( 'AIVT_DB_VERSION', '1.0.0' );
define( 'AIVT_FILE', __FILE__ );
define( 'AIVT_PATH', plugin_dir_path( __FILE__ ) );
define( 'AIVT_URL', plugin_dir_url( __FILE__ ) );

// Shared Vyntic menu + automatic updates from the Vyntic Hub (vyntic.studio).
require_once AIVT_PATH . 'vendor/vyntic-client/loader.php';
vyntic_client_register(
	array(
		'file' => __FILE__,
		'slug' => 'vyntic-ai-visibility',
		'name' => 'Vyntic AI Visibility',
		'page' => 'vyntic-ai-visibility',
		// Menu icon when this is the only Vyntic plugin: an eye with a spark.
		'icon' => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M10 4C5.5 4 2.1 7 1 10c1.1 3 4.5 6 9 6s7.9-3 9-6c-1.1-3-4.5-6-9-6zm0 10a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/><path fill="#a7aaad" d="M10 7.6l.7 1.7 1.7.7-1.7.7-.7 1.7-.7-1.7-1.7-.7 1.7-.7z"/></svg>' ), // phpcs:ignore
	)
);

require_once AIVT_PATH . 'includes/class-aivt-settings.php';
require_once AIVT_PATH . 'includes/class-aivt-install.php';
require_once AIVT_PATH . 'includes/class-aivt-repository.php';
require_once AIVT_PATH . 'includes/engines/class-aivt-engine.php';
require_once AIVT_PATH . 'includes/engines/class-aivt-engine-gemini.php';
require_once AIVT_PATH . 'includes/engines/class-aivt-engine-groq.php';
require_once AIVT_PATH . 'includes/class-aivt-analyzer.php';
require_once AIVT_PATH . 'includes/class-aivt-runner.php';
require_once AIVT_PATH . 'includes/class-aivt-stats.php';
require_once AIVT_PATH . 'includes/class-aivt-crawlers.php';
require_once AIVT_PATH . 'includes/class-aivt-llms-txt.php';
require_once AIVT_PATH . 'includes/class-aivt-admin.php';

register_activation_hook( __FILE__, array( 'AIVT_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AIVT_Install', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'vyntic-ai-visibility', false, dirname( plugin_basename( AIVT_FILE ) ) . '/languages' );

		AIVT_Install::maybe_upgrade();
		AIVT_Runner::init();
		AIVT_Llms_Txt::init();

		if ( is_admin() ) {
			AIVT_Admin::init();
		}
	}
);
