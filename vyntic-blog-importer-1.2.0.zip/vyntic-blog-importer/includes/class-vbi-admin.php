<?php
/**
 * Posts → Import blog file screen.
 *
 * @package Vyntic_Blog_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VBI_Admin {

	const SLUG = 'vbi-import';
	const CAP  = 'manage_options';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_vbi_upload', array( __CLASS__, 'handle_upload' ) );
		add_action( 'admin_post_vbi_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_vbi_undo', array( __CLASS__, 'handle_undo' ) );
		add_action( 'admin_post_vbi_authors', array( __CLASS__, 'handle_authors' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( VBI_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_posts_page( __( 'Import blog file', 'vyntic-blog-importer' ), __( 'Import blog file', 'vyntic-blog-importer' ), self::CAP, self::SLUG, array( __CLASS__, 'render' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Import', 'vyntic-blog-importer' ) . '</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( 'posts_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'vbi-admin', VBI_URL . 'assets/admin.css', array(), VBI_VERSION );
		wp_enqueue_script( 'vbi-admin', VBI_URL . 'assets/admin.js', array(), VBI_VERSION, true );
	}

	private static function url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG ), $args ), admin_url( 'edit.php' ) );
	}

	private static function key( $kind, $token ) {
		return 'vbi_' . $kind . '_' . get_current_user_id() . '_' . preg_replace( '/[^a-zA-Z0-9]/', '', $token );
	}

	private static function fail( $message ) {
		set_transient( self::key( 'notice', 'x' ), array( 'error', $message ), 120 );
		wp_safe_redirect( self::url() );
		exit;
	}

	/* ---------------------------------------------------------------- Handlers */

	public static function handle_upload() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to import posts.', 'vyntic-blog-importer' ), 403 );
		}
		check_admin_referer( 'vbi_upload' );

		$raw    = '';
		$source = 'pasted.json';
		$dir    = '';
		$root   = '';
		if ( isset( $_FILES['vbi_file']['error'] ) && in_array( (int) $_FILES['vbi_file']['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
			/* translators: %s: maximum upload size. */
			self::fail( sprintf( __( 'The file is larger than this server allows (%s). Upload the smaller part files, or ask your host to raise the upload limit.', 'vyntic-blog-importer' ), size_format( wp_max_upload_size() ) ) );
		}
		if ( ! empty( $_FILES['vbi_file']['tmp_name'] ) && is_uploaded_file( $_FILES['vbi_file']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$tmp    = $_FILES['vbi_file']['tmp_name']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$source = sanitize_file_name( wp_unslash( $_FILES['vbi_file']['name'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$is_zip = 'zip' === strtolower( pathinfo( $source, PATHINFO_EXTENSION ) ) || "PK\x03\x04" === file_get_contents( $tmp, false, null, 0, 4 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $is_zip ) {
				$zip = VBI_Zip::extract( $tmp );
				if ( is_wp_error( $zip ) ) {
					self::fail( $zip->get_error_message() );
				}
				$raw  = $zip['json'];
				$dir  = $zip['dir'];
				$root = $zip['root'];
			} else {
				if ( (int) $_FILES['vbi_file']['size'] > 8 * MB_IN_BYTES ) {
					self::fail( __( 'The file is larger than 8 MB.', 'vyntic-blog-importer' ) );
				}
				$raw = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		} elseif ( ! empty( $_POST['vbi_json'] ) ) {
			$raw = wp_unslash( $_POST['vbi_json'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- JSON is decoded and every field is sanitised by the parser.
		}
		if ( '' === trim( (string) $raw ) ) {
			self::fail( __( 'Choose a .json file first, or paste its contents.', 'vyntic-blog-importer' ) );
		}

		$data = VBI_Parser::parse( $raw, $dir );
		if ( is_wp_error( $data ) ) {
			if ( $root ) {
				VBI_Zip::remove( $root );
			}
			self::fail( $data->get_error_message() );
		}

		$token = strtolower( wp_generate_password( 12, false, false ) );
		set_transient(
			self::key( 'upload', $token ),
			array(
				'source' => $source,
				'data'   => $data,
				'dir'    => $dir,
				'root'   => $root,
			),
			2 * HOUR_IN_SECONDS
		);
		wp_safe_redirect( self::url( array( 'step' => 'review', 'token' => $token ) ) );
		exit;
	}

	public static function handle_import() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to import posts.', 'vyntic-blog-importer' ), 403 );
		}
		check_admin_referer( 'vbi_import' );

		$token  = isset( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
		$upload = get_transient( self::key( 'upload', $token ) );
		if ( ! $upload ) {
			self::fail( __( 'The uploaded file expired. Upload it again.', 'vyntic-blog-importer' ) );
		}

		$d        = VBI_Importer::default_settings();
		$in       = isset( $_POST['vbi'] ) ? (array) wp_unslash( $_POST['vbi'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$settings = array(
			'mode'          => isset( $in['mode'] ) && in_array( $in['mode'], array( 'spread', 'file', 'now', 'draft' ), true ) ? $in['mode'] : $d['mode'],
			'start'         => isset( $in['start'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['start'] ) ? $in['start'] : $d['start'],
			'time'          => isset( $in['time'] ) && preg_match( '/^\d{2}:\d{2}$/', $in['time'] ) ? $in['time'] : $d['time'],
			'every'         => isset( $in['every'] ) ? min( 60, max( 1, (int) $in['every'] ) ) : $d['every'],
			'skip_weekends' => empty( $in['skip_weekends'] ) ? 0 : 1,
			'author'        => $d['author'],
			'authors'       => self::valid_authors( isset( $in['authors'] ) ? (array) $in['authors'] : array() ),
			'duplicate'     => isset( $in['duplicate'] ) && in_array( $in['duplicate'], array( 'skip', 'update', 'new' ), true ) ? $in['duplicate'] : $d['duplicate'],
			'blocks'        => empty( $in['blocks'] ) ? 0 : 1,
			'images'        => empty( $in['images'] ) ? 0 : 1,
		);
		update_user_meta( get_current_user_id(), 'vbi_last_settings', array_diff_key( $settings, array( 'start' => 1 ) ) );

		$pick  = isset( $in['pick'] ) ? array_map( 'intval', (array) $in['pick'] ) : array();
		$posts = array_values(
			array_filter(
				$upload['data']['posts'],
				function ( $p ) use ( $pick ) {
					return in_array( $p['index'], $pick, true );
				}
			)
		);
		if ( ! $posts ) {
			set_transient( self::key( 'notice', 'x' ), array( 'error', __( 'Tick at least one post to import.', 'vyntic-blog-importer' ) ), 120 );
			wp_safe_redirect( self::url( array( 'step' => 'review', 'token' => $token ) ) );
			exit;
		}

		$result = VBI_Importer::run( $posts, $settings, $upload['source'], isset( $upload['dir'] ) ? $upload['dir'] : '' );
		if ( ! empty( $upload['root'] ) ) {
			VBI_Zip::remove( $upload['root'] );
		}
		delete_transient( self::key( 'upload', $token ) );
		set_transient( self::key( 'result', $token ), $result, HOUR_IN_SECONDS );
		wp_safe_redirect( self::url( array( 'step' => 'done', 'token' => $token ) ) );
		exit;
	}

	/**
	 * Keep only ids of users who can write posts.
	 */
	private static function valid_authors( array $ids ) {
		$ok = array();
		foreach ( $ids as $id ) {
			if ( user_can( (int) $id, 'edit_posts' ) ) {
				$ok[] = (int) $id;
			}
		}
		return $ok ? array_values( array_unique( $ok ) ) : array( get_current_user_id() );
	}

	public static function handle_authors() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'vyntic-blog-importer' ), 403 );
		}
		check_admin_referer( 'vbi_authors' );
		$in    = isset( $_POST['vbi'] ) ? (array) wp_unslash( $_POST['vbi'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$known = wp_list_pluck( VBI_Importer::imported_posts(), 'ID' );
		$pick  = array_values( array_intersect( array_map( 'intval', isset( $in['posts'] ) ? (array) $in['posts'] : array() ), array_map( 'intval', $known ) ) );
		$back  = add_query_arg( array( 'page' => self::SLUG, 'step' => 'authors' ), admin_url( 'edit.php' ) );
		if ( ! $pick ) {
			set_transient( self::key( 'notice', 'x' ), array( 'error', __( 'Tick at least one post.', 'vyntic-blog-importer' ) ), 120 );
			wp_safe_redirect( $back );
			exit;
		}
		$map = array();
		if ( isset( $in['mode'] ) && 'category' === $in['mode'] ) {
			$by_cat = isset( $in['cat'] ) ? array_map( 'intval', (array) $in['cat'] ) : array();
			foreach ( $pick as $pid ) {
				$cats = wp_get_post_categories( $pid );
				$cat  = $cats ? (int) $cats[0] : 0;
				if ( ! empty( $by_cat[ $cat ] ) && user_can( $by_cat[ $cat ], 'edit_posts' ) ) {
					$map[ $pid ] = $by_cat[ $cat ];
				}
			}
		} else {
			$authors = self::valid_authors( isset( $in['authors'] ) ? (array) $in['authors'] : array() );
			$order   = VBI_Importer::author_order( $authors, count( $pick ) );
			foreach ( $pick as $i => $pid ) {
				$map[ $pid ] = $order[ $i ];
			}
		}
		$n = VBI_Importer::set_authors( $pick, $map );
		/* translators: %d: number of posts. */
		set_transient( self::key( 'notice', 'x' ), array( 'success', sprintf( _n( 'Author updated on %d post.', 'Authors updated on %d posts.', $n, 'vyntic-blog-importer' ), $n ) ), 120 );
		wp_safe_redirect( $back );
		exit;
	}

	public static function handle_undo() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'vyntic-blog-importer' ), 403 );
		}
		$batch = isset( $_GET['batch'] ) ? sanitize_text_field( wp_unslash( $_GET['batch'] ) ) : '';
		check_admin_referer( 'vbi_undo_' . $batch );
		$n = VBI_Importer::undo( $batch );
		/* translators: %d: number of posts. */
		set_transient( self::key( 'notice', 'x' ), array( 'success', sprintf( _n( '%d post moved to the bin.', '%d posts moved to the bin.', $n, 'vyntic-blog-importer' ), $n ) ), 120 );
		wp_safe_redirect( self::url() );
		exit;
	}

	/* ---------------------------------------------------------------- Screens */

	public static function render() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$step  = isset( $_GET['step'] ) ? sanitize_key( $_GET['step'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$token = isset( $_GET['token'] ) ? sanitize_key( $_GET['token'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		echo '<div class="wrap vbi">';
		echo '<h1>' . esc_html__( 'Import blog file', 'vyntic-blog-importer' ) . '</h1>';

		$steps = array(
			''       => __( 'Upload', 'vyntic-blog-importer' ),
			'review' => __( 'Review and schedule', 'vyntic-blog-importer' ),
			'done'   => __( 'Done', 'vyntic-blog-importer' ),
		);
		echo '<ol class="vbi-steps">';
		$reached = true;
		foreach ( $steps as $k => $label ) {
			$cls = $k === $step ? 'is-current' : ( $reached ? 'is-done' : '' );
			if ( $k === $step ) {
				$reached = false;
			}
			echo '<li class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</li>';
		}
		echo '</ol>';

		$notice = get_transient( self::key( 'notice', 'x' ) );
		if ( $notice ) {
			delete_transient( self::key( 'notice', 'x' ) );
			echo '<div class="notice notice-' . esc_attr( $notice[0] ) . ' is-dismissible"><p>' . esc_html( $notice[1] ) . '</p></div>';
		}

		if ( 'review' === $step ) {
			$upload = get_transient( self::key( 'upload', $token ) );
			if ( $upload ) {
				self::screen_review( $upload, $token );
			} else {
				echo '<div class="notice notice-warning"><p>' . esc_html__( 'This upload expired. Upload the file again.', 'vyntic-blog-importer' ) . '</p></div>';
				self::screen_upload();
			}
		} elseif ( 'authors' === $step ) {
			self::screen_authors();
		} elseif ( 'done' === $step ) {
			$result = get_transient( self::key( 'result', $token ) );
			if ( $result ) {
				self::screen_done( $result );
			} else {
				self::screen_upload();
			}
		} else {
			self::screen_upload();
		}
		echo '</div>';
	}

	private static function screen_upload() {
		?>
		<div class="vbi-grid">
			<form class="vbi-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<?php wp_nonce_field( 'vbi_upload' ); ?>
				<input type="hidden" name="action" value="vbi_upload">
				<h2><?php esc_html_e( '1. Upload your blog file', 'vyntic-blog-importer' ); ?></h2>
				<p><?php esc_html_e( 'Choose the .zip (posts and images) or .json file with your posts. Nothing is saved yet: on the next screen you check every post and choose when each one goes live.', 'vyntic-blog-importer' ); ?></p>
				<label class="vbi-drop">
					<input type="file" name="vbi_file" accept=".json,.zip,application/json,application/zip">
					<span class="vbi-drop__text"><?php esc_html_e( 'Click to choose a .zip or .json file, or drop it here', 'vyntic-blog-importer' ); ?></span>
				</label>
				<p class="description">
					<?php
					/* translators: %s: maximum upload size. */
					printf( esc_html__( 'Use the .zip when your posts come with images. Largest file this server accepts: %s.', 'vyntic-blog-importer' ), esc_html( size_format( wp_max_upload_size() ) ) );
					?>
				</p>
				<details class="vbi-paste">
					<summary><?php esc_html_e( 'Or paste the file contents', 'vyntic-blog-importer' ); ?></summary>
					<textarea name="vbi_json" rows="8" class="large-text code" placeholder='{ "posts": [ ... ] }'></textarea>
				</details>
				<p><button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Upload and review', 'vyntic-blog-importer' ); ?></button></p>
			</form>

			<div class="vbi-card vbi-help">
				<h2><?php esc_html_e( 'How it works', 'vyntic-blog-importer' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Upload the file.', 'vyntic-blog-importer' ); ?></li>
					<li><?php esc_html_e( 'Pick a start date and how often to publish, for example every 3 days at 9:00. You see the exact date of every post before importing.', 'vyntic-blog-importer' ); ?></li>
					<li><?php esc_html_e( 'Import. Posts are scheduled in WordPress and go live on their own. Categories, tags, SEO title, meta description, focus keyword, FAQ schema and featured images are all set for you.', 'vyntic-blog-importer' ); ?></li>
				</ol>
				<p><a class="button" href="<?php echo esc_url( VBI_URL . 'sample/sample-blog-file.json' ); ?>" download><?php esc_html_e( 'Download a sample file', 'vyntic-blog-importer' ); ?></a></p>
				<details>
					<summary><?php esc_html_e( 'File format', 'vyntic-blog-importer' ); ?></summary>
					<p><?php esc_html_e( 'Only "title" and "content" are required. Content is HTML: p, h2, h3, ul, ol, blockquote, img, figure and table all work.', 'vyntic-blog-importer' ); ?></p>
					<p><?php esc_html_e( 'Images: put the .json file and an images folder in one .zip. Use "image": "images/cover.jpg" for the featured image and <img src="images/chart.jpg" alt="..."> inside the content. Every image is added to the Media Library with its alt text.', 'vyntic-blog-importer' ); ?></p>
					<pre><?php echo esc_html( self::format_example() ); ?></pre>
					<p><?php esc_html_e( 'Links inside content: {{contact|anchor text}} links to a Vyntic theme page by its key, {{post:post-slug|anchor}} to a blog post (also one that is scheduled), {{/services/|anchor}} to any path on this site and {{ext:https://example.com|anchor}} to an outside site in a new tab. {{price:starter}} prints your current price.', 'vyntic-blog-importer' ); ?></p>
				</details>
			</div>
		</div>
		<?php
		self::history();
	}

	private static function format_example() {
		return '{
  "defaults": { "category": "Web design" },
  "posts": [
    {
      "title": "Post title (the H1)",
      "slug": "post-url-slug",
      "content": "<p>Intro...</p><h2>Section</h2><p>...</p>",
      "excerpt": "Short summary for the blog list.",
      "category": "Web design",
      "tags": ["WordPress", "SEO"],
      "seo_title": "Title for Google, under 60 characters",
      "meta_description": "Under 160 characters.",
      "focus_keyword": "main keyword",
      "image": "images/cover.jpg",
      "image_alt": "What the image shows",
      "date": "2026-11-03 09:00",
      "faq": [ { "q": "Question?", "a": "Answer." } ]
    }
  ]
}';
	}

	private static function history() {
		$batches = array_reverse( get_option( VBI_Importer::BATCHES, array() ), true );
		if ( ! $batches ) {
			return;
		}
		echo '<div class="vbi-card"><h2 class="vbi-h2-row">' . esc_html__( 'Recent imports', 'vyntic-blog-importer' ) . ' <a class="button" href="' . esc_url( self::url( array( 'step' => 'authors' ) ) ) . '">' . esc_html__( 'Change authors', 'vyntic-blog-importer' ) . '</a></h2>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Imported', 'vyntic-blog-importer' ) . '</th><th>' . esc_html__( 'File', 'vyntic-blog-importer' ) . '</th><th>' . esc_html__( 'Posts', 'vyntic-blog-importer' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $batches as $id => $b ) {
			$live = 0;
			$sch  = 0;
			foreach ( $b['ids'] as $pid ) {
				$st = get_post_status( $pid );
				$live += 'publish' === $st ? 1 : 0;
				$sch  += 'future' === $st ? 1 : 0;
			}
			$undo = wp_nonce_url( add_query_arg( array( 'action' => 'vbi_undo', 'batch' => $id ), admin_url( 'admin-post.php' ) ), 'vbi_undo_' . $id );
			echo '<tr><td>' . esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $b['time'] ) ) . '</td>';
			echo '<td>' . esc_html( $b['source'] ) . '</td>';
			/* translators: 1: total posts, 2: published, 3: scheduled. */
			echo '<td>' . esc_html( sprintf( __( '%1$d posts: %2$d live, %3$d scheduled', 'vyntic-blog-importer' ), count( $b['ids'] ), $live, $sch ) ) . '</td>';
			echo '<td class="vbi-right"><a class="button-link-delete" href="' . esc_url( $undo ) . '" onclick="return confirm(\'' . esc_js( __( 'Move every post from this import to the bin?', 'vyntic-blog-importer' ) ) . '\')">' . esc_html__( 'Undo import', 'vyntic-blog-importer' ) . '</a></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	private static function screen_review( array $upload, $token ) {
		$posts    = $upload['data']['posts'];
		$settings = array_merge( VBI_Importer::default_settings(), (array) get_user_meta( get_current_user_id(), 'vbi_last_settings', true ) );
		$has_date = count( array_filter( wp_list_pluck( $posts, 'date' ) ) );
		if ( $has_date === count( $posts ) && 'spread' === $settings['mode'] ) {
			$settings['mode'] = 'file';
		}
		$now  = new DateTimeImmutable( 'now', wp_timezone() );
		$data = array();
		foreach ( $posts as $p ) {
			$data[] = array(
				'i'      => $p['index'],
				'date'   => $p['date'],
				'draft'  => 'draft' === $p['status'],
			);
		}
		$wp_cron_off = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$thumb_base  = '';
		if ( ! empty( $upload['dir'] ) ) {
			$up         = wp_upload_dir( null, false );
			$thumb_base = trailingslashit( str_replace( wp_normalize_path( $up['basedir'] ), $up['baseurl'], wp_normalize_path( $upload['dir'] ) ) );
		}
		$past = 0;
		foreach ( $posts as $p ) {
			if ( $p['date'] && $p['date'] < $now->format( 'Y-m-d H:i' ) ) {
				$past++;
			}
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vbi-review" data-vbi-review
			data-posts="<?php echo esc_attr( wp_json_encode( $data ) ); ?>"
			data-now="<?php echo esc_attr( $now->format( 'Y-m-d H:i' ) ); ?>"
			data-locale="<?php echo esc_attr( str_replace( '_', '-', get_user_locale() ) ); ?>">
			<?php wp_nonce_field( 'vbi_import' ); ?>
			<input type="hidden" name="action" value="vbi_import">
			<input type="hidden" name="token" value="<?php echo esc_attr( $token ); ?>">

			<div class="vbi-card">
				<h2><?php esc_html_e( '2. When should the posts go live?', 'vyntic-blog-importer' ); ?></h2>
				<div class="vbi-modes">
					<?php
					$modes = array(
						'spread' => array( __( 'Spread them out', 'vyntic-blog-importer' ), __( 'One post every few days from a start date.', 'vyntic-blog-importer' ) ),
						'file'   => array( __( 'Use the dates in the file', 'vyntic-blog-importer' ), __( 'Posts without a date are spread out after the start date.', 'vyntic-blog-importer' ) ),
						'now'    => array( __( 'Publish all now', 'vyntic-blog-importer' ), __( 'Every post goes live straight away.', 'vyntic-blog-importer' ) ),
						'draft'  => array( __( 'Save as drafts', 'vyntic-blog-importer' ), __( 'Nothing goes live. Publish them yourself later.', 'vyntic-blog-importer' ) ),
					);
					foreach ( $modes as $k => $m ) :
						?>
						<label class="vbi-mode">
							<input type="radio" name="vbi[mode]" value="<?php echo esc_attr( $k ); ?>" <?php checked( $settings['mode'], $k ); ?>>
							<span><strong><?php echo esc_html( $m[0] ); ?></strong><small><?php echo esc_html( $m[1] ); ?></small></span>
						</label>
					<?php endforeach; ?>
				</div>

				<div class="vbi-fields" data-vbi-spread>
					<label><?php esc_html_e( 'First post on', 'vyntic-blog-importer' ); ?>
						<input type="date" name="vbi[start]" value="<?php echo esc_attr( $settings['start'] ); ?>" min="<?php echo esc_attr( $now->format( 'Y-m-d' ) ); ?>">
					</label>
					<label><?php esc_html_e( 'at', 'vyntic-blog-importer' ); ?>
						<input type="time" name="vbi[time]" value="<?php echo esc_attr( $settings['time'] ); ?>">
					</label>
					<label><?php esc_html_e( 'then one post every', 'vyntic-blog-importer' ); ?>
						<input type="number" name="vbi[every]" value="<?php echo esc_attr( $settings['every'] ); ?>" min="1" max="60" class="small-text"> <?php esc_html_e( 'days', 'vyntic-blog-importer' ); ?>
					</label>
					<label class="vbi-check"><input type="checkbox" name="vbi[skip_weekends]" value="1" <?php checked( $settings['skip_weekends'] ); ?>> <?php esc_html_e( 'Skip Saturdays and Sundays', 'vyntic-blog-importer' ); ?></label>
				</div>
				<p class="description">
					<?php
					/* translators: %s: time zone name. */
					printf( esc_html__( 'Times use your site time zone: %s (Settings → General).', 'vyntic-blog-importer' ), '<strong>' . esc_html( wp_timezone_string() ) . '</strong>' );
					?>
					<span data-vbi-summary></span>
				</p>
				<?php if ( in_array( wp_timezone_string(), array( 'UTC', '+00:00' ), true ) ) : ?>
					<div class="notice notice-warning inline"><p>
						<?php
						/* translators: %s: link to Settings → General. */
						printf( esc_html__( 'Your site time zone is UTC, so 9:00 here may not be 9:00 for your readers. Pick your city in %s first.', 'vyntic-blog-importer' ), '<a href="' . esc_url( admin_url( 'options-general.php#timezone_string' ) ) . '" target="_blank">' . esc_html__( 'Settings → General', 'vyntic-blog-importer' ) . '</a>' );
						?>
					</p></div>
				<?php endif; ?>
				<?php if ( $past ) : ?>
					<div class="notice notice-warning inline" data-vbi-past><p>
						<?php
						/* translators: %d: number of posts. */
						printf( esc_html( _n( '%d date in the file is already in the past, so with "Use the dates in the file" that post goes live straight away. To keep the same rhythm from today, choose "Spread them out".', '%d dates in the file are already in the past, so with "Use the dates in the file" those posts go live straight away. To keep the same rhythm from today, choose "Spread them out".', $past, 'vyntic-blog-importer' ) ), (int) $past );
						?>
					</p></div>
				<?php endif; ?>
				<?php if ( $wp_cron_off ) : ?>
					<div class="notice notice-info inline"><p><?php esc_html_e( 'WP-Cron is turned off on this site (DISABLE_WP_CRON), so make sure your host runs wp-cron.php on a schedule. This plugin also publishes any post that missed its time on the next page view.', 'vyntic-blog-importer' ); ?></p></div>
				<?php endif; ?>
			</div>

			<div class="vbi-card">
				<h2>
					<?php
					/* translators: %d: number of posts. */
					printf( esc_html( _n( '3. Check %d post', '3. Check %d posts', count( $posts ), 'vyntic-blog-importer' ) ), count( $posts ) );
					?>
					<small><?php echo esc_html( $upload['source'] ); ?></small>
				</h2>
				<table class="widefat vbi-table">
					<thead><tr>
						<td class="check-column"><input type="checkbox" checked data-vbi-all aria-label="<?php esc_attr_e( 'Select all', 'vyntic-blog-importer' ); ?>"></td>
						<th><?php esc_html_e( 'Post', 'vyntic-blog-importer' ); ?></th>
						<th><?php esc_html_e( 'Category', 'vyntic-blog-importer' ); ?></th>
						<th><?php esc_html_e( 'SEO', 'vyntic-blog-importer' ); ?></th>
						<th><?php esc_html_e( 'Goes live', 'vyntic-blog-importer' ); ?></th>
					</tr></thead>
					<tbody>
					<?php
					$dupes = 0;
					foreach ( $posts as $p ) :
						$exists = get_page_by_path( $p['slug'], OBJECT, 'post' );
						$exists = $exists && 'trash' !== $exists->post_status ? $exists : null;
						$dupes += $exists ? 1 : 0;
						$bad    = (bool) $p['errors'];
						?>
						<tr class="<?php echo $bad ? 'vbi-bad' : ''; ?>" data-vbi-row="<?php echo esc_attr( $p['index'] ); ?>">
							<th scope="row" class="check-column"><input type="checkbox" name="vbi[pick][]" value="<?php echo esc_attr( $p['index'] ); ?>" <?php checked( ! $bad ); ?> <?php disabled( $bad ); ?>></th>
							<td class="vbi-post">
								<?php if ( $thumb_base && $p['image'] && VBI_Zip::resolve( $upload['dir'], $p['image'] ) ) : ?>
									<img class="vbi-thumb" src="<?php echo esc_url( $thumb_base . ltrim( $p['image'], './' ) ); ?>" alt="" loading="lazy">
								<?php endif; ?>
								<strong><?php echo esc_html( $p['title'] ? $p['title'] : __( '(no title)', 'vyntic-blog-importer' ) ); ?></strong>
								<div class="vbi-meta">/<?php echo esc_html( $p['slug'] ); ?>/ · <?php echo esc_html( sprintf( /* translators: %s: number of words. */ __( '%s words', 'vyntic-blog-importer' ), number_format_i18n( $p['words'] ) ) ); ?><?php echo $p['faq'] ? ' · ' . esc_html( sprintf( /* translators: %d: number of questions. */ _n( '%d FAQ', '%d FAQs', count( $p['faq'] ), 'vyntic-blog-importer' ), count( $p['faq'] ) ) ) : ''; ?><?php echo ( $p['image_url'] || $p['image'] ) ? ' · ' . esc_html__( 'featured image', 'vyntic-blog-importer' ) : ''; ?><?php echo $p['images_inline'] ? ' · ' . esc_html( sprintf( /* translators: %d: number of images. */ _n( '%d image in text', '%d images in text', $p['images_inline'], 'vyntic-blog-importer' ), $p['images_inline'] ) ) : ''; ?><?php echo $p['pillar'] ? ' · ' . esc_html__( 'pillar', 'vyntic-blog-importer' ) : ''; ?></div>
								<?php if ( $exists ) : ?>
									<div class="vbi-flag vbi-flag--dupe"><?php esc_html_e( 'Already on the site', 'vyntic-blog-importer' ); ?> · <a href="<?php echo esc_url( get_edit_post_link( $exists->ID ) ); ?>" target="_blank"><?php esc_html_e( 'open', 'vyntic-blog-importer' ); ?></a></div>
								<?php endif; ?>
								<?php foreach ( $p['errors'] as $e ) : ?>
									<div class="vbi-flag vbi-flag--error"><?php echo esc_html( $e ); ?></div>
								<?php endforeach; ?>
								<?php foreach ( $p['warnings'] as $w ) : ?>
									<div class="vbi-flag"><?php echo esc_html( $w ); ?></div>
								<?php endforeach; ?>
							</td>
							<td><?php echo esc_html( $p['categories'] ? implode( ', ', $p['categories'] ) : get_cat_name( (int) get_option( 'default_category' ) ) ); ?><?php echo $p['tags'] ? '<div class="vbi-meta">' . esc_html( implode( ', ', $p['tags'] ) ) . '</div>' : ''; ?></td>
							<td class="vbi-seo">
								<?php if ( $p['focus_keyword'] ) : ?><div><span><?php esc_html_e( 'Keyword', 'vyntic-blog-importer' ); ?></span> <?php echo esc_html( $p['focus_keyword'] ); ?></div><?php endif; ?>
								<?php if ( $p['seo_title'] ) : ?><div><span><?php esc_html_e( 'Title', 'vyntic-blog-importer' ); ?></span> <?php echo esc_html( $p['seo_title'] ); ?> <em>(<?php echo esc_html( mb_strlen( $p['seo_title'] ) ); ?>)</em></div><?php endif; ?>
								<?php if ( $p['meta_description'] ) : ?><div><span><?php esc_html_e( 'Meta', 'vyntic-blog-importer' ); ?></span> <em>(<?php echo esc_html( mb_strlen( $p['meta_description'] ) ); ?> <?php esc_html_e( 'characters', 'vyntic-blog-importer' ); ?>)</em></div><?php endif; ?>
							</td>
							<td class="vbi-when" data-vbi-when>-</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="vbi-card">
				<h2><?php esc_html_e( '4. Options', 'vyntic-blog-importer' ); ?></h2>
				<div class="vbi-fields">
					<?php self::author_boxes( 'vbi[authors][]', isset( $settings['authors'] ) ? (array) $settings['authors'] : array( $settings['author'] ) ); ?>
					<label><?php esc_html_e( 'If a post with the same slug exists', 'vyntic-blog-importer' ); ?>
						<select name="vbi[duplicate]">
							<option value="skip" <?php selected( $settings['duplicate'], 'skip' ); ?>><?php esc_html_e( 'Skip it (safest)', 'vyntic-blog-importer' ); ?></option>
							<option value="update" <?php selected( $settings['duplicate'], 'update' ); ?>><?php esc_html_e( 'Replace it with the file version', 'vyntic-blog-importer' ); ?></option>
							<option value="new" <?php selected( $settings['duplicate'], 'new' ); ?>><?php esc_html_e( 'Add it as a new post', 'vyntic-blog-importer' ); ?></option>
						</select>
					</label>
				</div>
				<?php if ( $dupes ) : ?>
					<p class="description">
						<?php
						/* translators: %d: number of posts. */
						printf( esc_html( _n( '%d post in this file is already on the site.', '%d posts in this file are already on the site.', $dupes, 'vyntic-blog-importer' ) ), (int) $dupes );
						?>
					</p>
				<?php endif; ?>
				<label class="vbi-check"><input type="checkbox" name="vbi[blocks]" value="1" <?php checked( $settings['blocks'] ); ?>> <?php esc_html_e( 'Convert to editor blocks, so every paragraph and heading can be edited on its own', 'vyntic-blog-importer' ); ?></label>
				<label class="vbi-check"><input type="checkbox" name="vbi[images]" value="1" <?php checked( $settings['images'] ); ?>> <?php esc_html_e( 'Download featured images into the Media Library', 'vyntic-blog-importer' ); ?></label>
			</div>

			<p class="vbi-actions">
				<button type="submit" class="button button-primary button-hero" data-vbi-submit><?php esc_html_e( 'Import posts', 'vyntic-blog-importer' ); ?></button>
				<a class="button button-hero" href="<?php echo esc_url( self::url() ); ?>"><?php esc_html_e( 'Cancel', 'vyntic-blog-importer' ); ?></a>
			</p>
		</form>
		<?php
	}

	/**
	 * Author checkboxes. Ticking more than one spreads the posts evenly between them.
	 */
	private static function author_boxes( $name, array $checked ) {
		$users = VBI_Importer::authors();
		echo '<fieldset class="vbi-authors"><legend>' . esc_html__( 'Authors', 'vyntic-blog-importer' ) . ' <small>' . esc_html__( 'Tick more than one to share the posts evenly between them, in a mixed order.', 'vyntic-blog-importer' ) . '</small></legend>';
		foreach ( $users as $u ) {
			$job = get_user_meta( $u->ID, 'vyntic_job', true );
			echo '<label class="vbi-author"><input type="checkbox" name="' . esc_attr( $name ) . '" value="' . (int) $u->ID . '" ' . checked( in_array( (int) $u->ID, array_map( 'intval', $checked ), true ), true, false ) . '> <span>' . get_avatar( $u->ID, 28 ) . '<b>' . esc_html( $u->display_name ) . '</b>' . ( $job ? '<small>' . esc_html( $job ) . '</small>' : '' ) . '</span></label>';
		}
		echo '</fieldset>';
		if ( count( $users ) < 2 ) {
			echo '<p class="description">' . wp_kses_post( sprintf( /* translators: %s: link to add a user. */ __( 'Only one person can write posts on this site. To show different authors, add your team in %s with the role Author, then come back here.', 'vyntic-blog-importer' ), '<a href="' . esc_url( admin_url( 'user-new.php' ) ) . '">' . esc_html__( 'Users → Add New', 'vyntic-blog-importer' ) . '</a>' ) ) . '</p>';
		}
	}

	private static function screen_authors() {
		$posts = VBI_Importer::imported_posts();
		echo '<p><a href="' . esc_url( self::url() ) . '">&larr; ' . esc_html__( 'Back to import', 'vyntic-blog-importer' ) . '</a></p>';
		if ( ! $posts ) {
			echo '<div class="vbi-card"><p>' . esc_html__( 'There are no imported posts to change.', 'vyntic-blog-importer' ) . '</p></div>';
			return;
		}
		$cats = array();
		foreach ( $posts as $p ) {
			$c = wp_get_post_categories( $p->ID );
			if ( $c ) {
				$cats[ (int) $c[0] ] = get_cat_name( (int) $c[0] );
			}
		}
		$users = VBI_Importer::authors();
		$fmt   = get_option( 'date_format' );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vbi_authors' ); ?>
			<input type="hidden" name="action" value="vbi_authors">
			<div class="vbi-card">
				<h2><?php esc_html_e( 'Change authors', 'vyntic-blog-importer' ); ?></h2>
				<p><?php esc_html_e( 'Choose how to share the imported posts between your team. Dates and schedules stay exactly as they are.', 'vyntic-blog-importer' ); ?></p>
				<div class="vbi-modes vbi-modes--2">
					<label class="vbi-mode"><input type="radio" name="vbi[mode]" value="spread" checked> <span><strong><?php esc_html_e( 'Shuffle evenly', 'vyntic-blog-importer' ); ?></strong><small><?php esc_html_e( 'Each ticked author gets the same number of posts, in a mixed order.', 'vyntic-blog-importer' ); ?></small></span></label>
					<label class="vbi-mode"><input type="radio" name="vbi[mode]" value="category"> <span><strong><?php esc_html_e( 'By topic', 'vyntic-blog-importer' ); ?></strong><small><?php esc_html_e( 'Pick one author per category, for example your SEO lead for Local SEO.', 'vyntic-blog-importer' ); ?></small></span></label>
				</div>
				<div data-vbi-panel="spread"><?php self::author_boxes( 'vbi[authors][]', wp_list_pluck( $users, 'ID' ) ); ?></div>
				<div data-vbi-panel="category" hidden>
					<div class="vbi-fields">
						<?php foreach ( $cats as $cid => $cname ) : ?>
							<label><?php echo esc_html( $cname ); ?>
								<select name="vbi[cat][<?php echo (int) $cid; ?>]">
									<?php foreach ( $users as $u ) : ?>
										<option value="<?php echo (int) $u->ID; ?>"><?php echo esc_html( $u->display_name ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
			<div class="vbi-card">
				<h2>
					<?php
					/* translators: %d: number of posts. */
					printf( esc_html__( 'Posts (%d)', 'vyntic-blog-importer' ), count( $posts ) );
					?>
				</h2>
				<table class="widefat striped vbi-table">
					<thead><tr><td class="check-column"><input type="checkbox" checked data-vbi-allposts aria-label="<?php esc_attr_e( 'Select all', 'vyntic-blog-importer' ); ?>"></td><th><?php esc_html_e( 'Post', 'vyntic-blog-importer' ); ?></th><th><?php esc_html_e( 'Category', 'vyntic-blog-importer' ); ?></th><th><?php esc_html_e( 'Date', 'vyntic-blog-importer' ); ?></th><th><?php esc_html_e( 'Author now', 'vyntic-blog-importer' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $posts as $p ) : ?>
						<?php $c = wp_get_post_categories( $p->ID ); ?>
						<tr>
							<th scope="row" class="check-column"><input type="checkbox" name="vbi[posts][]" value="<?php echo (int) $p->ID; ?>" checked></th>
							<td><strong><?php echo esc_html( get_the_title( $p ) ); ?></strong></td>
							<td><?php echo esc_html( $c ? get_cat_name( (int) $c[0] ) : '' ); ?></td>
							<td><?php echo esc_html( get_the_date( $fmt, $p ) ); ?> <span class="vbi-badge vbi-badge--<?php echo esc_attr( $p->post_status ); ?>"><?php echo esc_html( 'future' === $p->post_status ? __( 'Scheduled', 'vyntic-blog-importer' ) : ( 'publish' === $p->post_status ? __( 'Published', 'vyntic-blog-importer' ) : __( 'Draft', 'vyntic-blog-importer' ) ) ); ?></span></td>
							<td><?php echo esc_html( get_the_author_meta( 'display_name', $p->post_author ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<p class="vbi-actions"><button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Update authors', 'vyntic-blog-importer' ); ?></button></p>
		</form>
		<?php
	}

	private static function screen_done( array $result ) {
		$labels = array(
			'created' => __( 'Created', 'vyntic-blog-importer' ),
			'updated' => __( 'Replaced', 'vyntic-blog-importer' ),
			'skipped' => __( 'Skipped', 'vyntic-blog-importer' ),
			'error'   => __( 'Not imported', 'vyntic-blog-importer' ),
		);
		$count = array_count_values( wp_list_pluck( $result['results'], 'result' ) );
		$fmt   = get_option( 'date_format' ) . ', ' . get_option( 'time_format' );
		?>
		<div class="vbi-card">
			<h2><?php esc_html_e( 'Import finished', 'vyntic-blog-importer' ); ?></h2>
			<p class="vbi-totals">
				<?php foreach ( $labels as $k => $l ) : ?>
					<?php if ( ! empty( $count[ $k ] ) ) : ?>
						<span class="vbi-pill vbi-pill--<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $l . ': ' . $count[ $k ] ); ?></span>
					<?php endif; ?>
				<?php endforeach; ?>
			</p>
			<table class="widefat striped vbi-table">
				<thead><tr>
					<th><?php esc_html_e( 'Post', 'vyntic-blog-importer' ); ?></th>
					<th><?php esc_html_e( 'Result', 'vyntic-blog-importer' ); ?></th>
					<th><?php esc_html_e( 'Goes live', 'vyntic-blog-importer' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $result['results'] as $r ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $r['title'] ); ?></strong>
							<?php foreach ( $r['notes'] as $n ) : ?><div class="vbi-flag"><?php echo esc_html( $n ); ?></div><?php endforeach; ?>
						</td>
						<td><span class="vbi-pill vbi-pill--<?php echo esc_attr( $r['result'] ); ?>"><?php echo esc_html( $labels[ $r['result'] ] ); ?></span></td>
						<td>
							<?php
							if ( 'skipped' === $r['result'] || 'error' === $r['result'] ) {
								echo '-';
							} elseif ( 'draft' === $r['status'] ) {
								esc_html_e( 'Draft', 'vyntic-blog-importer' );
							} else {
								$ts = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $r['date'], wp_timezone() );
								echo '<span class="vbi-badge vbi-badge--' . esc_attr( $r['status'] ) . '">' . esc_html( 'future' === $r['status'] ? __( 'Scheduled', 'vyntic-blog-importer' ) : __( 'Published', 'vyntic-blog-importer' ) ) . '</span> ';
								echo esc_html( $ts ? wp_date( $fmt, $ts->getTimestamp() ) : $r['date'] );
							}
							?>
						</td>
						<td class="vbi-right">
							<?php if ( $r['id'] ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $r['id'] ) ); ?>"><?php esc_html_e( 'Edit', 'vyntic-blog-importer' ); ?></a> ·
								<a href="<?php echo esc_url( get_permalink( $r['id'] ) ); ?>" target="_blank"><?php echo esc_html( 'publish' === get_post_status( $r['id'] ) ? __( 'View', 'vyntic-blog-importer' ) : __( 'Preview', 'vyntic-blog-importer' ) ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_status=future&post_type=post' ) ); ?>"><?php esc_html_e( 'See scheduled posts', 'vyntic-blog-importer' ); ?></a>
				<a class="button" href="<?php echo esc_url( self::url() ); ?>"><?php esc_html_e( 'Import another file', 'vyntic-blog-importer' ); ?></a>
			</p>
			<p class="description"><?php esc_html_e( 'Changed your mind? "Undo import" under Recent imports moves every post from this file to the bin.', 'vyntic-blog-importer' ); ?></p>
		</div>
		<?php
	}
}
