<?php
/**
 * Branded PDF report built with FPDF (bundled, no external service needed).
 */

if ( ! defined( 'ABSPATH' ) && PHP_SAPI !== 'cli' ) {
	exit;
}

if ( ! class_exists( 'FPDF' ) ) {
	if ( ! defined( 'FPDF_FONTPATH' ) ) {
		define( 'FPDF_FONTPATH', dirname( __DIR__ ) . '/lib/fpdf/font/' );
	}
	require_once dirname( __DIR__ ) . '/lib/fpdf/fpdf.php';
}

class VSA_PDF extends FPDF {

	public $brand  = 'Vyntic Studio';
	public $site   = '';
	public $accent  = array( 199, 67, 31 );   // Vyntic orange #c7431f.
	public $ink     = array( 15, 43, 46 );    // Deep teal #0f2b2e.
	public $muted   = array( 74, 98, 102 );   // #4a6266.
	public $line    = array( 213, 224, 221 ); // #d5e0dd.
	public $mist    = array( 238, 243, 241 ); // #eef3f1.
	public $on_dark = array( 211, 226, 223 ); // #d3e2df.
	public $website = '';

	public function Header() {
		if ( 1 === $this->PageNo() ) {
			return;
		}
		$this->SetFont( 'Helvetica', 'B', 9 );
		$this->SetTextColor( ...$this->ink );
		$this->SetXY( 15, 10 );
		$this->Cell( 90, 6, $this->t( $this->brand ), 0, 0, 'L' );
		$this->SetFont( 'Helvetica', '', 9 );
		$this->SetTextColor( ...$this->muted );
		$this->Cell( 90, 6, $this->t( 'Website audit: ' . $this->site ), 0, 0, 'R' );
		$this->SetDrawColor( ...$this->line );
		$this->SetLineWidth( 0.3 );
		$this->Line( 15, 18, 195, 18 );
		$this->SetY( 24 );
	}

	public function Footer() {
		$this->SetY( -13 );
		$this->SetFont( 'Helvetica', '', 8 );
		$this->SetTextColor( ...$this->muted );
		$this->Cell( 60, 5, $this->t( $this->brand ), 0, 0, 'L' );
		$this->Cell( 60, 5, $this->t( 'Page ' . $this->PageNo() . ' of {nb}' ), 0, 0, 'C' );
		if ( $this->website ) {
			$this->SetTextColor( ...$this->accent );
			$this->Cell( 60, 5, $this->t( preg_replace( '#^https?://#', '', rtrim( $this->website, '/' ) ) ), 0, 0, 'R', false, $this->website );
		}
	}

	/** UTF-8 to the Windows-1252 encoding FPDF core fonts use. */
	public function t( $s ) {
		$s = str_replace( array( '’', '‘', '“', '”', '–', '—', '…', '•', '★' ), array( "'", "'", '"', '"', '-', '-', '...', '-', '*' ), (string) $s );
		$c = function_exists( 'iconv' ) ? @iconv( 'UTF-8', 'windows-1252//TRANSLIT//IGNORE', $s ) : false;
		return false === $c ? preg_replace( '/[^\x20-\x7E]/', '', $s ) : $c;
	}

	public function RoundedRect( $x, $y, $w, $h, $r, $style = 'F' ) {
		$k   = $this->k;
		$hp  = $this->h;
		$op  = 'F' === $style ? 'f' : ( 'FD' === $style || 'DF' === $style ? 'B' : 'S' );
		$arc = 4 / 3 * ( M_SQRT2 - 1 );
		$this->_out( sprintf( '%.2F %.2F m', ( $x + $r ) * $k, ( $hp - $y ) * $k ) );
		$xc = $x + $w - $r;
		$yc = $y + $r;
		$this->_out( sprintf( '%.2F %.2F l', $xc * $k, ( $hp - $y ) * $k ) );
		$this->bez( $xc + $r * $arc, $yc - $r, $xc + $r, $yc - $r * $arc, $xc + $r, $yc );
		$xc = $x + $w - $r;
		$yc = $y + $h - $r;
		$this->_out( sprintf( '%.2F %.2F l', ( $x + $w ) * $k, ( $hp - $yc ) * $k ) );
		$this->bez( $xc + $r, $yc + $r * $arc, $xc + $r * $arc, $yc + $r, $xc, $yc + $r );
		$xc = $x + $r;
		$yc = $y + $h - $r;
		$this->_out( sprintf( '%.2F %.2F l', $xc * $k, ( $hp - ( $y + $h ) ) * $k ) );
		$this->bez( $xc - $r * $arc, $yc + $r, $xc - $r, $yc + $r * $arc, $xc - $r, $yc );
		$xc = $x + $r;
		$yc = $y + $r;
		$this->_out( sprintf( '%.2F %.2F l', $x * $k, ( $hp - $yc ) * $k ) );
		$this->bez( $xc - $r, $yc - $r * $arc, $xc - $r * $arc, $yc - $r, $xc, $yc - $r );
		$this->_out( $op );
	}

	protected function bez( $x1, $y1, $x2, $y2, $x3, $y3 ) {
		$h = $this->h;
		$k = $this->k;
		$this->_out( sprintf( '%.2F %.2F %.2F %.2F %.2F %.2F c', $x1 * $k, ( $h - $y1 ) * $k, $x2 * $k, ( $h - $y2 ) * $k, $x3 * $k, ( $h - $y3 ) * $k ) );
	}

	/** Stroke an arc. Angles in degrees, clockwise from 12 o'clock. */
	public function Arc( $xc, $yc, $r, $from, $to ) {
		if ( $to - $from <= 0 ) {
			return;
		}
		$pt  = function ( $deg ) use ( $xc, $yc, $r ) {
			$a = deg2rad( $deg );
			return array( $xc + $r * sin( $a ), $yc - $r * cos( $a ) );
		};
		$p0  = $pt( $from );
		$this->_out( sprintf( '%.2F %.2F m', $p0[0] * $this->k, ( $this->h - $p0[1] ) * $this->k ) );
		$segs = max( 1, (int) ceil( ( $to - $from ) / 90 ) );
		$step = ( $to - $from ) / $segs;
		for ( $i = 0; $i < $segs; $i++ ) {
			$a0 = deg2rad( $from + $i * $step );
			$a1 = deg2rad( $from + ( $i + 1 ) * $step );
			$kk = 4 / 3 * tan( ( $a1 - $a0 ) / 4 ) * $r;
			$s  = array( $xc + $r * sin( $a0 ), $yc - $r * cos( $a0 ) );
			$e  = array( $xc + $r * sin( $a1 ), $yc - $r * cos( $a1 ) );
			$this->bez( $s[0] + $kk * cos( $a0 ), $s[1] + $kk * sin( $a0 ), $e[0] - $kk * cos( $a1 ), $e[1] - $kk * sin( $a1 ), $e[0], $e[1] );
		}
		$this->_out( 'S' );
	}

	/** Left-aligned by default; justified text looks uneven with long URLs. */
	public function MultiCell( $w, $h, $txt, $border = 0, $align = 'L', $fill = false ) {
		parent::MultiCell( $w, $h, $txt, $border, $align, $fill );
	}

	public function LineCap( $round = true ) {
		$this->_out( $round ? '1 J' : '0 J' );
	}

	/** Number of lines a MultiCell of width $w will take. */
	public function NbLines( $w, $txt ) {
		$cw   = $this->CurrentFont['cw'];
		$wmax = ( $w - 2 * $this->cMargin ) * 1000 / $this->FontSize;
		$s    = str_replace( "\r", '', $txt );
		$nb   = strlen( $s );
		$sep  = -1;
		$i    = 0;
		$j    = 0;
		$l    = 0;
		$nl   = 1;
		while ( $i < $nb ) {
			$c = $s[ $i ];
			if ( "\n" === $c ) {
				$i++;
				$sep = -1;
				$j   = $i;
				$l   = 0;
				$nl++;
				continue;
			}
			if ( ' ' === $c ) {
				$sep = $i;
			}
			$l += isset( $cw[ $c ] ) ? $cw[ $c ] : 500;
			if ( $l > $wmax ) {
				if ( -1 === $sep ) {
					if ( $i === $j ) {
						$i++;
					}
				} else {
					$i = $sep + 1;
				}
				$sep = -1;
				$j   = $i;
				$l   = 0;
				$nl++;
			} else {
				$i++;
			}
		}
		return $nl;
	}
}

class VSA_Report {

	protected $pdf;
	protected $data;
	protected $opts;

	const STATUS = array(
		'pass' => array( 'label' => 'Passed', 'rgb' => array( 14, 159, 106 ) ),
		'warn' => array( 'label' => 'Needs work', 'rgb' => array( 199, 124, 0 ) ),
		'fail' => array( 'label' => 'Critical', 'rgb' => array( 214, 50, 46 ) ),
	);

	/**
	 * @param array $data  { checks, meta, score } as saved by the plugin.
	 * @param array $opts  brand, accent (hex), booking_url, contact_email, about, lead_name, logo_path.
	 */
	public function __construct( array $data, array $opts ) {
		$this->data = $data;
		$this->opts = array_merge(
			array(
				'brand'         => 'Vyntic Studio',
				'accent'        => '#c7431f',
				'booking_url'   => '',
				'contact_email' => '',
				'website'       => '',
				'about'         => '',
				'lead_name'     => '',
				'logo_path'     => '',
				'links'         => array(),
			),
			$opts
		);
	}

	public static function hex2rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) {
			return array( 199, 67, 31 );
		}
		return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
	}

	protected function score_rgb( $score ) {
		if ( null === $score ) {
			return array( 150, 150, 150 );
		}
		return $score >= 80 ? self::STATUS['pass']['rgb'] : ( $score >= 55 ? self::STATUS['warn']['rgb'] : self::STATUS['fail']['rgb'] );
	}

	/**
	 * Build the PDF and return it as a string. Nothing is written to disk.
	 */
	public function render() {
		$p          = new VSA_PDF( 'P', 'mm', 'A4' );
		$this->pdf  = $p;
		$p->brand   = $this->opts['brand'];
		$p->site    = $this->data['meta']['host'];
		$p->accent  = self::hex2rgb( $this->opts['accent'] );
		$p->website = $this->opts['website'];
		$p->AliasNbPages();
		$p->SetMargins( 15, 24, 15 );
		$p->SetAutoPageBreak( true, 18 );
		$p->SetTitle( $p->t( 'Website audit - ' . $this->data['meta']['host'] ) );
		$p->SetAuthor( $p->t( $this->opts['brand'] ) );

		$this->cover();
		$this->speed_page();
		foreach ( array( 'speed', 'seo', 'conversion', 'security', 'mobile' ) as $cat ) {
			$this->category_section( $cat );
		}
		$this->closing_page();

		return $p->Output( 'S' );
	}

	/* ------------------------------------------------------------------ */

	protected function cover() {
		$p     = $this->pdf;
		$score = $this->data['score'];
		$meta  = $this->data['meta'];
		$p->AddPage();

		// Top band.
		$p->SetFillColor( ...$p->ink );
		$p->Rect( 0, 0, 210, 92, 'F' );
		$p->SetFillColor( ...$p->accent );
		$p->Rect( 0, 92, 210, 2.2, 'F' );

		$logo_ok = false;
		if ( $this->opts['logo_path'] && file_exists( $this->opts['logo_path'] ) ) {
			try {
				$p->Image( $this->opts['logo_path'], 15, 14, 0, 10 );
				$logo_ok = true;
			} catch ( Exception $e ) {
				$logo_ok = false;
			}
		}
		if ( ! $logo_ok ) {
			$p->SetXY( 15, 14 );
			$p->SetFont( 'Helvetica', 'B', 13 );
			$p->SetTextColor( 255, 255, 255 );
			$p->Cell( 100, 10, $p->t( $this->opts['brand'] ) );
		}

		$p->SetXY( 110, 14 );
		$p->SetFont( 'Helvetica', '', 9 );
		$p->SetTextColor( ...$p->on_dark );
		$p->Cell( 85, 10, $p->t( date( 'j F Y' ) ), 0, 0, 'R' );

		$p->SetXY( 15, 40 );
		$p->SetFont( 'Helvetica', 'B', 10 );
		$p->SetTextColor( ...$p->accent );
		$p->Cell( 180, 6, $p->t( 'WEBSITE AUDIT REPORT' ) );
		$p->SetXY( 15, 48 );
		$p->SetFont( 'Helvetica', 'B', 26 );
		$p->SetTextColor( 255, 255, 255 );
		$p->Cell( 180, 13, $p->t( $meta['host'] ) );
		if ( $this->opts['lead_name'] ) {
			$p->SetXY( 15, 64 );
			$p->SetFont( 'Helvetica', '', 11 );
			$p->SetTextColor( ...$p->on_dark );
			$p->Cell( 180, 6, $p->t( 'Prepared for ' . $this->opts['lead_name'] ) );
		}
		$p->SetXY( 15, 72 );
		$p->SetFont( 'Helvetica', '', 9 );
		$p->SetTextColor( ...$p->on_dark );
		$p->Cell( 180, 6, $p->t( sprintf( '%d checks across speed, SEO, lead conversion, security and mobile.', array_sum( $score['counts'] ) ) ) );

		// Score gauge.
		$cx = 48;
		$cy = 130;
		$r  = 24;
		$p->LineCap( true );
		$p->SetLineWidth( 5 );
		$p->SetDrawColor( ...$p->line );
		$p->Arc( $cx, $cy, $r, 0, 359.9 );
		$p->SetDrawColor( ...$this->score_rgb( $score['overall'] ) );
		$p->Arc( $cx, $cy, $r, 0, max( 1, 359.9 * $score['overall'] / 100 ) );
		$p->LineCap( false );
		$p->SetLineWidth( 0.2 );

		$p->SetTextColor( ...$p->ink );
		$p->SetFont( 'Helvetica', 'B', 30 );
		$p->SetXY( $cx - 20, $cy - 9 );
		$p->Cell( 40, 12, (string) $score['overall'], 0, 0, 'C' );
		$p->SetFont( 'Helvetica', '', 8 );
		$p->SetTextColor( ...$p->muted );
		$p->SetXY( $cx - 20, $cy + 3 );
		$p->Cell( 40, 5, 'out of 100', 0, 0, 'C' );

		// Summary beside gauge.
		$p->SetXY( 90, 108 );
		$p->SetFont( 'Helvetica', 'B', 16 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 105, 8, $p->t( 'Grade ' . $score['grade'] . ': ' . $this->verdict( $score['overall'] ) ) );
		$p->SetXY( 90, 118 );
		$p->SetFont( 'Helvetica', '', 10 );
		$p->SetTextColor( ...$p->muted );
		$p->MultiCell( 105, 5.2, $p->t( $this->summary_sentence( $score ) ) );

		$y = max( $p->GetY() + 4, 138 );
		$x = 90;
		foreach ( array( 'fail', 'warn', 'pass' ) as $st ) {
			$p->SetFillColor( ...self::STATUS[ $st ]['rgb'] );
			$p->RoundedRect( $x, $y + 1.2, 3, 3, 1.5, 'F' );
			$p->SetXY( $x + 4.5, $y );
			$p->SetFont( 'Helvetica', 'B', 10 );
			$p->SetTextColor( ...$p->ink );
			$words = array( 'fail' => 'critical', 'warn' => 'need work', 'pass' => 'passed' );
			$label = $score['counts'][ $st ] . ' ' . $words[ $st ];
			$w     = $p->GetStringWidth( $label ) + 9;
			$p->Cell( $w, 5.5, $p->t( $label ) );
			$x += $w + 2;
		}

		// Category bars.
		$y = 162;
		$p->SetXY( 15, $y );
		$p->SetFont( 'Helvetica', 'B', 12 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 180, 7, 'Scores by area' );
		$y += 11;
		foreach ( $score['categories'] as $cat ) {
			if ( null === $cat['score'] ) {
				continue;
			}
			$p->SetXY( 15, $y );
			$p->SetFont( 'Helvetica', '', 10 );
			$p->SetTextColor( ...$p->ink );
			$p->Cell( 55, 6, $p->t( $cat['label'] ) );
			$p->SetFillColor( ...$p->mist );
			$p->RoundedRect( 72, $y + 1.5, 105, 3.2, 1.6, 'F' );
			$p->SetFillColor( ...$this->score_rgb( $cat['score'] ) );
			$p->RoundedRect( 72, $y + 1.5, max( 3.2, 105 * $cat['score'] / 100 ), 3.2, 1.6, 'F' );
			$p->SetXY( 180, $y );
			$p->SetFont( 'Helvetica', 'B', 10 );
			$p->Cell( 15, 6, (string) $cat['score'], 0, 0, 'R' );
			$y += 8;
		}

		// Priorities.
		if ( ! empty( $score['priorities'] ) ) {
			$y += 3;
			$p->SetXY( 15, $y );
			$p->SetFont( 'Helvetica', 'B', 12 );
			$p->SetTextColor( ...$p->ink );
			$p->Cell( 180, 7, 'Fix these first' );
			$y += 9;
			$n = 1;
			foreach ( array_slice( $score['priorities'], 0, 4 ) as $issue ) {
				if ( $y > 266 ) {
					break;
				}
				$p->SetFillColor( ...self::STATUS[ $issue['status'] ]['rgb'] );
				$p->RoundedRect( 15, $y, 6, 6, 3, 'F' );
				$p->SetXY( 15, $y );
				$p->SetFont( 'Helvetica', 'B', 8 );
				$p->SetTextColor( 255, 255, 255 );
				$p->Cell( 6, 6, (string) $n, 0, 0, 'C' );
				$p->SetXY( 24, $y - 0.3 );
				$p->SetFont( 'Helvetica', 'B', 10 );
				$p->SetTextColor( ...$p->ink );
				$p->Cell( 171, 6, $p->t( $issue['title'] ) );
				$p->SetXY( 24, $y + 5.5 );
				$p->SetFont( 'Helvetica', '', 9 );
				$p->SetTextColor( ...$p->muted );
				$txt = $p->t( $issue['finding'] );
				$p->MultiCell( 171, 4.5, $txt );
				$y = $p->GetY() + 2;
				$n++;
			}
		}
	}

	protected function speed_page() {
		$psi = isset( $this->data['meta']['psi'] ) ? $this->data['meta']['psi'] : null;
		if ( empty( $psi ) || null === $psi['performance'] ) {
			return;
		}
		$p = $this->pdf;
		$p->AddPage();
		$this->h1( 'How fast your site feels on a phone' );
		$this->para( 'Measured with Google Lighthouse on a simulated mid-range phone over a mobile connection, the same engine behind Google PageSpeed Insights.' );

		$top  = $p->GetY() + 4;
		$shot = $this->screenshot_file();
		$left = 15;
		if ( $shot ) {
			$size = @getimagesize( $shot );
			if ( $size ) {
				$w = 50;
				$h = min( 105, $w * $size[1] / $size[0] );
				$p->SetDrawColor( ...$p->line );
				$p->SetLineWidth( 0.4 );
				$p->Rect( 15 - 0.5, $top - 0.5, $w + 1, $h + 1 );
				$p->Image( $shot, 15, $top, $w, $h );
				$left = 75;
			}
			@unlink( $shot );
		}

		$rows = array(
			array( 'Performance score', null !== $psi['performance'] ? $psi['performance'] . ' / 100' : '-', 'Aim for 90+', $this->grade3( $psi['performance'], 90, 50, true ) ),
			array( 'Main content visible (LCP)', null !== $psi['lcp'] ? sprintf( '%.1f s', $psi['lcp'] / 1000 ) : '-', '2.5 s or less', $this->grade3( $psi['lcp'], 2500, 4000 ) ),
			array( 'First content (FCP)', null !== $psi['fcp'] ? sprintf( '%.1f s', $psi['fcp'] / 1000 ) : '-', '1.8 s or less', $this->grade3( $psi['fcp'], 1800, 3000 ) ),
			array( 'Page frozen (TBT)', null !== $psi['tbt'] ? sprintf( '%d ms', $psi['tbt'] ) : '-', '200 ms or less', $this->grade3( $psi['tbt'], 200, 600 ) ),
			array( 'Layout shift (CLS)', null !== $psi['cls'] ? sprintf( '%.2f', $psi['cls'] ) : '-', '0.1 or less', $this->grade3( $psi['cls'], 0.1, 0.25 ) ),
			array( 'Speed index', null !== $psi['si'] ? sprintf( '%.1f s', $psi['si'] / 1000 ) : '-', '3.4 s or less', $this->grade3( $psi['si'], 3400, 5800 ) ),
		);
		$w = 195 - $left;
		$y = $top;
		foreach ( $rows as $row ) {
			$p->SetFillColor( ...self::STATUS[ $row[3] ]['rgb'] );
			$p->RoundedRect( $left, $y + 3.2, 2.6, 2.6, 1.3, 'F' );
			$p->SetXY( $left + 5, $y );
			$p->SetFont( 'Helvetica', '', 10 );
			$p->SetTextColor( ...$p->ink );
			$p->Cell( $w * 0.52, 9, $p->t( $row[0] ) );
			$p->SetFont( 'Helvetica', 'B', 11 );
			$p->Cell( $w * 0.2, 9, $p->t( $row[1] ), 0, 0, 'R' );
			$p->SetFont( 'Helvetica', '', 8 );
			$p->SetTextColor( ...$p->muted );
			$p->Cell( $w * 0.28 - 5, 9, $p->t( $row[2] ), 0, 0, 'R' );
			$p->SetDrawColor( ...$p->line );
			$p->SetLineWidth( 0.2 );
			$p->Line( $left, $y + 9, 195, $y + 9 );
			$y += 10;
		}

		$y += 4;
		$others = array( 'Accessibility' => $psi['accessibility'], 'Best practices' => $psi['best_practices'], 'Technical SEO' => $psi['seo'] );
		$bx     = $left;
		$bw     = ( $w - 8 ) / 3;
		foreach ( $others as $label => $val ) {
			$p->SetFillColor( ...$p->mist );
			$p->RoundedRect( $bx, $y, $bw, 20, 2.5, 'F' );
			$p->SetXY( $bx, $y + 3 );
			$p->SetFont( 'Helvetica', 'B', 15 );
			$p->SetTextColor( ...$this->score_rgb( $val ) );
			$p->Cell( $bw, 7, null === $val ? '-' : (string) $val, 0, 0, 'C' );
			$p->SetXY( $bx, $y + 11 );
			$p->SetFont( 'Helvetica', '', 8 );
			$p->SetTextColor( ...$p->muted );
			$p->Cell( $bw, 5, $p->t( $label ), 0, 0, 'C' );
			$bx += $bw + 4;
		}
		$y += 26;

		if ( $psi['field'] ) {
			$p->SetXY( $left, $y );
			$p->SetFont( 'Helvetica', '', 9 );
			$p->SetTextColor( ...$p->muted );
			$map = array( 'FAST' => 'good', 'AVERAGE' => 'needs improvement', 'SLOW' => 'poor' );
			$p->MultiCell( $w, 4.6, $p->t( 'Real Chrome users over the last 28 days rate this page\'s experience as ' . ( isset( $map[ $psi['field'] ] ) ? $map[ $psi['field'] ] : strtolower( $psi['field'] ) ) . '.' ) );
			$y = $p->GetY() + 2;
		}

		$p->SetY( max( $y, $top + 110 ) + 4 );
		if ( ! empty( $psi['opportunities'] ) ) {
			$this->h2( 'Biggest time savings Google found' );
			foreach ( $psi['opportunities'] as $opp ) {
				$p->SetX( 15 );
				$p->SetFont( 'Helvetica', '', 10 );
				$p->SetTextColor( ...$p->ink );
				$p->Cell( 150, 7, $p->t( $opp['title'] ) );
				$p->SetFont( 'Helvetica', 'B', 10 );
				$p->SetTextColor( ...self::STATUS['fail']['rgb'] );
				$p->Cell( 30, 7, $p->t( 'save ' . $opp['savings'] . ' s' ), 0, 1, 'R' );
				$p->SetDrawColor( ...$p->line );
				$p->Line( 15, $p->GetY(), 195, $p->GetY() );
			}
		}
	}

	protected function category_section( $cat ) {
		$checks = array_values( array_filter( $this->data['checks'], function ( $c ) use ( $cat ) {
			return $c['category'] === $cat && 'info' !== $c['status'];
		} ) );
		if ( ! $checks ) {
			return;
		}
		usort( $checks, function ( $a, $b ) {
			$rank = array( 'fail' => 0, 'warn' => 1, 'pass' => 2 );
			return array( $rank[ $a['status'] ], -$a['weight'] ) <=> array( $rank[ $b['status'] ], -$b['weight'] );
		} );

		$p     = $this->pdf;
		$info  = $this->data['score']['categories'][ $cat ];
		$p->AddPage();

		$p->SetFont( 'Helvetica', 'B', 18 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 150, 10, $p->t( $info['label'] ) );
		$p->SetFont( 'Helvetica', 'B', 18 );
		$p->SetTextColor( ...$this->score_rgb( $info['score'] ) );
		$p->Cell( 30, 10, $info['score'] . '/100', 0, 1, 'R' );
		$p->SetFont( 'Helvetica', '', 9 );
		$p->SetTextColor( ...$p->muted );
		$p->Cell( 180, 5, $p->t( sprintf( '%d critical, %d need work, %d passed', $info['fail'], $info['warn'], $info['pass'] ) ), 0, 1 );
		$p->Ln( 4 );

		foreach ( $checks as $c ) {
			$this->check_block( $c );
		}
		$this->help_box( $cat, $info );
	}

	/** "How we can help" box at the end of a section, linking to the matching service page. */
	protected function help_box( $cat, $info ) {
		if ( empty( $this->opts['links']['sections'][ $cat ] ) ) {
			return;
		}
		list( $label, $url ) = $this->opts['links']['sections'][ $cat ];
		$p = $this->pdf;
		if ( $p->GetY() + 30 > 277 ) {
			$p->AddPage();
		}
		$y     = $p->GetY() + 2;
		$fixes = $info['fail'] + $info['warn'];
		$text  = $fixes
			? sprintf( 'We can fix the %d %s in this section for you. See how our %s service works, with a fixed price before any work starts.', $fixes, 1 === $fixes ? 'issue' : 'issues', strtolower( $label ) )
			: sprintf( 'This area is in good shape. If you want to keep it that way, see our %s service.', strtolower( $label ) );
		$p->SetFillColor( ...$p->mist );
		$p->RoundedRect( 15, $y, 180, 26, 3, 'F' );
		$p->SetFillColor( ...$p->accent );
		$p->Rect( 15, $y + 4, 1.2, 18, 'F' );
		$p->SetXY( 21, $y + 4 );
		$p->SetFont( 'Helvetica', 'B', 10.5 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 170, 6, $p->t( 'How ' . $this->opts['brand'] . ' can help' ), 0, 2 );
		$p->SetFont( 'Helvetica', '', 9 );
		$p->SetTextColor( ...$p->muted );
		$p->MultiCell( 168, 4.6, $p->t( $text ) );
		$p->SetX( 21 );
		$p->SetFont( 'Helvetica', 'B', 9.5 );
		$p->SetTextColor( ...$p->accent );
		$p->Cell( 168, 6, $p->t( $label . ' ->' ), 0, 1, 'L', false, $url );
		$p->SetY( $y + 30 );
	}

	protected function check_block( array $c ) {
		$p       = $this->pdf;
		$tw      = 150;
		$detail  = 'pass' !== $c['status'] && ( $c['impact'] || $c['fix'] );
		$p->SetFont( 'Helvetica', '', 9.5 );
		$lines   = $p->NbLines( $tw, $p->t( $c['finding'] ) );
		$height  = 8 + $lines * 4.8;
		if ( $detail ) {
			$p->SetFont( 'Helvetica', '', 9 );
			$height += ( $p->NbLines( $tw - 24, $p->t( $c['impact'] ) ) + $p->NbLines( $tw - 24, $p->t( $c['fix'] ) ) ) * 4.6 + 6;
		}
		if ( $p->GetY() + $height > 277 ) {
			$p->AddPage();
		}

		$y  = $p->GetY();
		$st = self::STATUS[ $c['status'] ];

		// Status pill.
		$p->SetFillColor( ...$st['rgb'] );
		$p->RoundedRect( 15, $y + 0.8, 24, 5.4, 2.7, 'F' );
		$p->SetXY( 15, $y + 0.8 );
		$p->SetFont( 'Helvetica', 'B', 7.5 );
		$p->SetTextColor( 255, 255, 255 );
		$p->Cell( 24, 5.4, $p->t( $st['label'] ), 0, 0, 'C' );

		$p->SetXY( 44, $y );
		$p->SetFont( 'Helvetica', 'B', 11 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( $tw, 7, $p->t( $c['title'] ), 0, 2 );
		$p->SetFont( 'Helvetica', '', 9.5 );
		$p->SetTextColor( 70, 76, 90 );
		$p->MultiCell( $tw, 4.8, $p->t( $c['finding'] ) );

		if ( $detail ) {
			$p->Ln( 1.5 );
			foreach ( array( 'Why it matters' => $c['impact'], 'How to fix' => $c['fix'] ) as $label => $txt ) {
				if ( ! $txt ) {
					continue;
				}
				$p->SetX( 44 );
				$p->SetFont( 'Helvetica', 'B', 9 );
				$p->SetTextColor( ...$p->ink );
				$p->Cell( 24, 4.6, $p->t( $label ) );
				$p->SetFont( 'Helvetica', '', 9 );
				$p->SetTextColor( 70, 76, 90 );
				$p->MultiCell( $tw - 24, 4.6, $p->t( $txt ) );
				$p->Ln( 0.8 );
			}
		}

		$p->Ln( 3 );
		$p->SetDrawColor( ...$p->line );
		$p->SetLineWidth( 0.2 );
		$p->Line( 15, $p->GetY(), 195, $p->GetY() );
		$p->Ln( 4 );
	}

	protected function closing_page() {
		$p = $this->pdf;
		$p->AddPage();

		$p->SetFillColor( ...$p->ink );
		$p->RoundedRect( 15, 30, 180, 68, 4, 'F' );
		$p->SetXY( 25, 42 );
		$p->SetFont( 'Helvetica', 'B', 20 );
		$p->SetTextColor( 255, 255, 255 );
		$p->Cell( 160, 10, $p->t( 'Want these issues fixed?' ) );
		$p->SetXY( 25, 56 );
		$p->SetFont( 'Helvetica', '', 11 );
		$p->SetTextColor( ...$p->on_dark );
		$issues = $this->data['score']['counts']['fail'] + $this->data['score']['counts']['warn'];
		$p->MultiCell( 160, 5.8, $p->t( sprintf( 'We found %d things holding %s back. Book a free 15-minute call and we will walk you through the fixes that will bring in the most enquiries, with a clear quote and timeline.', $issues, $this->data['meta']['host'] ) ) );

		$y = max( 76, $p->GetY() + 8 );
		if ( $this->opts['booking_url'] ) {
			$p->SetFillColor( ...$p->accent );
			$p->RoundedRect( 25, $y, 70, 12, 6, 'F' );
			$p->SetXY( 25, $y );
			$p->SetFont( 'Helvetica', 'B', 11 );
			$p->SetTextColor( 255, 255, 255 );
			$p->Cell( 70, 12, $p->t( 'Book a free call' ), 0, 0, 'C', false, $this->opts['booking_url'] );
		}
		if ( $this->opts['contact_email'] ) {
			$p->SetXY( $this->opts['booking_url'] ? 102 : 25, $y );
			$p->SetFont( 'Helvetica', '', 10 );
			$p->SetTextColor( ...$p->on_dark );
			$p->Cell( 85, 12, $p->t( 'or email ' . $this->opts['contact_email'] ), 0, 0, 'L', false, 'mailto:' . $this->opts['contact_email'] );
		}

		$p->SetXY( 15, 112 );
		if ( $this->opts['about'] ) {
			$this->h2( 'About ' . $this->opts['brand'] );
			$this->para( $this->opts['about'] );
			if ( $this->opts['website'] ) {
				$p->SetFont( 'Helvetica', 'B', 10 );
				$p->SetTextColor( ...$p->accent );
				$p->Cell( 180, 6, $p->t( preg_replace( '#^https?://#', '', rtrim( $this->opts['website'], '/' ) ) ), 0, 1, 'L', false, $this->opts['website'] );
			}
			$p->Ln( 6 );
		}

		$this->link_lists();

		$this->h2( 'About this report' );
		$this->para( sprintf(
			'This is an automated snapshot of %s taken on %s. It checks the homepage only, using publicly available information and Google Lighthouse lab data. Results can vary between tests, and a full manual review may uncover further issues, including on inner pages.',
			$this->data['meta']['final_url'],
			date( 'j F Y' )
		) );
		if ( ! empty( $this->data['meta']['technologies'] ) ) {
			$p->Ln( 2 );
			$this->para( 'Technology detected: ' . implode( ', ', $this->data['meta']['technologies'] ) . '.' );
		}
	}

	/* ------------------------------------------------------------------ */

	/** Two columns of clickable links: our services and free guides. */
	protected function link_lists() {
		$links = $this->opts['links'];
		if ( empty( $links['services'] ) && empty( $links['guides'] ) ) {
			return;
		}
		$p   = $this->pdf;
		$top = $p->GetY();
		if ( $top + 60 > 277 ) {
			$p->AddPage();
			$top = $p->GetY();
		}
		$cols = array(
			array( 15, 'Our services', isset( $links['services'] ) ? $links['services'] : array() ),
			array( 108, 'Free guides', isset( $links['guides'] ) ? $links['guides'] : array() ),
		);
		$bottom = $top;
		foreach ( $cols as $col ) {
			list( $x, $title, $items ) = $col;
			if ( ! $items ) {
				continue;
			}
			$p->SetXY( $x, $top );
			$p->SetFont( 'Helvetica', 'B', 12 );
			$p->SetTextColor( ...$p->ink );
			$p->Cell( 87, 8, $p->t( $title ), 0, 2 );
			foreach ( $items as $item ) {
				$y = $p->GetY();
				$p->SetFillColor( ...$p->accent );
				$p->RoundedRect( $x, $y + 2.6, 1.8, 1.8, 0.9, 'F' );
				$p->SetXY( $x + 4, $y );
				$p->SetFont( 'Helvetica', '', 10 );
				$p->SetTextColor( ...$p->accent );
				$p->Cell( 83, 7, $p->t( $item[0] ), 0, 2, 'L', false, $item[1] );
				$p->SetX( $x );
			}
			$bottom = max( $bottom, $p->GetY() );
		}
		$p->SetXY( 15, $bottom + 6 );
	}

	protected function h1( $txt ) {
		$p = $this->pdf;
		$p->SetFont( 'Helvetica', 'B', 18 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 180, 10, $p->t( $txt ), 0, 1 );
	}

	protected function h2( $txt ) {
		$p = $this->pdf;
		$p->SetFont( 'Helvetica', 'B', 12 );
		$p->SetTextColor( ...$p->ink );
		$p->Cell( 180, 8, $p->t( $txt ), 0, 1 );
	}

	protected function para( $txt ) {
		$p = $this->pdf;
		$p->SetFont( 'Helvetica', '', 10 );
		$p->SetTextColor( ...$p->muted );
		$p->MultiCell( 180, 5.2, $p->t( $txt ) );
	}

	protected function grade3( $v, $good, $ok, $higher_is_better = false ) {
		if ( null === $v ) {
			return 'warn';
		}
		if ( $higher_is_better ) {
			return $v >= $good ? 'pass' : ( $v >= $ok ? 'warn' : 'fail' );
		}
		return $v <= $good ? 'pass' : ( $v <= $ok ? 'warn' : 'fail' );
	}

	protected function verdict( $score ) {
		if ( $score >= 90 ) {
			return 'excellent';
		}
		if ( $score >= 80 ) {
			return 'good, with room to grow';
		}
		if ( $score >= 70 ) {
			return 'fair';
		}
		if ( $score >= 55 ) {
			return 'underperforming';
		}
		return 'losing you customers';
	}

	protected function summary_sentence( $score ) {
		$cats = array_filter( $score['categories'], function ( $c ) {
			return null !== $c['score'];
		} );
		uasort( $cats, function ( $a, $b ) {
			return $a['score'] <=> $b['score'];
		} );
		$weakest = reset( $cats );
		$best    = end( $cats );
		if ( $score['counts']['fail'] === 0 && $score['counts']['warn'] === 0 ) {
			return 'Every check passed. Your homepage is in excellent shape.';
		}
		return sprintf(
			'Your strongest area is %s (%d). The biggest opportunity is %s (%d), which is where fixes will make the most difference to enquiries.',
			strtolower( $best['label'] ), $best['score'], strtolower( $weakest['label'] ), $weakest['score']
		);
	}

	protected function screenshot_file() {
		$data = isset( $this->data['meta']['screenshot'] ) ? $this->data['meta']['screenshot'] : '';
		if ( ! $data || ! preg_match( '#^data:image/(jpeg|jpg|png);base64,(.+)$#s', $data, $m ) ) {
			return '';
		}
		$bin = base64_decode( $m[2] );
		if ( ! $bin ) {
			return '';
		}
		$file = rtrim( sys_get_temp_dir(), '/' ) . '/vsa-shot-' . bin2hex( random_bytes( 6 ) ) . '.' . ( 'png' === $m[1] ? 'png' : 'jpg' );
		file_put_contents( $file, $bin );
		return $file;
	}
}
