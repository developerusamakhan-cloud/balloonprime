/**
 * Vyntic Index Assistant admin: buttons, tabs, filters, paging and the settings
 * form work over AJAX, without reloading the page. Without JavaScript the same
 * links and forms still work as normal page loads.
 */
( function () {
	'use strict';

	var app = document.querySelector( '.sia-app' );
	if ( ! app || ! window.SIA ) {
		return;
	}
	var body = app.querySelector( '#sia-body' );
	var toasts = app.querySelector( '.sia-toasts' );
	var i18n = SIA.i18n || {};
	var busy = false;

	/* -------------------------------------------------------------------
	 * WordPress notices: keep them out of the banner.
	 * Some plugins insert notices after the first heading they find. Anything
	 * that lands inside the banner is moved to just below it.
	 * ----------------------------------------------------------------- */
	var header = app.querySelector( '.vy-header' );
	var headerEnd = app.querySelector( '.wp-header-end' );
	function rescueNotices() {
		if ( ! header || ! headerEnd ) {
			return;
		}
		var found = header.querySelectorAll( '.notice, .updated, .error, .update-nag, .notice-warning' );
		var after = headerEnd;
		Array.prototype.forEach.call( found, function ( el ) {
			after.parentNode.insertBefore( el, after.nextSibling );
			after = el;
		} );
	}
	rescueNotices();
	if ( header && window.MutationObserver ) {
		new MutationObserver( rescueNotices ).observe( header, { childList: true, subtree: true } );
	}

	/* -------------------------------------------------------------------
	 * Toasts
	 * ----------------------------------------------------------------- */
	function toast( type, text ) {
		if ( ! toasts || ! text ) {
			return;
		}
		var el = document.createElement( 'div' );
		el.className = 'sia-toast sia-toast--' + ( type || 'info' );
		var msg = document.createElement( 'span' );
		msg.className = 'sia-toast__text';
		msg.textContent = text;
		var close = document.createElement( 'button' );
		close.type = 'button';
		close.className = 'sia-toast__close';
		close.setAttribute( 'aria-label', i18n.close || 'Dismiss' );
		close.innerHTML = '&times;';
		close.addEventListener( 'click', function () {
			hide( el );
		} );
		el.appendChild( msg );
		el.appendChild( close );
		toasts.appendChild( el );
		requestAnimationFrame( function () {
			el.classList.add( 'is-in' );
		} );
		// Errors and warnings stay until closed; good news fades after a few seconds.
		if ( 'success' === type || 'info' === type ) {
			setTimeout( function () {
				hide( el );
			}, 6000 );
		}
	}
	function hide( el ) {
		el.classList.remove( 'is-in' );
		setTimeout( function () {
			if ( el.parentNode ) {
				el.parentNode.removeChild( el );
			}
		}, 250 );
	}

	/* -------------------------------------------------------------------
	 * Requests
	 * ----------------------------------------------------------------- */
	function post( data ) {
		data.append( 'nonce', SIA.nonce );
		return fetch( SIA.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data } ).then( function ( res ) {
			return res.text().then( function ( raw ) {
				var json = null;
				try {
					json = JSON.parse( raw );
				} catch ( e ) {
					// admin-ajax answers "0" or "-1" when the login or nonce has expired.
					throw new Error( '0' === raw.trim() || '-1' === raw.trim() ? i18n.expired : i18n.failed );
				}
				if ( ! json || ! json.success ) {
					throw new Error( json && json.data && json.data.text ? json.data.text : i18n.failed );
				}
				return json.data;
			} );
		} );
	}

	function setLoading( on ) {
		busy = on;
		body.classList.toggle( 'is-loading', on );
		body.setAttribute( 'aria-busy', on ? 'true' : 'false' );
	}

	function swap( html ) {
		body.innerHTML = html;
	}

	function currentArgs() {
		var q = new URLSearchParams( window.location.search );
		return {
			tab: 'settings' === q.get( 'tab' ) ? 'settings' : 'dashboard',
			status: q.get( 'status' ) || '',
			paged: q.get( 'paged' ) || ''
		};
	}

	function setActiveTab( tab ) {
		app.setAttribute( 'data-tab', tab );
		Array.prototype.forEach.call( app.querySelectorAll( '.vy-tab[data-sia-tab]' ), function ( a ) {
			var on = a.getAttribute( 'data-sia-tab' ) === tab;
			a.classList.toggle( 'is-active', on );
			if ( on ) {
				a.setAttribute( 'aria-current', 'page' );
			} else {
				a.removeAttribute( 'aria-current' );
			}
		} );
	}

	/**
	 * Load a tab, filter or page into the body.
	 *
	 * @param {string}  href Link to load (same admin page).
	 * @param {boolean} push Add a browser history entry.
	 */
	function loadView( href, push ) {
		if ( busy ) {
			return;
		}
		var url = new URL( href, window.location.href );
		var tab = 'settings' === url.searchParams.get( 'tab' ) ? 'settings' : 'dashboard';
		var data = new FormData();
		data.append( 'action', 'sia_view' );
		data.append( 'tab', tab );
		[ 'status', 'paged' ].forEach( function ( key ) {
			if ( url.searchParams.get( key ) ) {
				data.append( key, url.searchParams.get( key ) );
			}
		} );
		setLoading( true );
		post( data )
			.then( function ( res ) {
				swap( res.html );
				setActiveTab( res.tab );
				if ( push ) {
					history.pushState( { sia: true }, '', url.pathname + url.search + url.hash );
				}
				if ( url.hash ) {
					var target = document.getElementById( url.hash.slice( 1 ) );
					if ( target ) {
						target.scrollIntoView( { behavior: 'smooth', block: 'start' } );
					}
				} else if ( push ) {
					app.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}
			} )
			.catch( function ( err ) {
				toast( 'error', err.message );
			} )
			.then( function () {
				setLoading( false );
			} );
	}

	function buttonBusy( btn, on, label ) {
		if ( ! btn ) {
			return;
		}
		if ( on ) {
			btn.setAttribute( 'data-label', btn.textContent );
			btn.disabled = true;
			btn.classList.add( 'is-busy' );
			btn.innerHTML = '<span class="sia-spinner" aria-hidden="true"></span>' + ( label || i18n.working || '' );
		} else {
			btn.disabled = false;
			btn.classList.remove( 'is-busy' );
			btn.textContent = btn.getAttribute( 'data-label' ) || btn.textContent;
		}
	}

	/* -------------------------------------------------------------------
	 * Action buttons (Run a batch, Test connection, Done, Check next run, Resume)
	 * ----------------------------------------------------------------- */
	function runAction( form ) {
		if ( busy ) {
			return;
		}
		var action = form.getAttribute( 'data-sia-action' );
		var btn = form.querySelector( 'button' );
		var args = currentArgs();
		var data = new FormData();
		data.append( 'action', 'sia_action' );
		data.append( 'sia_action', action );
		if ( form.getAttribute( 'data-sia-id' ) ) {
			data.append( 'id', form.getAttribute( 'data-sia-id' ) );
		}
		if ( args.status ) {
			data.append( 'status', args.status );
		}
		if ( args.paged ) {
			data.append( 'paged', args.paged );
		}
		var row = form.closest( 'tr' );
		if ( row ) {
			row.classList.add( 'is-working' );
		}
		buttonBusy( btn, true, 'run' === action ? i18n.running : i18n.working );
		busy = true;
		post( data )
			.then( function ( res ) {
				var scroll = window.scrollY;
				if ( 'dashboard' === app.getAttribute( 'data-tab' ) ) {
					swap( res.html );
					window.scrollTo( 0, scroll );
				}
				toast( res.type, res.text );
			} )
			.catch( function ( err ) {
				buttonBusy( btn, false );
				if ( row ) {
					row.classList.remove( 'is-working' );
				}
				toast( 'error', err.message );
			} )
			.then( function () {
				busy = false;
			} );
	}

	/* -------------------------------------------------------------------
	 * Settings form
	 * ----------------------------------------------------------------- */
	function saveSettings( form ) {
		if ( busy ) {
			return;
		}
		var btn = form.querySelector( 'button[type="submit"]' );
		var data = new FormData( form );
		data.set( 'action', 'sia_save_settings' );
		buttonBusy( btn, true, i18n.saving );
		busy = true;
		post( data )
			.then( function ( res ) {
				var scroll = window.scrollY;
				swap( res.html );
				window.scrollTo( 0, scroll );
				toast( res.type, res.text );
			} )
			.catch( function ( err ) {
				buttonBusy( btn, false );
				toast( 'error', err.message );
			} )
			.then( function () {
				busy = false;
			} );
	}

	/* -------------------------------------------------------------------
	 * Event wiring (delegated, so it keeps working after the body is replaced)
	 * ----------------------------------------------------------------- */
	app.addEventListener( 'submit', function ( e ) {
		var form = e.target;
		if ( form.matches( '.sia-inline-form[data-sia-action]' ) ) {
			e.preventDefault();
			runAction( form );
		} else if ( 'sia-settings-form' === form.id ) {
			e.preventDefault();
			saveSettings( form );
		}
	} );

	app.addEventListener( 'click', function ( e ) {
		if ( e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey ) {
			return;
		}
		var link = e.target.closest( 'a[data-sia-tab], a[data-sia-nav], .sia-pagination a' );
		if ( ! link || ! app.contains( link ) ) {
			return;
		}
		e.preventDefault();
		loadView( link.href, true );
	} );

	window.addEventListener( 'popstate', function () {
		loadView( window.location.href, false );
	} );
}() );
