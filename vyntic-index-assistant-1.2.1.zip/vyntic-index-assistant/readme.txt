=== Vyntic Index Assistant ===
Contributors: vyntic
Author: Vyntic Studio
Author URI: https://vyntic.studio/
Plugin URI: https://vyntic.studio/plugins/safe-index-assistant/
Tags: google index, search console, indexing, sitemap, indexnow
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Finds which posts and pages Google has not indexed, explains why, and helps get them indexed only in ways Google allows, within strict daily limits.

== Description ==

Most "instant indexing" plugins push normal blog posts through the Google Indexing API. Google only allows that API for job postings and livestream (BroadcastEvent) pages. Other use is against its policy and can get API access revoked. This plugin does **not** use the Indexing API.

What it does instead:

1. **Checks index status** of your posts and pages with the official Search Console **URL Inspection API**. That API only reads status; it is allowed for every site.
2. **Explains why** a page is not indexed: "Crawled: currently not indexed", "Discovered: currently not indexed", noindex, robots.txt, canonical/duplicate, soft 404, server errors. It also gives local hints such as thin content (word count) and pages that no other post links to.
3. **Suggests internal links**: indexed posts from the same category that could link to the page.
4. **Today's request list**: up to 10 not-indexed pages a day with a direct "Open in Search Console" button, so you can click "Request indexing" yourself. Google offers no API for that button on normal pages.
5. **Resubmits your sitemap** to Search Console, at most once per 24 hours and only when posts were published or updated.
6. **IndexNow** (optional), for Bing, Yandex, Seznam, Naver and Yep. It sends only new or changed URLs, each URL at most once per 24 hours. Google does not use IndexNow.
7. A **"Google" column** in the Posts/Pages lists.

= Limits (built in, cannot be raised from Settings) =

* URL checks: Google allows 2,000/day per property. The plugin never does more than **1,000/day**, and the default is 100.
* Checks are **spread over the day**: a background run every 15 minutes checks at most 10 URLs, with a 1.5-second pause between calls. That is at most about 40 calls a minute; Google allows 600.
* Usage is counted *before* each call, per Pacific day, because Google's quota resets at midnight Pacific time.
* If Google answers "quota exceeded" (429), everything stops until Google's quota resets. If it answers "permission denied", the plugin pauses until you fix it.
* New posts are first checked after 3 days, because checking earlier wastes quota. Indexed pages are re-checked every 30 days and not-indexed pages every 7 days.
* Pages marked noindex in Yoast, Rank Math or SEOPress, and password-protected pages, are never sent to Google.
* Manual request list: max 10 a day. Search Console's own button allows about 10 to 12.
* Sitemap: max once per 24 hours. IndexNow: max 1,000 URLs/day, and the default is 100.

= Honest note =

No tool can force Google to index a page. "Crawled: currently not indexed" is Google's quality decision. The plugin shows you *which* pages and *why*; better content and internal links are what actually get them indexed.

== Installation ==

1. In WordPress go to Plugins, Add New, Upload Plugin, choose `vyntic-index-assistant.zip` and activate.
2. In [Google Cloud Console](https://console.cloud.google.com/) create a project and enable **Google Search Console API**.
3. IAM & Admin > Service Accounts > Create service account > Keys > Add key > JSON.
4. In [Search Console](https://search.google.com/search-console) > Settings > Users and permissions > Add user: the service account email (`…@….iam.gserviceaccount.com`), permission **Full**.
5. Vyntic, Index Assistant, Settings tab: paste the JSON key, enter your property exactly as in Search Console (`https://example.com/` or `sc-domain:example.com`) and save.
6. Dashboard tab, "Test Google connection". This uses no inspection quota.

Optional: instead of pasting the key, add it to wp-config.php:

`define( 'SIA_SERVICE_ACCOUNT_JSON', '{"type":"service_account", ... }' );`

= WP-Cron =

Background runs use WP-Cron. On low-traffic sites, or with `DISABLE_WP_CRON`, add a real cron job that calls `wp-cron.php` every 15 minutes.

== Frequently Asked Questions ==

= Does this use the Google Indexing API? =

No. Google only allows the Indexing API for job postings and livestream pages. This plugin reads index status with the URL Inspection API, which is allowed for every site, and leaves the "Request indexing" click to you.

= I used "Safe Index Assistant" before. Do I lose my data? =

No. The Google connection, settings and index history carry over. Deactivate and delete the old plugin, then activate this one.

= Can it force Google to index a page? =

No tool can. It shows which pages are not indexed and why, so you can improve the content and internal links that actually get them indexed.

== Uninstall ==

The saved Google key is always removed when the plugin is deleted. The table and settings are removed only when "Delete all data on uninstall" is enabled.

== Changelog ==

= 1.2.1 (2026-10-20) =
* Vyntic plugins page: "More from Vyntic" now shows only plugins that are not installed on the site. Installed Vyntic plugins (also Site Audit, AI Planner and Blog Importer) appear under "Installed", with an Activate button when they are switched off.

= 1.2.0 (2026-10-20) =
* Every button, tab, filter, page number and the settings form now works without reloading the page, with progress spinners and short messages in the corner.
* Cleaner dashboard: stat cards, usage bars, activity panel, filter pills with counts and easier to read tables (cards on phones).
* Settings grouped into numbered panels with a save bar that stays in view.
* Fix: notices from WordPress or other plugins no longer appear inside the header banner.
* Nothing else changed: same checks, limits, Google calls and settings.

= 1.1.1 (2026-10-13) =
* New Guide link in the header, to https://vyntic.studio/plugins/safe-index-assistant/.
* Updates now match the plugin's entry in the Vyntic Hub (safe-index-assistant), so new versions show up on every site.

= 1.1.0 (2026-10-13) =
* Now part of the Vyntic plugin family: one "Index Assistant" item in the shared Vyntic menu, with Dashboard and Settings as tabs.
* New look in Vyntic Studio colours.
* Automatic updates from vyntic.studio, with an Updates tab.
* Data from "Safe Index Assistant" carries over unchanged. Running both at once is blocked with a clear notice instead of an error.

= 1.0.2 (2026-09-29) =
* Fix: sitemap submission failed with HTTP 411 (missing Content-Length). A failed submission is now retried after 1 hour instead of 24.
* Fix: pages "Unknown to Google" now appear in Today's request list.
* Internal link count now includes links inside Elementor layouts.

= 1.0.1 (2026-09-17) =
* "Test Google connection" now lists the properties the service account can see when the saved one does not match.

= 1.0.0 (2026-09-08) =
* First release.
