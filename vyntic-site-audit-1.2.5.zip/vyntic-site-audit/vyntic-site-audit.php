<?php
/**
 * Plugin Name:       Vyntic Site Audit
 * Plugin URI:        https://vyntic.studio/free-audit/
 * Description:       Free website audit lead magnet. Visitors enter their website and email, answer a quick maths question and get a branded PDF report (speed, SEO, security, mobile and lead conversion). PDFs are built on request and never stored. Use the shortcode [vyntic_audit].
 * Version:           1.2.5
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vyntic Studio
 * Author URI:        https://vyntic.studio/
 * License:           GPLv2 or later
 * Text Domain:       vyntic-site-audit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VSA_VERSION', '1.2.5' );
define( 'VSA_FILE', __FILE__ );
define( 'VSA_DIR', plugin_dir_path( __FILE__ ) );
define( 'VSA_URL', plugin_dir_url( __FILE__ ) );

require_once VSA_DIR . 'includes/class-vsa-auditor.php';
require_once VSA_DIR . 'includes/class-vsa-report.php';
require_once VSA_DIR . 'includes/class-vsa-email.php';
require_once VSA_DIR . 'includes/class-vsa-admin.php';

final class Vyntic_Site_Audit {

	const OPTION = 'vsa_settings';
	const TABLE  = 'vsa_leads';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_assets' ) );
		add_shortcode( 'vyntic_audit', array( $this, 'shortcode' ) );

		foreach ( array( 'nonce', 'start', 'speed', 'finish', 'download' ) as $step ) {
			add_action( 'wp_ajax_vsa_' . $step, array( $this, 'ajax_' . $step ) );
			add_action( 'wp_ajax_nopriv_vsa_' . $step, array( $this, 'ajax_' . $step ) );
		}

		add_action( 'vsa_cleanup', array( $this, 'cleanup' ) );
		add_action( 'init', array( __CLASS__, 'maybe_upgrade' ) );

		if ( is_admin() ) {
			new VSA_Admin();
		}
	}

	/* ---------------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------------- */

	public static function defaults() {
		return array(
			'brand'          => get_bloginfo( 'name' ),
			'website'        => home_url( '/' ),
			'psi_key'        => '',
			'accent'         => '#c7431f',
			'on_accent'      => '#ffffff',
			'radius'         => 12,
			'booking_url'    => self::page_url( 'contact', '/contact/' ),
			'contact_email'  => get_option( 'admin_email' ),
			'notify_email'   => get_option( 'admin_email' ),
			'from_name'      => get_bloginfo( 'name' ),
			'send_email'     => 1,
			'allow_download' => 1,
			'logo_url'       => '',
			'about'          => 'Vyntic Studio designs and builds fast websites, runs SEO and local SEO, and makes sure AI tools can recommend your business. We work with clients in the USA, the United Kingdom, Canada, Australia, Germany, France, the Netherlands, Singapore, the United Arab Emirates and New Zealand.',
			'privacy_url'    => get_privacy_policy_url(),
			'consent_text'   => 'We email your report to this address and never share it.',
			'rate_ip'        => 5,
			'retention_days' => 30,
		);
	}

	/**
	 * URL of a site page: the Vyntic theme's page for a setup key when the theme is active,
	 * otherwise the fallback path.
	 */
	public static function page_url( $key, $fallback_path ) {
		if ( function_exists( 'vyntic_key_url' ) ) {
			$url = vyntic_key_url( $key );
			if ( $url ) {
				return $url;
			}
		}
		return home_url( $fallback_path );
	}

	/**
	 * Links printed in the PDF: one service per report section, plus services and guides
	 * on the closing page. Change them with the "vsa_report_links" filter.
	 */
	public static function report_links() {
		$links = array(
			'sections' => array(
				'speed'      => array( 'Website speed optimization', self::page_url( 'speed-optimization', '/services/website-speed-optimization/' ) ),
				'seo'        => array( 'SEO services', self::page_url( 'seo', '/services/seo-services/' ) ),
				'conversion' => array( 'Website design', self::page_url( 'web-design', '/services/web-design/' ) ),
				'security'   => array( 'Website care plans', self::page_url( 'care-plans', '/care-plans/' ) ),
				'mobile'     => array( 'Website redesign', self::page_url( 'website-redesign', '/services/website-redesign/' ) ),
			),
			'services' => array(
				array( 'Website design', self::page_url( 'web-design', '/services/web-design/' ) ),
				array( 'Local SEO', self::page_url( 'local-seo', '/services/local-seo/' ) ),
				array( 'AI search visibility', self::page_url( 'ai-search-visibility', '/services/ai-search-visibility/' ) ),
				array( 'Plans and pricing', self::page_url( 'care-plans', '/care-plans/' ) ),
				array( 'Case studies', self::page_url( 'work', '/work/' ) ),
			),
			'guides'   => array(
				array( 'Core Web Vitals explained', self::page_url( 'post-core-web-vitals-explained', '/core-web-vitals-explained/' ) ),
				array( 'Local SEO guide for small businesses', self::page_url( 'post-local-seo-guide', '/local-seo-guide/' ) ),
				array( 'How to get recommended by ChatGPT', self::page_url( 'post-get-recommended-by-chatgpt', '/get-recommended-by-chatgpt/' ) ),
				array( 'How much does a website cost?', self::page_url( 'post-website-cost', '/website-cost/' ) ),
			),
		);
		return apply_filters( 'vsa_report_links', $links );
	}

	public static function settings() {
		return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	/* ---------------------------------------------------------------------
	 * Install
	 * ------------------------------------------------------------------- */

	public static function activate() {
		global $wpdb;
		$table   = $wpdb->prefix . self::TABLE;
		$charset = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created_at datetime NOT NULL,
				name varchar(190) NOT NULL DEFAULT '',
				email varchar(190) NOT NULL DEFAULT '',
				website varchar(255) NOT NULL DEFAULT '',
				score tinyint(3) unsigned DEFAULT NULL,
				grade char(1) NOT NULL DEFAULT '',
				status varchar(20) NOT NULL DEFAULT 'scanning',
				token char(40) NOT NULL,
				results longtext NULL,
				pdf_file varchar(100) NOT NULL DEFAULT '',
				email_sent tinyint(1) NOT NULL DEFAULT 0,
				consent tinyint(1) NOT NULL DEFAULT 0,
				ip varchar(64) NOT NULL DEFAULT '',
				source_url varchar(255) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				UNIQUE KEY token (token),
				KEY email (email),
				KEY created_at (created_at)
			) {$charset};"
		);
		self::remove_legacy_reports();
		if ( ! wp_next_scheduled( 'vsa_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'vsa_cleanup' );
		}
		update_option( 'vsa_db_version', VSA_VERSION );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'vsa_cleanup' );
	}

	/** Version 1.0 stored PDFs in uploads/vsa-reports. Reports are now built on request, so remove them. */
	public static function remove_legacy_reports() {
		$upload = wp_upload_dir();
		$dir    = trailingslashit( $upload['basedir'] ) . 'vsa-reports';
		if ( ! is_dir( $dir ) ) {
			return;
		}
		foreach ( array_merge( (array) glob( $dir . '/*' ), array( $dir . '/.htaccess' ) ) as $file ) {
			if ( $file && is_file( $file ) ) {
				@unlink( $file );
			}
		}
		@rmdir( $dir );
	}

	/** Run install steps again after an update (the activation hook does not run on updates). */
	public static function maybe_upgrade() {
		if ( get_option( 'vsa_db_version' ) !== VSA_VERSION ) {
			self::activate();
		}
	}

	/* ---------------------------------------------------------------------
	 * Front end
	 * ------------------------------------------------------------------- */

	public function register_assets() {
		wp_register_style( 'vsa-audit', VSA_URL . 'assets/audit.css', array(), VSA_VERSION );
		wp_register_script( 'vsa-audit', VSA_URL . 'assets/audit.js', array(), VSA_VERSION, true );
	}

	public function shortcode( $atts ) {
		$s    = self::settings();
		$atts = shortcode_atts(
			array(
				'title'    => 'Free website audit',
				'subtitle' => 'See what is slowing your site down and costing you leads. Get a detailed PDF report in about a minute.',
				'button'   => 'Run my free audit',
				'accent'   => '',
			),
			$atts,
			'vyntic_audit'
		);

		wp_enqueue_style( 'vsa-audit' );
		wp_enqueue_script( 'vsa-audit' );
		wp_localize_script(
			'vsa-audit',
			'VSA',
			array(
				'ajax'      => admin_url( 'admin-ajax.php' ),
				'booking'   => esc_url_raw( $s['booking_url'] ),
				'allowDl'   => (bool) $s['allow_download'],
				'sendEmail' => (bool) $s['send_email'],
			)
		);

		$accent = $atts['accent'] ? $atts['accent'] : $s['accent'];
		$style  = array();
		if ( $accent && sanitize_hex_color( $accent ) ) {
			$style[] = '--vsa-accent:' . sanitize_hex_color( $accent );
		}
		if ( $s['on_accent'] && sanitize_hex_color( $s['on_accent'] ) ) {
			$style[] = '--vsa-on-accent:' . sanitize_hex_color( $s['on_accent'] );
		}
		$style[] = '--vsa-radius:' . absint( $s['radius'] ) . 'px';

		$note = esc_html( str_replace( '{brand}', $s['brand'], $s['consent_text'] ) );
		if ( $s['privacy_url'] ) {
			$note .= ' <a href="' . esc_url( $s['privacy_url'] ) . '" target="_blank" rel="noopener">Privacy policy</a>';
		}
		$uid = 'vsa-' . wp_generate_password( 6, false );

		ob_start();
		?>
		<div class="vsa" id="<?php echo esc_attr( $uid ); ?>" style="<?php echo esc_attr( implode( ';', $style ) ); ?>">
			<?php if ( $atts['title'] || $atts['subtitle'] ) : ?>
				<div class="vsa-intro">
					<?php if ( $atts['title'] ) : ?>
						<h2 class="vsa-title"><?php echo esc_html( $atts['title'] ); ?></h2>
					<?php endif; ?>
					<?php if ( $atts['subtitle'] ) : ?>
						<p class="vsa-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<form class="vsa-form" novalidate>
				<div class="vsa-field vsa-field--url">
					<label for="<?php echo esc_attr( $uid ); ?>-url">Your website</label>
					<input class="vsa-input" id="<?php echo esc_attr( $uid ); ?>-url" name="website" type="text" inputmode="url" autocomplete="url" placeholder="yourbusiness.com" required>
				</div>
				<div class="vsa-field vsa-field--email">
					<label for="<?php echo esc_attr( $uid ); ?>-email">Where should we send the report?</label>
					<input class="vsa-input" id="<?php echo esc_attr( $uid ); ?>-email" name="email" type="email" autocomplete="email" placeholder="you@company.com" required>
				</div>
				<div class="vsa-field vsa-field--captcha">
					<label for="<?php echo esc_attr( $uid ); ?>-captcha"><span class="vsa-captcha-q">Quick check: what is the answer?</span></label>
					<input class="vsa-input" id="<?php echo esc_attr( $uid ); ?>-captcha" name="captcha" type="text" inputmode="numeric" autocomplete="off" maxlength="3" required>
				</div>
				<div class="vsa-hp" aria-hidden="true">
					<label>Company fax<input type="text" name="company_fax" tabindex="-1" autocomplete="off"></label>
				</div>
				<div class="vsa-actions">
					<button class="vsa-btn" type="submit"><?php echo esc_html( $atts['button'] ); ?></button>
					<span class="vsa-note"><?php echo wp_kses( $note, array( 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) ) ); ?></span>
				</div>
				<p class="vsa-error" role="alert" hidden></p>
			</form>

			<div class="vsa-progress" hidden>
				<div class="vsa-scan-head">
					<span class="vsa-favicon" aria-hidden="true"></span>
					<div class="vsa-scan-id">
						<p class="vsa-progress-site"></p>
						<p class="vsa-scan-sub"></p>
					</div>
					<span class="vsa-live"><i></i>Live</span>
				</div>

				<div class="vsa-scan-body">
					<div class="vsa-meter" aria-hidden="true">
						<svg viewBox="0 0 120 120"><circle class="vsa-meter-track" cx="60" cy="60" r="52"></circle><circle class="vsa-meter-bar" cx="60" cy="60" r="52" pathLength="100"></circle></svg>
						<div class="vsa-meter-num"><b>0</b><small>%</small></div>
						<p class="vsa-meter-time">0s</p>
					</div>
					<ol class="vsa-steps" aria-live="polite">
						<li data-step="connect"><span class="vsa-dot"></span><div><strong>Opening your homepage</strong><em></em></div></li>
						<li data-step="security"><span class="vsa-dot"></span><div><strong>Checking HTTPS and security headers</strong><em></em></div></li>
						<li data-step="seo"><span class="vsa-dot"></span><div><strong>Reading titles, headings and schema</strong><em></em></div></li>
						<li data-step="conversion"><span class="vsa-dot"></span><div><strong>Checking mobile layout and lead capture</strong><em></em></div></li>
						<li data-step="speed"><span class="vsa-dot"></span><div><strong>Google Lighthouse mobile speed test</strong><em></em></div></li>
						<li data-step="finish"><span class="vsa-dot"></span><div><strong>Building your PDF report</strong><em></em></div></li>
					</ol>
				</div>

				<div class="vsa-tech" hidden></div>
				<div class="vsa-feed" aria-hidden="true"><p class="vsa-feed-head">Findings</p><ul></ul></div>
			</div>

			<div class="vsa-result" hidden></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/* ---------------------------------------------------------------------
	 * Maths question (spam check)
	 * ------------------------------------------------------------------- */

	/** A new question and a signed token. The answer never leaves the server. */
	private function new_captcha() {
		$a     = wp_rand( 2, 9 );
		$b     = wp_rand( 1, 9 );
		$time  = time();
		$token = $time . '.' . wp_hash( 'vsa_captcha|' . $time . '|' . ( $a + $b ) );
		return array(
			'question' => sprintf( 'Quick check: what is %d + %d?', $a, $b ),
			'token'    => $token,
		);
	}

	/** True when the answer matches the token, the token is less than an hour old and unused. */
	private function captcha_ok( $answer, $token ) {
		if ( ! preg_match( '/^(\d{9,11})\.([a-f0-9]{32})$/', (string) $token, $m ) ) {
			return false;
		}
		if ( (int) $m[1] < time() - HOUR_IN_SECONDS || ! preg_match( '/^\d{1,3}$/', trim( (string) $answer ) ) ) {
			return false;
		}
		if ( ! hash_equals( wp_hash( 'vsa_captcha|' . $m[1] . '|' . (int) trim( $answer ) ), $m[2] ) ) {
			return false;
		}
		$used = 'vsa_cap_' . md5( $token );
		if ( get_transient( $used ) ) {
			return false;
		}
		set_transient( $used, 1, HOUR_IN_SECONDS );
		return true;
	}

	/* ---------------------------------------------------------------------
	 * AJAX helpers
	 * ------------------------------------------------------------------- */

	private function fail( $message, $code = 400, $extra = array() ) {
		wp_send_json_error( array_merge( array( 'message' => $message ), $extra ), $code );
	}

	private function verify_nonce() {
		if ( ! check_ajax_referer( 'vsa_audit', 'nonce', false ) ) {
			$this->fail( 'Your session expired. Refresh the page and try again.', 403 );
		}
	}

	private function client_ip() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = trim( explode( ',', wp_unslash( $_SERVER[ $key ] ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		return '0.0.0.0';
	}

	private function lead_by_token( $allowed_status ) {
		global $wpdb;
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		if ( ! preg_match( '/^[a-f0-9]{40}$/', $token ) ) {
			$this->fail( 'Invalid audit reference.' );
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}" . self::TABLE . ' WHERE token = %s', $token ) );
		if ( ! $row ) {
			$this->fail( 'Audit not found. Please start again.', 404 );
		}
		if ( ! in_array( $row->status, (array) $allowed_status, true ) ) {
			$this->fail( 'This audit step has already run. Please start a new audit.', 409 );
		}
		if ( strtotime( $row->created_at . ' UTC' ) < time() - HOUR_IN_SECONDS ) {
			$this->fail( 'This audit expired. Please start again.', 410 );
		}
		$row->data = $row->results ? json_decode( $row->results, true ) : array();
		return $row;
	}

	private function update_lead( $id, array $fields ) {
		global $wpdb;
		$wpdb->update( $wpdb->prefix . self::TABLE, $fields, array( 'id' => $id ) );
	}

	/* ---------------------------------------------------------------------
	 * AJAX: fresh nonce and maths question (so page caching never breaks the form)
	 * ------------------------------------------------------------------- */

	public function ajax_nonce() {
		nocache_headers();
		wp_send_json_success(
			array(
				'nonce'   => wp_create_nonce( 'vsa_audit' ),
				'captcha' => $this->new_captcha(),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * AJAX step 1: validate, rate limit, on-page scan
	 * ------------------------------------------------------------------- */

	public function ajax_start() {
		$this->verify_nonce();
		$s = self::settings();

		// Honeypot.
		if ( ! empty( $_POST['company_fax'] ) ) {
			$this->fail( 'Something went wrong. Please try again.' );
		}

		$email  = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$raw    = isset( $_POST['website'] ) ? sanitize_text_field( wp_unslash( $_POST['website'] ) ) : '';
		$source = isset( $_POST['source'] ) ? esc_url_raw( wp_unslash( $_POST['source'] ) ) : '';
		$answer = isset( $_POST['captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha'] ) ) : '';
		$ctoken = isset( $_POST['captcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_token'] ) ) : '';

		$url = VSA_Auditor::normalize_url( $raw );
		if ( ! $url ) {
			$this->fail( 'Enter a valid website address, like yourbusiness.com.', 400, array( 'field' => 'website' ) );
		}
		if ( ! is_email( $email ) ) {
			$this->fail( 'Enter a valid email address. Your report is sent there.', 400, array( 'field' => 'email' ) );
		}
		if ( ! $this->captcha_ok( $answer, $ctoken ) ) {
			$this->fail( 'That answer was not right. Try the new question.', 400, array( 'field' => 'captcha', 'captcha' => $this->new_captcha() ) );
		}
		if ( ! VSA_Auditor::is_public_host( wp_parse_url( $url, PHP_URL_HOST ) ) ) {
			$this->fail( 'We could not find that website. Check the spelling and try again.', 400, array( 'field' => 'website' ) );
		}

		// Rate limits.
		$ip     = $this->client_ip();
		$ip_key = 'vsa_rl_ip_' . md5( $ip );
		$em_key = 'vsa_rl_em_' . md5( strtolower( $email ) );
		$ip_n   = (int) get_transient( $ip_key );
		$em_n   = (int) get_transient( $em_key );
		$limit  = max( 1, (int) $s['rate_ip'] );
		if ( ! current_user_can( 'manage_options' ) && ( $ip_n >= $limit || $em_n >= $limit ) ) {
			$this->fail( 'You have run several audits recently. Please try again in an hour.', 429 );
		}
		set_transient( $ip_key, $ip_n + 1, HOUR_IN_SECONDS );
		set_transient( $em_key, $em_n + 1, HOUR_IN_SECONDS );

		@set_time_limit( 90 );
		$auditor = new VSA_Auditor( $url );
		$result  = $auditor->run_onpage();
		if ( ! empty( $result['error'] ) ) {
			$this->fail( $result['error'], 422 );
		}

		global $wpdb;
		$token = bin2hex( random_bytes( 20 ) );
		$wpdb->insert(
			$wpdb->prefix . self::TABLE,
			array(
				'created_at' => current_time( 'mysql', true ),
				'name'       => '',
				'email'      => $email,
				'website'    => $result['meta']['final_url'],
				'status'     => 'onpage',
				'token'      => $token,
				'results'    => wp_json_encode( $result ),
				'consent'    => 1,
				'ip'         => $ip,
				'source_url' => $source,
			)
		);

		$score = VSA_Auditor::score( $result['checks'] );

		// Real details for the live progress screen: what was found, per area.
		$areas = array();
		foreach ( VSA_Auditor::CATEGORIES as $key => $cfg ) {
			$areas[ $key ] = array( 'checks' => 0, 'issues' => 0 );
		}
		$feed = array();
		foreach ( $result['checks'] as $c ) {
			if ( ! isset( $areas[ $c['category'] ] ) || 'info' === $c['status'] ) {
				continue;
			}
			$areas[ $c['category'] ]['checks']++;
			if ( 'pass' !== $c['status'] ) {
				$areas[ $c['category'] ]['issues']++;
			}
			$feed[ $c['category'] ][] = array( 'status' => $c['status'], 'title' => $c['title'], 'area' => VSA_Auditor::CATEGORIES[ $c['category'] ]['label'] );
		}
		// Up to three findings per area, problems first, in the order the scan runs.
		$rank = array( 'fail' => 0, 'warn' => 1, 'pass' => 2 );
		$list = array();
		foreach ( array( 'security', 'seo', 'speed', 'mobile', 'conversion' ) as $cat ) {
			if ( empty( $feed[ $cat ] ) ) {
				continue;
			}
			usort( $feed[ $cat ], function ( $a, $b ) use ( $rank ) {
				return $rank[ $a['status'] ] <=> $rank[ $b['status'] ];
			} );
			$list = array_merge( $list, array_slice( $feed[ $cat ], 0, 3 ) );
		}
		$feed = $list;
		$m = $result['meta'];
		wp_send_json_success(
			array(
				'token'   => $token,
				'host'    => $m['host'],
				'checks'  => count( $result['checks'] ),
				'issues'  => $score['counts']['fail'] + $score['counts']['warn'],
				'https'   => 0 === stripos( (string) $m['final_url'], 'https://' ),
				'time'    => isset( $m['response_time'] ) ? (float) $m['response_time'] : 0,
				'kb'      => isset( $m['html_kb'] ) ? (int) $m['html_kb'] : 0,
				'title'   => isset( $m['page_title'] ) ? wp_html_excerpt( (string) $m['page_title'], 70, '…' ) : '',
				'tech'    => isset( $m['technologies'] ) ? array_values( (array) $m['technologies'] ) : array(),
				'blocked' => ! empty( $m['blocked'] ),
				'areas'   => $areas,
				'feed'    => array_slice( $feed, 0, 14 ),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * AJAX step 2: Google PageSpeed Insights
	 * ------------------------------------------------------------------- */

	public function ajax_speed() {
		$this->verify_nonce();
		$lead = $this->lead_by_token( 'onpage' );
		$data = $lead->data;
		$s    = self::settings();

		@set_time_limit( 150 );
		$cache_key = 'vsa_psi_' . md5( $data['meta']['final_url'] );
		$psi       = get_transient( $cache_key );
		if ( ! $psi ) {
			$auditor = new VSA_Auditor( $data['meta']['final_url'] );
			$psi     = $auditor->run_psi( $s['psi_key'], $data['meta']['final_url'] );
			if ( empty( $psi['error'] ) ) {
				set_transient( $cache_key, $psi, 6 * HOUR_IN_SECONDS );
			}
		}

		$ok = empty( $psi['error'] );
		// The firewall blocked the on-page scan and Google could not test the page either:
		// there is nothing honest to score, so say so instead of showing 0/100.
		if ( ! $ok && ! empty( $data['meta']['blocked'] ) ) {
			$this->update_lead( $lead->id, array( 'status' => 'blocked', 'results' => wp_json_encode( $data ) ) );
			$this->fail( 'This website\'s firewall blocks automated checks, and Google could not test it right now either. Please try again in a few minutes, or book a call and we will check it by hand.', 422 );
		}
		if ( $ok ) {
			$data['checks'] = array_merge( $data['checks'], $psi['checks'] );
			$data['meta']   = array_merge( $data['meta'], $psi['meta'] );
		} else {
			$data['meta']['psi_error'] = $psi['error'];
		}
		$this->update_lead( $lead->id, array( 'status' => 'speed', 'results' => wp_json_encode( $data ) ) );

		wp_send_json_success(
			array(
				'ok'          => $ok,
				'performance' => $ok && isset( $psi['meta']['psi']['performance'] ) ? $psi['meta']['psi']['performance'] : null,
				'lcp'         => $ok && isset( $psi['meta']['psi']['lcp'] ) ? $psi['meta']['psi']['lcp'] : null,
				'cls'         => $ok && isset( $psi['meta']['psi']['cls'] ) ? $psi['meta']['psi']['cls'] : null,
				'tbt'         => $ok && isset( $psi['meta']['psi']['tbt'] ) ? $psi['meta']['psi']['tbt'] : null,
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * PDF: built in memory whenever it is needed, never written to the server
	 * ------------------------------------------------------------------- */

	/**
	 * @return string PDF bytes, or '' on failure.
	 */
	public static function build_pdf( $lead, array $data ) {
		$s    = self::settings();
		$logo = self::logo_path( self::logo_for_dark( $s['logo_url'] ) ? $s['logo_url'] : '' );
		$pdf  = '';
		try {
			$report = new VSA_Report(
				$data,
				array(
					'brand'         => $s['brand'],
					'accent'        => $s['accent'] ? $s['accent'] : '#c7431f',
					'booking_url'   => $s['booking_url'],
					'contact_email' => $s['contact_email'],
					'website'       => $s['website'],
					'about'         => $s['about'],
					'lead_name'     => $lead->name,
					'logo_path'     => $logo,
					'links'         => self::report_links(),
				)
			);
			$pdf = $report->render();
		} catch ( Throwable $e ) {
			error_log( 'Vyntic Site Audit PDF error: ' . $e->getMessage() );
		}
		// Only delete a logo this plugin downloaded to the temp folder, never the bundled one.
		if ( $logo && 0 === strpos( basename( $logo ), 'vsa-logo-' ) && 0 === strpos( $logo, get_temp_dir() ) ) {
			@unlink( $logo );
		}
		return (string) $pdf;
	}

	public static function pdf_filename( $host ) {
		return 'website-audit-' . sanitize_file_name( $host ) . '.pdf';
	}

	/* ---------------------------------------------------------------------
	 * AJAX step 3: score, PDF, emails
	 * ------------------------------------------------------------------- */

	public function ajax_finish() {
		$this->verify_nonce();
		$lead = $this->lead_by_token( array( 'onpage', 'speed' ) );
		$data = $lead->data;
		$s    = self::settings();

		@set_time_limit( 60 );
		$data['score'] = VSA_Auditor::score( $data['checks'] );
		$pdf           = self::build_pdf( $lead, $data );
		$pdf_ok        = '' !== $pdf;

		$this->update_lead(
			$lead->id,
			array(
				'status'  => $pdf_ok ? 'complete' : 'pdf_error',
				'score'   => $data['score']['overall'],
				'grade'   => $data['score']['grade'],
				'results' => wp_json_encode( $data ),
			)
		);

		$sent = false;
		if ( $pdf_ok && $s['send_email'] ) {
			$mail = $this->email_lead( $lead, $data, $pdf, $s );
			$sent = $mail['sent'];
			$data['meta']['email'] = $mail;
			$this->update_lead( $lead->id, array( 'email_sent' => $sent ? 1 : 0 ) );
		}
		$owner = $this->email_owner( $lead, $data, $pdf, $s );
		if ( $owner ) {
			$data['meta']['owner_email'] = $owner;
		}
		if ( ! empty( $data['meta']['email'] ) || $owner ) {
			$this->update_lead( $lead->id, array( 'results' => wp_json_encode( $data ) ) );
			if ( ( ! empty( $data['meta']['email']['error'] ) && ! $sent ) || ( $owner && ! $owner['sent'] ) ) {
				error_log( 'Vyntic Site Audit email failed: ' . ( ! empty( $data['meta']['email']['error'] ) ? $data['meta']['email']['error'] : $owner['error'] ) );
			}
		}
		unset( $pdf );

		$priorities = array_map(
			function ( $c ) {
				return array( 'status' => $c['status'], 'title' => $c['title'], 'finding' => $c['finding'] );
			},
			array_slice( $data['score']['priorities'], 0, 3 )
		);
		$categories = array();
		foreach ( $data['score']['categories'] as $key => $cat ) {
			if ( null !== $cat['score'] ) {
				$categories[] = array( 'key' => $key, 'label' => $cat['label'], 'score' => $cat['score'] );
			}
		}

		wp_send_json_success(
			array(
				'host'       => $data['meta']['host'],
				'overall'    => $data['score']['overall'],
				'grade'      => $data['score']['grade'],
				'counts'     => $data['score']['counts'],
				'categories' => $categories,
				'priorities' => $priorities,
				'emailed'    => $sent,
				'email'      => $lead->email,
				'download'   => ( $pdf_ok && $s['allow_download'] ) ? add_query_arg( array( 'action' => 'vsa_download', 'token' => $lead->token ), admin_url( 'admin-ajax.php' ) ) : '',
				'psiError'   => ! empty( $data['meta']['psi_error'] ),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * AJAX: PDF download, rebuilt on request (the token acts as an unguessable key)
	 * ------------------------------------------------------------------- */

	public function ajax_download() {
		global $wpdb;
		$s     = self::settings();
		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		if ( ! preg_match( '/^[a-f0-9]{40}$/', $token ) ) {
			wp_die( 'Invalid report link.', 'Report', array( 'response' => 400 ) );
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}" . self::TABLE . ' WHERE token = %s', $token ) );
		$old = $row ? strtotime( $row->created_at . ' UTC' ) < time() - max( 1, (int) $s['retention_days'] ) * DAY_IN_SECONDS : true;
		if ( ! $row || 'complete' !== $row->status || ! $row->results || ( $old && ! current_user_can( 'manage_options' ) ) ) {
			wp_die( 'This report is no longer available. Run a new audit to get a fresh one.', 'Report', array( 'response' => 404 ) );
		}
		$data = json_decode( $row->results, true );
		$pdf  = self::build_pdf( $row, $data );
		if ( '' === $pdf ) {
			wp_die( 'The report could not be created. Please try again.', 'Report', array( 'response' => 500 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . self::pdf_filename( wp_parse_url( $row->website, PHP_URL_HOST ) ) . '"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		header( 'X-Robots-Tag: noindex' );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput -- binary PDF.
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Emails (the PDF is attached from memory)
	 * ------------------------------------------------------------------- */

	public static function mail_headers( $s ) {
		$domain = wp_parse_url( home_url(), PHP_URL_HOST );
		$domain = preg_replace( '/^www\./', '', $domain );
		$from   = apply_filters( 'vsa_from_email', 'wordpress@' . $domain );
		$h      = array( 'Content-Type: text/html; charset=UTF-8', 'From: ' . wp_specialchars_decode( $s['from_name'] ) . ' <' . $from . '>' );
		if ( is_email( $s['contact_email'] ) ) {
			$h[] = 'Reply-To: ' . $s['contact_email'];
		}
		return $h;
	}

	/** wp_mail() with the PDF attached straight from memory. */
	/**
	 * Send an email with the PDF, trying the most private way first:
	 * 1. attached straight from memory,
	 * 2. from a temporary file deleted right after sending (some SMTP and API mail plugins need a file),
	 * 3. without the attachment, using $fallback_body (which links to the download) when given.
	 *
	 * @return array { sent: bool, method: attached|temp-file|link|failed, error: string }
	 */
	public static function mail_with_pdf( $to, $subject, $body, $headers, $pdf, $filename, $fallback_body = '', $text = '', $fallback_text = '' ) {
		// Plain-text version alongside the HTML: helps the email pass spam filters.
		$alt_text = $text;
		$alt      = function ( $phpmailer ) use ( &$alt_text ) {
			if ( $alt_text ) {
				$phpmailer->AltBody = $alt_text;
			}
		};
		add_action( 'phpmailer_init', $alt );
		$errors  = array();
		$catch   = function ( $err ) use ( &$errors ) {
			$errors[] = is_wp_error( $err ) ? $err->get_error_message() : 'Unknown mail error';
		};
		add_action( 'wp_mail_failed', $catch );

		$result = array( 'sent' => false, 'method' => 'failed', 'error' => '' );

		if ( '' !== $pdf ) {
			// 1. From memory.
			$attach = function ( $phpmailer ) use ( $pdf, $filename ) {
				$phpmailer->addStringAttachment( $pdf, $filename, 'base64', 'application/pdf' );
			};
			add_action( 'phpmailer_init', $attach );
			$sent = wp_mail( $to, $subject, $body, $headers );
			remove_action( 'phpmailer_init', $attach );
			if ( $sent ) {
				$result = array( 'sent' => true, 'method' => 'attached', 'error' => '' );
			} else {
				// 2. From a temporary file, removed straight after sending.
				$dir = trailingslashit( get_temp_dir() ) . 'vsa-' . wp_generate_password( 12, false );
				if ( wp_mkdir_p( $dir ) ) {
					$file = $dir . '/' . $filename;
					if ( false !== file_put_contents( $file, $pdf ) ) {
						$sent = wp_mail( $to, $subject, $body, $headers, array( $file ) );
						if ( $sent ) {
							$result = array( 'sent' => true, 'method' => 'temp-file', 'error' => '' );
						}
					}
					@unlink( $file );
					@rmdir( $dir );
				}
			}
		}

		// 3. Without the attachment.
		if ( ! $result['sent'] && ( $fallback_body || '' === $pdf ) ) {
			$alt_text = $fallback_text ? $fallback_text : $text;
			if ( wp_mail( $to, $subject, $fallback_body ? $fallback_body : $body, $headers ) ) {
				$result = array( 'sent' => true, 'method' => 'link', 'error' => '' );
			}
		}

		remove_action( 'wp_mail_failed', $catch );
		remove_action( 'phpmailer_init', $alt );
		if ( $errors ) {
			$result['error'] = implode( ' | ', array_unique( $errors ) );
		} elseif ( ! $result['sent'] ) {
			$result['error'] = 'wp_mail() returned false. Check your SMTP plugin settings and its email log.';
		}
		return $result;
	}

	/** Brand options for the HTML emails. */
	public static function email_options( $s ) {
		$accent = sanitize_hex_color( $s['accent'] ) ? $s['accent'] : '#c7431f';
		return array(
			'brand'         => $s['brand'],
			'accent'        => $accent,
			'accent_soft'   => '#c7431f' === strtolower( $accent ) ? '#f4a48c' : $accent,
			'on_accent'     => $s['on_accent'] ? $s['on_accent'] : '#ffffff',
			'logo_url'      => self::logo_for_dark( $s['logo_url'] ) ? $s['logo_url'] : VSA_URL . 'assets/logo-light.png',
			'website'       => $s['website'],
			'booking_url'   => $s['booking_url'],
			'contact_email' => $s['contact_email'],
			'links'         => self::report_links(),
			'footer'        => '',
		);
	}

	private function email_lead( $lead, $data, $pdf, $s ) {
		$host     = $data['meta']['host'];
		$subject  = sprintf( 'Your website audit for %s: %d/100', $host, $data['score']['overall'] );
		$o        = self::email_options( $s );
		$body     = VSA_Email::lead_html( $data, $o );
		$text     = VSA_Email::lead_text( $data, $o );
		$o['download_url'] = add_query_arg( array( 'action' => 'vsa_download', 'token' => $lead->token ), admin_url( 'admin-ajax.php' ) );
		$fallback = VSA_Email::lead_html( $data, $o );
		$fb_text  = VSA_Email::lead_text( $data, $o );
		return self::mail_with_pdf( $lead->email, $subject, $body, self::mail_headers( $s ), $pdf, self::pdf_filename( $host ), $fallback, $text, $fb_text );
	}

	private function email_owner( $lead, $data, $pdf, $s ) {
		if ( ! is_email( $s['notify_email'] ) ) {
			return null;
		}
		$subject = sprintf( 'New audit lead: %s (%s) scored %d', $lead->email, $data['meta']['host'], $data['score']['overall'] );
		$html    = VSA_Email::owner_html( $lead, $data, self::email_options( $s ), admin_url( 'admin.php?page=vsa-leads' ) );
		$headers = array( 'Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . $lead->email );
		$text    = VSA_Email::owner_text( $lead, $data, admin_url( 'admin.php?page=vsa-leads' ) );
		return self::mail_with_pdf( $s['notify_email'], $subject, $html, $headers, $pdf, self::pdf_filename( $data['meta']['host'] ), $html, $text, $text );
	}

	/**
	 * Whether a logo can sit on the dark email and PDF header: a PNG or JPG that is
	 * mostly light. A dark logo (or an SVG, which Gmail and the PDF cannot show)
	 * returns false, and the white Vyntic logo is used instead. Cached for a week.
	 *
	 * @param string $url Logo URL.
	 * @return bool
	 */
	public static function logo_for_dark( $url ) {
		if ( ! $url ) {
			return false;
		}
		if ( ! preg_match( '/\.(png|jpe?g)(\?.*)?$/i', $url ) ) {
			return false;
		}
		$key    = 'vsa_logo_ok_' . md5( $url );
		$cached = get_transient( $key );
		if ( false !== $cached ) {
			return 'yes' === $cached;
		}
		$ok = true; // Without GD we cannot judge, so trust the setting.
		if ( function_exists( 'imagecreatefromstring' ) ) {
			$bytes  = '';
			$upload = wp_upload_dir();
			if ( 0 === strpos( $url, $upload['baseurl'] ) ) {
				$local = $upload['basedir'] . substr( strtok( $url, '?' ), strlen( $upload['baseurl'] ) );
				$bytes = file_exists( $local ) ? (string) file_get_contents( $local ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
			} else {
				$res   = wp_safe_remote_get( $url, array( 'timeout' => 10 ) );
				$bytes = is_wp_error( $res ) ? '' : (string) wp_remote_retrieve_body( $res );
			}
			$img = $bytes ? @imagecreatefromstring( $bytes ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( ! $img ) {
				$ok = false;
			} else {
				$w     = imagesx( $img );
				$h     = imagesy( $img );
				$step  = max( 1, (int) floor( max( $w, $h ) / 80 ) );
				$seen  = 0;
				$dark  = 0;
				$truec = imageistruecolor( $img );
				for ( $x = 0; $x < $w; $x += $step ) {
					for ( $y = 0; $y < $h; $y += $step ) {
						$c = imagecolorat( $img, $x, $y );
						if ( $truec ) {
							$a = ( $c >> 24 ) & 0x7F;
							$r = ( $c >> 16 ) & 0xFF;
							$g = ( $c >> 8 ) & 0xFF;
							$b = $c & 0xFF;
						} else {
							$rgba = imagecolorsforindex( $img, $c );
							list( $r, $g, $b, $a ) = array( $rgba['red'], $rgba['green'], $rgba['blue'], $rgba['alpha'] );
						}
						if ( $a > 64 ) {
							continue; // Transparent: the header shows through.
						}
						++$seen;
						if ( ( 0.2126 * $r + 0.7152 * $g + 0.0722 * $b ) / 255 < 0.25 ) {
							++$dark;
						}
					}
				}
				imagedestroy( $img );
				// Dark letters on a transparent background would vanish on the dark header.
				$ok = $seen > 0 && $dark / $seen < 0.4;
			}
		}
		set_transient( $key, $ok ? 'yes' : 'no', WEEK_IN_SECONDS );
		return $ok;
	}

	/**
	 * Resolve the logo to a local file FPDF can read (PNG or JPG only).
	 * Without a logo URL, the bundled Vyntic logo is used.
	 */
	private static function logo_path( $url ) {
		if ( ! $url ) {
			$bundled = VSA_DIR . 'assets/logo-light.png';
			return file_exists( $bundled ) ? $bundled : '';
		}
		if ( ! preg_match( '/\.(png|jpe?g)(\?.*)?$/i', $url ) ) {
			return '';
		}
		$upload = wp_upload_dir();
		if ( 0 === strpos( $url, $upload['baseurl'] ) ) {
			$local = $upload['basedir'] . substr( strtok( $url, '?' ), strlen( $upload['baseurl'] ) );
			return file_exists( $local ) ? $local : '';
		}
		$res = wp_safe_remote_get( $url, array( 'timeout' => 10 ) );
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			return '';
		}
		$ext = preg_match( '/\.png/i', $url ) ? 'png' : 'jpg';
		$tmp = trailingslashit( get_temp_dir() ) . 'vsa-logo-' . wp_generate_password( 8, false ) . '.' . $ext;
		file_put_contents( $tmp, wp_remote_retrieve_body( $res ) );
		return $tmp;
	}

	/* ---------------------------------------------------------------------
	 * Housekeeping
	 * ------------------------------------------------------------------- */

	public function cleanup() {
		global $wpdb;
		$s      = self::settings();
		$days   = max( 1, (int) $s['retention_days'] );
		$table  = $wpdb->prefix . self::TABLE;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// After the download period, drop the page screenshot (the largest part) but keep the lead and scores.
		$old = $wpdb->get_results( $wpdb->prepare( "SELECT id, results FROM {$table} WHERE created_at < %s AND results LIKE %s LIMIT 200", $cutoff, '%"screenshot"%' ) );
		foreach ( $old as $row ) {
			$data = json_decode( (string) $row->results, true );
			if ( is_array( $data ) ) {
				unset( $data['meta']['screenshot'] );
				$wpdb->update( $table, array( 'results' => wp_json_encode( $data ) ), array( 'id' => $row->id ) );
			}
		}
		// Visitors who closed the tab mid-scan are still leads: flag them instead of deleting.
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'incomplete' WHERE status IN ('onpage','speed') AND created_at < %s", gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );
	}
}

register_activation_hook( __FILE__, array( 'Vyntic_Site_Audit', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Vyntic_Site_Audit', 'deactivate' ) );
add_action( 'plugins_loaded', array( 'Vyntic_Site_Audit', 'instance' ) );
