/* Vyntic Blog Importer: live schedule preview. Mirrors VBI_Importer::schedule(). */
(function () {
	'use strict';

	var form = document.querySelector('[data-vbi-review]');

	// Upload screen: show the chosen file name in the drop zone.
	var file = document.querySelector('.vbi-drop input[type=file]');
	if (file) {
		file.addEventListener('change', function () {
			var t = file.parentNode.querySelector('.vbi-drop__text');
			if (file.files[0]) { t.textContent = file.files[0].name; file.parentNode.classList.add('has-file'); }
		});
	}
	if (!form) { return; }

	var posts = JSON.parse(form.getAttribute('data-posts') || '[]');
	var now = parse(form.getAttribute('data-now'));
	var locale = form.getAttribute('data-locale') || undefined;
	var DAY = 86400000;

	// Dates are handled as "site local" wall-clock time stored in UTC fields, so the
	// browser's own time zone never shifts them.
	function parse(s) {
		var m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(s || '');
		return m ? Date.UTC(+m[1], m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0)) : null;
	}
	function show(t) {
		try {
			return new Intl.DateTimeFormat(locale, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }).format(new Date(t));
		} catch (e) {
			return new Date(t).toISOString().slice(0, 16).replace('T', ' ');
		}
	}
	function field(name) { return form.querySelector('[name="vbi[' + name + ']"]'); }
	function mode() { var r = form.querySelector('[name="vbi[mode]"]:checked'); return r ? r.value : 'spread'; }

	function update() {
		var m = mode();
		var start = parse(field('start').value + ' ' + (field('time').value || '09:00'));
		var every = Math.min(60, Math.max(1, parseInt(field('every').value, 10) || 1));
		var skip = field('skip_weekends').checked;
		var slot = null;
		var n = 0;
		var picked = 0, sched = 0, live = 0, drafts = 0, last = null;

		form.querySelector('[data-vbi-spread]').classList.toggle('is-off', m === 'now' || m === 'draft');

		function next() {
			slot = slot === null ? (start === null ? now + DAY : start) : slot + every * DAY;
			if (skip) { while ([0, 6].indexOf(new Date(slot).getUTCDay()) > -1) { slot += DAY; } }
			return slot;
		}

		posts.forEach(function (p) {
			var row = form.querySelector('[data-vbi-row="' + p.i + '"]');
			var box = row.querySelector('input[type=checkbox]');
			var cell = row.querySelector('[data-vbi-when]');
			row.classList.toggle('is-skipped', !box.checked);
			if (!box.checked) { cell.textContent = box.disabled ? 'Not imported' : 'Not selected'; return; }
			picked++;
			var status, t = null;
			if (m === 'draft' || p.draft) {
				status = 'draft';
			} else if (m === 'now') {
				status = 'publish'; t = now - n * 60000; n++;
			} else {
				t = (m === 'file' && p.date) ? parse(p.date) : next();
				status = t > now ? 'future' : 'publish';
			}
			if (status === 'draft') { drafts++; cell.innerHTML = '<span class="vbi-badge vbi-badge--draft">Draft</span>'; return; }
			if (status === 'future') { sched++; } else { live++; }
			if (last === null || t > last) { last = t; }
			cell.innerHTML = '<span class="vbi-badge vbi-badge--' + status + '">' + (status === 'future' ? 'Scheduled' : (m === 'now' ? 'Now' : 'Published, past date')) + '</span> ' + show(t);
		});

		var parts = [];
		if (sched) { parts.push(sched + ' scheduled'); }
		if (live) { parts.push(live + ' published now'); }
		if (drafts) { parts.push(drafts + ' as drafts'); }
		var summary = form.querySelector('[data-vbi-summary]');
		summary.textContent = picked ? ' ' + parts.join(', ') + (sched && last ? '. Last post goes live ' + show(last) + '.' : '.') : '';
		var btn = form.querySelector('[data-vbi-submit]');
		btn.disabled = !picked;
		btn.textContent = picked ? 'Import ' + picked + (picked === 1 ? ' post' : ' posts') : 'Select posts to import';
	}

	var all = form.querySelector('[data-vbi-all]');
	all.addEventListener('change', function () {
		form.querySelectorAll('[name="vbi[pick][]"]:not(:disabled)').forEach(function (b) { b.checked = all.checked; });
		update();
	});
	form.addEventListener('change', update);
	form.addEventListener('input', update);
	form.addEventListener('submit', function () {
		var btn = form.querySelector('[data-vbi-submit]');
		setTimeout(function () { btn.disabled = true; btn.textContent = 'Importing, please wait...'; }, 0);
	});
	update();
})();
