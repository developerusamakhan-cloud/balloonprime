<?php
/**
 * Plugin Name:       Vyntic Blog Importer
 * Plugin URI:        https://vyntic.studio/
 * Description:       Import a batch of blog posts from one JSON file and schedule them. Sets categories, tags, featured images, Rank Math or Yoast SEO fields and FAQ schema, with a preview before anything is saved. Go to Posts → Import blog file.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Vyntic Studio
 * Author URI:        https://vyntic.studio/
 * License:           GPLv2 or later
 * Text Domain:       vyntic-blog-importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VBI_VERSION', '1.0.0' );
define( 'VBI_FILE', __FILE__ );
define( 'VBI_DIR', plugin_dir_path( __FILE__ ) );
define( 'VBI_URL', plugin_dir_url( __FILE__ ) );

require_once VBI_DIR . 'includes/class-vbi-parser.php';
require_once VBI_DIR . 'includes/class-vbi-importer.php';
require_once VBI_DIR . 'includes/class-vbi-admin.php';

/**
 * Front end and housekeeping hooks.
 */
final class Vyntic_Blog_Importer {

	public static function init() {
		VBI_Admin::init();
		add_action( 'init', array( __CLASS__, 'publish_missed' ) );
		add_action( 'wp_head', array( __CLASS__, 'faq_schema' ), 20 );
	}

	/**
	 * Scheduled posts rely on WP-Cron, which only runs when someone visits the site.
	 * On quiet sites or hosts that block loopback requests a post can miss its time
	 * ("Missed schedule"). Every five minutes this publishes any scheduled post whose
	 * time has passed.
	 */
	public static function publish_missed() {
		if ( get_transient( 'vbi_missed_check' ) ) {
			return;
		}
		set_transient( 'vbi_missed_check', 1, 5 * MINUTE_IN_SECONDS );

		$ids = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => 'future',
				'posts_per_page'   => 20,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'date_query'       => array(
					array(
						'column' => 'post_date_gmt',
						'before' => gmdate( 'Y-m-d H:i:s', time() - 60 ),
					),
				),
			)
		);
		foreach ( $ids as $id ) {
			wp_publish_post( $id );
		}
	}

	/**
	 * FAQPage schema for imported posts that have questions.
	 */
	public static function faq_schema() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		$faq = get_post_meta( get_queried_object_id(), '_vbi_faq', true );
		if ( empty( $faq ) || ! is_array( $faq ) ) {
			return;
		}
		$items = array();
		foreach ( $faq as $item ) {
			$items[] = array(
				'@type'          => 'Question',
				'name'           => wp_strip_all_tags( $item['q'] ),
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => wp_strip_all_tags( $item['a'] ),
				),
			);
		}
		echo '<script type="application/ld+json">' . wp_json_encode(
			array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $items,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		) . "</script>\n";
	}
}

Vyntic_Blog_Importer::init();
