<?php
/**
 * Creates posts from a parsed import file.
 *
 * @package Vyntic_Blog_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VBI_Importer {

	const BATCHES = 'vbi_batches';

	/**
	 * Default import settings.
	 *
	 * @return array
	 */
	public static function default_settings() {
		$tomorrow = new DateTimeImmutable( 'tomorrow', wp_timezone() );
		return array(
			'mode'          => 'spread', // spread | file | now | draft.
			'start'         => $tomorrow->format( 'Y-m-d' ),
			'time'          => '09:00',
			'every'         => 3,
			'skip_weekends' => 0,
			'author'        => get_current_user_id(),
			'duplicate'     => 'skip', // skip | update | new.
			'blocks'        => 1,
			'images'        => 1,
		);
	}

	/**
	 * Work out the status and local date ("Y-m-d H:i") for each selected post.
	 *
	 * The same rules run in assets/admin.js so the preview matches the result.
	 *
	 * @param array $posts    Parsed posts (only the ones being imported, in file order).
	 * @param array $settings Import settings.
	 * @return array index => array( status, date )
	 */
	public static function schedule( array $posts, array $settings ) {
		$tz    = wp_timezone();
		$now   = new DateTimeImmutable( 'now', $tz );
		$out   = array();
		$slot  = null;
		$every = min( 60, max( 1, (int) $settings['every'] ) );

		$next_slot = function () use ( &$slot, $settings, $tz, $every ) {
			if ( null === $slot ) {
				$slot = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $settings['start'] . ' ' . $settings['time'], $tz );
				if ( ! $slot ) {
					$slot = new DateTimeImmutable( 'tomorrow 09:00', $tz );
				}
			} else {
				$slot = $slot->modify( '+' . $every . ' days' );
			}
			if ( ! empty( $settings['skip_weekends'] ) ) {
				while ( (int) $slot->format( 'N' ) >= 6 ) {
					$slot = $slot->modify( '+1 day' );
				}
			}
			return $slot;
		};

		$n = 0;
		foreach ( $posts as $p ) {
			$i = $p['index'];
			if ( 'draft' === $settings['mode'] || 'draft' === $p['status'] ) {
				$out[ $i ] = array( 'draft', '' );
				continue;
			}
			if ( 'now' === $settings['mode'] ) {
				// One minute apart so the first post in the file shows first on the blog.
				$out[ $i ] = array( 'publish', $now->modify( '-' . $n . ' minutes' )->format( 'Y-m-d H:i' ) );
				$n++;
				continue;
			}
			if ( 'file' === $settings['mode'] && $p['date'] ) {
				$d = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $p['date'], $tz );
			} else {
				$d = $next_slot();
			}
			$out[ $i ] = array( $d > $now ? 'future' : 'publish', $d->format( 'Y-m-d H:i' ) );
		}
		return $out;
	}

	/**
	 * Import the selected posts.
	 *
	 * @param array  $posts    Parsed posts to import.
	 * @param array  $settings Import settings.
	 * @param string $source   File name, for the history list.
	 * @return array Results per post and the batch id.
	 */
	public static function run( array $posts, array $settings, $source ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$plan    = self::schedule( $posts, $settings );
		$batch   = gmdate( 'YmdHis' ) . '-' . wp_generate_password( 4, false, false );
		$results = array();
		$ids     = array();

		foreach ( $posts as $p ) {
			$r = self::import_one( $p, $plan[ $p['index'] ], $settings, $batch );
			$results[] = $r;
			if ( ! empty( $r['id'] ) && in_array( $r['result'], array( 'created', 'updated' ), true ) ) {
				$ids[] = $r['id'];
			}
		}

		if ( $ids ) {
			$batches           = get_option( self::BATCHES, array() );
			$batches[ $batch ] = array(
				'time'   => time(),
				'user'   => get_current_user_id(),
				'source' => sanitize_file_name( $source ),
				'ids'    => $ids,
			);
			$batches = array_slice( $batches, -25, null, true );
			update_option( self::BATCHES, $batches, false );
		}

		return array(
			'batch'   => $batch,
			'results' => $results,
		);
	}

	/**
	 * Create or update one post.
	 */
	private static function import_one( array $p, array $plan, array $settings, $batch ) {
		$r = array(
			'title'  => $p['title'],
			'result' => 'error',
			'id'     => 0,
			'status' => $plan[0],
			'date'   => $plan[1],
			'notes'  => array(),
		);
		if ( $p['errors'] ) {
			$r['notes'] = $p['errors'];
			return $r;
		}

		$existing = get_page_by_path( $p['slug'], OBJECT, 'post' );
		if ( $existing && 'trash' === $existing->post_status ) {
			$existing = null;
		}
		if ( $existing && 'skip' === $settings['duplicate'] ) {
			$r['result']  = 'skipped';
			$r['id']      = $existing->ID;
			$r['notes'][] = __( 'A post with this slug already exists.', 'vyntic-blog-importer' );
			return $r;
		}

		$content = self::content( $p, ! empty( $settings['blocks'] ) );
		$args    = array(
			'post_type'      => 'post',
			'post_title'     => $p['title'],
			'post_name'      => $p['slug'],
			'post_content'   => $content,
			'post_excerpt'   => $p['excerpt'],
			'post_status'    => $plan[0],
			'post_author'    => (int) $settings['author'],
			'post_category'  => self::category_ids( $p['categories'] ),
			'tags_input'     => $p['tags'],
			'comment_status' => get_default_comment_status( 'post' ),
		);
		if ( $plan[1] ) {
			$args['post_date']     = $plan[1] . ':00';
			$args['post_date_gmt'] = get_gmt_from_date( $args['post_date'] );
			$args['edit_date']     = true;
		}
		if ( $existing && 'update' === $settings['duplicate'] ) {
			$args['ID'] = $existing->ID;
		}

		$id = $existing && 'update' === $settings['duplicate'] ? wp_update_post( wp_slash( $args ), true ) : wp_insert_post( wp_slash( $args ), true );
		if ( is_wp_error( $id ) ) {
			$r['notes'][] = $id->get_error_message();
			return $r;
		}

		$r['id']     = $id;
		$r['result'] = isset( $args['ID'] ) ? 'updated' : 'created';

		update_post_meta( $id, '_vbi_batch', $batch );
		if ( $p['faq'] ) {
			update_post_meta( $id, '_vbi_faq', $p['faq'] );
		} else {
			delete_post_meta( $id, '_vbi_faq' );
		}
		self::seo( $id, $p );

		if ( $p['image_url'] && ! empty( $settings['images'] ) ) {
			$img = self::image( $p['image_url'], $id, $p['image_alt'] );
			if ( is_wp_error( $img ) ) {
				/* translators: %s: error message. */
				$r['notes'][] = sprintf( __( 'Featured image not added: %s', 'vyntic-blog-importer' ), $img->get_error_message() );
			}
		}
		return $r;
	}

	/**
	 * Category ids from names, creating any that do not exist yet.
	 *
	 * @param array $names Category names.
	 * @return int[]
	 */
	private static function category_ids( array $names ) {
		$ids = array();
		foreach ( $names as $name ) {
			$term = get_term_by( 'name', $name, 'category' );
			if ( ! $term ) {
				$term = get_term_by( 'slug', sanitize_title( $name ), 'category' );
			}
			if ( $term ) {
				$ids[] = (int) $term->term_id;
				continue;
			}
			$new = wp_insert_term( $name, 'category' );
			if ( ! is_wp_error( $new ) ) {
				$ids[] = (int) $new['term_id'];
			}
		}
		return $ids ? $ids : array( (int) get_option( 'default_category' ) );
	}

	/**
	 * Rank Math and Yoast fields. Rank Math is written when it is active or when no
	 * SEO plugin is active (it is the one this site uses).
	 */
	private static function seo( $id, array $p ) {
		$rank = defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
		$yoast = defined( 'WPSEO_VERSION' );
		if ( $rank || ! $yoast ) {
			$map = array(
				'rank_math_title'         => $p['seo_title'],
				'rank_math_description'   => $p['meta_description'],
				'rank_math_focus_keyword' => $p['focus_keyword'],
			);
		} else {
			$map = array();
		}
		if ( $yoast ) {
			$map['_yoast_wpseo_title']    = $p['seo_title'];
			$map['_yoast_wpseo_metadesc'] = $p['meta_description'];
			$map['_yoast_wpseo_focuskw']  = $p['focus_keyword'];
		}
		foreach ( $map as $key => $value ) {
			if ( '' !== $value ) {
				update_post_meta( $id, $key, $value );
			}
		}
	}

	/**
	 * Download an image into the Media Library and set it as the featured image.
	 *
	 * @return int|WP_Error Attachment id.
	 */
	private static function image( $url, $post_id, $alt ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Reuse the file if this URL was imported before.
		$found = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_vbi_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $url, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( $found ) {
			$att = (int) $found[0];
		} else {
			$att = media_sideload_image( $url, $post_id, $alt, 'id' );
			if ( is_wp_error( $att ) ) {
				return $att;
			}
			update_post_meta( $att, '_vbi_source_url', $url );
		}
		update_post_meta( $att, '_wp_attachment_image_alt', $alt );
		set_post_thumbnail( $post_id, $att );
		return $att;
	}

	/**
	 * Build the post content: link tokens, then blocks, then the FAQ section.
	 *
	 * @param array $p      Parsed post.
	 * @param bool  $blocks Convert HTML to editor blocks.
	 * @return string
	 */
	public static function content( array $p, $blocks ) {
		$html = self::tokens( $p['content'] );
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			$html = wp_kses_post( $html );
		}

		$faq = '';
		if ( $p['faq'] ) {
			$faq .= '<h2 id="faq">' . esc_html__( 'Frequently asked questions', 'vyntic-blog-importer' ) . '</h2>';
			foreach ( $p['faq'] as $f ) {
				$faq .= '<h3>' . esc_html( $f['q'] ) . '</h3><p>' . esc_html( $f['a'] ) . '</p>';
			}
		}

		if ( $blocks && false === strpos( $html, '<!-- wp:' ) && class_exists( 'DOMDocument' ) ) {
			return self::to_blocks( $html . $faq );
		}
		return $html . $faq;
	}

	/**
	 * {{key|anchor}} links to a Vyntic theme page by its key, {{/path/|anchor}} links to a
	 * path on this site, {{ext:https://...|anchor}} opens an outside link in a new tab and
	 * {{price:starter}} prints a price from the theme settings.
	 */
	public static function tokens( $html ) {
		$html = preg_replace_callback(
			'/\{\{price:([a-z_]+)\}\}/',
			function ( $m ) {
				return function_exists( 'vyntic_mod' ) ? esc_html( (string) vyntic_mod( 'price_' . $m[1] ) ) : '';
			},
			$html
		);
		return preg_replace_callback(
			'/\{\{(ext:)?([^|}]+)\|([^}]+)\}\}/',
			function ( $m ) {
				$target = trim( $m[2] );
				$anchor = esc_html( trim( $m[3] ) );
				if ( $m[1] ) {
					return '<a href="' . esc_url( $target ) . '" target="_blank" rel="noopener">' . $anchor . '</a>';
				}
				if ( '/' === $target[0] ) {
					$url = home_url( $target );
				} elseif ( preg_match( '#^https?://#', $target ) ) {
					$url = $target;
				} elseif ( function_exists( 'vyntic_setup_link' ) ) {
					$url = vyntic_setup_link( $target );
				} else {
					$url = home_url( '/' );
				}
				return '<a href="' . esc_url( $url ) . '">' . $anchor . '</a>';
			},
			$html
		);
	}

	/**
	 * Turn plain HTML into block editor markup so each paragraph, heading and list
	 * is its own editable block. Anything else becomes a Custom HTML block.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public static function to_blocks( $html ) {
		$doc  = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8"?><div id="vbi-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );

		$root = $doc->getElementById( 'vbi-root' );
		if ( ! $root ) {
			return $html;
		}

		$out    = array();
		$inline = '';
		$flush  = function () use ( &$inline, &$out ) {
			if ( '' !== trim( wp_strip_all_tags( $inline ) ) ) {
				$out[] = "<!-- wp:paragraph -->\n<p>" . trim( $inline ) . "</p>\n<!-- /wp:paragraph -->";
			}
			$inline = '';
		};

		foreach ( iterator_to_array( $root->childNodes ) as $node ) {
			if ( XML_TEXT_NODE === $node->nodeType ) {
				$inline .= esc_html( $node->textContent );
				continue;
			}
			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				continue;
			}
			$tag = strtolower( $node->nodeName );
			if ( in_array( $tag, array( 'a', 'strong', 'em', 'b', 'i', 'span', 'code', 'br', 'mark', 'small', 'sup', 'sub' ), true ) ) {
				$inline .= $doc->saveHTML( $node );
				continue;
			}
			$flush();
			$inner = self::inner( $doc, $node );

			if ( 'p' === $tag ) {
				if ( '' !== trim( wp_strip_all_tags( $inner, true ) ) || false !== strpos( $inner, '<img' ) ) {
					$out[] = "<!-- wp:paragraph -->\n<p>" . trim( $inner ) . "</p>\n<!-- /wp:paragraph -->";
				}
			} elseif ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
				$level = max( 2, (int) $m[1] ); // The post title is the only H1.
				$id    = $node->getAttribute( 'id' );
				$attrs = array();
				if ( 2 !== $level ) {
					$attrs['level'] = $level;
				}
				if ( $id ) {
					$attrs['anchor'] = $id;
				}
				$out[] = '<!-- wp:heading' . ( $attrs ? ' ' . wp_json_encode( $attrs ) : '' ) . " -->\n<h{$level} class=\"wp-block-heading\"" . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . '>' . trim( $inner ) . "</h{$level}>\n<!-- /wp:heading -->";
			} elseif ( ( 'ul' === $tag || 'ol' === $tag ) && ! self::has_nested_list( $node ) ) {
				$items = '';
				foreach ( $node->childNodes as $li ) {
					if ( XML_ELEMENT_NODE === $li->nodeType && 'li' === strtolower( $li->nodeName ) ) {
						$items .= '<!-- wp:list-item --><li>' . trim( self::inner( $doc, $li ) ) . '</li><!-- /wp:list-item -->';
					}
				}
				$out[] = ( 'ol' === $tag ? "<!-- wp:list {\"ordered\":true} -->\n<ol class=\"wp-block-list\">" : "<!-- wp:list -->\n<ul class=\"wp-block-list\">" ) . $items . "</{$tag}>\n<!-- /wp:list -->";
			} elseif ( 'blockquote' === $tag ) {
				$paras = '';
				foreach ( $node->childNodes as $c ) {
					if ( XML_ELEMENT_NODE === $c->nodeType && 'p' === strtolower( $c->nodeName ) ) {
						$paras .= "<!-- wp:paragraph -->\n<p>" . trim( self::inner( $doc, $c ) ) . "</p>\n<!-- /wp:paragraph -->\n";
					}
				}
				if ( '' === $paras ) {
					$paras = "<!-- wp:paragraph -->\n<p>" . trim( $inner ) . "</p>\n<!-- /wp:paragraph -->\n";
				}
				$out[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">" . $paras . "</blockquote>\n<!-- /wp:quote -->";
			} elseif ( 'hr' === $tag ) {
				$out[] = "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->";
			} else {
				$out[] = "<!-- wp:html -->\n" . $doc->saveHTML( $node ) . "\n<!-- /wp:html -->";
			}
		}
		$flush();

		return implode( "\n\n", $out );
	}

	private static function inner( DOMDocument $doc, DOMNode $node ) {
		$html = '';
		foreach ( $node->childNodes as $c ) {
			$html .= $doc->saveHTML( $c );
		}
		return $html;
	}

	private static function has_nested_list( DOMNode $list ) {
		foreach ( $list->getElementsByTagName( 'ul' ) as $x ) {
			return true;
		}
		foreach ( $list->getElementsByTagName( 'ol' ) as $x ) {
			return true;
		}
		return false;
	}

	/**
	 * Move every post from one import to the bin.
	 *
	 * @param string $batch Batch id.
	 * @return int Number of posts moved.
	 */
	public static function undo( $batch ) {
		$batches = get_option( self::BATCHES, array() );
		if ( ! isset( $batches[ $batch ] ) ) {
			return 0;
		}
		$n = 0;
		foreach ( $batches[ $batch ]['ids'] as $id ) {
			if ( get_post_meta( $id, '_vbi_batch', true ) === $batch && current_user_can( 'delete_post', $id ) && wp_trash_post( $id ) ) {
				$n++;
			}
		}
		unset( $batches[ $batch ] );
		update_option( self::BATCHES, $batches, false );
		return $n;
	}
}
