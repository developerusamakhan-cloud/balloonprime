=== Vyntic Blog Importer ===
Contributors: vynticstudio
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Import a batch of blog posts from one JSON file and schedule them.

== Description ==

Posts → Import blog file.

1. Upload a .json file with your posts.
2. Choose when they go live: spread out (for example one post every 3 days at 9:00), use the
   dates in the file, publish all now, or save as drafts. The exact date of every post shows
   before you import.
3. Import. Each post gets its category (created if missing), tags, excerpt, featured image,
   Rank Math or Yoast SEO title, meta description and focus keyword, plus FAQ schema.

Also included:

* Duplicate check by slug: skip, replace or add as new.
* HTML is converted into editor blocks, so every paragraph and heading can be edited.
* Link tokens: {{contact|anchor}} (Vyntic theme page key), {{/path/|anchor}},
  {{ext:https://example.com|anchor}} and {{price:starter}}.
* Missed schedule fix: any scheduled post whose time has passed is published on the next
  page view, so posts go live even when WP-Cron is unreliable.
* Recent imports with "Undo import", which moves that batch to the bin.

== Changelog ==

= 1.0.0 =
* First release.
