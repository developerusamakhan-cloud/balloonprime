<?php
/**
 * Admin: dashboard, prompts, responses, crawlers, settings.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI and AJAX endpoints.
 */
class AIVT_Admin {

	const CAP = 'manage_options';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_aivt_add_prompts', array( __CLASS__, 'handle_add_prompts' ) );
		add_action( 'admin_post_aivt_prompt_action', array( __CLASS__, 'handle_prompt_action' ) );
		add_action( 'admin_post_aivt_refresh_robots', array( __CLASS__, 'handle_refresh_robots' ) );
		add_action( 'wp_ajax_aivt_jobs', array( __CLASS__, 'ajax_jobs' ) );
		add_action( 'wp_ajax_aivt_run_job', array( __CLASS__, 'ajax_run_job' ) );
		add_action( 'wp_ajax_aivt_suggest_prompts', array( __CLASS__, 'ajax_suggest_prompts' ) );
		add_action( 'wp_ajax_aivt_test_engine', array( __CLASS__, 'ajax_test_engine' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( AIVT_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Admin page slug (one page, with tabs).
	 */
	const SLUG = 'vyntic-ai-visibility';

	/**
	 * Tabs.
	 *
	 * @return array
	 */
	public static function tabs() {
		return array(
			'dashboard' => __( 'Dashboard', 'vyntic-ai-visibility' ),
			'prompts'   => __( 'Prompts', 'vyntic-ai-visibility' ),
			'responses' => __( 'Responses', 'vyntic-ai-visibility' ),
			'crawlers'  => __( 'AI Crawlers & llms.txt', 'vyntic-ai-visibility' ),
			'settings'  => __( 'Settings', 'vyntic-ai-visibility' ),
		);
	}

	/**
	 * URL of a tab.
	 *
	 * @param string $tab  Tab key.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function url( $tab = 'dashboard', array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Menu: one item inside the shared "Vyntic" menu.
	 */
	public static function menu() {
		if ( class_exists( 'Vyntic_Client' ) ) {
			add_submenu_page( Vyntic_Client::MENU, __( 'Vyntic AI Visibility', 'vyntic-ai-visibility' ), __( 'AI Visibility', 'vyntic-ai-visibility' ), self::CAP, self::SLUG, array( __CLASS__, 'render' ) );
			return;
		}
		add_menu_page( __( 'Vyntic AI Visibility', 'vyntic-ai-visibility' ), __( 'AI Visibility', 'vyntic-ai-visibility' ), self::CAP, self::SLUG, array( __CLASS__, 'render' ), 'dashicons-visibility', 59 );
	}

	/**
	 * Branded page with tabs; each tab reuses its original view.
	 */
	public static function render() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tabs = self::tabs();
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'dashboard';
		}
		$views = array(
			'dashboard' => 'dashboard_page',
			'prompts'   => 'prompts_page',
			'responses' => 'responses_page',
			'crawlers'  => 'crawlers_page',
			'settings'  => 'settings_page',
		);
		ob_start();
		call_user_func( array( __CLASS__, $views[ $tab ] ) );
		$html = (string) ob_get_clean();
		// The views were written as separate pages: drop their outer .wrap and turn the page title into a section title.
		$html = preg_replace( '/class="wrap aivt-wrap"/', 'class="aivt-wrap aivt-view"', $html, 1 );
		$html = preg_replace( '#<h1>(.*?)</h1>#s', '<h2 class="aivt-view-title">$1</h2>', $html, 1 );
		?>
		<div class="wrap vy-wrap">
			<div class="vy-header">
				<div class="vy-brand">
					<span class="vy-logo" aria-hidden="true"><svg viewBox="0 0 108 108" focusable="false"><polygon points="2,12 30,12 62,96 34,96" fill="#ffffff"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>
					<div>
						<h1><?php esc_html_e( 'Vyntic AI Visibility', 'vyntic-ai-visibility' ); ?></h1>
						<p><?php esc_html_e( 'See if AI assistants recommend your business, using free API keys.', 'vyntic-ai-visibility' ); ?>
							<span class="vy-by"><?php esc_html_e( 'by', 'vyntic-ai-visibility' ); ?> <a href="https://vyntic.studio/" target="_blank" rel="noopener">Vyntic Studio</a></span></p>
					</div>
				</div>
				<div class="vy-header-actions">
					<a class="vy-link" href="https://vyntic.studio/plugins/vyntic-ai-visibility/" target="_blank" rel="noopener"><?php esc_html_e( 'Guide', 'vyntic-ai-visibility' ); ?> &#8599;</a>
					<a class="vy-link" href="https://vyntic.studio/" target="_blank" rel="noopener">vyntic.studio &#8599;</a>
				</div>
			</div>
			<hr class="wp-header-end">
			<nav class="vy-tabs">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="vy-tab <?php echo $key === $tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( self::url( $key ) ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<?php if ( class_exists( 'Vyntic_Client' ) && method_exists( 'Vyntic_Client', 'updates_link' ) ) : ?>
					<?php $vy_upd = Vyntic_Client::updates_link( self::SLUG ); ?>
					<a class="vy-tab vy-tab--updates" href="<?php echo esc_url( $vy_upd['url'] ); ?>"><?php echo esc_html( $vy_upd['label'] ); ?><?php if ( $vy_upd['count'] ) : ?> <span class="vy-tab-count"><?php echo (int) $vy_upd['count']; ?></span><?php endif; ?></a>
				<?php endif; ?>
			</nav>
			<div class="vy-body">
				<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the views. ?>
			</div>
			<div class="vy-footer">
				<span><?php esc_html_e( 'Want AI tools to recommend you? Vyntic Studio helps businesses get found in Google and AI search.', 'vyntic-ai-visibility' ); ?></span>
				<span><a href="https://vyntic.studio/services/ai-search-visibility/" target="_blank" rel="noopener"><?php esc_html_e( 'AI search visibility service', 'vyntic-ai-visibility' ); ?></a> · <a href="https://vyntic.studio/plugins/" target="_blank" rel="noopener"><?php esc_html_e( 'More free plugins', 'vyntic-ai-visibility' ); ?></a></span>
			</div>
		</div>
		<?php
	}

	/**
	 * Settings link on the plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url( 'settings' ) ) . '">' . esc_html__( 'Settings', 'vyntic-ai-visibility' ) . '</a>' );
		return $links;
	}

	/**
	 * Admin assets.
	 *
	 * @param string $hook Page hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'aivt-brand', AIVT_URL . 'assets/css/vyntic-brand.css', array(), AIVT_VERSION );
		wp_enqueue_style( 'aivt-admin', AIVT_URL . 'assets/css/aivt-admin.css', array( 'aivt-brand' ), AIVT_VERSION );
		wp_enqueue_script( 'aivt-admin', AIVT_URL . 'assets/js/aivt-admin.js', array( 'jquery' ), AIVT_VERSION, true );
		wp_localize_script(
			'aivt-admin',
			'aivtAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'aivt_ajax' ),
				'i18n'    => array(
					'running'    => __( 'Checking %1$d of %2$d…', 'vyntic-ai-visibility' ),
					'done'       => __( 'Done! %1$d checks completed, %2$d failed. Reloading…', 'vyntic-ai-visibility' ),
					'noJobs'     => __( 'Nothing to check. Add prompts and enable at least one AI engine in Settings.', 'vyntic-ai-visibility' ),
					'confirmRun' => __( 'This sends %d requests to the AI engines using your free API keys. Continue?', 'vyntic-ai-visibility' ),
					'suggesting' => __( 'Asking AI for ideas…', 'vyntic-ai-visibility' ),
					'error'      => __( 'Something went wrong.', 'vyntic-ai-visibility' ),
					'testing'    => __( 'Asking the AI a test question with web search…', 'vyntic-ai-visibility' ),
				),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Pages
	 * ------------------------------------------------------------------- */

	/**
	 * Dashboard.
	 */
	public static function dashboard_page() {
		$days = isset( $_GET['days'] ) ? absint( $_GET['days'] ) : 30; // phpcs:ignore WordPress.Security.NonceVerification
		$days = in_array( $days, array( 7, 30, 90 ), true ) ? $days : 30;
		$data = AIVT_Stats::dashboard( $days );
		include AIVT_PATH . 'templates/dashboard.php';
	}

	/**
	 * Prompts list + add form.
	 */
	public static function prompts_page() {
		$prompts = AIVT_Repository::prompts();
		$latest  = array();
		foreach ( AIVT_Repository::latest_results() as $row ) {
			$latest[ $row->prompt_id ][ $row->engine ] = $row;
		}
		$engines = AIVT_Engine::active();
		include AIVT_PATH . 'templates/prompts.php';
	}

	/**
	 * Responses log.
	 */
	public static function responses_page() {
		// phpcs:disable WordPress.Security.NonceVerification
		$filters = array(
			'engine'    => isset( $_GET['engine'] ) ? sanitize_key( $_GET['engine'] ) : '',
			'prompt_id' => isset( $_GET['prompt_id'] ) ? absint( $_GET['prompt_id'] ) : 0,
			'mentioned' => isset( $_GET['mentioned'] ) && in_array( $_GET['mentioned'], array( '0', '1' ), true ) ? sanitize_key( $_GET['mentioned'] ) : '',
			'page'      => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1,
			'per_page'  => 20,
		);
		// phpcs:enable
		$result  = AIVT_Repository::results_page( $filters );
		$prompts = array();
		foreach ( AIVT_Repository::prompts() as $p ) {
			$prompts[ $p->id ] = $p->prompt;
		}
		include AIVT_PATH . 'templates/responses.php';
	}

	/**
	 * Crawler check + llms.txt.
	 */
	public static function crawlers_page() {
		$bots = AIVT_Crawlers::check();
		include AIVT_PATH . 'templates/crawlers.php';
	}

	/**
	 * Settings.
	 */
	public static function settings_page() {
		$s = AIVT_Settings::all();
		include AIVT_PATH . 'templates/settings.php';
	}

	/**
	 * Settings API registration.
	 */
	public static function register_settings() {
		register_setting(
			'aivt_settings_group',
			AIVT_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'AIVT_Settings', 'sanitize' ),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Form handlers
	 * ------------------------------------------------------------------- */

	/**
	 * Add one prompt per line.
	 */
	public static function handle_add_prompts() {
		self::guard( 'aivt_add_prompts' );
		$raw   = isset( $_POST['prompts'] ) ? sanitize_textarea_field( wp_unslash( $_POST['prompts'] ) ) : '';
		$tag   = isset( $_POST['tag'] ) ? sanitize_text_field( wp_unslash( $_POST['tag'] ) ) : '';
		$added = 0;
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			if ( AIVT_Repository::add_prompt( mb_substr( trim( $line ), 0, 500 ), $tag ) ) {
				++$added;
			}
		}
		self::back( 'aivt-prompts', array( 'added' => $added ) );
	}

	/**
	 * Pause / resume / delete a prompt.
	 */
	public static function handle_prompt_action() {
		self::guard( 'aivt_prompt_action' );
		$id     = isset( $_POST['prompt_id'] ) ? absint( $_POST['prompt_id'] ) : 0;
		$action = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';

		if ( 'delete' === $action ) {
			AIVT_Repository::delete_prompt( $id );
		} elseif ( in_array( $action, array( 'pause', 'resume' ), true ) ) {
			AIVT_Repository::set_prompt_active( $id, 'resume' === $action );
		}
		self::back( 'aivt-prompts', array( 'updated' => 1 ) );
	}

	/**
	 * Re-fetch robots.txt.
	 */
	public static function handle_refresh_robots() {
		self::guard( 'aivt_refresh_robots' );
		AIVT_Crawlers::robots_txt( true );
		self::back( 'aivt-crawlers', array( 'refreshed' => 1 ) );
	}

	/**
	 * Capability + nonce check for admin-post handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'vyntic-ai-visibility' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Redirect back to a plugin page.
	 *
	 * @param string $page Page slug.
	 * @param array  $args Query args.
	 */
	private static function back( $page, array $args = array() ) {
		wp_safe_redirect( self::url( str_replace( 'aivt-', '', $page ), $args ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------- */

	/**
	 * Capability + nonce check for AJAX.
	 */
	private static function ajax_guard() {
		if ( ! current_user_can( self::CAP ) || ! check_ajax_referer( 'aivt_ajax', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'vyntic-ai-visibility' ) ), 403 );
		}
	}

	/**
	 * Jobs for "Run check now" (optionally a single prompt).
	 */
	public static function ajax_jobs() {
		self::ajax_guard();
		$jobs      = AIVT_Runner::jobs();
		$prompt_id = isset( $_POST['prompt_id'] ) ? absint( $_POST['prompt_id'] ) : 0;
		if ( $prompt_id ) {
			$jobs = array();
			if ( AIVT_Repository::prompt( $prompt_id ) ) {
				foreach ( array_keys( AIVT_Engine::active() ) as $engine ) {
					$jobs[] = array(
						'prompt_id' => $prompt_id,
						'engine'    => $engine,
					);
				}
			}
		}
		wp_send_json_success( array( 'jobs' => $jobs ) );
	}

	/**
	 * Run one prompt on one engine.
	 */
	public static function ajax_run_job() {
		self::ajax_guard();
		$prompt_id = isset( $_POST['prompt_id'] ) ? absint( $_POST['prompt_id'] ) : 0;
		$engine    = isset( $_POST['engine'] ) ? sanitize_key( $_POST['engine'] ) : '';

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$result = AIVT_Runner::run_job( $prompt_id, $engine );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		update_option( 'aivt_last_run', time(), false );
		wp_send_json_success(
			array(
				'mentioned' => (int) $result['brand_mentioned'],
				'cited'     => (int) $result['brand_cited'],
			)
		);
	}

	/**
	 * Connection test: one short question with web search, using the key in the field or the saved key.
	 */
	public static function ajax_test_engine() {
		self::ajax_guard();
		$id     = isset( $_POST['engine'] ) ? sanitize_key( $_POST['engine'] ) : '';
		$engine = AIVT_Engine::make( $id );
		if ( ! $engine ) {
			wp_send_json_error( array( 'message' => __( 'Unknown engine.', 'vyntic-ai-visibility' ) ) );
		}
		$engine->set_override(
			isset( $_POST['key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['key'] ) ) ) : '',
			isset( $_POST['model'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['model'] ) ) ) : ''
		);
		if ( '' === $engine->api_key() ) {
			wp_send_json_error( array( 'message' => __( 'Paste an API key first.', 'vyntic-ai-visibility' ) ) );
		}

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$start  = microtime( true );
		$answer = $engine->ask(
			$engine->searches()
				? 'Search the web: what is the latest stable version of WordPress? Answer in one short sentence and name your source.'
				: 'In one short sentence: what is WordPress?',
			true
		);
		$secs   = round( microtime( true ) - $start, 1 );

		if ( is_wp_error( $answer ) ) {
			AIVT_Engine::set_status( $id, false, $answer->get_error_message() );
			wp_send_json_error(
				array(
					'message' => $answer->get_error_message(),
					'badge'   => self::status_badge( $id ),
				)
			);
		}
		if ( '' === trim( $answer['text'] ) ) {
			$msg = __( 'The AI replied with an empty answer. Try again, or try another model.', 'vyntic-ai-visibility' );
			AIVT_Engine::set_status( $id, false, $msg );
			wp_send_json_error(
				array(
					'message' => $msg,
					'badge'   => self::status_badge( $id ),
				)
			);
		}

		$sources  = count( $answer['citations'] );
		$searched = ! isset( $answer['searched'] ) || $answer['searched'];
		AIVT_Engine::set_status( $id, true, '', $sources );
		if ( ! $searched ) {
			wp_send_json_success(
				array(
					/* translators: 1: model, 2: seconds */
					'message' => sprintf( __( 'Working. %1$s answered in %2$s seconds from its own knowledge (Google Search is off).', 'vyntic-ai-visibility' ), $answer['model'], $secs ),
					'answer'  => wp_trim_words( preg_replace( '/\[([^\]]+)\]\([^)]+\)/', '$1', $answer['text'] ), 40 ),
					'warn'    => false,
					'badge'   => self::status_badge( $id ),
				)
			);
		}
		wp_send_json_success(
			array(
				'message' => $sources
					/* translators: 1: model, 2: seconds, 3: number of web sources */
					? sprintf( _n( 'Working. %1$s answered in %2$s seconds and searched the web (%3$d source).', 'Working. %1$s answered in %2$s seconds and searched the web (%3$d sources).', $sources, 'vyntic-ai-visibility' ), $answer['model'], $secs, $sources )
					/* translators: 1: model, 2: seconds */
					: sprintf( __( 'The key works and %1$s answered in %2$s seconds, but it returned no web sources this time. Checks still run; if this keeps happening, try another model.', 'vyntic-ai-visibility' ), $answer['model'], $secs ),
				'answer'  => wp_trim_words( preg_replace( '/\[([^\]]+)\]\([^)]+\)/', '$1', $answer['text'] ), 40 ),
				'warn'    => ! $sources,
				'badge'   => self::status_badge( $id ),
			)
		);
	}

	/**
	 * Ask the first ready engine for prompt ideas.
	 */
	public static function ajax_suggest_prompts() {
		self::ajax_guard();
		$engines = AIVT_Engine::active();
		if ( ! $engines ) {
			wp_send_json_error( array( 'message' => __( 'Enable an AI engine and add its API key in Settings first.', 'vyntic-ai-visibility' ) ) );
		}
		$engine = reset( $engines );

		$brief = sprintf(
			"Business: %s\nWebsite: %s\nWhat it does: %s\nCompetitors: %s",
			AIVT_Settings::get( 'brand_name' ),
			AIVT_Settings::get( 'brand_domain' ),
			AIVT_Settings::get( 'brand_description' ),
			implode( ', ', wp_list_pluck( AIVT_Settings::competitors(), 'name' ) )
		);

		$instruction = "You help a business track whether AI assistants recommend it.\n\n{$brief}\n\n"
			. 'Write 10 realistic questions a potential customer would type into an AI assistant such as ChatGPT or Gemini while looking for a product or service like this one '
			. '(for example "best ... in ...", "... vs ...", "how do I choose a ..."). Do not mention the business name. '
			. 'Write them in the language of the description. Return only the questions, one per line, with no numbering or extra text.';

		$answer = $engine->ask( $instruction, false );
		if ( is_wp_error( $answer ) ) {
			wp_send_json_error( array( 'message' => $answer->get_error_message() ) );
		}

		$ideas = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $answer['text'] ) as $line ) {
			$line = trim( preg_replace( '/^\s*(?:[-*•]|\d+[.)])\s*/u', '', $line ), " \t\"'" );
			if ( mb_strlen( $line ) > 8 ) {
				$ideas[] = sanitize_text_field( $line );
			}
		}
		wp_send_json_success( array( 'ideas' => array_slice( $ideas, 0, 15 ) ) );
	}

	/* ---------------------------------------------------------------------
	 * View helpers
	 * ------------------------------------------------------------------- */

	/**
	 * "Working" / "Not working" / "Not tested" pill for an engine.
	 *
	 * @param string $id Engine ID.
	 * @return string HTML.
	 */
	public static function status_badge( $id ) {
		return '<span class="aivt-badge">' . self::status_badge_inner( $id ) . '</span>';
	}

	/**
	 * Inside of status_badge().
	 *
	 * @param string $id Engine ID.
	 * @return string HTML.
	 */
	private static function status_badge_inner( $id ) {
		$status = AIVT_Engine::status( $id );
		if ( ! $status ) {
			return '<span class="aivt-epill is-none">' . esc_html__( 'Not tested yet', 'vyntic-ai-visibility' ) . '</span>';
		}
		/* translators: %s: time ago, e.g. "5 mins" */
		$when = sprintf( __( '%s ago', 'vyntic-ai-visibility' ), human_time_diff( $status['time'] ) );
		if ( $status['ok'] ) {
			return '<span class="aivt-epill is-ok">' . esc_html__( 'Working', 'vyntic-ai-visibility' ) . '</span> <span class="aivt-muted">' . esc_html( $when ) . '</span>';
		}
		return '<span class="aivt-epill is-bad" title="' . esc_attr( $status['message'] ) . '">' . esc_html__( 'Not working', 'vyntic-ai-visibility' ) . '</span> <span class="aivt-muted">' . esc_html( $when . ': ' . wp_trim_words( $status['message'], 18 ) ) . '</span>';
	}

	/**
	 * Inline SVG line chart of daily visibility and citation rate.
	 *
	 * @param array $trend date => visibility, citation.
	 * @return string SVG markup.
	 */
	public static function trend_svg( array $trend ) {
		if ( count( $trend ) < 2 ) {
			return '<p class="aivt-muted">' . esc_html__( 'The trend chart appears after checks have run on at least two different days.', 'vyntic-ai-visibility' ) . '</p>';
		}

		$w     = 640;
		$h     = 220;
		$pad   = 32;
		$n     = count( $trend );
		$dates = array_keys( $trend );
		$lines = array(
			'visibility' => '',
			'citation'   => '',
		);
		$dots  = '';
		$i     = 0;

		foreach ( $trend as $date => $point ) {
			$x = $pad + ( $w - 2 * $pad ) * $i / ( $n - 1 );
			foreach ( array_keys( $lines ) as $key ) {
				$y              = $h - $pad - ( $h - 2 * $pad ) * $point[ $key ] / 100;
				$lines[ $key ] .= sprintf( '%s%.1f,%.1f ', '' === $lines[ $key ] ? 'M' : 'L', $x, $y );
				$dots          .= sprintf(
					'<circle class="aivt-dot-%1$s" cx="%2$.1f" cy="%3$.1f" r="3"><title>%4$s: %5$s%%</title></circle>',
					esc_attr( $key ),
					$x,
					$y,
					esc_attr( date_i18n( get_option( 'date_format' ), strtotime( $date ) ) ),
					esc_attr( $point[ $key ] )
				);
			}
			++$i;
		}

		$grid = '';
		foreach ( array( 0, 25, 50, 75, 100 ) as $pct ) {
			$y     = $h - $pad - ( $h - 2 * $pad ) * $pct / 100;
			$grid .= sprintf( '<line x1="%1$d" x2="%2$d" y1="%3$.1f" y2="%3$.1f" class="aivt-grid"/><text x="4" y="%4$.1f" class="aivt-axis">%5$d%%</text>', $pad, $w - $pad, $y, $y + 4, $pct );
		}
		$labels = sprintf(
			'<text x="%1$d" y="%2$d" class="aivt-axis">%3$s</text><text x="%4$d" y="%2$d" class="aivt-axis" text-anchor="end">%5$s</text>',
			$pad,
			$h - 8,
			esc_html( date_i18n( 'M j', strtotime( $dates[0] ) ) ),
			$w - $pad,
			esc_html( date_i18n( 'M j', strtotime( $dates[ $n - 1 ] ) ) )
		);

		return sprintf(
			'<svg class="aivt-chart" viewBox="0 0 %1$d %2$d" role="img" aria-label="%3$s">%4$s<path class="aivt-line-visibility" d="%5$s"/><path class="aivt-line-citation" d="%6$s"/>%7$s%8$s</svg>',
			$w,
			$h,
			esc_attr__( 'Visibility trend', 'vyntic-ai-visibility' ),
			$grid,
			esc_attr( trim( $lines['visibility'] ) ),
			esc_attr( trim( $lines['citation'] ) ),
			$dots,
			$labels
		);
	}

	/**
	 * Arrow + change vs. previous period.
	 *
	 * @param float|null $now     Current value.
	 * @param float|null $before  Previous value.
	 * @param bool       $lower_is_better E.g. average position.
	 * @return string HTML.
	 */
	public static function delta( $now, $before, $lower_is_better = false ) {
		if ( null === $now || null === $before ) {
			return '';
		}
		$diff = round( $now - $before, 1 );
		if ( 0.0 === (float) $diff ) {
			return '<span class="aivt-delta">±0</span>';
		}
		$good = $lower_is_better ? $diff < 0 : $diff > 0;
		return sprintf( '<span class="aivt-delta %s">%s%s</span>', $good ? 'is-up' : 'is-down', $diff > 0 ? '▲ +' : '▼ ', esc_html( $diff ) );
	}

	/**
	 * Colored sentiment pill.
	 *
	 * @param string $sentiment positive|neutral|negative|''.
	 * @return string HTML.
	 */
	public static function sentiment_pill( $sentiment ) {
		$labels = array(
			'positive' => __( 'Positive', 'vyntic-ai-visibility' ),
			'neutral'  => __( 'Neutral', 'vyntic-ai-visibility' ),
			'negative' => __( 'Negative', 'vyntic-ai-visibility' ),
		);
		if ( ! isset( $labels[ $sentiment ] ) ) {
			return '<span class="aivt-muted">-</span>';
		}
		return sprintf( '<span class="aivt-pill is-%s">%s</span>', esc_attr( $sentiment ), esc_html( $labels[ $sentiment ] ) );
	}
}
