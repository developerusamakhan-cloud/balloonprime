=== Vyntic AI Visibility ===
Contributors: vyntic
Author: Vyntic Studio
Author URI: https://vyntic.studio/
Plugin URI: https://vyntic.studio/plugins/vyntic-ai-visibility/
Tags: ai visibility, gemini, generative engine optimization, llms.txt, brand monitoring
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

See how often AI assistants mention and cite your business, which competitors they recommend instead, and what to do about it. Works with free API keys.

== Description ==

AI assistants now answer questions like "who is the best dentist in Austin?" directly. This plugin tracks whether those answers include you.

How it works:

1. You add the questions ("prompts") your customers ask AI, or let AI suggest them.
2. On a schedule (or when you click "Run check now") the plugin sends every prompt to every enabled AI engine through its official API, with web search turned on so the answers match what the consumer apps show.
3. Each answer is analysed:
   * **Mention**: is your brand name (or an alias / your domain) in the answer?
   * **Position**: are you named first, second, third… compared with your competitors?
   * **Citation**: does the answer link to your website?
   * **Sentiment**: are the sentences about you positive, neutral or negative?
   * **Competitors**: which competitors are named or cited?
   * **Sources**: which websites the AI used.
4. The dashboard shows AI Visibility %, Citation %, average position, net sentiment, a trend chart, results per engine, share of voice vs. competitors, the sources AI cites most, and a prioritised list of **opportunities**:
   * prompts where competitors are recommended but you are not,
   * prompts where AI describes you negatively,
   * prompts where you are mentioned but another site is linked,
   * third-party sites AI keeps citing (outreach / listing targets),
   * AI crawlers blocked in robots.txt, missing llms.txt.

Extras:

* **AI Crawlers check**: shows whether robots.txt blocks GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-SearchBot, PerplexityBot, Google-Extended, Bingbot and more, and explains which ones matter for AI answers.
* **llms.txt generator**: serves `/llms.txt` built from your pages, products and posts.
* **Responses log**: read every AI answer with its sources, filter by prompt, engine and mentioned / not mentioned.

The plugin is free and so are the engines it uses: GPT-OSS on Groq (with browser search) and Google Gemini both give free API keys. On Gemini's free tier answers come from Gemini's own knowledge; Google Search answers need a paid Gemini API project. Nothing is sent to any other server.

== Installation ==

1. In WordPress go to Plugins, Add New, Upload Plugin, choose `vyntic-ai-visibility.zip` and activate.
2. Open **Vyntic, AI Visibility, Settings** (or **AI Visibility** when it is your only Vyntic plugin): enter your brand name, other spellings, domain, a short description and your competitors (`Name | domain.com`, one per line).
3. Enable at least one engine and paste its free API key:
   * Gemini: https://aistudio.google.com/app/apikey
   * GPT-OSS (Groq): https://console.groq.com/keys
4. Open the **Prompts** tab, add 10 to 20 questions (or click "Suggest prompts with AI") and click "Run all prompts now".
5. Open the **Dashboard** tab. Checks repeat weekly by default (Settings, Automatic checks).

Updates arrive automatically from vyntic.studio, like every Vyntic plugin.

== Frequently Asked Questions ==

= Why do results differ from what I see in ChatGPT? =

AI answers vary between runs, locations and accounts. Track the trend over several checks rather than one answer, and use enough prompts (10+) for meaningful percentages.

= How much does it cost? =

Nothing. Both engines have free API keys. Requests per run = active prompts × enabled engines, so 20 prompts × 2 engines weekly is 40 requests a week, well inside the free limits. If a provider's rate limit is reached, that answer is logged as an error and the next run tries again.

= Why not ChatGPT, Claude, Perplexity or Grok? =

Their APIs are paid from the first request. Version 1.2.0 keeps the plugin free to run, so only engines with a free API key are included. Answers saved from those engines before 1.2.0 stay in your history.

= Can I change the models? =

Yes, each engine has a model field. The model must support web search through the API: Gemini models (gemini-3.8-flash by default; turn on Google Search only on a paid Gemini API project) and Groq models with browser search (openai/gpt-oss-120b or openai/gpt-oss-20b).

= How do I know an engine is working? =

Settings, AI engines, click "Test connection". You see Working (with the model, the time and the number of web sources) or the exact error from the provider, such as a wrong key or a rate limit. The Dashboard shows the same status for each engine.

= Does WP-Cron need to run? =

Scheduled checks use WP-Cron, which runs when your site gets visits. On low-traffic sites set up a real cron job that calls `wp-cron.php`. Manual checks from the admin always work.

= I used "AI Visibility Tracker" before. Do I lose my data? =

No. Vyntic AI Visibility uses the same prompts, results and settings. Deactivate and delete the old plugin, then activate this one; everything is still there.

= Is my API key sent anywhere else? =

No. Keys are stored in your WordPress database and sent only to the AI provider you enabled. Nothing goes to Vyntic Studio.

== Changelog ==

= 1.2.2 (2026-10-13) =
* Gemini now uses gemini-3.8-flash. Google closed gemini-2.5-flash to new users, so sites still on it move to gemini-3.8-flash automatically.
* If Google retires a Gemini model again, the plugin switches to the model Google names in the error and saves it.
* Gemini answers from its own knowledge by default, which works on the free tier. New "Answer with Google Search" option for paid Gemini API projects, since Google Search is not part of Gemini's free tier.
* Cleaner Settings screen: fields in tidy rows, one card per AI engine with an on/off switch, its key, model, Test connection button and status, and a Save bar that stays at the bottom of the screen.

= 1.2.1 (2026-10-13) =
* New "Test connection" button for each engine: asks one short question with web search and shows whether the key works, the model, the answer time and how many web sources came back. Works before you save the key.
* Each engine shows Working, Not working (with the reason) or Not tested yet, in Settings and on the Dashboard. Every check updates it.

= 1.2.0 (2026-10-13) =
* Free engines only: added GPT-OSS on Groq with browser search, kept Gemini with Google Search. Removed ChatGPT, Claude and Perplexity, whose APIs are paid; their saved keys are deleted on update, and their earlier answers stay in your history.
* Settings show each engine's free tier limits.

= 1.1.0 (2026-10-13) =
* Now part of the Vyntic plugin family: one "AI Visibility" item in the shared Vyntic menu, with Dashboard, Prompts, Responses, AI Crawlers and Settings as tabs.
* New look in Vyntic Studio colours.
* Automatic updates from vyntic.studio, with an Updates tab.
* Data from "AI Visibility Tracker" carries over unchanged. Running both at once is blocked with a clear notice instead of an error.

= 1.0.0 (2026-09-22) =
* First release: AI visibility, citation and sentiment tracking across ChatGPT, Claude, Gemini and Perplexity, competitor share of voice, opportunities, AI crawler check and llms.txt generator.
