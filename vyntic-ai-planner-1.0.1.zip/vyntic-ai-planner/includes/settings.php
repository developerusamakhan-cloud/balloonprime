<?php
/**
 * Settings: AI Planner → Settings.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Default settings. */
function vap_defaults() {
	return array(
		'provider'       => 'gemini',
		'gemini_key'     => '',
		'gemini_model'   => 'gemini-2.5-flash',
		'oa_base'        => 'https://api.groq.com/openai/v1',
		'oa_key'         => '',
		'oa_model'       => 'llama-3.3-70b-versatile',
		'fallback'       => 1,
		'per_visitor'    => 3,
		'daily_cap'      => 200,
		'notify_email'   => get_option( 'admin_email' ),
		'send_copy'      => 1,
		'from_name'      => get_bloginfo( 'name' ),
		'cta_url'        => '',
		'cta_label'      => 'Book a free project call',
		'consent_text'   => 'Send me my plan by email and contact me about my project. No spam, unsubscribe anytime.',
		'privacy_url'    => '',
		'agency_context' => 'Vyntic Studio is a web design, SEO and AI search studio. It builds fast websites on WordPress, Webflow, Shopify, Wix and GoHighLevel, and offers local SEO, AI search visibility and care plans.',
	);
}

/** Get one setting. */
function vap_opt( $key ) {
	$all = wp_parse_args( (array) get_option( 'vap_settings', array() ), vap_defaults() );
	return isset( $all[ $key ] ) ? $all[ $key ] : '';
}

add_action( 'admin_menu', function () {
	add_menu_page( __( 'AI Planner', 'vyntic-ai-planner' ), __( 'AI Planner', 'vyntic-ai-planner' ), 'manage_options', 'vap-settings', 'vap_settings_screen', 'dashicons-lightbulb', 58 );
	add_submenu_page( 'vap-settings', __( 'Settings', 'vyntic-ai-planner' ), __( 'Settings', 'vyntic-ai-planner' ), 'manage_options', 'vap-settings', 'vap_settings_screen' );
} );

add_action( 'admin_init', function () {
	register_setting(
		'vap_settings_group',
		'vap_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'vap_sanitize_settings',
		)
	);
} );

/**
 * Sanitize settings. Saved API keys are kept when the field is left empty,
 * because keys are never printed back into the form.
 *
 * @param array $in Raw input.
 * @return array
 */
function vap_sanitize_settings( $in ) {
	$in  = (array) $in;
	$d   = vap_defaults();
	$old = (array) get_option( 'vap_settings', array() );
	$get = function ( $k, $fallback = '' ) use ( $in ) {
		return isset( $in[ $k ] ) ? $in[ $k ] : $fallback;
	};
	$out                 = array();
	$out['provider']     = in_array( $get( 'provider' ), array( 'gemini', 'openai', 'wp' ), true ) ? $get( 'provider' ) : 'gemini';
	$out['gemini_key']   = trim( (string) $get( 'gemini_key' ) ) ? preg_replace( '/\s+/', '', sanitize_text_field( $get( 'gemini_key' ) ) ) : ( isset( $old['gemini_key'] ) ? $old['gemini_key'] : '' );
	$out['oa_key']       = trim( (string) $get( 'oa_key' ) ) ? preg_replace( '/\s+/', '', sanitize_text_field( $get( 'oa_key' ) ) ) : ( isset( $old['oa_key'] ) ? $old['oa_key'] : '' );
	if ( $get( 'clear_gemini' ) ) {
		$out['gemini_key'] = '';
	}
	if ( $get( 'clear_oa' ) ) {
		$out['oa_key'] = '';
	}
	$out['gemini_model']   = sanitize_text_field( $get( 'gemini_model' ) ? $get( 'gemini_model' ) : $d['gemini_model'] );
	$out['oa_base']        = esc_url_raw( untrailingslashit( $get( 'oa_base' ) ? $get( 'oa_base' ) : $d['oa_base'] ) );
	$out['oa_model']       = sanitize_text_field( $get( 'oa_model' ) ? $get( 'oa_model' ) : $d['oa_model'] );
	$out['fallback']       = $get( 'fallback' ) ? 1 : 0;
	$out['per_visitor']    = max( 1, min( 50, absint( $get( 'per_visitor', 3 ) ) ) );
	$out['daily_cap']      = max( 1, min( 5000, absint( $get( 'daily_cap', 200 ) ) ) );
	$out['notify_email']   = sanitize_email( $get( 'notify_email' ) );
	$out['send_copy']      = $get( 'send_copy' ) ? 1 : 0;
	$out['from_name']      = sanitize_text_field( $get( 'from_name' ) );
	$out['cta_url']        = esc_url_raw( $get( 'cta_url' ) );
	$out['cta_label']      = sanitize_text_field( $get( 'cta_label', $d['cta_label'] ) );
	$out['consent_text']   = sanitize_text_field( $get( 'consent_text', $d['consent_text'] ) );
	$out['privacy_url']    = esc_url_raw( $get( 'privacy_url' ) );
	$out['agency_context'] = sanitize_textarea_field( $get( 'agency_context', $d['agency_context'] ) );
	return $out;
}

/** "Test connection" button. */
add_action( 'admin_post_vap_test', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vap_test' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic-ai-planner' ) );
	}
	$res = vap_generate( 'Reply with JSON only, exactly: {"ok": true}', 'Test' );
	$msg = is_wp_error( $res ) ? 'error:' . $res->get_error_message() : 'ok';
	wp_safe_redirect( add_query_arg( array( 'page' => 'vap-settings', 'vap_test' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
	exit;
} );

/**
 * Short, safe preview of a saved key, e.g. "AIza…7890".
 *
 * @param string $key Key.
 * @return string
 */
function vap_key_preview( $key ) {
	$key = (string) $key;
	return strlen( $key ) > 10 ? substr( $key, 0, 4 ) . '…' . substr( $key, -4 ) : str_repeat( '•', 6 );
}

/**
 * "Key saved" line under a key field.
 *
 * @param string $key Saved key.
 */
function vap_key_status( $key ) {
	if ( $key ) {
		/* translators: %s key preview */
		echo '<p class="description" style="color:#008a20;font-weight:600">&#10003; ' . esc_html( sprintf( __( 'Key saved: %s. Leave the field empty to keep it, or paste a new key to replace it.', 'vyntic-ai-planner' ), vap_key_preview( $key ) ) ) . '</p>';
	} else {
		echo '<p class="description" style="color:#b32d2e;font-weight:600">' . esc_html__( 'No key saved yet.', 'vyntic-ai-planner' ) . '</p>';
	}
}

function vap_settings_screen() {
	$o = wp_parse_args( (array) get_option( 'vap_settings', array() ), vap_defaults() );
	$f = function ( $k ) {
		return 'vap_settings[' . $k . ']';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Vyntic AI Planner', 'vyntic-ai-planner' ); ?></h1>
		<?php settings_errors(); ?>
		<?php if ( isset( $_GET['vap_test'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<?php $vap_t = sanitize_text_field( wp_unslash( $_GET['vap_test'] ) ); // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice <?php echo 0 === strpos( $vap_t, 'error:' ) ? 'notice-error' : 'notice-success'; ?>"><p>
				<?php
				if ( 0 === strpos( $vap_t, 'error:' ) ) {
					/* translators: %s error */
					echo esc_html( sprintf( __( 'Connection failed: %s', 'vyntic-ai-planner' ), substr( $vap_t, 6 ) ) );
				} else {
					esc_html_e( 'Connection works. The planner is ready.', 'vyntic-ai-planner' );
				}
				?>
			</p></div>
		<?php endif; ?>

		<p><?php echo wp_kses_post( __( 'Add the planner anywhere with the shortcode <code>[vyntic_planner]</code>. The Vyntic theme shows it on the homepage automatically.', 'vyntic-ai-planner' ) ); ?></p>

		<form method="post" action="options.php">
			<?php settings_fields( 'vap_settings_group' ); ?>
			<h2><?php esc_html_e( 'AI provider', 'vyntic-ai-planner' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Main provider', 'vyntic-ai-planner' ); ?></th><td>
					<select name="<?php echo esc_attr( $f( 'provider' ) ); ?>">
						<option value="gemini" <?php selected( $o['provider'], 'gemini' ); ?>><?php esc_html_e( 'Google Gemini (free tier)', 'vyntic-ai-planner' ); ?></option>
						<option value="openai" <?php selected( $o['provider'], 'openai' ); ?>><?php esc_html_e( 'OpenAI-compatible API (Groq, OpenRouter, OpenAI)', 'vyntic-ai-planner' ); ?></option>
						<option value="wp" <?php selected( $o['provider'], 'wp' ); ?> <?php disabled( ! function_exists( 'wp_ai_client_prompt' ) ); ?>><?php esc_html_e( 'WordPress AI Client (Settings, Connectors)', 'vyntic-ai-planner' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'If the main provider fails or hits its free limit, the planner can try the other provider you set up below.', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Gemini API key', 'vyntic-ai-planner' ); ?></th><td>
					<input type="password" class="regular-text" name="<?php echo esc_attr( $f( 'gemini_key' ) ); ?>" value="" placeholder="<?php echo $o['gemini_key'] ? esc_attr( vap_key_preview( $o['gemini_key'] ) ) : 'AIza...'; ?>" autocomplete="new-password" spellcheck="false">
					<?php vap_key_status( $o['gemini_key'] ); ?>
					<?php if ( $o['gemini_key'] ) : ?><label><input type="checkbox" name="<?php echo esc_attr( $f( 'clear_gemini' ) ); ?>" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-ai-planner' ); ?></label><?php endif; ?>
					<p class="description"><?php echo wp_kses_post( __( 'Get a free key from <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>. No card needed.', 'vyntic-ai-planner' ) ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Gemini model', 'vyntic-ai-planner' ); ?></th><td>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'gemini_model' ) ); ?>" value="<?php echo esc_attr( $o['gemini_model'] ); ?>">
					<p class="description"><?php esc_html_e( 'Use a Flash or Flash-Lite model, which stay on the free tier. If you see "model not found", copy the current model name from Google AI Studio.', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: API base URL', 'vyntic-ai-planner' ); ?></th><td>
					<input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'oa_base' ) ); ?>" value="<?php echo esc_attr( $o['oa_base'] ); ?>">
					<p class="description"><?php esc_html_e( 'Groq: https://api.groq.com/openai/v1. OpenRouter: https://openrouter.ai/api/v1. OpenAI: https://api.openai.com/v1', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: API key', 'vyntic-ai-planner' ); ?></th><td>
					<input type="password" class="regular-text" name="<?php echo esc_attr( $f( 'oa_key' ) ); ?>" value="" placeholder="<?php echo $o['oa_key'] ? esc_attr( vap_key_preview( $o['oa_key'] ) ) : ''; ?>" autocomplete="new-password" spellcheck="false">
					<?php if ( $o['oa_key'] ) { vap_key_status( $o['oa_key'] ); } ?>
					<?php if ( $o['oa_key'] ) : ?><label><input type="checkbox" name="<?php echo esc_attr( $f( 'clear_oa' ) ); ?>" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-ai-planner' ); ?></label><?php endif; ?>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: model', 'vyntic-ai-planner' ); ?></th><td>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'oa_model' ) ); ?>" value="<?php echo esc_attr( $o['oa_model'] ); ?>">
				</td></tr>
				<tr><th><?php esc_html_e( 'Use backup provider', 'vyntic-ai-planner' ); ?></th><td>
					<label><input type="checkbox" name="<?php echo esc_attr( $f( 'fallback' ) ); ?>" value="1" <?php checked( $o['fallback'], 1 ); ?>> <?php esc_html_e( 'Try the other provider if the main one fails', 'vyntic-ai-planner' ); ?></label>
				</td></tr>
			</table>

			<h2><?php esc_html_e( 'Leads and limits', 'vyntic-ai-planner' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Send new leads to', 'vyntic-ai-planner' ); ?></th><td><input type="email" class="regular-text" name="<?php echo esc_attr( $f( 'notify_email' ) ); ?>" value="<?php echo esc_attr( $o['notify_email'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Email the plan to the visitor', 'vyntic-ai-planner' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( $f( 'send_copy' ) ); ?>" value="1" <?php checked( $o['send_copy'], 1 ); ?>> <?php esc_html_e( 'Yes, send a copy of their plan', 'vyntic-ai-planner' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Email sender name', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'from_name' ) ); ?>" value="<?php echo esc_attr( $o['from_name'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Plans per visitor per day', 'vyntic-ai-planner' ); ?></th><td><input type="number" min="1" max="50" name="<?php echo esc_attr( $f( 'per_visitor' ) ); ?>" value="<?php echo esc_attr( $o['per_visitor'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Plans per day for the whole site', 'vyntic-ai-planner' ); ?></th><td><input type="number" min="1" max="5000" name="<?php echo esc_attr( $f( 'daily_cap' ) ); ?>" value="<?php echo esc_attr( $o['daily_cap'] ); ?>">
					<p class="description"><?php esc_html_e( 'Keep this below your free API daily limit.', 'vyntic-ai-planner' ); ?></p></td></tr>
				<tr><th><?php esc_html_e( 'Result button link', 'vyntic-ai-planner' ); ?></th><td><input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'cta_url' ) ); ?>" value="<?php echo esc_attr( $o['cta_url'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/contact/' ) ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Result button label', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'cta_label' ) ); ?>" value="<?php echo esc_attr( $o['cta_label'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Consent text', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="large-text" name="<?php echo esc_attr( $f( 'consent_text' ) ); ?>" value="<?php echo esc_attr( $o['consent_text'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Privacy policy URL', 'vyntic-ai-planner' ); ?></th><td><input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'privacy_url' ) ); ?>" value="<?php echo esc_attr( $o['privacy_url'] ); ?>" placeholder="<?php echo esc_attr( get_privacy_policy_url() ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'About your agency (for the AI)', 'vyntic-ai-planner' ); ?></th><td><textarea class="large-text" rows="3" name="<?php echo esc_attr( $f( 'agency_context' ) ); ?>"><?php echo esc_textarea( $o['agency_context'] ); ?></textarea></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vap_test' ); ?>
			<input type="hidden" name="action" value="vap_test">
			<?php submit_button( __( 'Test connection', 'vyntic-ai-planner' ), 'secondary' ); ?>
		</form>
	</div>
	<?php
}
