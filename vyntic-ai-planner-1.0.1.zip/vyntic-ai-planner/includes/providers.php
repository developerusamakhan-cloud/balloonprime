<?php
/**
 * AI providers. All calls run on the server, so API keys never reach the browser.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate text with the main provider, then the backup if it fails.
 *
 * @param string $system System instruction.
 * @param string $prompt User prompt.
 * @return string|WP_Error
 */
function vap_generate( $system, $prompt ) {
	// Lets tests or other plugins supply an answer.
	$pre = apply_filters( 'vap_pre_generate', null, $system, $prompt );
	if ( null !== $pre ) {
		return $pre;
	}

	$main  = vap_opt( 'provider' );
	$order = array( $main );
	if ( vap_opt( 'fallback' ) ) {
		foreach ( array( 'gemini', 'openai', 'wp' ) as $p ) {
			if ( $p !== $main ) {
				$order[] = $p;
			}
		}
	}

	$last = new WP_Error( 'vap_no_provider', __( 'No AI provider is set up yet. Add an API key under AI Planner, Settings.', 'vyntic-ai-planner' ) );
	foreach ( $order as $provider ) {
		if ( ! vap_provider_ready( $provider ) ) {
			continue;
		}
		$fn  = 'vap_call_' . $provider;
		$res = $fn( $system, $prompt );
		if ( ! is_wp_error( $res ) && '' !== trim( (string) $res ) ) {
			return $res;
		}
		$last = is_wp_error( $res ) ? $res : new WP_Error( 'vap_empty', __( 'The AI returned an empty answer.', 'vyntic-ai-planner' ) );
	}
	return $last;
}

/** Whether a provider has what it needs. */
function vap_provider_ready( $provider ) {
	switch ( $provider ) {
		case 'gemini':
			return (bool) vap_opt( 'gemini_key' );
		case 'openai':
			return vap_opt( 'oa_key' ) && vap_opt( 'oa_base' ) && vap_opt( 'oa_model' );
		case 'wp':
			return function_exists( 'wp_ai_client_prompt' );
	}
	return false;
}

/** Friendly error from an HTTP response. */
function vap_http_error( $res, $name ) {
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	$msg  = '';
	if ( isset( $body['error']['message'] ) ) {
		$msg = $body['error']['message'];
	} elseif ( isset( $body['message'] ) ) {
		$msg = $body['message'];
	}
	if ( 429 === (int) $code ) {
		$msg = __( 'free limit reached for now', 'vyntic-ai-planner' ) . ( $msg ? ' (' . $msg . ')' : '' );
	}
	/* translators: 1: provider, 2: HTTP code, 3: message */
	return new WP_Error( 'vap_http', sprintf( __( '%1$s error %2$s: %3$s', 'vyntic-ai-planner' ), $name, $code, wp_strip_all_tags( $msg ) ), array( 'status' => $code ) );
}

/** Google Gemini (AI Studio key, free tier on Flash models). */
function vap_call_gemini( $system, $prompt ) {
	$model = rawurlencode( vap_opt( 'gemini_model' ) );
	$res   = wp_remote_post(
		'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent',
		array(
			'timeout' => 45,
			'headers' => array(
				'Content-Type'   => 'application/json',
				'x-goog-api-key' => vap_opt( 'gemini_key' ),
			),
			'body'    => wp_json_encode(
				array(
					'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
					'contents'          => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $prompt ) ) ) ),
					'generationConfig'  => array(
						'temperature'      => 0.7,
						'maxOutputTokens'  => 4096,
						'responseMimeType' => 'application/json',
					),
				)
			),
		)
	);
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return vap_http_error( $res, 'Gemini' );
	}
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	$text = '';
	if ( ! empty( $body['candidates'][0]['content']['parts'] ) ) {
		foreach ( $body['candidates'][0]['content']['parts'] as $part ) {
			if ( isset( $part['text'] ) && empty( $part['thought'] ) ) {
				$text .= $part['text'];
			}
		}
	}
	return $text ? $text : new WP_Error( 'vap_empty', __( 'Gemini returned no text.', 'vyntic-ai-planner' ) );
}

/** Any OpenAI-compatible chat API (Groq, OpenRouter, OpenAI, Together and more). */
function vap_call_openai( $system, $prompt ) {
	$payload = array(
		'model'           => vap_opt( 'oa_model' ),
		'temperature'     => 0.7,
		'max_tokens'      => 1500,
		'messages'        => array(
			array( 'role' => 'system', 'content' => $system ),
			array( 'role' => 'user', 'content' => $prompt ),
		),
		'response_format' => array( 'type' => 'json_object' ),
	);
	$args = array(
		'timeout' => 45,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . vap_opt( 'oa_key' ),
			'HTTP-Referer'  => home_url( '/' ),
			'X-Title'       => get_bloginfo( 'name' ),
		),
	);
	$url  = trailingslashit( vap_opt( 'oa_base' ) ) . 'chat/completions';
	$res  = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );

	// Some models do not support JSON mode. Retry once without it.
	if ( ! is_wp_error( $res ) && 400 === (int) wp_remote_retrieve_response_code( $res ) ) {
		unset( $payload['response_format'] );
		$res = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );
	}
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return vap_http_error( $res, 'API' );
	}
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	return isset( $body['choices'][0]['message']['content'] ) ? (string) $body['choices'][0]['message']['content'] : new WP_Error( 'vap_empty', __( 'The API returned no text.', 'vyntic-ai-planner' ) );
}

/** WordPress AI Client (WordPress 7.0+, provider set in Settings, Connectors). */
function vap_call_wp( $system, $prompt ) {
	$builder = wp_ai_client_prompt( $prompt );
	if ( is_callable( array( $builder, 'using_system_instruction' ) ) ) {
		$builder = $builder->using_system_instruction( $system );
	} else {
		$builder = wp_ai_client_prompt( $system . "\n\n" . $prompt );
	}
	if ( is_callable( array( $builder, 'using_max_tokens' ) ) ) {
		$builder = $builder->using_max_tokens( 1500 );
	}
	$text = $builder->generate_text();
	return is_string( $text ) ? $text : ( is_wp_error( $text ) ? $text : new WP_Error( 'vap_empty', 'Empty answer' ) );
}

/**
 * Pull the JSON object out of a model answer.
 *
 * @param string $text Raw answer.
 * @return array|null
 */
function vap_parse_json( $text ) {
	$text  = trim( preg_replace( '/^```(?:json)?|```$/m', '', (string) $text ) );
	$start = strpos( $text, '{' );
	$end   = strrpos( $text, '}' );
	if ( false === $start || false === $end ) {
		return null;
	}
	$data = json_decode( substr( $text, $start, $end - $start + 1 ), true );
	return is_array( $data ) ? $data : null;
}
