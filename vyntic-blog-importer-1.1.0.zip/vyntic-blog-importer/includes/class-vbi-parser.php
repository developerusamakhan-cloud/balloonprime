<?php
/**
 * Reads and checks a blog import file.
 *
 * @package Vyntic_Blog_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VBI_Parser {

	const MAX_POSTS = 200;

	/**
	 * Parse the JSON text of an import file.
	 *
	 * Accepted shapes:
	 *   { "defaults": {...}, "posts": [ {...}, ... ] }
	 *   [ {...}, ... ]   (a plain list of posts)
	 *
	 * @param string $raw File contents.
	 * @return array|WP_Error { posts: array, defaults: array }
	 */
	public static function parse( $raw, $dir = '' ) {
		$raw  = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $raw ); // Strip a UTF-8 BOM.
		$data = json_decode( $raw, true );
		if ( null === $data ) {
			/* translators: %s: JSON error message. */
			return new WP_Error( 'vbi_json', sprintf( __( 'This is not a valid JSON file (%s). Upload the .json file exactly as you received it.', 'vyntic-blog-importer' ), json_last_error_msg() ) );
		}

		$defaults = array();
		if ( isset( $data['posts'] ) && is_array( $data['posts'] ) ) {
			$defaults = isset( $data['defaults'] ) && is_array( $data['defaults'] ) ? $data['defaults'] : array();
			$list     = $data['posts'];
		} elseif ( is_array( $data ) && isset( $data[0] ) ) {
			$list = $data;
		} else {
			return new WP_Error( 'vbi_shape', __( 'The file has no "posts" list.', 'vyntic-blog-importer' ) );
		}

		if ( ! $list ) {
			return new WP_Error( 'vbi_empty', __( 'The file has no posts in it.', 'vyntic-blog-importer' ) );
		}
		if ( count( $list ) > self::MAX_POSTS ) {
			/* translators: %d: maximum number of posts. */
			return new WP_Error( 'vbi_many', sprintf( __( 'One file can hold up to %d posts. Split it into smaller files.', 'vyntic-blog-importer' ), self::MAX_POSTS ) );
		}

		$posts = array();
		foreach ( array_values( $list ) as $i => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$posts[] = self::normalise( array_merge( $defaults, $item ), $i, $dir );
		}
		if ( ! $posts ) {
			return new WP_Error( 'vbi_empty', __( 'The file has no posts in it.', 'vyntic-blog-importer' ) );
		}

		return array(
			'posts'    => $posts,
			'defaults' => $defaults,
		);
	}

	/**
	 * Clean one post and collect warnings.
	 *
	 * @param array $p Raw post.
	 * @param int   $i Position in the file.
	 * @return array
	 */
	private static function normalise( array $p, $i, $dir = '' ) {
		$get = function ( $keys, $default = '' ) use ( $p ) {
			foreach ( (array) $keys as $k ) {
				if ( isset( $p[ $k ] ) && '' !== $p[ $k ] && array() !== $p[ $k ] ) {
					return $p[ $k ];
				}
			}
			return $default;
		};

		$title   = sanitize_text_field( (string) $get( 'title' ) );
		$content = (string) $get( array( 'content', 'html', 'body' ) );
		$slug    = sanitize_title( (string) $get( 'slug', $title ) );

		$cats = $get( array( 'categories', 'category' ), array() );
		$tags = $get( 'tags', array() );
		$cats = array_values( array_filter( array_map( 'sanitize_text_field', is_array( $cats ) ? $cats : explode( ',', (string) $cats ) ) ) );
		$tags = array_values( array_filter( array_map( 'sanitize_text_field', is_array( $tags ) ? $tags : explode( ',', (string) $tags ) ) ) );

		$faq = array();
		foreach ( (array) $get( 'faq', array() ) as $f ) {
			$q = is_array( $f ) ? ( isset( $f['q'] ) ? $f['q'] : ( isset( $f['question'] ) ? $f['question'] : ( isset( $f[0] ) ? $f[0] : '' ) ) ) : '';
			$a = is_array( $f ) ? ( isset( $f['a'] ) ? $f['a'] : ( isset( $f['answer'] ) ? $f['answer'] : ( isset( $f[1] ) ? $f[1] : '' ) ) ) : '';
			if ( '' !== trim( (string) $q ) && '' !== trim( (string) $a ) ) {
				$faq[] = array(
					'q' => sanitize_text_field( $q ),
					'a' => sanitize_textarea_field( $a ),
				);
			}
		}

		$img       = trim( (string) $get( array( 'image', 'image_url', 'featured_image' ) ) );
		$img_url   = preg_match( '#^https?://#i', $img ) ? esc_url_raw( $img ) : '';
		$img_local = $img_url ? '' : sanitize_text_field( $img );

		$post = array(
			'index'            => $i,
			'title'            => $title,
			'slug'             => $slug,
			'content'          => $content,
			'excerpt'          => sanitize_textarea_field( (string) $get( 'excerpt' ) ),
			'categories'       => $cats,
			'tags'             => $tags,
			'seo_title'        => sanitize_text_field( (string) $get( array( 'seo_title', 'meta_title' ) ) ),
			'meta_description' => sanitize_textarea_field( (string) $get( array( 'meta_description', 'description' ) ) ),
			'focus_keyword'    => sanitize_text_field( (string) $get( array( 'focus_keyword', 'keyword' ) ) ),
			'image_url'        => $img_url,
			'image'            => $img_local,
			'pillar'           => ! empty( $p['pillar'] ),
			'images_inline'    => preg_match_all( '/<img\b/i', $content ),
			'image_alt'        => sanitize_text_field( (string) $get( 'image_alt', $title ) ),
			'date'             => self::date( (string) $get( 'date' ) ),
			'status'           => sanitize_key( (string) $get( 'status' ) ),
			'faq'              => $faq,
			'words'            => str_word_count( wp_strip_all_tags( $content ) ),
			'warnings'         => array(),
			'errors'           => array(),
		);

		if ( '' === $title ) {
			$post['errors'][] = __( 'No title.', 'vyntic-blog-importer' );
		}
		if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
			$post['errors'][] = __( 'No content.', 'vyntic-blog-importer' );
		}
		if ( '' !== (string) $get( 'date' ) && ! $post['date'] ) {
			$post['warnings'][] = __( 'The date could not be read, so the schedule settings below are used.', 'vyntic-blog-importer' );
		}
		if ( $img_local && ! VBI_Zip::resolve( $dir, $img_local ) ) {
			$post['warnings'][] = $dir ? __( 'The featured image file is missing from the .zip.', 'vyntic-blog-importer' ) : __( 'The featured image is a file name, so upload the .zip that holds the images, not the .json on its own.', 'vyntic-blog-importer' );
		}
		if ( preg_match_all( '/<img\b[^>]*\ssrc=("|\')((?!https?:|\/\/)[^"\']+)\1/i', $content, $m ) ) {
			foreach ( $m[2] as $src ) {
				if ( ! VBI_Zip::resolve( $dir, $src ) ) {
					/* translators: %s: file name. */
					$post['warnings'][] = sprintf( __( 'Image %s is missing from the .zip.', 'vyntic-blog-importer' ), basename( $src ) );
				}
			}
		}
		if ( '' === $post['meta_description'] ) {
			$post['warnings'][] = __( 'No meta description.', 'vyntic-blog-importer' );
		} elseif ( mb_strlen( $post['meta_description'] ) > 160 ) {
			$post['warnings'][] = __( 'Meta description is longer than 160 characters.', 'vyntic-blog-importer' );
		}
		if ( '' !== $post['seo_title'] && mb_strlen( $post['seo_title'] ) > 65 ) {
			$post['warnings'][] = __( 'SEO title is longer than 65 characters.', 'vyntic-blog-importer' );
		}
		if ( '' === $post['focus_keyword'] ) {
			$post['warnings'][] = __( 'No focus keyword.', 'vyntic-blog-importer' );
		}

		return $post;
	}

	/**
	 * Read a date written as "2026-10-20", "2026-10-20 09:30" or ISO 8601, in the
	 * site's time zone. Returns "Y-m-d H:i" or an empty string.
	 *
	 * @param string $value Date text.
	 * @return string
	 */
	public static function date( $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		$formats = array( 'Y-m-d H:i', 'Y-m-d H:i:s', 'Y-m-d\TH:i', 'Y-m-d\TH:i:s', DATE_ATOM, 'Y-m-d' );
		foreach ( $formats as $f ) {
			$d = DateTimeImmutable::createFromFormat( '!' . $f, $value, wp_timezone() );
			if ( $d && $d->format( $f ) === $value ) {
				if ( 'Y-m-d' === $f ) {
					$d = $d->setTime( 9, 0 );
				}
				return $d->setTimezone( wp_timezone() )->format( 'Y-m-d H:i' );
			}
		}
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/', $value ) ) {
			try {
				$d = new DateTimeImmutable( $value, wp_timezone() );
				return $d->setTimezone( wp_timezone() )->format( 'Y-m-d H:i' );
			} catch ( Exception $e ) {
				return '';
			}
		}
		return '';
	}
}
