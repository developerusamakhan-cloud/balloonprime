<?php
/**
 * Unpacks an import .zip (one JSON file plus images) into a private temporary folder.
 *
 * Only .json and image files are written; every other file in the zip is ignored, so
 * nothing executable can ever reach the uploads folder.
 *
 * @package Vyntic_Blog_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VBI_Zip {

	const IMAGE_EXT = array( 'jpg', 'jpeg', 'png', 'webp', 'gif' );
	const MAX_FILES = 400;
	const MAX_BYTES = 200 * MB_IN_BYTES; // Unpacked size limit.

	/**
	 * Base folder for temporary imports.
	 */
	public static function base() {
		$up = wp_upload_dir( null, false );
		return trailingslashit( $up['basedir'] ) . 'vbi-tmp';
	}

	/**
	 * Unpack a zip.
	 *
	 * @param string $zip_path Uploaded zip.
	 * @return array|WP_Error { dir, json }
	 */
	public static function extract( $zip_path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'vbi_nozip', __( 'This server cannot open .zip files (the PHP Zip extension is missing). Ask your host to enable it, or upload the .json file on its own.', 'vyntic-blog-importer' ) );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_path ) ) {
			return new WP_Error( 'vbi_badzip', __( 'The .zip file could not be opened. Upload it again exactly as you received it.', 'vyntic-blog-importer' ) );
		}
		if ( $zip->numFiles > self::MAX_FILES ) {
			$zip->close();
			return new WP_Error( 'vbi_bigzip', __( 'The .zip file has too many files.', 'vyntic-blog-importer' ) );
		}

		self::cleanup();
		$base = self::base();
		wp_mkdir_p( $base );
		if ( ! file_exists( $base . '/index.php' ) ) {
			file_put_contents( $base . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$dir = $base . '/' . strtolower( wp_generate_password( 20, false, false ) );
		wp_mkdir_p( $dir );

		$json  = array();
		$total = 0;
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			$name = str_replace( '\\', '/', $stat['name'] );
			if ( '/' === substr( $name, -1 ) || false !== strpos( $name, '__MACOSX' ) || '.' === basename( $name )[0] ) {
				continue;
			}
			$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			if ( 'json' !== $ext && ! in_array( $ext, self::IMAGE_EXT, true ) ) {
				continue;
			}
			// Rebuild a safe relative path: no "..", no absolute paths, clean names.
			$parts = array();
			foreach ( explode( '/', $name ) as $seg ) {
				if ( '' === $seg || '.' === $seg || '..' === $seg ) {
					continue;
				}
				$parts[] = sanitize_file_name( $seg );
			}
			if ( ! $parts ) {
				continue;
			}
			$total += (int) $stat['size'];
			if ( $total > self::MAX_BYTES ) {
				$zip->close();
				self::remove( $dir );
				return new WP_Error( 'vbi_bigzip', __( 'The .zip file is too large once unpacked.', 'vyntic-blog-importer' ) );
			}
			$rel    = implode( '/', $parts );
			$target = $dir . '/' . $rel;
			wp_mkdir_p( dirname( $target ) );
			$data = $zip->getFromIndex( $i );
			if ( false === $data ) {
				continue;
			}
			file_put_contents( $target, $data ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( 'json' === $ext ) {
				$json[] = $rel;
			}
		}
		$zip->close();

		if ( ! $json ) {
			self::remove( $dir );
			return new WP_Error( 'vbi_nojson', __( 'The .zip file has no .json file with posts in it.', 'vyntic-blog-importer' ) );
		}
		// Prefer the JSON file closest to the top of the zip.
		usort(
			$json,
			function ( $a, $b ) {
				return substr_count( $a, '/' ) - substr_count( $b, '/' );
			}
		);
		$main = $dir . '/' . $json[0];

		return array(
			'dir'  => dirname( $main ),
			'root' => $dir,
			'json' => file_get_contents( $main ), // phpcs:ignore WordPress.WP.AlternativeFunctions
		);
	}

	/**
	 * Resolve a path written in the JSON ("images/photo.jpg") to a real image file
	 * inside the unpacked folder, or false.
	 */
	public static function resolve( $dir, $rel ) {
		if ( ! $dir || ! $rel || preg_match( '#^(https?:)?//#i', $rel ) ) {
			return false;
		}
		$rel  = ltrim( str_replace( '\\', '/', $rel ), './' );
		$rel  = implode( '/', array_map( 'sanitize_file_name', array_filter( explode( '/', $rel ), function ( $s ) { return '' !== $s && '.' !== $s && '..' !== $s; } ) ) );
		$path = realpath( $dir . '/' . $rel );
		$base = realpath( self::base() );
		if ( ! $path || ! $base || 0 !== strpos( $path, $base ) || ! is_file( $path ) ) {
			return false;
		}
		return in_array( strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ), self::IMAGE_EXT, true ) ? $path : false;
	}

	/**
	 * Remove one unpacked folder.
	 */
	public static function remove( $dir ) {
		$base = realpath( self::base() );
		$real = realpath( $dir );
		if ( ! $base || ! $real || 0 !== strpos( $real, $base ) || $real === $base ) {
			return;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $real, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $it as $f ) {
			$f->isDir() ? rmdir( $f->getPathname() ) : unlink( $f->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		rmdir( $real ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Delete unpacked folders older than a day (uploads that were never imported).
	 */
	public static function cleanup() {
		$base = self::base();
		if ( ! is_dir( $base ) ) {
			return;
		}
		foreach ( (array) glob( $base . '/*', GLOB_ONLYDIR ) as $d ) {
			if ( filemtime( $d ) < time() - DAY_IN_SECONDS ) {
				self::remove( $d );
			}
		}
	}
}
