<?php
/**
 * Admin: dashboard, settings, actions and the "Google" column in post lists.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI.
 */
class SIA_Admin {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'post_columns' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( array( 'run', 'test', 'resume', 'requested', 'recheck' ) as $action ) {
			add_action( 'admin_post_sia_' . $action, array( __CLASS__, 'action_' . $action ) );
		}
		add_filter( 'plugin_action_links_' . plugin_basename( SIA_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Admin page slug (one page, with tabs).
	 */
	const SLUG = 'vyntic-index-assistant';

	/**
	 * URL of a tab.
	 *
	 * @param string $tab  dashboard|settings.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function url( $tab = 'dashboard', array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Menu: one item inside the shared "Vyntic" menu.
	 */
	public static function menu() {
		if ( class_exists( 'Vyntic_Client' ) ) {
			add_submenu_page( Vyntic_Client::MENU, __( 'Vyntic Index Assistant', 'vyntic-index-assistant' ), __( 'Index Assistant', 'vyntic-index-assistant' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
			return;
		}
		add_menu_page( __( 'Vyntic Index Assistant', 'vyntic-index-assistant' ), __( 'Index Assistant', 'vyntic-index-assistant' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ), 'dashicons-search', 59 );
	}

	/**
	 * Branded page with Dashboard and Settings tabs.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tabs = array(
			'dashboard' => __( 'Dashboard', 'vyntic-index-assistant' ),
			'settings'  => __( 'Settings', 'vyntic-index-assistant' ),
		);
		$tab  = isset( $_GET['tab'] ) && 'settings' === $_GET['tab'] ? 'settings' : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification
		ob_start();
		'settings' === $tab ? self::settings_page() : self::dashboard_page();
		$html = (string) ob_get_clean();
		// The views were separate pages: drop their outer .wrap and turn the page title into a section title.
		$html = preg_replace( '/class="wrap sia-wrap"/', 'class="sia-wrap sia-view"', $html, 1 );
		$html = preg_replace( '#<h1>(.*?)</h1>#s', '<h2 class="sia-view-title">$1</h2>', $html, 1 );
		?>
		<div class="wrap vy-wrap">
			<div class="vy-header">
				<div class="vy-brand">
					<span class="vy-logo" aria-hidden="true"><svg viewBox="0 0 108 108" focusable="false"><polygon points="2,12 30,12 62,96 34,96" fill="#ffffff"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>
					<div>
						<h1><?php esc_html_e( 'Vyntic Index Assistant', 'vyntic-index-assistant' ); ?></h1>
						<p><?php esc_html_e( 'Find what Google has not indexed, see why, and fix it the safe way.', 'vyntic-index-assistant' ); ?>
							<span class="vy-by"><?php esc_html_e( 'by', 'vyntic-index-assistant' ); ?> <a href="https://vyntic.studio/" target="_blank" rel="noopener">Vyntic Studio</a></span></p>
					</div>
				</div>
				<div class="vy-header-actions">
					<a class="vy-link" href="https://vyntic.studio/plugins/safe-index-assistant/" target="_blank" rel="noopener"><?php esc_html_e( 'Guide', 'vyntic-index-assistant' ); ?> &#8599;</a>
					<a class="vy-link" href="https://search.google.com/search-console" target="_blank" rel="noopener"><?php esc_html_e( 'Search Console', 'vyntic-index-assistant' ); ?> &#8599;</a>
					<a class="vy-link" href="https://vyntic.studio/" target="_blank" rel="noopener">vyntic.studio &#8599;</a>
				</div>
			</div>
			<hr class="wp-header-end">
			<nav class="vy-tabs">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="vy-tab <?php echo $key === $tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( self::url( $key ) ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<?php if ( class_exists( 'Vyntic_Client' ) && method_exists( 'Vyntic_Client', 'updates_link' ) ) : ?>
					<?php $vy_upd = Vyntic_Client::updates_link( self::SLUG ); ?>
					<a class="vy-tab vy-tab--updates" href="<?php echo esc_url( $vy_upd['url'] ); ?>"><?php echo esc_html( $vy_upd['label'] ); ?><?php if ( $vy_upd['count'] ) : ?> <span class="vy-tab-count"><?php echo (int) $vy_upd['count']; ?></span><?php endif; ?></a>
				<?php endif; ?>
			</nav>
			<div class="vy-body">
				<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the views. ?>
			</div>
			<div class="vy-footer">
				<span><?php esc_html_e( 'Pages still not indexed? Vyntic Studio fixes the content, links and technical issues that hold them back.', 'vyntic-index-assistant' ); ?></span>
				<span><a href="https://vyntic.studio/services/seo-services/" target="_blank" rel="noopener"><?php esc_html_e( 'SEO services', 'vyntic-index-assistant' ); ?></a> · <a href="https://vyntic.studio/plugins/" target="_blank" rel="noopener"><?php esc_html_e( 'More free plugins', 'vyntic-index-assistant' ); ?></a></span>
			</div>
		</div>
		<?php
	}

	/**
	 * Settings link on the plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url( 'settings' ) ) . '">' . esc_html__( 'Settings', 'vyntic-index-assistant' ) . '</a>' );
		return $links;
	}

	/**
	 * Admin CSS.
	 *
	 * @param string $hook Page hook.
	 */
	public static function assets( $hook ) {
		if ( false !== strpos( (string) $hook, self::SLUG ) ) {
			wp_enqueue_style( 'sia-brand', SIA_URL . 'assets/css/vyntic-brand.css', array(), SIA_VERSION );
		}
		if ( false !== strpos( (string) $hook, self::SLUG ) || 'edit.php' === $hook ) {
			wp_enqueue_style( 'sia-admin', SIA_URL . 'assets/css/sia-admin.css', array(), SIA_VERSION );
		}
	}

	/* ---------------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------------- */

	/**
	 * Settings API registration.
	 */
	public static function register_settings() {
		register_setting(
			'sia_settings_group',
			SIA_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => SIA_Settings::defaults(),
			)
		);
	}

	/**
	 * Sanitize settings and handle the service account key field.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- options.php checks the nonce.
		if ( ! empty( $_POST['sia_remove_credentials'] ) ) {
			delete_option( SIA_Settings::CREDENTIALS_OPTION );
		}
		$raw = isset( $_POST['sia_credentials'] ) ? trim( wp_unslash( $_POST['sia_credentials'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON key, validated below.
		// phpcs:enable
		if ( '' !== $raw ) {
			$json = SIA_Settings::validate_credentials( $raw );
			if ( is_wp_error( $json ) ) {
				add_settings_error( SIA_Settings::OPTION, 'sia_credentials', $json->get_error_message() );
			} else {
				update_option( SIA_Settings::CREDENTIALS_OPTION, $json, false );
				SIA_Quota::resume();
			}
		}
		return SIA_Settings::sanitize( $input );
	}

	/**
	 * Settings page.
	 */
	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s     = SIA_Settings::all();
		$creds = SIA_Settings::credentials();
		$name  = SIA_Settings::OPTION;
		$types = get_post_types( array( 'public' => true ), 'objects' );
		unset( $types['attachment'] );
		?>
		<div class="wrap sia-wrap">
			<h1><?php esc_html_e( 'Index Assistant Settings', 'vyntic-index-assistant' ); ?></h1>
			<?php settings_errors( SIA_Settings::OPTION ); ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'sia_settings_group' ); ?>

				<h2><?php esc_html_e( '1. Connect Google Search Console', 'vyntic-index-assistant' ); ?></h2>
				<ol class="sia-steps">
					<li><?php echo wp_kses_post( __( 'In <a href="https://console.cloud.google.com/" target="_blank" rel="noopener">Google Cloud Console</a> create a project and enable the <strong>Google Search Console API</strong>.', 'vyntic-index-assistant' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'IAM &amp; Admin → Service Accounts → Create service account → Keys → Add key → <strong>JSON</strong>. Paste the file contents below.', 'vyntic-index-assistant' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'In <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → Settings → Users and permissions → Add user: the service account email, permission <strong>Full</strong>.', 'vyntic-index-assistant' ) ); ?></li>
				</ol>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sia_credentials"><?php esc_html_e( 'Service account key (JSON)', 'vyntic-index-assistant' ); ?></label></th>
						<td>
							<?php if ( defined( 'SIA_SERVICE_ACCOUNT_JSON' ) ) : ?>
								<p><?php esc_html_e( 'Set in wp-config.php (SIA_SERVICE_ACCOUNT_JSON).', 'vyntic-index-assistant' ); ?></p>
							<?php else : ?>
								<?php if ( $creds ) : ?>
									<p class="sia-ok">✔ <?php echo esc_html( sprintf( /* translators: %s: email */ __( 'Saved: %s', 'vyntic-index-assistant' ), $creds['client_email'] ) ); ?></p>
									<label><input type="checkbox" name="sia_remove_credentials" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-index-assistant' ); ?></label>
								<?php endif; ?>
								<textarea id="sia_credentials" name="sia_credentials" rows="5" class="large-text code" autocomplete="off" placeholder="<?php echo esc_attr( $creds ? __( 'Paste a new key only if you want to replace the saved one.', 'vyntic-index-assistant' ) : '{ "type": "service_account", ... }' ); ?>"></textarea>
								<p class="description"><?php esc_html_e( 'Stored in your database (not autoloaded) and never shown again. For extra safety define SIA_SERVICE_ACCOUNT_JSON in wp-config.php instead.', 'vyntic-index-assistant' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sia_property"><?php esc_html_e( 'Search Console property', 'vyntic-index-assistant' ); ?></label></th>
						<td>
							<input type="text" id="sia_property" class="regular-text" name="<?php echo esc_attr( $name ); ?>[property]" value="<?php echo esc_attr( $s['property'] ); ?>" placeholder="<?php echo esc_attr( trailingslashit( home_url() ) ); ?>">
							<p class="description"><?php esc_html_e( 'Exactly as in Search Console: "https://example.com/" for a URL-prefix property or "sc-domain:example.com" for a domain property. Empty = this site\'s URL.', 'vyntic-index-assistant' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '2. Daily limits', 'vyntic-index-assistant' ); ?></h2>
				<p class="description sia-limits-note">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: hard cap, 2: per run, 3: manual cap */
							__( 'Google allows 2,000 URL checks per day per property. This plugin never does more than %1$d, at most %2$d per 15-minute run with a pause between calls, and suggests at most %3$d manual "Request indexing" clicks per day.', 'vyntic-index-assistant' ),
							SIA_Settings::HARD_DAILY_INSPECTIONS,
							SIA_Settings::HARD_PER_RUN,
							SIA_Settings::HARD_MANUAL_PER_DAY
						)
					);
					?>
				</p>
				<table class="form-table" role="presentation">
					<?php
					self::number_row( 'daily_limit', __( 'URL checks per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_DAILY_INSPECTIONS, __( 'Recommended: 100 for small sites, up to 500 for large ones. Spread evenly over the day.', 'vyntic-index-assistant' ) );
					self::number_row( 'manual_daily', __( 'Manual requests per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_MANUAL_PER_DAY, __( 'How many URLs appear in "Today\'s request list". Max 10.', 'vyntic-index-assistant' ) );
					self::number_row( 'first_check_days', __( 'Wait before first check (days)', 'vyntic-index-assistant' ), $s, 1, 30, __( 'New posts need a few days before Google finds them; checking earlier wastes quota.', 'vyntic-index-assistant' ) );
					self::number_row( 'recheck_unindexed_days', __( 'Re-check not-indexed pages every (days)', 'vyntic-index-assistant' ), $s, 3, 60, '' );
					self::number_row( 'recheck_indexed_days', __( 'Re-check indexed pages every (days)', 'vyntic-index-assistant' ), $s, 7, 180, '' );
					?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Post types to track', 'vyntic-index-assistant' ); ?></th>
						<td>
							<?php foreach ( $types as $type ) : ?>
								<label class="sia-inline"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[post_types][]" value="<?php echo esc_attr( $type->name ); ?>" <?php checked( in_array( $type->name, (array) $s['post_types'], true ) ); ?>> <?php echo esc_html( $type->labels->name ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '3. Sitemap', 'vyntic-index-assistant' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Resubmit sitemap', 'vyntic-index-assistant' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[sitemap_auto]" value="1" <?php checked( $s['sitemap_auto'] ); ?>> <?php esc_html_e( 'Submit the sitemap to Google at most once per 24 hours, only when posts were published or updated.', 'vyntic-index-assistant' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><label for="sia_sitemap_url"><?php esc_html_e( 'Sitemap URL', 'vyntic-index-assistant' ); ?></label></th>
						<td>
							<input type="url" id="sia_sitemap_url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[sitemap_url]" value="<?php echo esc_attr( $s['sitemap_url'] ); ?>" placeholder="<?php echo esc_attr( SIA_Settings::sitemap_url() ); ?>">
							<p class="description"><?php esc_html_e( 'Empty = detected automatically (Yoast, Rank Math, SEOPress, AIOSEO or WordPress core).', 'vyntic-index-assistant' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '4. IndexNow (Bing, Yandex, Seznam, Naver)', 'vyntic-index-assistant' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Google does not use IndexNow; this only helps other search engines. Turn it off if your SEO plugin already sends IndexNow pings.', 'vyntic-index-assistant' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable IndexNow', 'vyntic-index-assistant' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[indexnow_enabled]" value="1" <?php checked( $s['indexnow_enabled'] ); ?>> <?php esc_html_e( 'Notify IndexNow when a post is published or its content changes (each URL max once per 24 hours).', 'vyntic-index-assistant' ); ?></label>
							<?php if ( $s['indexnow_enabled'] ) : ?>
								<p class="description"><?php esc_html_e( 'Key file:', 'vyntic-index-assistant' ); ?> <a href="<?php echo esc_url( SIA_IndexNow::key_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( SIA_IndexNow::key_url() ); ?></a></p>
							<?php endif; ?>
						</td>
					</tr>
					<?php self::number_row( 'indexnow_daily', __( 'IndexNow URLs per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_INDEXNOW_PER_DAY, '' ); ?>
				</table>

				<h2><?php esc_html_e( '5. Other', 'vyntic-index-assistant' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::number_row( 'thin_words', __( 'Thin content below (words)', 'vyntic-index-assistant' ), $s, 0, 2000, __( 'Not-indexed pages shorter than this get a "thin content" hint. 0 = off.', 'vyntic-index-assistant' ) ); ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Delete all data on uninstall', 'vyntic-index-assistant' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'] ); ?>> <?php esc_html_e( 'Remove the table, settings and the saved key when the plugin is deleted.', 'vyntic-index-assistant' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Number input row.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Label.
	 * @param array  $s     Settings.
	 * @param int    $min   Min.
	 * @param int    $max   Max.
	 * @param string $help  Help text.
	 */
	private static function number_row( $key, $label, $s, $min, $max, $help ) {
		?>
		<tr>
			<th scope="row"><label for="sia_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input type="number" id="sia_<?php echo esc_attr( $key ); ?>" class="small-text" name="<?php echo esc_attr( SIA_Settings::OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>">
				<?php if ( $help ) : ?>
					<p class="description"><?php echo esc_html( $help ); ?></p>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Dashboard
	 * ------------------------------------------------------------------- */

	/**
	 * Dashboard page.
	 */
	public static function dashboard_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$counts = SIA_Urls::counts();
		$pause  = SIA_Quota::pause_info();
		$last   = get_option( 'sia_last_run', array() );
		$map    = get_option( 'sia_sitemap_last', array() );
		$inow   = get_option( SIA_IndexNow::LOG_OPTION, array() );
		$next   = wp_next_scheduled( SIA_Cron::HOOK );
		?>
		<div class="wrap sia-wrap">
			<h1><?php esc_html_e( 'Index Assistant', 'vyntic-index-assistant' ); ?></h1>
			<?php self::notices( $pause ); ?>

			<div class="sia-cards">
				<?php
				$cards = array(
					'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
					'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
					'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
					'error'       => __( 'Errors', 'vyntic-index-assistant' ),
					'excluded'    => __( 'Skipped (noindex)', 'vyntic-index-assistant' ),
				);
				foreach ( $cards as $key => $label ) :
					?>
					<a class="sia-card sia-card-<?php echo esc_attr( $key ); ?>" href="<?php echo esc_url( add_query_arg( 'status', $key, self::url( 'dashboard' ) ) . '#sia-all' ); ?>">
						<strong><?php echo esc_html( number_format_i18n( $counts[ $key ] ) ); ?></strong>
						<span><?php echo esc_html( $label ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( 'Today\'s usage (always within limits)', 'vyntic-index-assistant' ); ?></h2>
			<table class="widefat striped sia-usage">
				<tbody>
					<?php
					self::usage_row( __( 'Google URL checks', 'vyntic-index-assistant' ), 'inspect', __( 'Google allows 2,000/day', 'vyntic-index-assistant' ) );
					self::usage_row( __( 'Manual "Request indexing"', 'vyntic-index-assistant' ), 'manual', __( 'Search Console allows about 10 to 12 a day', 'vyntic-index-assistant' ) );
					if ( SIA_IndexNow::enabled() ) {
						self::usage_row( __( 'IndexNow URLs', 'vyntic-index-assistant' ), 'indexnow', $inow ? sprintf( /* translators: 1: time, 2: count, 3: HTTP code */ __( 'Last: %1$s, %2$d URLs, HTTP %3$d', 'vyntic-index-assistant' ), self::ago( $inow['time'] ), $inow['count'], $inow['code'] ) : '' );
					}
					?>
					<tr>
						<th><?php esc_html_e( 'Sitemap', 'vyntic-index-assistant' ); ?></th>
						<td colspan="2">
							<?php
							if ( ! SIA_Settings::get( 'sitemap_auto' ) ) {
								esc_html_e( 'Automatic resubmission is off.', 'vyntic-index-assistant' );
							} elseif ( $map ) {
								echo esc_html( $map['message'] . ' (' . self::ago( $map['time'] ) . ') - ' . $map['url'] );
							} else {
								esc_html_e( 'Not submitted yet. Max once per 24 hours.', 'vyntic-index-assistant' );
							}
							?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Background runs', 'vyntic-index-assistant' ); ?></th>
						<td colspan="2">
							<?php
							$parts = array();
							if ( $last ) {
								/* translators: 1: time, 2: number */
								$parts[] = sprintf( __( 'Last run %1$s: %2$d checked.', 'vyntic-index-assistant' ), self::ago( $last['time'] ), $last['inspected'] );
								if ( ! empty( $last['stopped'] ) ) {
									$parts[] = rtrim( $last['stopped'], '.' ) . '.';
								}
							}
							if ( $next ) {
								/* translators: %s: time */
								$parts[] = sprintf( __( 'Next run: %s.', 'vyntic-index-assistant' ), self::ago( $next ) );
							}
							echo esc_html( $parts ? implode( ' ', $parts ) : __( 'No run yet.', 'vyntic-index-assistant' ) );
							?>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="sia-buttons">
				<?php self::action_button( 'run', __( 'Run a batch now', 'vyntic-index-assistant' ), 'button-primary' ); ?>
				<?php self::action_button( 'test', __( 'Test Google connection', 'vyntic-index-assistant' ) ); ?>
				<span class="description"><?php esc_html_e( '"Run a batch now" uses the same daily limit as the background runs.', 'vyntic-index-assistant' ); ?></span>
			</p>

			<?php self::manual_list(); ?>
			<?php self::all_urls(); ?>
		</div>
		<?php
	}

	/**
	 * Notices at the top of the dashboard.
	 *
	 * @param array $pause Pause info.
	 */
	private static function notices( $pause ) {
		$notice = get_transient( 'sia_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'sia_notice_' . get_current_user_id() );
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notice['type'] ), esc_html( $notice['text'] ) );
		}
		if ( ! SIA_Settings::credentials() ) {
			printf(
				'<div class="notice notice-warning"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
				esc_html__( 'Google Search Console is not connected yet.', 'vyntic-index-assistant' ),
				esc_url( self::url( 'settings' ) ),
				esc_html__( 'Open Settings', 'vyntic-index-assistant' )
			);
		}
		if ( ! get_option( 'blog_public' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Settings → Reading → "Discourage search engines from indexing this site" is ON. Google will not index anything until you switch it off.', 'vyntic-index-assistant' ) . '</p></div>';
		}
		if ( $pause['until'] > time() ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $pause['reason'] ) . ' ';
			/* translators: %s: time */
			echo esc_html( sprintf( __( 'Paused until %s.', 'vyntic-index-assistant' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $pause['until'] ) ) );
			echo '</p>';
			if ( 'quota' !== $pause['kind'] ) {
				echo '<p>';
				self::action_button( 'resume', __( 'Resume', 'vyntic-index-assistant' ) );
				echo '</p>';
			}
			echo '</div>';
		}
	}

	/**
	 * Usage table row.
	 *
	 * @param string $label Label.
	 * @param string $type  Counter.
	 * @param string $note  Note.
	 */
	private static function usage_row( $label, $type, $note ) {
		$used  = SIA_Quota::used( $type );
		$limit = SIA_Quota::limit( $type );
		$pct   = $limit ? min( 100, round( $used / $limit * 100 ) ) : 0;
		?>
		<tr>
			<th><?php echo esc_html( $label ); ?></th>
			<td class="sia-bar-cell">
				<span class="sia-bar"><span style="width:<?php echo esc_attr( $pct ); ?>%"></span></span>
				<?php echo esc_html( sprintf( '%s / %s', number_format_i18n( $used ), number_format_i18n( $limit ) ) ); ?>
			</td>
			<td class="description"><?php echo esc_html( $note ); ?></td>
		</tr>
		<?php
	}

	/**
	 * Today's manual "Request indexing" list.
	 */
	private static function manual_list() {
		$remaining = SIA_Quota::remaining( 'manual' );
		$rows      = $remaining > 0 ? SIA_Urls::manual_candidates( $remaining ) : array();
		?>
		<h2><?php esc_html_e( 'Today\'s request list', 'vyntic-index-assistant' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Google has no allowed API for "Request indexing" on normal pages, so this is done by hand: open each page in Search Console, click "Request indexing", then click "Done". Improve the content and internal links first, requesting indexing for a weak page will not help.', 'vyntic-index-assistant' ); ?>
		</p>
		<?php if ( $remaining <= 0 ) : ?>
			<p class="sia-ok">✔ <?php esc_html_e( 'Done for today. New suggestions tomorrow.', 'vyntic-index-assistant' ); ?></p>
			<?php
			return;
		endif;
		if ( ! $rows ) :
			?>
			<p><?php esc_html_e( 'Nothing to request right now.', 'vyntic-index-assistant' ); ?></p>
			<?php
			return;
		endif;
		?>
		<table class="widefat striped sia-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th>
					<th><?php esc_html_e( 'Why not indexed / what to do', 'vyntic-index-assistant' ); ?></th>
					<th><?php esc_html_e( 'Link to it from', 'vyntic-index-assistant' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $rows as $row ) :
					$d = SIA_Diagnosis::explain( $row );
					?>
					<tr>
						<td><?php self::page_cell( $row ); ?></td>
						<td><?php self::reason_cell( $d ); ?></td>
						<td>
							<?php
							$sources = SIA_Diagnosis::link_sources( $row );
							if ( $sources ) {
								echo '<ul class="sia-list">';
								foreach ( $sources as $source ) {
									printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( (string) get_edit_post_link( $source ) ), esc_html( get_the_title( $source ) ) );
								}
								echo '</ul>';
							} else {
								echo '&mdash;';
							}
							?>
						</td>
						<td class="sia-actions">
							<a class="button" href="<?php echo esc_url( self::gsc_link( $row ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Search Console', 'vyntic-index-assistant' ); ?></a>
							<?php self::action_button( 'requested', __( 'Done', 'vyntic-index-assistant' ), 'button-primary', $row->id ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * All tracked URLs with filter and paging.
	 */
	private static function all_urls() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'not_indexed';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		$valid = array( 'not_indexed', 'error', 'pending', 'indexed', 'excluded', 'all' );
		$status = in_array( $status, $valid, true ) ? $status : 'not_indexed';
		$data   = SIA_Urls::page( 'all' === $status ? '' : $status, $paged );
		$pages  = (int) ceil( $data['total'] / 50 );
		$labels = array(
			'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
			'error'       => __( 'Errors', 'vyntic-index-assistant' ),
			'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
			'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
			'excluded'    => __( 'Skipped', 'vyntic-index-assistant' ),
			'all'         => __( 'All', 'vyntic-index-assistant' ),
		);
		?>
		<h2 id="sia-all"><?php esc_html_e( 'All pages', 'vyntic-index-assistant' ); ?></h2>
		<ul class="subsubsub">
			<?php
			$links = array();
			foreach ( $labels as $key => $label ) {
				$links[] = sprintf(
					'<li><a href="%1$s"%2$s>%3$s</a></li>',
					esc_url( add_query_arg( 'status', $key, self::url( 'dashboard' ) ) . '#sia-all' ),
					$key === $status ? ' class="current"' : '',
					esc_html( $label )
				);
			}
			echo implode( ' | ', $links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			?>
		</ul>
		<table class="widefat striped sia-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th>
					<th><?php esc_html_e( 'Status / what to do', 'vyntic-index-assistant' ); ?></th>
					<th><?php esc_html_e( 'Checked', 'vyntic-index-assistant' ); ?></th>
					<th><?php esc_html_e( 'Next check', 'vyntic-index-assistant' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! $data['rows'] ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'Nothing here.', 'vyntic-index-assistant' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $data['rows'] as $row ) : ?>
					<tr>
						<td><?php self::page_cell( $row ); ?></td>
						<td><?php self::reason_cell( SIA_Diagnosis::explain( $row ) ); ?></td>
						<td><?php echo esc_html( $row->inspected_at ? self::ago( strtotime( $row->inspected_at . ' UTC' ) ) : '-' ); ?></td>
						<td><?php echo esc_html( 'excluded' === $row->status ? '-' : self::ago( strtotime( $row->next_check_at . ' UTC' ) ) ); ?></td>
						<td class="sia-actions">
							<?php if ( 'excluded' !== $row->status ) : ?>
								<a class="button button-small" href="<?php echo esc_url( self::gsc_link( $row ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Search Console', 'vyntic-index-assistant' ); ?></a>
								<?php self::action_button( 'recheck', __( 'Check next run', 'vyntic-index-assistant' ), 'button-small', $row->id ); ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( $pages > 1 ) : ?>
			<div class="tablenav"><div class="tablenav-pages">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'    => add_query_arg( array( 'paged' => '%#%', 'status' => $status ), self::url( 'dashboard' ) ) . '#sia-all',
							'format'  => '',
							'current' => $paged,
							'total'   => $pages,
						)
					)
				);
				?>
			</div></div>
		<?php endif; ?>
		<?php
	}

	/**
	 * Title + URL cell.
	 *
	 * @param object $row Row.
	 */
	private static function page_cell( $row ) {
		$title = get_the_title( $row->post_id );
		printf(
			'<strong><a href="%1$s">%2$s</a></strong><br><a class="sia-url" href="%3$s" target="_blank" rel="noopener">%4$s</a>',
			esc_url( (string) get_edit_post_link( $row->post_id ) ),
			esc_html( '' !== $title ? $title : __( '(no title)', 'vyntic-index-assistant' ) ),
			esc_url( $row->url ),
			esc_html( $row->url )
		);
	}

	/**
	 * Diagnosis cell.
	 *
	 * @param array $d Diagnosis.
	 */
	private static function reason_cell( $d ) {
		printf( '<span class="sia-badge sia-%1$s">%2$s</span>', esc_attr( $d['level'] ), esc_html( $d['label'] ) );
		if ( $d['advice'] ) {
			echo '<ul class="sia-list">';
			foreach ( $d['advice'] as $line ) {
				echo '<li>' . esc_html( $line ) . '</li>';
			}
			echo '</ul>';
		}
	}

	/**
	 * Search Console URL inspection link for a row.
	 *
	 * @param object $row Row.
	 * @return string
	 */
	private static function gsc_link( $row ) {
		if ( ! empty( $row->inspect_link ) ) {
			return $row->inspect_link;
		}
		return add_query_arg(
			array(
				'resource_id' => rawurlencode( SIA_Settings::property() ),
				'id'          => rawurlencode( $row->url ),
			),
			'https://search.google.com/search-console/inspect'
		);
	}

	/**
	 * Human time difference ("3 hours ago" / "in 10 mins").
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function ago( $timestamp ) {
		$timestamp = (int) $timestamp;
		$diff      = human_time_diff( $timestamp, time() );
		/* translators: %s: time span */
		return $timestamp > time() ? sprintf( __( 'in %s', 'vyntic-index-assistant' ), $diff ) : sprintf( __( '%s ago', 'vyntic-index-assistant' ), $diff );
	}

	/**
	 * Small POST form button for an admin action.
	 *
	 * @param string $action Action suffix.
	 * @param string $label  Label.
	 * @param string $class  Extra CSS class.
	 * @param int    $id     Optional row ID.
	 */
	private static function action_button( $action, $label, $class = '', $id = 0 ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sia-inline-form">
			<input type="hidden" name="action" value="sia_<?php echo esc_attr( $action ); ?>">
			<?php if ( $id ) : ?>
				<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
			<?php endif; ?>
			<?php wp_nonce_field( 'sia_' . $action ); ?>
			<button type="submit" class="button <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Actions
	 * ------------------------------------------------------------------- */

	/**
	 * Capability + nonce check.
	 *
	 * @param string $action Action suffix.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'vyntic-index-assistant' ), 403 );
		}
		check_admin_referer( 'sia_' . $action );
	}

	/**
	 * Store a notice and go back to the dashboard.
	 *
	 * @param string $type success|error|warning|info.
	 * @param string $text Message.
	 */
	private static function back( $type, $text ) {
		set_transient(
			'sia_notice_' . get_current_user_id(),
			array(
				'type' => $type,
				'text' => $text,
			),
			MINUTE_IN_SECONDS
		);
		wp_safe_redirect( self::url( 'dashboard' ) );
		exit;
	}

	/**
	 * Run one batch now (same limits as cron).
	 */
	public static function action_run() {
		self::guard( 'run' );
		$s    = SIA_Cron::run();
		$text = sprintf(
			/* translators: 1: checked, 2: added, 3: IndexNow */
			__( 'Checked %1$d URLs, added %2$d new pages, sent %3$d to IndexNow.', 'vyntic-index-assistant' ),
			$s['inspected'],
			$s['synced'],
			$s['indexnow']
		);
		foreach ( array( 'sitemap', 'stopped' ) as $key ) {
			if ( '' !== $s[ $key ] ) {
				$text .= ' ' . $s[ $key ];
			}
		}
		self::back( '' !== $s['stopped'] && 0 === $s['inspected'] ? 'warning' : 'success', $text );
	}

	/**
	 * Test the Google connection (does not use URL Inspection quota).
	 */
	public static function action_test() {
		self::guard( 'test' );
		$result = SIA_Google::test_connection();
		if ( is_wp_error( $result ) ) {
			self::back( 'error', $result->get_error_message() );
		}
		$ok = in_array( $result['permission'], array( 'siteOwner', 'siteFullUser' ), true );
		self::back(
			$ok ? 'success' : 'warning',
			sprintf(
				/* translators: 1: property, 2: permission */
				__( 'Connected to %1$s (permission: %2$s).', 'vyntic-index-assistant' ),
				$result['property'],
				$result['permission']
			) . ( $ok ? '' : ' ' . __( 'Give the service account "Full" permission so it can also submit the sitemap.', 'vyntic-index-assistant' ) )
		);
	}

	/**
	 * Lift an access pause.
	 */
	public static function action_resume() {
		self::guard( 'resume' );
		SIA_Quota::resume();
		self::back( 'success', __( 'Resumed.', 'vyntic-index-assistant' ) );
	}

	/**
	 * Mark a URL as manually requested in Search Console.
	 */
	public static function action_requested() {
		self::guard( 'requested' );
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( ! SIA_Quota::reserve( 'manual' ) ) {
			self::back( 'warning', __( 'Today\'s manual request limit is reached. Continue tomorrow.', 'vyntic-index-assistant' ) );
		}
		SIA_Urls::mark_requested( $id );
		self::back( 'success', __( 'Marked as requested. It will be checked again in 3 days.', 'vyntic-index-assistant' ) );
	}

	/**
	 * Check a URL on the next run (still within the daily limit).
	 */
	public static function action_recheck() {
		self::guard( 'recheck' );
		SIA_Urls::recheck( isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 );
		self::back( 'success', __( 'Queued for the next run (within the daily limit).', 'vyntic-index-assistant' ) );
	}

	/* ---------------------------------------------------------------------
	 * Post list column
	 * ------------------------------------------------------------------- */

	/**
	 * Register the "Google" column for tracked post types.
	 */
	public static function post_columns() {
		foreach ( SIA_Settings::post_types() as $type ) {
			add_filter( "manage_{$type}_posts_columns", array( __CLASS__, 'add_column' ) );
			add_action( "manage_{$type}_posts_custom_column", array( __CLASS__, 'render_column' ), 10, 2 );
		}
	}

	/**
	 * Add the column.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		$columns['sia_index'] = __( 'Google', 'vyntic-index-assistant' );
		return $columns;
	}

	/**
	 * Render the column.
	 *
	 * @param string $column  Column.
	 * @param int    $post_id Post.
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'sia_index' !== $column ) {
			return;
		}
		$row = SIA_Urls::by_post( $post_id );
		if ( ! $row ) {
			echo '&mdash;';
			return;
		}
		$d = SIA_Diagnosis::explain( $row );
		printf( '<span class="sia-badge sia-%1$s" title="%2$s">%3$s</span>', esc_attr( $d['level'] ), esc_attr( implode( ' ', $d['advice'] ) ), esc_html( $d['label'] ) );
	}
}
