<?php
/**
 * A plugin's own page from the Vyntic Hub plugin (/plugins/{slug}/).
 * The Hub builds the page itself (header, tabs, sidebar); the theme adds the
 * breadcrumbs, more plugins and the contact section around it.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	$vyntic_hub_page = function_exists( 'vyntic_hub_page' ) ? vyntic_hub_page() : null;
	?>
	<section class="section section--plugin">
		<div class="wrap">
			<nav class="crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'vyntic' ); ?>">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'vyntic' ); ?></a>
				<span class="crumbs__sep" aria-hidden="true">/</span>
				<?php if ( $vyntic_hub_page ) : ?>
					<a href="<?php echo esc_url( get_permalink( $vyntic_hub_page ) ); ?>"><?php echo esc_html( get_the_title( $vyntic_hub_page ) ); ?></a>
					<span class="crumbs__sep" aria-hidden="true">/</span>
				<?php endif; ?>
				<span aria-current="page"><?php the_title(); ?></span>
			</nav>
			<div class="plug-single"><?php the_content(); ?></div>
		</div>
	</section>
	<?php
	$vyntic_more = array();
	if ( class_exists( 'VH_API' ) ) {
		foreach ( VH_API::catalog() as $vyntic_item ) {
			if ( get_post_meta( get_the_ID(), '_vh_slug', true ) !== $vyntic_item['slug'] ) {
				$vyntic_more[] = $vyntic_item;
			}
		}
	}
	if ( $vyntic_more ) :
		?>
		<section class="section section--tight" aria-labelledby="plug-more">
			<div class="wrap">
				<div class="plug-head">
					<h2 class="section__title section__title--sm" id="plug-more"><?php esc_html_e( 'More free plugins', 'vyntic' ); ?></h2>
					<?php if ( $vyntic_hub_page ) : ?>
						<a class="link-arrow" href="<?php echo esc_url( get_permalink( $vyntic_hub_page ) ); ?>"><?php esc_html_e( 'All plugins', 'vyntic' ); ?> &rarr;</a>
					<?php endif; ?>
				</div>
				<ul class="lp-related">
					<?php foreach ( array_slice( $vyntic_more, 0, 3 ) as $vyntic_item ) : ?>
						<li>
							<a class="lp-rel" href="<?php echo esc_url( $vyntic_item['url'] ); ?>">
								<span class="lp-rel__icon"><?php echo vyntic_icon( 'code' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
								<span class="lp-rel__name"><?php echo esc_html( $vyntic_item['name'] ); ?></span>
								<span class="lp-rel__text"><?php echo esc_html( $vyntic_item['short_description'] ); ?></span>
								<span class="lp-rel__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
		<?php
	endif;
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
