<?php
/**
 * Template Name: Contact
 *
 * Inquiry form plus direct contact details. Form emails go to the address
 * set in Customize → Vyntic options → Contact and social.
 *
 * @package Vyntic
 */

$vyntic_email = vyntic_mod( 'email' );
$vyntic_phone = vyntic_mod( 'phone' );
$vyntic_wa    = preg_replace( '/\D+/', '', (string) vyntic_mod( 'whatsapp' ) );

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<section class="contact">
		<div class="wrap contact__inner">
			<div class="contact__info">
				<h1 class="intro__title"><?php echo esc_html( vyntic_page_h1() ); ?></h1>
				<p class="intro__lead">
					<?php echo esc_html( has_excerpt() ? get_the_excerpt() : __( 'Tell us what you need. You will get a reply within 24 hours with next steps and a rough budget range.', 'vyntic' ) ); ?>
				</p>
				<ol class="next-steps">
					<li><?php esc_html_e( 'We read your message and look at your current site.', 'vyntic' ); ?></li>
					<li><?php esc_html_e( 'We book a 30-minute call at a time that suits your time zone.', 'vyntic' ); ?></li>
					<li><?php esc_html_e( 'You get a written scope with a fixed price within two business days.', 'vyntic' ); ?></li>
				</ol>
				<ul class="contact__direct">
					<?php if ( $vyntic_email ) : ?>
						<li><span><?php esc_html_e( 'Email', 'vyntic' ); ?></span><a href="mailto:<?php echo esc_attr( antispambot( $vyntic_email ) ); ?>"><?php echo esc_html( antispambot( $vyntic_email ) ); ?></a></li>
					<?php endif; ?>
					<?php if ( $vyntic_phone ) : ?>
						<li><span><?php esc_html_e( 'Phone', 'vyntic' ); ?></span><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $vyntic_phone ) ); ?>"><?php echo esc_html( $vyntic_phone ); ?></a></li>
					<?php endif; ?>
					<?php if ( $vyntic_wa ) : ?>
						<li><span><?php esc_html_e( 'WhatsApp', 'vyntic' ); ?></span><a href="<?php echo esc_url( 'https://wa.me/' . $vyntic_wa ); ?>"><?php esc_html_e( 'Message us', 'vyntic' ); ?></a></li>
					<?php endif; ?>
				</ul>
			</div>
			<div class="contact__form">
				<?php get_template_part( 'template-parts/contact-form' ); ?>
			</div>
		</div>
	</section>
	<?php
	get_template_part( 'template-parts/map' );
	vyntic_render_article( vyntic_current_article_key(), __( 'Working with us', 'vyntic' ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
endwhile;
get_footer();
