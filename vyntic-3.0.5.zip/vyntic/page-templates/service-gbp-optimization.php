<?php
/**
 * Template Name: Service: Google Business Profile optimization
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "gbp-optimization".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'gbp-optimization' ) );
endwhile;
get_footer();
