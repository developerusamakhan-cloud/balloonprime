<?php
/**
 * Template Name: Plugins (Vyntic Hub)
 *
 * The public plugin directory: intro, trust points, the plugin grid from the
 * Vyntic Hub plugin, how installing and updates work, an SEO article and FAQ.
 * Used automatically for the Hub's plugins page (see inc/hub.php).
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', __( 'Small, fast plugins we build for our own client sites. Free to download, no account or API key, and updates arrive in your WordPress dashboard automatically.', 'vyntic' ) );

	$vyntic_points = array(
		array( 'check', __( 'Free and GPL licensed', 'vyntic' ), __( 'Use them on as many sites as you like.', 'vyntic' ) ),
		array( 'check', __( 'No account or API key', 'vyntic' ), __( 'Everything runs on your own server.', 'vyntic' ) ),
		array( 'check', __( 'Automatic updates', 'vyntic' ), __( 'New versions appear in Dashboard, Updates.', 'vyntic' ) ),
		array( 'check', __( 'Tested on real sites', 'vyntic' ), __( 'We run every release on client sites first.', 'vyntic' ) ),
	);
	$vyntic_extra = trim( wp_strip_all_tags( strip_shortcodes( get_the_content() ) ) );
	?>
	<section class="section section--tight">
		<div class="wrap">
			<ul class="plug-points">
				<?php foreach ( $vyntic_points as $vyntic_p ) : ?>
					<li>
						<span class="plug-points__icon"><?php echo vyntic_icon( $vyntic_p[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<span><strong><?php echo esc_html( $vyntic_p[1] ); ?></strong><?php echo esc_html( $vyntic_p[2] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<section class="section section--tight" aria-labelledby="plug-all">
		<div class="wrap">
			<div class="plug-head">
				<h2 class="section__title section__title--sm" id="plug-all"><?php esc_html_e( 'All plugins', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'Download the zip, then go to Plugins, Add New, Upload Plugin in WordPress.', 'vyntic' ); ?></p>
			</div>
			<?php if ( shortcode_exists( 'vyntic_plugins' ) ) : ?>
				<?php echo do_shortcode( '[vyntic_plugins]' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php else : ?>
				<p class="section__lead"><?php esc_html_e( 'Plugins are coming soon.', 'vyntic' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( str_word_count( $vyntic_extra ) > 30 ) : ?>
		<section class="section section--tight">
			<div class="wrap"><div class="prose"><?php echo apply_filters( 'the_content', str_replace( '[vyntic_plugins]', '', get_the_content() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div></div>
		</section>
	<?php endif; ?>

	<section class="section section--tight" aria-labelledby="plug-how">
		<div class="wrap">
			<h2 class="section__title section__title--sm" id="plug-how"><?php esc_html_e( 'Install in under a minute', 'vyntic' ); ?></h2>
			<ol class="plug-steps">
				<li><strong><?php esc_html_e( 'Download', 'vyntic' ); ?></strong><span><?php esc_html_e( 'Click Download on the plugin you want. You get a .zip file.', 'vyntic' ); ?></span></li>
				<li><strong><?php esc_html_e( 'Upload', 'vyntic' ); ?></strong><span><?php esc_html_e( 'In WordPress go to Plugins, Add New, Upload Plugin, choose the zip and click Install Now.', 'vyntic' ); ?></span></li>
				<li><strong><?php esc_html_e( 'Activate', 'vyntic' ); ?></strong><span><?php esc_html_e( 'Activate it and open it from the Vyntic menu. Updates arrive automatically from then on.', 'vyntic' ); ?></span></li>
			</ol>
		</div>
	</section>
	<?php
	vyntic_render_article( 'plugins', __( 'Plugins', 'vyntic' ) );
	get_template_part( 'template-parts/faq', null, array( 'key' => 'plugins' ) );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
