<?php
/**
 * Template Name: Website cost calculator
 *
 * Interactive estimate: project type, platform, pages, features, content and industry
 * give a price range, timeline and recommended package. Prices follow the starting
 * prices in Customize → Vyntic options → Pricing, so estimates match what you charge.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Answer six quick questions and get a price range, timeline and the package that fits. Free, instant and no email needed.', 'vyntic' ) );
	get_template_part( 'template-parts/cost-calculator' );
	vyntic_render_article( vyntic_current_article_key(), __( 'How the estimate works', 'vyntic' ) );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
