<?php
/**
 * Template Name: Location (local SEO)
 *
 * One page per country (or city) you serve, e.g. "Web design and SEO in Germany".
 * Custom fields (ACF or Custom Fields box):
 *   location_city: the city name used in headings (defaults to the page title)
 *   location_region: state, province or country (optional)
 * The Excerpt is the intro. Write unique local content in the editor
 * (clients nearby, areas covered, how you meet) so the page is not a copy of others.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	$vyntic_city   = vyntic_location_city();
	$vyntic_region = vyntic_field( 'location_region', '' );
	$vyntic_place  = $vyntic_region ? $vyntic_city . ', ' . $vyntic_region : $vyntic_city;
	$vyntic_lead   = has_excerpt() ? get_the_excerpt() : sprintf(
		/* translators: %s city */
		__( 'Fast websites, SEO and AI search visibility for businesses in %s. Built by a studio that answers within 24 hours and works in your time zone.', 'vyntic' ),
		$vyntic_place
	);
	$vyntic_faq = array(
		array(
			/* translators: %s city */
			'q' => sprintf( __( 'Do you work with businesses in %s?', 'vyntic' ), $vyntic_city ),
			/* translators: %s city */
			'a' => sprintf( __( 'Yes. We work with businesses in and around %s, with calls and progress reviews in your time zone.', 'vyntic' ), $vyntic_city ),
		),
		array(
			/* translators: %s city */
			'q' => sprintf( __( 'Can you help my business show up in Google Maps in %s?', 'vyntic' ), $vyntic_city ),
			'a' => __( 'Yes. Local SEO covers your Google Business Profile, location pages, reviews and local schema, so you appear in the map pack for nearby searches.', 'vyntic' ),
		),
		array(
			/* translators: %s city or country */
			'q' => sprintf( __( 'How much does a website cost for a business in %s?', 'vyntic' ), $vyntic_city ),
			/* translators: 1: starter price, 2: store price */
			'a' => sprintf( __( 'Our website packages start from %1$s for a starter site, and online stores start from %2$s. You get one fixed price in your own currency before any work starts.', 'vyntic' ), vyntic_mod( 'price_starter' ), vyntic_mod( 'price_store' ) ),
		),
		array(
			'q' => __( 'How long does a new website take?', 'vyntic' ),
			'a' => __( 'Most business sites take 4 to 6 weeks from signed scope to launch. Stores take 6 to 10 weeks.', 'vyntic' ),
		),
		array(
			/* translators: %s city or country */
			'q' => sprintf( __( 'Do you offer ongoing SEO and website support in %s?', 'vyntic' ), $vyntic_city ),
			'a' => __( 'Yes. Our monthly local SEO plans keep your rankings and reviews growing, and our care plans cover updates, backups, security and speed for a fixed monthly fee.', 'vyntic' ),
		),
	);
	// Country-specific questions from the page content (inc/data/articles.json, "qa"), after the first general one.
	$vyntic_articles = function_exists( 'vyntic_setup_articles' ) ? vyntic_setup_articles() : array();
	$vyntic_key      = vyntic_current_article_key();
	if ( $vyntic_key && ! empty( $vyntic_articles[ $vyntic_key ]['qa'] ) ) {
		$vyntic_local = array();
		foreach ( $vyntic_articles[ $vyntic_key ]['qa'] as $vyntic_q ) {
			$vyntic_local[] = array(
				'q' => $vyntic_q[0],
				'a' => preg_replace( '/\{\{(?:ext:)?[^|}]+\|([^}]+)\}\}/', '$1', $vyntic_q[1] ),
			);
		}
		array_splice( $vyntic_faq, 1, 0, $vyntic_local );
	}
	?>
	<section class="intro intro--split intro--location">
		<div class="wrap intro__inner">
			<div>
				<?php vyntic_breadcrumbs(); ?>
				<h1 class="intro__title"><?php echo esc_html( vyntic_page_h1() ); ?></h1>
				<p class="intro__lead"><?php echo esc_html( $vyntic_lead ); ?></p>
				<div class="hero__actions">
					<a class="btn btn--primary btn--lg" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
					<a class="btn btn--ghost btn--lg" href="#free-audit"><?php esc_html_e( 'Free website audit', 'vyntic' ); ?></a>
				</div>
			</div>
			<div class="intro__media"><img src="<?php echo esc_url( has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'large' ) : vyntic_img( 'services/pin.svg' ) ); ?>" alt="" width="360" height="240"></div>
		</div>
	</section>
	<?php
	$vyntic_article = vyntic_current_article_key();
	vyntic_render_article( $vyntic_article, get_the_title() );
	$vyntic_children = get_pages( array( 'child_of' => get_the_ID(), 'parent' => get_the_ID(), 'sort_column' => 'post_title' ) );
	if ( $vyntic_children ) :
		?>
		<section class="section section--tight" aria-labelledby="loc-cities">
			<div class="wrap">
				<h2 class="section__title section__title--sm" id="loc-cities">
					<?php
					/* translators: %s country */
					echo esc_html( sprintf( __( 'Cities we work with in %s', 'vyntic' ), $vyntic_city ) );
					?>
				</h2>
				<ul class="loc-grid">
					<?php foreach ( $vyntic_children as $vyntic_child ) : ?>
						<li><a class="loc-card" href="<?php echo esc_url( get_permalink( $vyntic_child ) ); ?>"><span class="loc-card__icon"><?php echo vyntic_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><span class="loc-card__city"><?php echo esc_html( vyntic_location_city( $vyntic_child->ID ) ); ?></span><span class="loc-card__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
		<?php
	endif;
	get_template_part(
		'template-parts/services-list',
		null,
		array(
			/* translators: %s city */
			'heading' => sprintf( __( 'What we do for businesses in %s', 'vyntic' ), $vyntic_city ),
			'intro'   => '',
		)
	);
	get_template_part( 'template-parts/work-grid', null, array( 'count' => 2, 'more' => true ) );
	get_template_part( 'template-parts/audit' );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/pricing' );
	?>
	<section class="section" aria-labelledby="loc-faq-title">
		<div class="wrap faq">
			<h2 class="section__title" id="loc-faq-title">
				<?php
				/* translators: %s city */
				echo esc_html( sprintf( __( 'Questions from %s businesses', 'vyntic' ), $vyntic_city ) );
				?>
			</h2>
			<div class="faq__list">
				<?php foreach ( $vyntic_faq as $vyntic_item ) : ?>
					<details class="faq__item">
						<summary><?php echo esc_html( $vyntic_item['q'] ); ?><span class="faq__icon"><?php echo vyntic_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></summary>
						<p><?php echo esc_html( $vyntic_item['a'] ); ?></p>
					</details>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	$vyntic_schema = array(
		'@context'   => 'https://schema.org',
		'@graph'     => array(
			array(
				'@type'       => 'Service',
				'name'        => get_the_title(),
				'serviceType' => 'Web design, SEO and AI search optimization',
				'provider'    => array(
					'@type' => 'ProfessionalService',
					'name'  => get_bloginfo( 'name' ),
					'url'   => home_url( '/' ),
					'email' => vyntic_mod( 'email' ),
				),
				'areaServed'  => array(
					'@type' => $vyntic_region ? 'City' : 'Country',
					'name'  => $vyntic_place,
				),
				'url'         => get_permalink(),
			),
			array(
				'@type'      => 'FAQPage',
				'mainEntity' => array_map(
					function ( $item ) {
						return array(
							'@type'          => 'Question',
							'name'           => $item['q'],
							'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $item['a'] ),
						);
					},
					$vyntic_faq
				),
			),
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $vyntic_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
