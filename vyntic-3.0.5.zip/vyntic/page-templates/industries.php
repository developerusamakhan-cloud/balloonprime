<?php
/**
 * Template Name: Industries (hub)
 *
 * Lists the industry pages. Cards link to pages that use an "Industry: ..." template.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Every industry has its own customers, questions and search habits. We build websites and SEO around yours, so your site speaks the language your clients use.', 'vyntic' ) );
	$vyntic_items = array_filter(
		vyntic_landing(),
		function ( $d ) {
			return 'industry' === $d['kind'] && empty( $d['group'] );
		}
	);
	$vyntic_seo_items = array_filter(
		vyntic_landing(),
		function ( $d ) {
			return 'industry' === $d['kind'] && ! empty( $d['group'] ) && 'seo' === $d['group'];
		}
	);
	?>
	<section class="section">
		<div class="wrap">
			<ul class="ind-grid">
				<?php foreach ( $vyntic_items as $vyntic_key => $vyntic_d ) : ?>
					<?php $vyntic_url = vyntic_landing_url( $vyntic_key ); ?>
					<li>
						<?php if ( $vyntic_url ) : ?><a class="ind-card" href="<?php echo esc_url( $vyntic_url ); ?>"><?php else : ?><div class="ind-card"><?php endif; ?>
							<span class="ind-card__art"><img src="<?php echo esc_url( vyntic_img( 'services/' . $vyntic_d['art'] . '.svg' ) ); ?>" alt="" width="360" height="240" loading="lazy"></span>
							<span class="ind-card__body">
								<span class="ind-card__name"><?php echo esc_html( $vyntic_d['label'] ); ?></span>
								<span class="ind-card__text"><?php echo esc_html( $vyntic_d['lead'] ); ?></span>
								<span class="ind-card__proof">
									<?php foreach ( $vyntic_d['proof'] as $vyntic_p ) : ?>
										<span><?php echo esc_html( $vyntic_p ); ?></span>
									<?php endforeach; ?>
								</span>
							</span>
							<span class="ind-card__go" aria-hidden="true"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php if ( $vyntic_url ) : ?></a><?php else : ?></div><?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php if ( $vyntic_seo_items ) : ?>
		<section class="section section--tight" aria-labelledby="ind-seo">
			<div class="wrap">
				<h2 class="section__title section__title--sm" id="ind-seo"><?php esc_html_e( 'SEO by industry', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'Already have a good website? These programs focus on Google Maps, rankings and the enquiries that follow.', 'vyntic' ); ?></p>
				<ul class="lp-related">
					<?php foreach ( $vyntic_seo_items as $vyntic_key => $vyntic_d ) : ?>
						<?php $vyntic_url = vyntic_landing_url( $vyntic_key ); ?>
						<?php if ( ! $vyntic_url ) { continue; } ?>
						<li>
							<a class="lp-rel" href="<?php echo esc_url( $vyntic_url ); ?>">
								<span class="lp-rel__icon"><?php echo vyntic_icon( $vyntic_d['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
								<span class="lp-rel__name"><?php echo esc_html( $vyntic_d['label'] ); ?></span>
								<span class="lp-rel__text"><?php echo esc_html( $vyntic_d['h1'] ); ?></span>
								<span class="lp-rel__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
				<p class="section__lead" style="margin-top:1.5rem"><?php echo wp_kses_post( sprintf( /* translators: %s contact link */ __( 'Do not see your industry? <a href="%s">Get a free quote</a> and we will tell you honestly whether we are a good fit.', 'vyntic' ), esc_url( vyntic_template_url( 'page-templates/contact.php' ) ? vyntic_template_url( 'page-templates/contact.php' ) : home_url( '/contact/' ) ) ) ); ?></p>
			</div>
		</section>
	<?php endif; ?>
	<?php
	get_template_part( 'template-parts/industries' );
	vyntic_render_article( vyntic_current_article_key(), __( 'Industries', 'vyntic' ) );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/pricing' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
