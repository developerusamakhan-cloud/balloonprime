<?php
/**
 * Template Name: Pricing
 *
 * Website design pricing and packages: the pricing tabs (websites and monthly care),
 * a link to the cost calculator, the long-form guide and the pricing FAQ.
 * Prices are set in Customize → Vyntic options → Pricing.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Clear starting prices for websites, online stores and monthly care. You always get one fixed price in writing before any work starts.', 'vyntic' ) );
	get_template_part( 'template-parts/pricing', null, array( 'heading' => __( 'Packages and prices', 'vyntic' ), 'lead' => __( 'Starting prices for our most common projects. Switch tabs to see monthly care plans.', 'vyntic' ) ) );
	$vyntic_calc = vyntic_template_url( 'page-templates/cost-calculator.php' );
	if ( $vyntic_calc ) :
		?>
		<section class="section section--tight">
			<div class="wrap calc-teaser">
				<p class="calc-teaser__text"><strong><?php esc_html_e( 'Want a number for your project?', 'vyntic' ); ?></strong> <?php esc_html_e( 'Answer six quick questions and get a price range and timeline in under a minute.', 'vyntic' ); ?></p>
				<a class="btn btn--primary" href="<?php echo esc_url( $vyntic_calc ); ?>"><?php esc_html_e( 'Open the website cost calculator', 'vyntic' ); ?></a>
			</div>
		</section>
		<?php
	endif;
	vyntic_render_article( vyntic_current_article_key(), __( 'About our pricing', 'vyntic' ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
