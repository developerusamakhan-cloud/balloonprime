/* Vyntic website cost calculator. Prices come from the theme's starting prices (data-prices). */
(function () {
	'use strict';

	var root = document.querySelector('[data-calc]');
	if (!root) { return; }

	var P = JSON.parse(root.getAttribute('data-prices') || '{}');
	var cur = root.getAttribute('data-currency') || '';
	var industries = JSON.parse(root.getAttribute('data-industries') || '{}');
	var form = root.querySelector('[data-calc-form]');
	var out = {
		price: root.querySelector('[data-calc-price]'),
		time: root.querySelector('[data-calc-time]'),
		pack: root.querySelector('[data-calc-package]'),
		drivers: root.querySelector('[data-calc-drivers]'),
		industry: root.querySelector('[data-calc-industry]'),
		cta: root.querySelector('[data-calc-cta]')
	};
	var tracked = false;
	var last = null;

	var labels = {};
	form.querySelectorAll('input').forEach(function (i) {
		labels[i.name.replace('[]', '') + ':' + i.value] = i.parentNode.textContent.trim();
	});

	function money(n) {
		return cur + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	}
	function round50(n) { return Math.round(n / 50) * 50; }
	function val(name) {
		var el = form.querySelector('input[name="' + name + '"]:checked');
		return el ? el.value : '';
	}
	function vals(name) {
		return [].slice.call(form.querySelectorAll('input[name="' + name + '[]"]:checked')).map(function (i) { return i.value; });
	}

	function estimate() {
		var type = val('type');
		var pages = parseInt(val('pages'), 10) || 5;
		var feats = vals('features');
		var content = val('content');
		var B = P.business;
		var perPage = Math.max(0, (P.business - P.starter) / 7);
		var drivers = [];
		var base;
		var pack;
		var weeks;

		var isStore = type === 'store' || feats.indexOf('shop') > -1;
		if (type === 'landing') {
			base = P.starter;
			pack = 'Starter website (single landing page)';
			weeks = [1, 2];
			drivers.push('One focused page with tracking and a form');
		} else if (isStore) {
			base = P.store + (pages > 12 ? (pages - 12) * perPage : 0);
			pack = 'Online store';
			weeks = pages > 12 ? [7, 10] : [5, 8];
			drivers.push('Store setup: products, payments, shipping and checkout testing');
		} else if (pages <= 5) {
			base = P.starter;
			pack = 'Starter website';
			weeks = [2, 4];
		} else if (pages <= 12) {
			base = P.business;
			pack = 'Business website';
			weeks = [4, 6];
		} else {
			base = P.business + (pages - 12) * perPage;
			pack = pages > 25 ? 'Business website (custom quote)' : 'Business website';
			weeks = pages > 25 ? [8, 12] : [6, 9];
		}
		if (type !== 'landing') {
			drivers.push(labels['pages:' + pages] + ' pages');
		}
		if (type === 'redesign') {
			drivers.push('Redesign with URL mapping and redirects to keep rankings');
		}
		if (type === 'migration') {
			base *= 1.1;
			weeks = [weeks[0] + 1, weeks[1] + 1];
			drivers.push('Platform move: content transfer, re-hosted images and 301 redirects');
		}

		var add = 0;
		var heavy = 0;
		var addons = { booking: 0.10, blog: 0.06, crm: 0.08, tool: 0.15, members: 0.20 };
		feats.forEach(function (f) {
			if (addons[f]) {
				add += addons[f] * B;
				drivers.push(labels['features:' + f]);
				if (f === 'tool' || f === 'members') { heavy++; }
			}
			if (f === 'shop' && type !== 'store') { drivers.push('Selling products'); }
		});
		var total = base + add;

		if (content === 'us') {
			total += (pages <= 5 ? 0.12 : (pages > 12 ? 0.10 : 0)) * B;
			drivers.push('Copywriting by our team');
		} else if (content === 'mix') {
			total += (pages <= 5 ? 0.06 : (pages > 12 ? 0.05 : 0)) * B;
			drivers.push('Some copywriting');
		}
		if (feats.indexOf('language') > -1) {
			total *= 1.25;
			heavy++;
			drivers.push('More than one language');
		}
		weeks = [weeks[0] + heavy, weeks[1] + heavy];

		var platform = val('platform');
		if (platform && platform !== 'unsure') {
			drivers.push('Built on ' + labels['platform:' + platform]);
		}
		if (isStore && (platform === 'wix' || platform === 'webflow')) {
			drivers.push('For larger stores we usually recommend Shopify or WooCommerce');
		}

		return {
			low: round50(total),
			high: round50(total * 1.3),
			weeks: weeks,
			pack: pack,
			drivers: drivers,
			type: type,
			pages: pages
		};
	}

	function render() {
		var e = estimate();
		last = e;
		var pagesQ = form.querySelector('[data-calc-q="pages"]');
		if (pagesQ) { pagesQ.classList.toggle('is-muted', e.type === 'landing'); }
		out.price.textContent = money(e.low) + ' to ' + money(e.high);
		out.time.textContent = e.weeks[0] + ' to ' + e.weeks[1] + ' weeks';
		out.pack.textContent = e.pack;
		out.drivers.innerHTML = '';
		e.drivers.forEach(function (d) {
			var li = document.createElement('li');
			li.textContent = d;
			out.drivers.appendChild(li);
		});
		var ind = val('industry');
		if (industries[ind] && industries[ind][1]) {
			out.industry.hidden = false;
			out.industry.innerHTML = '';
			out.industry.appendChild(document.createTextNode('See what we build for '));
			var a = document.createElement('a');
			a.href = industries[ind][1];
			a.textContent = industries[ind][0].toLowerCase();
			out.industry.appendChild(a);
			out.industry.appendChild(document.createTextNode('.'));
		} else {
			out.industry.hidden = true;
		}
		root.classList.remove('is-updated');
		void root.offsetWidth;
		root.classList.add('is-updated');
	}

	function summary() {
		var e = last || estimate();
		var feats = vals('features').map(function (f) { return labels['features:' + f]; });
		var lines = [
			'My website cost calculator estimate: ' + money(e.low) + ' to ' + money(e.high) + ', ' + e.weeks[0] + ' to ' + e.weeks[1] + ' weeks.',
			'Project: ' + labels['type:' + val('type')] + (e.type === 'landing' ? '' : ', ' + labels['pages:' + e.pages] + ' pages') + '.',
			'Platform: ' + labels['platform:' + val('platform')] + '.',
			'Features: ' + (feats.length ? feats.join(', ') : 'none selected') + '.',
			'Content: ' + labels['content:' + val('content')] + '.',
			'Industry: ' + labels['industry:' + val('industry')] + '.'
		];
		return lines.join('\n') + '\n\n';
	}

	form.addEventListener('change', function () {
		render();
		if (!tracked) {
			tracked = true;
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({ event: 'calculator_used' });
			if (typeof window.gtag === 'function') { window.gtag('event', 'calculator_used'); }
		}
	});

	out.cta.addEventListener('click', function () {
		try { sessionStorage.setItem('vyntic_plan', summary()); } catch (err) {}
		window.dataLayer = window.dataLayer || [];
		window.dataLayer.push({ event: 'calculator_quote_click', estimate_low: last ? last.low : null });
		if (typeof window.gtag === 'function') { window.gtag('event', 'calculator_quote_click'); }
	});

	render();
})();
