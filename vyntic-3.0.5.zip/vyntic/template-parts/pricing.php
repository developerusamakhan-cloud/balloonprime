<?php
/**
 * Pricing: website packages and monthly care plans, switched with two tabs.
 * Prices are set in Customize → Vyntic options → Pricing.
 *
 * Args: tab (websites|care), heading, lead, faq (bool, adds the pricing FAQ).
 *
 * @package Vyntic
 */

$vyntic_tab     = isset( $args['tab'] ) && 'care' === $args['tab'] ? 'care' : 'websites';
$vyntic_heading = isset( $args['heading'] ) ? $args['heading'] : __( 'Simple, honest pricing', 'vyntic' );
$vyntic_lead    = isset( $args['lead'] ) ? $args['lead'] : __( 'Starting prices for our most common projects. You always get one fixed price in writing before any work starts.', 'vyntic' );
$vyntic_cta     = vyntic_cta_url();
$vyntic_audit   = vyntic_template_url( 'page-templates/free-audit.php' );
$vyntic_uid     = wp_unique_id( 'pricing-' );
$vyntic_groups  = array(
	'websites' => array(
		'label' => __( 'Websites', 'vyntic' ),
		'items' => vyntic_website_packages(),
	),
	'care'     => array(
		'label' => __( 'Monthly care', 'vyntic' ),
		'items' => vyntic_plans(),
	),
);
$vyntic_plan_url = function ( $name ) use ( $vyntic_cta ) {
	return 0 === strpos( $vyntic_cta, 'http' ) ? add_query_arg( 'plan', rawurlencode( $name ), $vyntic_cta ) . '#contact-form' : $vyntic_cta;
};
?>
<section class="section pricing" aria-labelledby="<?php echo esc_attr( $vyntic_uid ); ?>-title" data-pricing>
	<div class="wrap">
		<div class="pricing__head">
			<div>
				<h2 class="section__title" id="<?php echo esc_attr( $vyntic_uid ); ?>-title"><?php echo esc_html( $vyntic_heading ); ?></h2>
				<?php if ( $vyntic_lead ) : ?><p class="section__lead"><?php echo esc_html( $vyntic_lead ); ?></p><?php endif; ?>
			</div>
			<div class="pricing__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Pricing type', 'vyntic' ); ?>">
				<?php foreach ( $vyntic_groups as $vyntic_gid => $vyntic_group ) : ?>
					<button type="button" role="tab" class="pricing__tab" id="<?php echo esc_attr( $vyntic_uid . '-tab-' . $vyntic_gid ); ?>" aria-controls="<?php echo esc_attr( $vyntic_uid . '-' . $vyntic_gid ); ?>" aria-selected="<?php echo $vyntic_tab === $vyntic_gid ? 'true' : 'false'; ?>" <?php echo $vyntic_tab === $vyntic_gid ? '' : 'tabindex="-1"'; ?> data-pricing-tab="<?php echo esc_attr( $vyntic_gid ); ?>"><?php echo esc_html( $vyntic_group['label'] ); ?></button>
				<?php endforeach; ?>
			</div>
		</div>

		<?php foreach ( $vyntic_groups as $vyntic_gid => $vyntic_group ) : ?>
			<div class="pricing__panel" role="tabpanel" id="<?php echo esc_attr( $vyntic_uid . '-' . $vyntic_gid ); ?>" aria-labelledby="<?php echo esc_attr( $vyntic_uid . '-tab-' . $vyntic_gid ); ?>" data-pricing-panel="<?php echo esc_attr( $vyntic_gid ); ?>" <?php echo $vyntic_tab === $vyntic_gid ? '' : 'hidden'; ?>>
				<?php foreach ( $vyntic_group['items'] as $vyntic_p ) : ?>
					<article class="price-card<?php echo ! empty( $vyntic_p['featured'] ) ? ' price-card--featured' : ''; ?>">
						<div class="price-card__top">
							<h3 class="price-card__name"><?php echo esc_html( $vyntic_p['name'] ); ?></h3>
							<?php if ( ! empty( $vyntic_p['featured'] ) ) : ?><span class="price-card__badge"><?php esc_html_e( 'Most popular', 'vyntic' ); ?></span><?php endif; ?>
						</div>
						<p class="price-card__for"><?php echo esc_html( $vyntic_p['for'] ); ?></p>
						<p class="price-card__price">
							<?php if ( 'websites' === $vyntic_gid ) : ?><span class="price-card__from"><?php esc_html_e( 'from', 'vyntic' ); ?></span><?php endif; ?>
							<span class="price-card__amount"><?php echo esc_html( $vyntic_p['price'] ); ?></span>
							<span class="price-card__period"><?php echo esc_html( 'websites' === $vyntic_gid ? $vyntic_p['period'] : __( '/month', 'vyntic' ) ); ?></span>
						</p>
						<ul class="price-card__list">
							<?php foreach ( $vyntic_p['features'] as $vyntic_f ) : ?>
								<li><span class="price-card__tick" aria-hidden="true"><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><?php echo esc_html( $vyntic_f ); ?></li>
							<?php endforeach; ?>
							<?php foreach ( isset( $vyntic_p['excluded'] ) ? $vyntic_p['excluded'] : array() as $vyntic_f ) : ?>
								<li class="is-excluded"><span class="price-card__tick" aria-hidden="true"><?php echo vyntic_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><span><span class="screen-reader-text"><?php esc_html_e( 'Not included:', 'vyntic' ); ?> </span><?php echo esc_html( $vyntic_f ); ?> <?php esc_html_e( 'not included', 'vyntic' ); ?></span></li>
							<?php endforeach; ?>
						</ul>
						<a class="btn <?php echo ! empty( $vyntic_p['featured'] ) ? 'btn--primary' : 'btn--ghost'; ?> price-card__cta" href="<?php echo esc_url( $vyntic_plan_url( $vyntic_p['name'] ) ); ?>" aria-label="<?php /* translators: %s plan name */ echo esc_attr( sprintf( __( 'Get started with %s', 'vyntic' ), $vyntic_p['name'] ) ); ?>">
							<?php esc_html_e( 'Get started', 'vyntic' ); ?> <span aria-hidden="true">&rarr;</span>
						</a>
						<?php if ( ! empty( $vyntic_p['note'] ) ) : ?><p class="price-card__note"><?php echo esc_html( $vyntic_p['note'] ); ?></p><?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endforeach; ?>

		<p class="pricing__foot">
			<?php esc_html_e( 'Prices in US dollars, quoted in your own currency on request. Need something different? Every project gets its own fixed quote.', 'vyntic' ); ?>
			<?php if ( $vyntic_audit ) : ?>
				<a href="<?php echo esc_url( $vyntic_audit ); ?>"><?php esc_html_e( 'Or start with a free audit', 'vyntic' ); ?> &rarr;</a>
			<?php endif; ?>
		</p>
		<?php
		$vyntic_calc_url    = vyntic_template_url( 'page-templates/cost-calculator.php' );
		$vyntic_pricing_url = vyntic_template_url( 'page-templates/website-pricing.php' );
		if ( $vyntic_calc_url || ( $vyntic_pricing_url && ! is_page_template( 'page-templates/website-pricing.php' ) ) ) :
			?>
			<p class="pricing__foot pricing__links">
				<?php if ( $vyntic_calc_url ) : ?>
					<a href="<?php echo esc_url( $vyntic_calc_url ); ?>"><?php esc_html_e( 'Estimate your project with the website cost calculator', 'vyntic' ); ?> &rarr;</a>
				<?php endif; ?>
				<?php if ( $vyntic_pricing_url && ! is_page_template( 'page-templates/website-pricing.php' ) ) : ?>
					<a href="<?php echo esc_url( $vyntic_pricing_url ); ?>"><?php esc_html_e( 'See all website design pricing', 'vyntic' ); ?> &rarr;</a>
				<?php endif; ?>
			</p>
		<?php endif; ?>
	</div>
</section>
<?php
if ( ! empty( $args['faq'] ) ) {
	get_template_part( 'template-parts/faq', null, array( 'key' => 'pricing' ) );
}
