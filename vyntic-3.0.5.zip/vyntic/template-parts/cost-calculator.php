<?php
/**
 * Website cost calculator. Estimates follow the starting prices in
 * Customize → Vyntic options → Pricing (starter, business, store).
 *
 * @package Vyntic
 */

list( $vyntic_starter, $vyntic_cur ) = vyntic_price_parts( 'starter' );
list( $vyntic_business ) = vyntic_price_parts( 'business' );
list( $vyntic_store )    = vyntic_price_parts( 'store' );
if ( $vyntic_starter <= 0 || $vyntic_business <= 0 || $vyntic_store <= 0 ) {
	return; // Without prices there is nothing honest to estimate.
}
wp_enqueue_script( 'vyntic-calculator', VYNTIC_URI . '/assets/js/calculator.js', array(), VYNTIC_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );

$vyntic_contact = vyntic_template_url( 'page-templates/contact.php' );
$vyntic_contact = $vyntic_contact ? $vyntic_contact : home_url( '/contact/' );
$vyntic_ind     = array();
foreach ( array( 'dental', 'law-firms', 'med-spa', 'hvac', 'plumbers', 'roofing', 'real-estate', 'ecommerce-brands' ) as $vyntic_k ) {
	$vyntic_d = vyntic_landing( $vyntic_k );
	if ( $vyntic_d ) {
		$vyntic_ind[ $vyntic_k ] = array( $vyntic_d['label'], vyntic_landing_url( $vyntic_k ) );
	}
}

$vyntic_q = array(
	'type'     => array(
		__( 'What do you need?', 'vyntic' ),
		'radio',
		array(
			'new'       => __( 'A new website', 'vyntic' ),
			'redesign'  => __( 'A redesign of my current site', 'vyntic' ),
			'migration' => __( 'A move to a new platform', 'vyntic' ),
			'store'     => __( 'An online store', 'vyntic' ),
			'landing'   => __( 'A landing page for ads', 'vyntic' ),
		),
	),
	'platform' => array(
		__( 'Which platform?', 'vyntic' ),
		'radio',
		array(
			'wordpress'   => 'WordPress',
			'webflow'     => 'Webflow',
			'shopify'     => 'Shopify',
			'woocommerce' => 'WooCommerce',
			'wix'         => __( 'Wix or Squarespace', 'vyntic' ),
			'unsure'      => __( 'Not sure yet', 'vyntic' ),
		),
	),
	'pages'    => array(
		__( 'How many pages?', 'vyntic' ),
		'radio',
		array(
			'5'  => __( 'Up to 5', 'vyntic' ),
			'12' => __( '6 to 12', 'vyntic' ),
			'25' => __( '13 to 25', 'vyntic' ),
			'40' => __( 'More than 25', 'vyntic' ),
		),
	),
	'features' => array(
		__( 'Which features do you need?', 'vyntic' ),
		'check',
		array(
			'booking'  => __( 'Online booking', 'vyntic' ),
			'blog'     => __( 'Blog or news', 'vyntic' ),
			'crm'      => __( 'CRM or email integration', 'vyntic' ),
			'shop'     => __( 'Selling products', 'vyntic' ),
			'tool'     => __( 'Calculator or custom tool', 'vyntic' ),
			'members'  => __( 'Members or client area', 'vyntic' ),
			'language' => __( 'More than one language', 'vyntic' ),
		),
	),
	'content'  => array(
		__( 'Who writes the content?', 'vyntic' ),
		'radio',
		array(
			'you'  => __( 'We have it ready', 'vyntic' ),
			'mix'  => __( 'We have some of it', 'vyntic' ),
			'us'   => __( 'Please write it for us', 'vyntic' ),
		),
	),
	'industry' => array(
		__( 'Your industry', 'vyntic' ),
		'radio',
		array_merge( array_map( function ( $v ) { return $v[0]; }, $vyntic_ind ), array( 'other' => __( 'Something else', 'vyntic' ) ) ),
	),
);
$vyntic_defaults = array( 'type' => 'new', 'platform' => 'unsure', 'pages' => '5', 'content' => 'mix', 'industry' => 'other' );
?>
<section class="section calc-section">
	<div class="wrap calc" data-calc
		data-prices="<?php echo esc_attr( wp_json_encode( array( 'starter' => $vyntic_starter, 'business' => $vyntic_business, 'store' => $vyntic_store ) ) ); ?>"
		data-currency="<?php echo esc_attr( $vyntic_cur ); ?>"
		data-contact="<?php echo esc_url( $vyntic_contact ); ?>"
		data-industries="<?php echo esc_attr( wp_json_encode( $vyntic_ind ) ); ?>">

		<form class="calc__form" data-calc-form>
			<?php $vyntic_n = 0; ?>
			<?php foreach ( $vyntic_q as $vyntic_name => $vyntic_def ) : ?>
				<?php $vyntic_n++; ?>
				<fieldset class="calc__q" data-calc-q="<?php echo esc_attr( $vyntic_name ); ?>">
					<legend><span class="calc__num"><?php echo esc_html( $vyntic_n ); ?></span><?php echo esc_html( $vyntic_def[0] ); ?></legend>
					<div class="calc__opts">
						<?php foreach ( $vyntic_def[2] as $vyntic_val => $vyntic_label ) : ?>
							<label class="calc__opt">
								<input type="<?php echo 'check' === $vyntic_def[1] ? 'checkbox' : 'radio'; ?>" name="<?php echo esc_attr( $vyntic_name . ( 'check' === $vyntic_def[1] ? '[]' : '' ) ); ?>" value="<?php echo esc_attr( $vyntic_val ); ?>" <?php checked( isset( $vyntic_defaults[ $vyntic_name ] ) && (string) $vyntic_defaults[ $vyntic_name ] === (string) $vyntic_val ); ?>>
								<span><?php echo esc_html( $vyntic_label ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</fieldset>
			<?php endforeach; ?>
		</form>

		<aside class="calc__result" aria-live="polite" data-calc-result>
			<p class="calc__eyebrow"><?php esc_html_e( 'Your estimate', 'vyntic' ); ?></p>
			<p class="calc__price" data-calc-price>-</p>
			<dl class="calc__facts">
				<div><dt><?php esc_html_e( 'Timeline', 'vyntic' ); ?></dt><dd data-calc-time>-</dd></div>
				<div><dt><?php esc_html_e( 'Best fit', 'vyntic' ); ?></dt><dd data-calc-package>-</dd></div>
			</dl>
			<p class="calc__label"><?php esc_html_e( 'What shapes your price', 'vyntic' ); ?></p>
			<ul class="calc__drivers" data-calc-drivers></ul>
			<p class="calc__industry" data-calc-industry hidden></p>
			<a class="btn btn--primary calc__cta" href="<?php echo esc_url( $vyntic_contact ); ?>#contact-form" data-calc-cta><?php esc_html_e( 'Get an exact quote in 24 hours', 'vyntic' ); ?></a>
			<p class="calc__note"><?php esc_html_e( 'An estimate based on our starting prices, not a quote. You get one fixed price in writing after a short call.', 'vyntic' ); ?></p>
			<noscript><p class="calc__note"><?php esc_html_e( 'The calculator needs JavaScript. See our pricing page or contact us for a quote.', 'vyntic' ); ?></p></noscript>
		</aside>
	</div>
</section>
<?php
echo '<script type="application/ld+json">' . wp_json_encode(
	array(
		'@context'            => 'https://schema.org',
		'@type'               => 'WebApplication',
		'name'                => __( 'Website cost calculator', 'vyntic' ),
		'url'                 => get_permalink(),
		'applicationCategory' => 'BusinessApplication',
		'operatingSystem'     => 'Any',
		'offers'              => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD' ),
		'provider'            => array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ) ),
	),
	JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
) . '</script>';
