<?php
/**
 * Ready-made service or industry page. Args: key (entry in inc/data/landing.json).
 *
 * @package Vyntic
 */

$vyntic_key = isset( $args['key'] ) ? $args['key'] : '';
$vyntic_d   = vyntic_landing( $vyntic_key );
if ( ! $vyntic_d ) {
	return;
}
$vyntic_is_industry = ( 'industry' === $vyntic_d['kind'] );
$vyntic_hub         = $vyntic_is_industry ? vyntic_template_url( 'page-templates/industries.php' ) : vyntic_template_url( 'page-templates/services.php' );
$vyntic_lead        = has_excerpt() ? get_the_excerpt() : $vyntic_d['lead'];
?>
<section class="intro intro--split lp-hero">
	<div class="wrap intro__inner">
		<div>
			<?php vyntic_breadcrumbs(); ?>
			<h1 class="intro__title"><?php echo esc_html( $vyntic_d['h1'] ); ?></h1>
			<p class="intro__lead"><?php echo esc_html( $vyntic_lead ); ?></p>
			<div class="hero__actions">
				<a class="btn btn--primary btn--lg" href="#contact"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
				<a class="btn btn--ghost btn--lg" href="#free-audit"><?php esc_html_e( 'Free website audit', 'vyntic' ); ?></a>
			</div>
			<?php if ( ! empty( $vyntic_d['proof'] ) ) : ?>
				<ul class="lp-proof">
					<?php foreach ( $vyntic_d['proof'] as $vyntic_p ) : ?>
						<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $vyntic_p ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<div class="lp-art">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'large', array( 'class' => 'lp-art__img', 'fetchpriority' => 'high' ) ); ?>
			<?php else : ?>
				<img class="lp-art__img" src="<?php echo esc_url( vyntic_img( 'services/' . $vyntic_d['art'] . '.svg' ) ); ?>" alt="" width="360" height="240" fetchpriority="high">
			<?php endif; ?>
			<span class="lp-art__icon" aria-hidden="true"><?php echo vyntic_icon( $vyntic_d['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
		</div>
	</div>
</section>

<section class="section problems" aria-labelledby="lp-problems">
	<div class="wrap problems__inner">
		<div class="problems__head">
			<h2 class="section__title" id="lp-problems"><?php echo esc_html( $vyntic_d['problems_title'] ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'If any of these sound like your business, you are in the right place. Each one is fixable.', 'vyntic' ); ?></p>
			<a class="btn btn--primary" href="#free-audit"><?php esc_html_e( 'Check my site for free', 'vyntic' ); ?></a>
		</div>
		<ul class="problems__list">
			<?php foreach ( $vyntic_d['problems'] as $vyntic_pr ) : ?>
				<li class="problem">
					<span class="problem__dot" aria-hidden="true"></span>
					<h3 class="problem__title"><?php echo esc_html( $vyntic_pr[0] ); ?></h3>
					<p><?php echo esc_html( $vyntic_pr[1] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="section section--mist" aria-labelledby="lp-included">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="lp-included"><?php echo esc_html( $vyntic_d['included_title'] ); ?></h2>
		</div>
		<ul class="lp-grid">
			<?php foreach ( $vyntic_d['included'] as $vyntic_i => $vyntic_item ) : ?>
				<li class="lp-card">
					<span class="lp-card__num"><?php echo esc_html( str_pad( (string) ( $vyntic_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
					<h3 class="lp-card__title"><?php echo esc_html( $vyntic_item[0] ); ?></h3>
					<p><?php echo esc_html( $vyntic_item[1] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( ! empty( $vyntic_d['tags'] ) ) : ?>
			<ul class="lp-tags" aria-label="<?php esc_attr_e( 'Tools and platforms', 'vyntic' ); ?>">
				<?php foreach ( $vyntic_d['tags'] as $vyntic_t ) : ?>
					<li><?php echo esc_html( $vyntic_t ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php if ( ! $vyntic_is_industry ) : ?>
			<?php $vyntic_inds = vyntic_industry_links(); ?>
			<?php if ( $vyntic_inds ) : ?>
				<div class="lp-for">
					<p class="lp-for__label"><?php esc_html_e( 'Industries we do this for', 'vyntic' ); ?></p>
					<ul>
						<?php foreach ( $vyntic_inds as $vyntic_ind ) : ?>
							<li><a href="<?php echo esc_url( $vyntic_ind[1] ); ?>"><?php echo esc_html( $vyntic_ind[0] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</section>

<?php
$vyntic_article = vyntic_current_article_key();
vyntic_render_article( $vyntic_article ? $vyntic_article : $vyntic_key, $vyntic_d['label'] );
?>

<section class="section process-stack" aria-labelledby="lp-steps">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="lp-steps"><?php esc_html_e( 'How it works', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Clear steps, one fixed price and no jargon along the way.', 'vyntic' ); ?></p>
		</div>
		<ol class="stack-cards">
			<?php foreach ( $vyntic_d['steps'] as $vyntic_i => $vyntic_step ) : ?>
				<li class="stack-card" style="--n: <?php echo esc_attr( $vyntic_i ); ?>">
					<div class="stack-card__body">
						<p class="stack-card__step"><?php /* translators: %d step number */ echo esc_html( sprintf( __( 'Step %d', 'vyntic' ), $vyntic_i + 1 ) ); ?></p>
						<h3 class="stack-card__title"><?php echo esc_html( $vyntic_step[0] ); ?></h3>
						<p class="stack-card__text"><?php echo esc_html( $vyntic_step[1] ); ?></p>
					</div>
					<span class="stack-card__num" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $vyntic_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>

<?php
get_template_part( 'template-parts/work-grid', null, array( 'count' => 2, 'more' => true, 'heading' => __( 'Recent work', 'vyntic' ), 'lead' => __( 'A few projects we are proud of.', 'vyntic' ) ) );
vyntic_post_cards( vyntic_landing_posts( $vyntic_key ), __( 'Guides on this topic', 'vyntic' ) );
get_template_part( 'template-parts/reviews' );
if ( ( 'industry' === $vyntic_d['kind'] && empty( $vyntic_d['group'] ) ) || in_array( $vyntic_key, array( 'web-design', 'website-redesign', 'ecommerce-development', 'landing-pages', 'wordpress-development', 'webflow-development', 'shopify-development', 'woocommerce-development', 'wix', 'squarespace', 'speed-optimization', 'website-migration' ), true ) ) {
	get_template_part( 'template-parts/pricing' );
}
get_template_part( 'template-parts/audit' );
?>

<section class="section" aria-labelledby="lp-faq">
	<div class="wrap faq">
		<h2 class="section__title" id="lp-faq"><?php esc_html_e( 'Questions we hear a lot', 'vyntic' ); ?></h2>
		<div class="faq__list">
			<?php foreach ( $vyntic_d['faq'] as $vyntic_q ) : ?>
				<details class="faq__item">
					<summary><?php echo esc_html( $vyntic_q[0] ); ?><span class="faq__icon"><?php echo vyntic_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></summary>
					<p><?php echo esc_html( $vyntic_q[1] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php if ( ! empty( $vyntic_d['related'] ) ) : ?>
	<section class="section section--tight" aria-labelledby="lp-related">
		<div class="wrap">
			<h2 class="section__title section__title--sm" id="lp-related"><?php esc_html_e( 'Often paired with', 'vyntic' ); ?></h2>
			<ul class="lp-related">
				<?php foreach ( $vyntic_d['related'] as $vyntic_r ) : ?>
					<?php
					$vyntic_rd  = vyntic_landing( $vyntic_r );
					$vyntic_url = $vyntic_rd ? vyntic_landing_url( $vyntic_r ) : '';
					if ( ! $vyntic_rd ) {
						continue;
					}
					?>
					<li>
						<?php if ( $vyntic_url ) : ?><a class="lp-rel" href="<?php echo esc_url( $vyntic_url ); ?>"><?php else : ?><span class="lp-rel"><?php endif; ?>
							<span class="lp-rel__icon"><?php echo vyntic_icon( $vyntic_rd['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							<span class="lp-rel__name"><?php echo esc_html( $vyntic_rd['label'] ); ?></span>
							<span class="lp-rel__text"><?php echo esc_html( $vyntic_rd['h1'] ); ?></span>
							<span class="lp-rel__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php if ( $vyntic_url ) : ?></a><?php else : ?></span><?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php
get_template_part( 'template-parts/contact-section' );

$vyntic_schema = array(
	'@context' => 'https://schema.org',
	'@graph'   => array(
		array(
			'@type'       => 'Service',
			'name'        => $vyntic_d['label'],
			'description' => $vyntic_lead,
			'url'         => get_permalink(),
			'provider'    => array(
				'@type' => 'ProfessionalService',
				'name'  => get_bloginfo( 'name' ),
				'url'   => home_url( '/' ),
			),
			'areaServed'  => array( 'United States', 'United Kingdom', 'Canada', 'Australia' ),
		),
		array(
			'@type'      => 'FAQPage',
			'mainEntity' => array_map(
				function ( $q ) {
					return array(
						'@type'          => 'Question',
						'name'           => $q[0],
						'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $q[1] ),
					);
				},
				$vyntic_d['faq']
			),
		),
	),
);
echo '<script type="application/ld+json">' . wp_json_encode( $vyntic_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
