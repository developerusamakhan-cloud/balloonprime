<?php
/**
 * Vyntic Hub plugin support: plugin pages use the theme design, the Hub's
 * plugins page gets the Plugins template automatically, and the Hub's colours
 * follow the theme.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The Hub prints the plugin name as the page H1 inside its header.
add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'vyntic-hub' );
	}
);

/**
 * The public plugins page (address set in Vyntic Hub, Settings), or null.
 *
 * @return WP_Post|null
 */
function vyntic_hub_page() {
	if ( ! class_exists( 'VH_Settings' ) ) {
		return null;
	}
	$page = get_page_by_path( VH_Settings::base() );
	return ( $page && 'publish' === $page->post_status ) ? $page : null;
}

/**
 * Use the Plugins template for the Hub's page unless another template was chosen.
 */
add_filter(
	'template_include',
	function ( $template ) {
		if ( ! is_page() ) {
			return $template;
		}
		$page = vyntic_hub_page();
		if ( ! $page || get_queried_object_id() !== $page->ID ) {
			return $template;
		}
		$chosen = get_page_template_slug( $page );
		if ( $chosen && 'page-templates/plugins.php' !== $chosen ) {
			return $template;
		}
		$ours = locate_template( 'page-templates/plugins.php' );
		return $ours ? $ours : $template;
	}
);

/**
 * The Plugins page uses the theme's article key "plugins" (SEO text and FAQ),
 * also when the page has no template set.
 */
add_filter(
	'vyntic_article_key',
	function ( $key, $post_id ) {
		$page = vyntic_hub_page();
		return ( ! $key && $page && (int) $post_id === $page->ID ) ? 'plugins' : $key;
	},
	10,
	2
);
