<?php
/**
 * Tools → Vyntic setup.
 *
 * One place to:
 * 1. Create the Phase 1 pages with the right template, parent and URL.
 * 2. Fill each page's editor with its long-form content (so Rank Math can analyse it).
 * 3. Fill Rank Math SEO title, meta description and focus keywords.
 *
 * Nothing is overwritten unless you tick "Overwrite". Data: inc/data/seo.json and inc/data/articles.json.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** SEO and page definitions. */
function vyntic_setup_pages() {
	static $data = null;
	if ( null === $data ) {
		$data = (array) json_decode( (string) file_get_contents( VYNTIC_DIR . '/inc/data/seo.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return $data;
}

/** Long-form articles. */
function vyntic_setup_articles() {
	static $data = null;
	if ( null === $data ) {
		$data = (array) json_decode( (string) file_get_contents( VYNTIC_DIR . '/inc/data/articles.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return $data;
}

/**
 * Find the page for a setup key.
 *
 * @param string $key Key from seo.json.
 * @return WP_Post|null
 */
function vyntic_setup_find( $key ) {
	$pages = vyntic_setup_pages();
	if ( empty( $pages[ $key ] ) ) {
		return null;
	}
	$p        = $pages[ $key ];
	$opt      = isset( $p[8] ) ? (array) $p[8] : array();
	$is_post  = isset( $opt['type'] ) && 'post' === $opt['type'];
	$slug     = $p[1];
	$template = $p[3];
	if ( 'home' === $key && get_option( 'page_on_front' ) ) {
		return get_post( (int) get_option( 'page_on_front' ) );
	}
	if ( 'blog' === $key && get_option( 'page_for_posts' ) ) {
		return get_post( (int) get_option( 'page_for_posts' ) );
	}
	if ( $is_post ) {
		$found = get_posts( array( 'post_type' => 'post', 'name' => $slug, 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => 1 ) );
		return $found ? $found[0] : null;
	}
	// Templates used by exactly one page can be matched by template.
	$shared = array( 'page-templates/location.php' );
	if ( $template && ! in_array( $template, $shared, true ) ) {
		$found = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 1,
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $template, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( $found ) {
			return $found[0];
		}
	}
	$path = vyntic_setup_path( $key );
	if ( $path ) {
		$page = get_page_by_path( $path );
		if ( $page ) {
			return $page;
		}
	}
	return null;
}

/** Full page path for a key, following parents (e.g. locations/canada/toronto). */
function vyntic_setup_path( $key ) {
	$pages = vyntic_setup_pages();
	if ( empty( $pages[ $key ] ) || '' === $pages[ $key ][1] ) {
		return '';
	}
	$parent = $pages[ $key ][2];
	if ( $parent ) {
		$pp = vyntic_setup_find( $parent );
		$pre = $pp ? get_page_uri( $pp ) : vyntic_setup_path( $parent );
		return trim( $pre . '/' . $pages[ $key ][1], '/' );
	}
	return $pages[ $key ][1];
}

/** URL for a key used inside article links. */
function vyntic_setup_link( $key ) {
	$pages = vyntic_setup_pages();
	$page  = isset( $pages[ $key ] ) ? vyntic_setup_find( $key ) : null;
	if ( $page ) {
		if ( 'publish' === $page->post_status ) {
			return get_permalink( $page );
		}
		// Drafts: use the URL the page will have once published.
		$opt = isset( $pages[ $key ][8] ) ? (array) $pages[ $key ][8] : array();
		if ( isset( $opt['type'] ) && 'post' === $opt['type'] ) {
			return home_url( '/' . $page->post_name . '/' );
		}
		return home_url( '/' . get_page_uri( $page ) . '/' );
	}
	if ( function_exists( 'vyntic_landing_url' ) && vyntic_landing( $key ) && vyntic_landing_url( $key ) ) {
		return vyntic_landing_url( $key );
	}
	return home_url( '/' );
}

/**
 * Turn one text line with {{key|anchor}} and {{ext:url|anchor}} tokens into safe HTML.
 * {{price:starter}} prints the current price from Customize (price_starter, price_growth...),
 * so page text always matches the prices you charge.
 */
function vyntic_setup_inline( $text ) {
	$parts = preg_split( '/(\{\{[^}]+\}\})/', $text, -1, PREG_SPLIT_DELIM_CAPTURE );
	$out   = '';
	foreach ( $parts as $part ) {
		if ( preg_match( '/^\{\{price:([a-z_]+)\}\}$/', $part, $m ) ) {
			$out .= esc_html( function_exists( 'vyntic_mod' ) ? (string) vyntic_mod( 'price_' . $m[1] ) : '' );
		} elseif ( preg_match( '/^\{\{(ext:)?([^|}]+)\|([^}]+)\}\}$/', $part, $m ) ) {
			if ( $m[1] ) {
				$out .= '<a href="' . esc_url( $m[2] ) . '" target="_blank" rel="noopener">' . esc_html( $m[3] ) . '</a>';
			} else {
				$out .= '<a href="' . esc_url( vyntic_setup_link( $m[2] ) ) . '">' . esc_html( $m[3] ) . '</a>';
			}
		} else {
			$out .= esc_html( $part );
		}
	}
	return $out;
}

/**
 * Build block editor content for a page.
 *
 * @param string $article_key Key in articles.json.
 * @param string $landing_key Key in landing.json (for FAQs), may be empty.
 * @return string
 */
function vyntic_setup_content( $article_key, $landing_key = '' ) {
	$articles = vyntic_setup_articles();
	if ( empty( $articles[ $article_key ] ) ) {
		return '';
	}
	$a    = $articles[ $article_key ];
	$kw   = $a['kw'];
	$html = '';
	foreach ( $a['body'] as $i => $block ) {
		list( $type, $value ) = $block;
		if ( 'p' === $type ) {
			$html .= "<!-- wp:paragraph -->\n<p>" . vyntic_setup_inline( $value ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		} elseif ( 'h2' === $type ) {
			$html .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $value ) . "</h2>\n<!-- /wp:heading -->\n\n";
		} elseif ( 'h3' === $type ) {
			$html .= "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">" . esc_html( $value ) . "</h3>\n<!-- /wp:heading -->\n\n";
		} elseif ( 'ul' === $type || 'ol' === $type ) {
			$html .= 'ol' === $type ? "<!-- wp:list {\"ordered\":true} -->\n<ol class=\"wp-block-list\">" : "<!-- wp:list -->\n<ul class=\"wp-block-list\">";
			foreach ( $value as $li ) {
				$html .= '<!-- wp:list-item --><li>' . vyntic_setup_inline( $li ) . '</li><!-- /wp:list-item -->';
			}
			$html .= '</' . $type . ">\n<!-- /wp:list -->\n\n";
		}
		if ( 0 === $i && ! empty( $a['img'] ) ) {
			$src   = vyntic_img( 'services/' . $a['img'] . '.svg' );
			$html .= "<!-- wp:image {\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"" . esc_url( $src ) . '" alt="' . esc_attr( ucfirst( $kw ) ) . "\"/></figure>\n<!-- /wp:image -->\n\n";
		}
	}

	if ( ! empty( $a['faq'] ) ) {
		$html .= "<!-- wp:heading {\"anchor\":\"faq\"} -->\n<h2 class=\"wp-block-heading\" id=\"faq\">" . esc_html__( 'Frequently asked questions', 'vyntic' ) . "</h2>\n<!-- /wp:heading -->\n\n";
		foreach ( $a['faq'] as $q ) {
			$html .= "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">" . esc_html( $q[0] ) . "</h3>\n<!-- /wp:heading -->\n\n";
			$html .= "<!-- wp:paragraph -->\n<p>" . esc_html( $q[1] ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		}
		$html .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html__( 'Key takeaways', 'vyntic' ) . "</h2>\n<!-- /wp:heading -->\n\n";
		$html .= "<!-- wp:paragraph -->\n<p>" . vyntic_setup_inline( 'The businesses that do well here are rarely the ones with the biggest budgets. They are the ones that get the basics right, measure what changes and keep going month after month. If you would like a second pair of eyes on your own site, {{free-audit|get a free website audit}} or {{contact|talk to us}}.' ) . "</p>\n<!-- /wp:paragraph -->\n";
		return $html;
	}

	$d = $landing_key && function_exists( 'vyntic_landing' ) ? vyntic_landing( $landing_key ) : null;
	if ( $d && ! empty( $d['faq'] ) ) {
		$html .= "<!-- wp:heading {\"anchor\":\"faq\"} -->\n<h2 class=\"wp-block-heading\" id=\"faq\">" . esc_html( ucfirst( $kw ) ) . " FAQs</h2>\n<!-- /wp:heading -->\n\n";
		$html .= "<!-- wp:paragraph -->\n<p>" . esc_html( sprintf( 'Here are straight answers to the questions we hear most about %s. If yours is not here, just ask.', $kw ) ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		foreach ( $d['faq'] as $q ) {
			$html .= "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">" . esc_html( $q[0] ) . "</h3>\n<!-- /wp:heading -->\n\n";
			$html .= "<!-- wp:paragraph -->\n<p>" . esc_html( $q[1] ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		}
		$html .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( sprintf( 'Why choose Vyntic Studio for %s', $kw ) ) . "</h2>\n<!-- /wp:heading -->\n\n";
		$html .= "<!-- wp:paragraph -->\n<p>" . vyntic_setup_inline( sprintf( 'Choosing a partner for %1$s is a real decision, and we do not take it lightly. You get one small team that handles design, build and search together, a fixed price agreed up front, honest timelines and reports you can actually read. If you want %1$s that brings customers rather than just compliments, {{contact|let us talk}}.', $kw ) ) . "</p>\n<!-- /wp:paragraph -->\n";
	}
	return $html;
}

/**
 * Words a visitor sees on a page. Template pages show their text from the theme
 * (inc/data/articles.json and landing.json), so the editor is empty on purpose.
 * Posts and editor pages (privacy, refund) are counted from the editor.
 *
 * @param string       $key  Setup key.
 * @param array        $p    Page definition.
 * @param WP_Post|null $page Page or post.
 * @return string Word count, or a dash when the page is built from theme sections only.
 */
function vyntic_setup_word_count( $key, $p, $page ) {
	$opt     = isset( $p[8] ) ? (array) $p[8] : array();
	$article = isset( $p[7] ) ? $p[7] : '';
	$count   = function ( $html ) {
		return str_word_count( wp_strip_all_tags( preg_replace( '/\{\{(?:ext:)?[^|}]+\|([^}]+)\}\}/', '$1', (string) $html ) ) );
	};
	if ( 'blog' === $key ) {
		return '-';
	}
	if ( ( isset( $opt['type'] ) && 'post' === $opt['type'] ) || ! empty( $opt['editor'] ) || ! $article ) {
		if ( ! $page ) {
			return '';
		}
		return $article || ! $p[3] ? (string) $count( $page->post_content ) : '-';
	}
	$articles = vyntic_setup_articles();
	$text     = '';
	if ( ! empty( $articles[ $article ] ) ) {
		foreach ( $articles[ $article ]['body'] as $block ) {
			$text .= ' ' . ( is_array( $block[1] ) ? implode( ' ', $block[1] ) : $block[1] );
		}
		foreach ( array( 'faq', 'qa' ) as $group ) {
			foreach ( isset( $articles[ $article ][ $group ] ) ? $articles[ $article ][ $group ] : array() as $q ) {
				$text .= ' ' . $q[0] . ' ' . $q[1];
			}
		}
	}
	// Page FAQ from inc/data/faq.json (the Care plans page shows the pricing FAQ).
	$page_faq = function_exists( 'vyntic_page_faq' ) ? vyntic_page_faq( 'care-plans' === $key ? 'pricing' : $key ) : null;
	if ( $page_faq ) {
		foreach ( $page_faq['items'] as $q ) {
			$text .= ' ' . $q[0] . ' ' . $q[1];
		}
	}
	$d = function_exists( 'vyntic_landing' ) ? vyntic_landing( $key ) : null;
	if ( $d ) {
		$text .= ' ' . $d['h1'] . ' ' . $d['lead'];
		foreach ( array( 'problems', 'included', 'steps', 'faq' ) as $group ) {
			foreach ( isset( $d[ $group ] ) ? (array) $d[ $group ] : array() as $item ) {
				$text .= ' ' . $item[0] . ' ' . $item[1];
			}
		}
	}
	return (string) $count( $text );
}

add_action( 'admin_menu', function () {
	add_management_page( __( 'Vyntic setup', 'vyntic' ), __( 'Vyntic setup', 'vyntic' ), 'manage_options', 'vyntic-setup', 'vyntic_setup_screen' );
} );

add_action( 'admin_post_vyntic_setup', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vyntic_setup' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic' ) );
	}
	$do        = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
	$overwrite = ! empty( $_POST['overwrite'] );
	$publish   = ! empty( $_POST['publish'] );
	$pages     = vyntic_setup_pages();
	$count     = 0;

	if ( 'create' === $do ) {
		foreach ( $pages as $key => $p ) {
			list( $title, $slug, $parent, $template ) = $p;
			$opt = isset( $p[8] ) ? (array) $p[8] : array();
			if ( vyntic_setup_find( $key ) ) {
				continue;
			}
			$is_post   = isset( $opt['type'] ) && 'post' === $opt['type'];
			$parent_id = 0;
			if ( $parent ) {
				$pp        = vyntic_setup_find( $parent );
				$parent_id = $pp ? $pp->ID : 0;
			}
			$status = ( $publish && empty( $opt['draft_only'] ) ) ? 'publish' : 'draft';
			$args   = array(
				'post_type'    => $is_post ? 'post' : 'page',
				'post_status'  => $status,
				'post_title'   => $title,
				'post_name'    => $slug ? $slug : sanitize_title( $title ),
				'post_parent'  => $is_post ? 0 : $parent_id,
				'post_excerpt' => isset( $opt['excerpt'] ) ? $opt['excerpt'] : '',
				'post_content' => ! empty( $opt['editor'] ) && ! empty( $p[7] ) ? vyntic_setup_content( $p[7] ) : '',
				'comment_status' => 'closed',
				'ping_status'  => 'closed',
			);
			if ( $is_post && ! empty( $opt['category'] ) ) {
				$term = term_exists( $opt['category'], 'category' );
				if ( ! $term ) {
					$term = wp_insert_term( $opt['category'], 'category' );
				}
				if ( ! is_wp_error( $term ) ) {
					$args['post_category'] = array( (int) ( is_array( $term ) ? $term['term_id'] : $term ) );
				}
			}
			$id = wp_insert_post( $args );
			if ( $id && ! is_wp_error( $id ) ) {
				if ( $template && ! $is_post ) {
					update_post_meta( $id, '_wp_page_template', $template );
				}
				if ( ! empty( $opt['meta'] ) ) {
					foreach ( $opt['meta'] as $mk => $mv ) {
						update_post_meta( $id, sanitize_key( $mk ), sanitize_text_field( $mv ) );
					}
				}
				if ( 'home' === $key && ! get_option( 'page_on_front' ) ) {
					update_option( 'show_on_front', 'page' );
					update_option( 'page_on_front', $id );
				}
				if ( 'blog' === $key && ! get_option( 'page_for_posts' ) ) {
					update_option( 'page_for_posts', $id );
				}
				if ( ! empty( $opt['privacy'] ) && ! get_post( (int) get_option( 'wp_page_for_privacy_policy' ) ) ) {
					update_option( 'wp_page_for_privacy_policy', $id );
				}
				$count++;
			}
		}
	}

	if ( 'content' === $do ) {
		foreach ( $pages as $key => $p ) {
			$article = isset( $p[7] ) ? $p[7] : '';
			$page    = vyntic_setup_find( $key );
			if ( ! $article || ! $page ) {
				continue;
			}
			$is_post = isset( $p[8]['type'] ) && 'post' === $p[8]['type'];
			if ( $is_post || ! empty( $p[8]['editor'] ) ) {
				if ( '' !== trim( $page->post_content ) && ! $overwrite ) {
					continue;
				}
				wp_update_post( array( 'ID' => $page->ID, 'post_content' => vyntic_setup_content( $article ) ) );
				$count++;
			} elseif ( 'about' !== $key && $overwrite && '' !== trim( $page->post_content ) ) {
				// Page content now lives in the template. Clear old editor copies so nothing is duplicated.
				wp_update_post( array( 'ID' => $page->ID, 'post_content' => '' ) );
				$count++;
			}
		}
	}

	if ( 'authors' === $do ) {
		$authors = get_users( array( 'role__in' => array( 'author', 'editor' ), 'orderby' => 'ID', 'fields' => array( 'ID' ) ) );
		$ids     = wp_list_pluck( $authors, 'ID' );
		if ( $ids ) {
			$posts = get_posts( array( 'numberposts' => -1, 'post_status' => array( 'publish', 'draft', 'future' ), 'orderby' => 'date', 'order' => 'ASC' ) );
			foreach ( $posts as $i => $po ) {
				if ( ! $overwrite && ! user_can( $po->post_author, 'manage_options' ) ) {
					continue;
				}
				wp_update_post( array( 'ID' => $po->ID, 'post_author' => (int) $ids[ $i % count( $ids ) ] ) );
				$count++;
			}
		}
	}

	if ( 'seo' === $do ) {
		foreach ( $pages as $key => $p ) {
			$page = vyntic_setup_find( $key );
			if ( ! $page ) {
				continue;
			}
			$fields = array(
				'rank_math_title'         => $p[4],
				'rank_math_description'   => $p[5],
				'rank_math_focus_keyword' => implode( ',', array_map( 'trim', explode( ',', $p[6] ) ) ),
			);
			$changed = false;
			// Blog posts: the headline is the post title, so keep it in line with the plan.
			if ( $overwrite && isset( $p[8]['type'] ) && 'post' === $p[8]['type'] && $p[0] !== $page->post_title ) {
				wp_update_post( array( 'ID' => $page->ID, 'post_title' => $p[0] ) );
				$changed = true;
			}
			foreach ( $fields as $meta => $value ) {
				if ( $overwrite || '' === (string) get_post_meta( $page->ID, $meta, true ) ) {
					update_post_meta( $page->ID, $meta, $value );
					$changed = true;
				}
			}
			$count += $changed ? 1 : 0;
		}
	}

	wp_safe_redirect( add_query_arg( array( 'page' => 'vyntic-setup', 'done' => $do, 'n' => $count ), admin_url( 'tools.php' ) ) );
	exit;
} );

function vyntic_setup_screen() {
	$pages = vyntic_setup_pages();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Vyntic setup', 'vyntic' ); ?></h1>
		<?php if ( isset( $_GET['done'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice notice-success"><p>
				<?php
				/* translators: %d number of pages */
				printf( esc_html__( 'Done. %d pages updated.', 'vyntic' ), (int) ( isset( $_GET['n'] ) ? $_GET['n'] : 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification
				?>
			</p></div>
		<?php endif; ?>
		<p><?php esc_html_e( 'Run the three steps in order. Existing content and SEO fields are kept unless you tick Overwrite.', 'vyntic' ); ?></p>

		<table class="widefat striped" style="max-width:1100px">
			<thead><tr><th><?php esc_html_e( 'Page', 'vyntic' ); ?></th><th><?php esc_html_e( 'Type', 'vyntic' ); ?></th><th>URL</th><th><?php esc_html_e( 'Status', 'vyntic' ); ?></th><th title="<?php esc_attr_e( 'Text visitors see. Theme pages count their built-in content; posts and editor pages count the editor.', 'vyntic' ); ?>"><?php esc_html_e( 'Words on page', 'vyntic' ); ?></th><th><?php esc_html_e( 'Rank Math title', 'vyntic' ); ?></th><th><?php esc_html_e( 'Focus keyword', 'vyntic' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $pages as $key => $p ) : ?>
				<?php $page = vyntic_setup_find( $key ); ?>
				<tr>
					<td><strong><?php echo esc_html( $p[0] ); ?></strong></td>
					<td><?php echo esc_html( ( isset( $p[8]['type'] ) && 'post' === $p[8]['type'] ) ? __( 'Post', 'vyntic' ) : ( ! empty( $p[8]['draft_only'] ) ? __( 'Page (draft)', 'vyntic' ) : __( 'Page', 'vyntic' ) ) ); ?></td>
					<td><?php echo $page ? '<a href="' . esc_url( get_permalink( $page ) ) . '" target="_blank">' . esc_html( wp_make_link_relative( get_permalink( $page ) ) ) . '</a>' : '<code>/' . esc_html( ( isset( $p[8]['type'] ) && 'post' === $p[8]['type'] ) ? $p[1] : vyntic_setup_path( $key ) ) . ( $p[1] ? '/' : '' ) . '</code>'; ?></td>
					<td><?php echo $page ? esc_html( ucfirst( $page->post_status ) ) : '<span style="color:#b32d2e">' . esc_html__( 'Missing', 'vyntic' ) . '</span>'; ?></td>
					<td><?php echo esc_html( vyntic_setup_word_count( $key, $p, $page ) ); ?></td>
					<td><?php echo $page && get_post_meta( $page->ID, 'rank_math_title', true ) ? '✓' : ''; ?></td>
					<td><?php echo esc_html( explode( ',', $p[6] )[0] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php
		$steps = array(
			'create'  => array( __( '1. Create missing pages', 'vyntic' ), __( 'Creates any missing page or blog post with the right template, parent, URL, category and excerpt. Existing pages are never touched. Privacy and refund policy pages are created as drafts with starter text, so you can check it with your advisor before publishing.', 'vyntic' ) ),
			'content' => array( __( '2. Add blog post content', 'vyntic' ), __( 'Writes each blog article with FAQs and internal links, and the privacy and refund policy text. Service, industry, location and main pages now show their content straight from the theme, so their editors stay empty. Tick Overwrite to also clear old copies from those page editors (your About page is never touched).', 'vyntic' ) ),
			'authors' => array( __( '3. Share posts between authors', 'vyntic' ), __( 'Spreads blog posts across your Authors and Editors in turn. Only posts written by an administrator are changed, unless Overwrite is ticked.', 'vyntic' ) ),
			'seo'     => array( __( '4. Fill Rank Math SEO', 'vyntic' ), __( 'Sets the SEO title, meta description and focus keywords for every page. Only fills empty fields unless Overwrite is ticked.', 'vyntic' ) ),
		);
		foreach ( $steps as $do => $s ) :
			?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:24px;padding:16px 20px;background:#fff;border:1px solid #dcdcde;max-width:1060px">
				<?php wp_nonce_field( 'vyntic_setup' ); ?>
				<input type="hidden" name="action" value="vyntic_setup">
				<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>">
				<h2 style="margin-top:0"><?php echo esc_html( $s[0] ); ?></h2>
				<p><?php echo esc_html( $s[1] ); ?></p>
				<?php if ( 'create' === $do ) : ?>
					<label><input type="checkbox" name="publish" value="1"> <?php esc_html_e( 'Publish now (otherwise pages are saved as drafts)', 'vyntic' ); ?></label>
				<?php else : ?>
					<label><input type="checkbox" name="overwrite" value="1"> <?php esc_html_e( 'Overwrite existing', 'vyntic' ); ?></label>
				<?php endif; ?>
				<p><button class="button button-primary"><?php echo esc_html( $s[0] ); ?></button></p>
			</form>
		<?php endforeach; ?>
	</div>
	<?php
}
