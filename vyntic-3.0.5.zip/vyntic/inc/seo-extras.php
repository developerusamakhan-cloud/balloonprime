<?php
/**
 * Technical SEO helpers from the SEO plan:
 * - policy pages are kept out of search results (they add no search value),
 * - robots.txt welcomes the AI crawlers you want to be found by.
 * Both can be changed with the filters below.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Page slugs that should not appear in search results. */
function vyntic_noindex_slugs() {
	return apply_filters( 'vyntic_noindex_slugs', array( 'privacy-policy', 'refund-policy', 'cookie-policy', 'terms', 'terms-of-service', 'terms-and-conditions' ) );
}

/** Whether the current request is a page that should be noindexed. */
function vyntic_is_noindex_page( $post = null ) {
	$post = get_post( $post );
	return $post && 'page' === $post->post_type && in_array( $post->post_name, vyntic_noindex_slugs(), true );
}

// Rank Math.
add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( is_singular( 'page' ) && vyntic_is_noindex_page() ) {
		$robots['index']  = 'noindex';
		$robots['follow'] = 'follow';
	}
	return $robots;
} );

// WordPress core robots meta, used when no SEO plugin is active.
add_filter( 'wp_robots', function ( $robots ) {
	if ( is_singular( 'page' ) && vyntic_is_noindex_page() && ! defined( 'RANK_MATH_VERSION' ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['max-image-preview'] );
	}
	return $robots;
} );

// Keep them out of the XML sitemaps too.
add_filter( 'rank_math/sitemap/posts_to_exclude', function ( $ids ) {
	foreach ( vyntic_noindex_slugs() as $slug ) {
		$p = get_page_by_path( $slug );
		if ( $p ) {
			$ids[] = $p->ID;
		}
	}
	return $ids;
} );
add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	if ( 'page' === $post_type ) {
		$exclude = array();
		foreach ( vyntic_noindex_slugs() as $slug ) {
			$p = get_page_by_path( $slug );
			if ( $p ) {
				$exclude[] = $p->ID;
			}
		}
		$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $exclude );
	}
	return $args;
}, 10, 2 );

/**
 * robots.txt: explicitly allow the AI search crawlers that can recommend your business.
 * Only affects the robots.txt WordPress (or Rank Math) generates, not a physical file.
 */
add_filter( 'robots_txt', function ( $output, $public ) {
	if ( ! $public ) {
		return $output;
	}
	$bots = apply_filters( 'vyntic_ai_crawlers', array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'PerplexityBot', 'Google-Extended', 'ClaudeBot', 'Applebot-Extended' ) );
	if ( ! $bots || false !== stripos( $output, 'GPTBot' ) ) {
		return $output;
	}
	$output = rtrim( $output ) . "\n\n# AI search crawlers\n";
	foreach ( $bots as $bot ) {
		$output .= "User-agent: {$bot}\nAllow: /\n\n";
	}
	return $output;
}, 99, 2 );
