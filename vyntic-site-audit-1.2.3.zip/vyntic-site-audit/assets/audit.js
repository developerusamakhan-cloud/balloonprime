(function () {
	'use strict';

	if (typeof window.VSA === 'undefined') { return; }
	var cfg = window.VSA;

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		Object.keys(data || {}).forEach(function (k) { body.append(k, data[k]); });
		return fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (res) {
				return res.json().catch(function () {
					throw new Error('The server returned an unexpected response (HTTP ' + res.status + '). Please try again.');
				});
			})
			.then(function (json) {
				if (!json || !json.success) {
					var err = new Error((json && json.data && json.data.message) || 'Something went wrong. Please try again.');
					err.data = (json && json.data) || {};
					throw err;
				}
				return json.data;
			});
	}

	function esc(s) {
		var d = document.createElement('div');
		d.textContent = s == null ? '' : String(s);
		return d.innerHTML;
	}

	function colorFor(score) {
		return score >= 80 ? 'var(--vsa-pass)' : (score >= 55 ? 'var(--vsa-warn)' : 'var(--vsa-fail)');
	}

	function verdict(score) {
		if (score >= 90) { return 'Excellent'; }
		if (score >= 80) { return 'Good, with room to grow'; }
		if (score >= 70) { return 'Fair'; }
		if (score >= 55) { return 'Underperforming'; }
		return 'Losing you customers';
	}

	function init(root) {
		var form = root.querySelector('.vsa-form');
		var btn = form.querySelector('.vsa-btn');
		var errorBox = form.querySelector('.vsa-error');
		var progress = root.querySelector('.vsa-progress');
		var result = root.querySelector('.vsa-result');
		var btnLabel = btn.textContent;
		var startLabel = progress.querySelector('[data-step="start"] span:last-child').textContent;
		var timer = null;
		var question = form.querySelector('.vsa-captcha-q');
		var nonce = null;
		var captchaToken = null;

		function setCaptcha(c) {
			if (!c) { return; }
			captchaToken = c.token;
			question.textContent = c.question;
			form.elements.captcha.value = '';
		}

		/* A fresh nonce and maths question, loaded after the page so page caching never breaks the form. */
		function loadChallenge() {
			return post('vsa_nonce', {}).then(function (d) {
				nonce = d.nonce;
				setCaptcha(d.captcha);
				return d;
			});
		}
		loadChallenge().catch(function () {});

		function showError(msg, field) {
			errorBox.textContent = msg;
			errorBox.hidden = false;
			form.querySelectorAll('[aria-invalid]').forEach(function (el) { el.removeAttribute('aria-invalid'); });
			if (field) {
				field.setAttribute('aria-invalid', 'true');
				field.focus();
			}
		}

		function step(name, state) {
			var li = progress.querySelector('[data-step="' + name + '"]');
			if (!li) { return; }
			li.classList.remove('is-active', 'is-done', 'is-skipped');
			if (state) { li.classList.add('is-' + state); }
		}

		function resetToForm(message, field) {
			clearInterval(timer);
			progress.hidden = true;
			result.hidden = true;
			form.hidden = false;
			btn.disabled = false;
			btn.textContent = btnLabel;
			['start', 'speed', 'finish'].forEach(function (s) { step(s, null); });
			progress.querySelector('[data-step="start"] span:last-child').textContent = startLabel;
			progress.querySelector('.vsa-timer').textContent = '';
			if (message) { showError(message, field); }
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			errorBox.hidden = true;

			var urlEl = form.elements.website;
			var emailEl = form.elements.email;
			var capEl = form.elements.captcha;
			var site = urlEl.value.trim();

			if (!/^(https?:\/\/)?[^\s\/]+\.[^\s\/]{2,}/i.test(site)) {
				return showError('Enter a valid website address, like yourbusiness.com.', urlEl);
			}
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailEl.value.trim())) {
				return showError('Enter a valid email address. Your report is sent there.', emailEl);
			}
			if (!/^\d{1,3}$/.test(capEl.value.trim())) {
				return showError('Answer the quick maths question.', capEl);
			}

			btn.disabled = true;
			btn.textContent = 'Starting audit...';

			var token;

			(nonce && captchaToken ? Promise.resolve() : loadChallenge())
				.then(function () {
					form.hidden = true;
					progress.hidden = false;
					progress.querySelector('.vsa-progress-site').textContent = 'Auditing ' + site.replace(/^https?:\/\//i, '').replace(/\/$/, '');
					step('start', 'active');
					return post('vsa_start', {
						nonce: nonce,
						website: site,
						email: emailEl.value.trim(),
						captcha: capEl.value.trim(),
						captcha_token: captchaToken,
						company_fax: form.elements.company_fax.value,
						source: window.location.href
					});
				})
				.then(function (d) {
					token = d.token;
					progress.querySelector('.vsa-progress-site').textContent = 'Auditing ' + d.host;
					step('start', 'done');
					var li = progress.querySelector('[data-step="start"] span:last-child');
					li.textContent = 'Homepage scanned: ' + d.checks + ' checks, ' + d.issues + ' issues so far';
					step('speed', 'active');
					var t0 = Date.now();
					var out = progress.querySelector('.vsa-timer');
					timer = setInterval(function () { out.textContent = Math.round((Date.now() - t0) / 1000) + 's'; }, 1000);
					return post('vsa_speed', { nonce: nonce, token: token });
				})
				.then(function (d) {
					clearInterval(timer);
					var out = progress.querySelector('.vsa-timer');
					if (d.ok) {
						out.textContent = d.performance !== null ? '(score ' + d.performance + ')' : '';
						step('speed', 'done');
					} else {
						out.textContent = '(unavailable right now, skipped)';
						step('speed', 'skipped');
					}
					step('finish', 'active');
					return post('vsa_finish', { nonce: nonce, token: token });
				})
				.then(function (d) {
					step('finish', 'done');
					renderResult(d);
				})
				.catch(function (err) {
					var data = err.data || {};
					captchaToken = null;
					resetToForm(err.message, data.field ? form.elements[data.field] : null);
					if (data.captcha) {
						setCaptcha(data.captcha);
					} else {
						loadChallenge().catch(function () {});
					}
				});
		});

		function renderResult(d) {
			var C = 2 * Math.PI * 62;
			var bars = d.categories.map(function (c) {
				return '<div class="vsa-bar"><span>' + esc(c.label) + '</span>' +
					'<div class="vsa-bar-track"><div class="vsa-bar-fill" data-w="' + c.score + '" style="background:' + colorFor(c.score) + '"></div></div>' +
					'<b>' + c.score + '</b></div>';
			}).join('');

			var issues = d.priorities.length ? '<div class="vsa-issues"><h3>Fix these first</h3><ol>' + d.priorities.map(function (p) {
				return '<li style="--vsa-issue:' + (p.status === 'fail' ? 'var(--vsa-fail)' : 'var(--vsa-warn)') + '"><div><strong>' + esc(p.title) + '</strong><span>' + esc(p.finding) + '</span></div></li>';
			}).join('') + '</ol></div>' : '';

			var actions = '';
			if (d.download) { actions += '<a class="vsa-btn" href="' + esc(d.download) + '">Download full PDF report</a>'; }
			if (cfg.booking) { actions += '<a class="' + (d.download ? 'vsa-btn-ghost' : 'vsa-btn') + '" href="' + esc(cfg.booking) + '">Book a free call to fix these</a>'; }

			var note = d.emailed
				? 'We also emailed the full report to ' + esc(d.email) + '. Check your spam folder if it does not arrive in a few minutes.'
				: (cfg.sendEmail && !d.download ? 'Your report is being prepared. If it does not arrive, contact us and we will send it manually.' : '');
			if (d.psiError) {
				note += (note ? ' ' : '') + 'Google\'s speed test was busy, so speed results are based on our server checks only.';
			}

			result.innerHTML =
				'<div class="vsa-result-head">' +
					'<div class="vsa-ring" role="img" aria-label="Overall score ' + d.overall + ' out of 100">' +
						'<svg viewBox="0 0 148 148"><circle class="vsa-ring-track" cx="74" cy="74" r="62"></circle>' +
						'<circle class="vsa-ring-bar" cx="74" cy="74" r="62" stroke="' + colorFor(d.overall) + '" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + C.toFixed(1) + '"></circle></svg>' +
						'<div class="vsa-ring-num">' + d.overall + '<small>out of 100</small></div>' +
					'</div>' +
					'<div>' +
						'<p class="vsa-result-host">' + esc(d.host) + '</p>' +
						'<p class="vsa-result-grade">Grade ' + esc(d.grade) + ': ' + verdict(d.overall) + '</p>' +
						'<ul class="vsa-counts">' +
							'<li><i style="background:var(--vsa-fail)"></i>' + d.counts.fail + ' critical</li>' +
							'<li><i style="background:var(--vsa-warn)"></i>' + d.counts.warn + ' need work</li>' +
							'<li><i style="background:var(--vsa-pass)"></i>' + d.counts.pass + ' passed</li>' +
						'</ul>' +
					'</div>' +
				'</div>' +
				'<div class="vsa-bars">' + bars + '</div>' +
				issues +
				(actions ? '<div class="vsa-result-actions">' + actions + '</div>' : '') +
				(note ? '<p class="vsa-result-note">' + note + '</p>' : '') +
				'<button type="button" class="vsa-link">Audit another website</button>';

			progress.hidden = true;
			result.hidden = false;
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });

			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					var ring = result.querySelector('.vsa-ring-bar');
					ring.style.strokeDashoffset = (C * (1 - d.overall / 100)).toFixed(1);
					result.querySelectorAll('.vsa-bar-fill').forEach(function (el) { el.style.width = el.getAttribute('data-w') + '%'; });
				});
			});

			result.querySelector('.vsa-link').addEventListener('click', function () {
				form.elements.website.value = '';
				resetToForm();
				loadChallenge().catch(function () {});
			});
		}
	}

	function boot() {
		document.querySelectorAll('.vsa').forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
