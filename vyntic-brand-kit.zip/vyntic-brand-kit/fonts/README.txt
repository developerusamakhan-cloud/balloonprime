VYNTIC STUDIO FONTS

Both fonts are free and open source (SIL Open Font License). Use them anywhere, including print and social media.

DISPLAY: Bricolage Grotesque
  Weights: 800 (big headlines), 700 (headings), 500 (small labels)
  Download: https://fonts.google.com/specimen/Bricolage+Grotesque
  Use for headlines, the wordmark feel, numbers and short labels. Never for long paragraphs.

BODY: Figtree
  Weights: 400 (text), 500 (emphasis), 600 (buttons, labels)
  Download: https://fonts.google.com/specimen/Figtree
  Use for paragraphs, buttons, forms, captions and UI.

Web embed (already used by the website):
https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Figtree:wght@400;500;600&display=swap

Canva: both fonts are in Canva's font list. Search "Bricolage Grotesque" and "Figtree".
Fallback when the fonts are not available: Segoe UI or Arial.
