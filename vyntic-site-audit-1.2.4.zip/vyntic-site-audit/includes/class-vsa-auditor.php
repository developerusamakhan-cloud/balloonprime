<?php
/**
 * Audit engine.
 *
 * Runs non-intrusive checks against a public homepage and, optionally,
 * Google PageSpeed Insights (Lighthouse). Works inside WordPress (uses the
 * WP HTTP API with SSRF protection) and falls back to cURL for CLI testing.
 */

if ( ! defined( 'ABSPATH' ) && PHP_SAPI !== 'cli' ) {
	exit;
}

class VSA_Auditor {

	// A normal browser identity: many firewalls (Cloudflare, Wordfence, Sucuri) answer 403 to
	// anything that calls itself a bot, even though the page is public.
	const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
	const USER_AGENT_MOBILE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1';

	/** User agent for the next request (changed when a site blocks the first one). */
	protected $ua = self::USER_AGENT;

	/** Browser-like request headers. */
	protected static function browser_headers() {
		return array(
			'Accept'                    => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			'Accept-Language'           => 'en-US,en;q=0.9',
			'Accept-Encoding'           => 'gzip, deflate',
			'Cache-Control'             => 'no-cache',
			'Upgrade-Insecure-Requests' => '1',
			'Sec-Fetch-Dest'            => 'document',
			'Sec-Fetch-Mode'            => 'navigate',
			'Sec-Fetch-Site'            => 'none',
			'Sec-Fetch-User'            => '?1',
		);
	}

	/** Category keys and their weight in the overall score. */
	const CATEGORIES = array(
		'speed'      => array( 'label' => 'Speed & performance', 'weight' => 25 ),
		'seo'        => array( 'label' => 'SEO & visibility', 'weight' => 25 ),
		'conversion' => array( 'label' => 'Lead conversion', 'weight' => 20 ),
		'security'   => array( 'label' => 'Security & trust', 'weight' => 15 ),
		'mobile'     => array( 'label' => 'Mobile & accessibility', 'weight' => 15 ),
	);

	protected $url;
	protected $final_url;
	protected $host;
	protected $html    = '';
	protected $headers = array();
	protected $status  = 0;
	protected $time    = 0.0;
	protected $dom;
	protected $xpath;
	protected $checks = array();
	protected $meta   = array();

	public function __construct( $url ) {
		$this->url  = $url;
		$this->host = wp_parse_url_safe( $url, PHP_URL_HOST );
	}

	/* ---------------------------------------------------------------------
	 * URL helpers
	 * ------------------------------------------------------------------- */

	/**
	 * Normalise user input into an absolute http(s) URL, or return false.
	 */
	public static function normalize_url( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return false;
		}
		if ( ! preg_match( '#^https?://#i', $raw ) ) {
			$raw = 'https://' . ltrim( $raw, '/' );
		}
		$parts = parse_url( $raw );
		if ( empty( $parts['host'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return false;
		}
		$host = strtolower( $parts['host'] );
		if ( false === strpos( $host, '.' ) || ! preg_match( '/^[a-z0-9.-]+$/', $host ) ) {
			return false;
		}
		$path = isset( $parts['path'] ) ? $parts['path'] : '/';
		$url  = strtolower( $parts['scheme'] ) . '://' . $host . ( isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '' ) . $path;
		if ( ! empty( $parts['query'] ) ) {
			$url .= '?' . $parts['query'];
		}
		return $url;
	}

	/**
	 * Block localhost / private network targets (SSRF protection).
	 */
	public static function is_public_host( $host ) {
		$host = strtolower( trim( $host ) );
		if ( function_exists( 'apply_filters' ) && apply_filters( 'vsa_allow_private_host', false, $host ) ) {
			return true; // Local testing only; never enable on a live site.
		}
		if ( in_array( $host, array( 'localhost', 'localhost.localdomain' ), true ) ) {
			return false;
		}
		$ips = filter_var( $host, FILTER_VALIDATE_IP ) ? array( $host ) : @gethostbynamel( $host );
		if ( empty( $ips ) ) {
			return false;
		}
		foreach ( $ips as $ip ) {
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * HTTP GET/HEAD returning a normalised array.
	 */
	protected function request( $url, $method = 'GET', $timeout = 20, $follow = true ) {
		$result = array(
			'ok'        => false,
			'status'    => 0,
			'headers'   => array(),
			'body'      => '',
			'time'      => 0,
			'final_url' => $url,
			'error'     => '',
		);
		$start = microtime( true );

		if ( function_exists( 'wp_safe_remote_request' ) ) {
			$response = wp_safe_remote_request(
				$url,
				array(
					'method'              => $method,
					'timeout'             => $timeout,
					'redirection'         => $follow ? 5 : 0,
					'user-agent'          => $this->ua,
					'limit_response_size' => 3 * MB_IN_BYTES,
					'headers'             => self::browser_headers(),
				)
			);
			$result['time'] = microtime( true ) - $start;
			if ( is_wp_error( $response ) ) {
				$result['error'] = $response->get_error_message();
				return $result;
			}
			$result['status'] = (int) wp_remote_retrieve_response_code( $response );
			$result['body']   = (string) wp_remote_retrieve_body( $response );
			$headers          = wp_remote_retrieve_headers( $response );
			foreach ( ( is_object( $headers ) ? $headers->getAll() : (array) $headers ) as $k => $v ) {
				$result['headers'][ strtolower( $k ) ] = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
			}
			if ( isset( $response['http_response'] ) && is_object( $response['http_response'] ) && method_exists( $response['http_response'], 'get_response_object' ) ) {
				$obj = $response['http_response']->get_response_object();
				if ( ! empty( $obj->url ) ) {
					$result['final_url'] = $obj->url;
				}
			}
			$result['ok'] = $result['status'] > 0;
			return $result;
		}

		// cURL fallback (CLI testing).
		$ch       = curl_init( $url );
		$raw_head = array();
		curl_setopt_array(
			$ch,
			array(
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_FOLLOWLOCATION => $follow,
				CURLOPT_MAXREDIRS      => 5,
				CURLOPT_TIMEOUT        => $timeout,
				CURLOPT_USERAGENT      => $this->ua,
				CURLOPT_HTTPHEADER     => array_map( function ( $k, $v ) { return $k . ': ' . $v; }, array_keys( self::browser_headers() ), self::browser_headers() ),
				CURLOPT_ENCODING       => 'gzip, deflate',
				CURLOPT_NOBODY         => 'HEAD' === $method,
				CURLOPT_HEADERFUNCTION => function ( $c, $line ) use ( &$raw_head ) {
					if ( preg_match( '#^HTTP/#', $line ) ) {
						$raw_head = array(); // Reset on each redirect hop.
					} elseif ( strpos( $line, ':' ) ) {
						list( $k, $v )                         = explode( ':', $line, 2 );
						$raw_head[ strtolower( trim( $k ) ) ] = trim( $v );
					}
					return strlen( $line );
				},
			)
		);
		$body             = curl_exec( $ch );
		$result['time']   = microtime( true ) - $start;
		$result['status'] = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE );
		if ( false === $body ) {
			$result['error'] = curl_error( $ch );
		} else {
			$result['body']      = (string) $body;
			$result['headers']   = $raw_head;
			$result['final_url'] = curl_getinfo( $ch, CURLINFO_EFFECTIVE_URL );
			$result['ok']        = $result['status'] > 0;
		}
		curl_close( $ch );
		return $result;
	}

	/* ---------------------------------------------------------------------
	 * Check registry
	 * ------------------------------------------------------------------- */

	protected function add( $category, $id, $status, $title, $finding, $impact = '', $fix = '', $weight = 2 ) {
		$this->checks[] = array(
			'category' => $category,
			'id'       => $id,
			'status'   => $status, // pass | warn | fail | info
			'title'    => $title,
			'finding'  => $finding,
			'impact'   => $impact,
			'fix'      => $fix,
			'weight'   => $weight,
		);
	}

	/* ---------------------------------------------------------------------
	 * Step 1: on-page scan
	 * ------------------------------------------------------------------- */

	/**
	 * @return array|WP_Error-like array with 'error' key.
	 */
	/** HTTP codes firewalls use to turn away automated visitors. */
	protected static function is_block_status( $code ) {
		return in_array( (int) $code, array( 401, 403, 406, 409, 429, 451, 503 ), true );
	}

	/**
	 * Fetch the home page. When a firewall blocks the first try, try again as a mobile
	 * browser and with the www / non-www address before giving up.
	 */
	protected function fetch_home() {
		$res      = $this->request( $this->url, 'GET', 25 );
		$tries    = array();
		$host     = (string) wp_parse_url_safe( $this->url, PHP_URL_HOST );
		$other    = 0 === strpos( $host, 'www.' ) ? substr( $host, 4 ) : 'www.' . $host;
		$alt_url  = preg_replace( '#^(https?://)' . preg_quote( $host, '#' ) . '#i', '$1' . $other, $this->url );
		$tries[]  = array( self::USER_AGENT_MOBILE, $this->url );
		$tries[]  = array( self::USER_AGENT, $alt_url );
		foreach ( $tries as $t ) {
			if ( $res['ok'] && ! self::is_block_status( $res['status'] ) ) {
				break;
			}
			$this->ua = $t[0];
			$next     = $this->request( $t[1], 'GET', 20 );
			$this->ua = self::USER_AGENT;
			// Keep the better answer: any real page beats a block or a network error.
			if ( $next['ok'] && ( ! $res['ok'] || ! self::is_block_status( $next['status'] ) ) ) {
				$res = $next;
			}
		}
		return $res;
	}

	/**
	 * The site's firewall blocked every try. Build a short result so the audit can
	 * still continue with Google PageSpeed Insights, which fetches the page from
	 * Google's own servers (firewalls almost always let Google in).
	 */
	protected function blocked_result( $status ) {
		$this->host      = (string) wp_parse_url_safe( $this->url, PHP_URL_HOST );
		$this->final_url = $this->url;
		$this->meta      = array(
			'url'           => $this->url,
			'final_url'     => $this->url,
			'host'          => $this->host,
			'page_title'    => '',
			'response_time' => 0,
			'html_kb'       => 0,
			'technologies'  => array(),
			'scanned_at'    => gmdate( 'c' ),
			'blocked'       => (int) $status,
		);
		$this->add(
			'security',
			'firewall_block',
			'info',
			'Your firewall blocked our on-page scan',
			sprintf( 'Your website\'s security settings answered our scanner with HTTP %d, so the on-page checks (titles, headings, schema, security headers) were skipped. Speed and Core Web Vitals in this report come from Google PageSpeed Insights.', (int) $status ),
			'Some firewalls also block useful visitors such as SEO tools and AI search crawlers.',
			'Check your firewall or bot-protection settings (for example Cloudflare Bot Fight Mode) to make sure search engines and AI crawlers you want are allowed in.',
			0
		);
		return array(
			'checks' => $this->checks,
			'meta'   => $this->meta,
		);
	}

	public function run_onpage() {
		$res = $this->fetch_home();
		if ( ! $res['ok'] ) {
			return array( 'error' => 'We could not reach this website. Check the address and try again.' . ( $res['error'] ? ' (' . $res['error'] . ')' : '' ) );
		}
		if ( self::is_block_status( $res['status'] ) ) {
			return $this->blocked_result( $res['status'] );
		}
		if ( $res['status'] >= 400 ) {
			return array( 'error' => sprintf( 'The website responded with an error (HTTP %d). Check the address and try again.', $res['status'] ) );
		}
		if ( strlen( trim( $res['body'] ) ) < 50 ) {
			return array( 'error' => 'The website returned an empty page, so there is nothing to audit.' );
		}

		$this->html      = $res['body'];
		$this->headers   = $res['headers'];
		$this->status    = $res['status'];
		$this->time      = $res['time'];
		$this->final_url = $res['final_url'];
		$this->host      = wp_parse_url_safe( $this->final_url, PHP_URL_HOST );

		libxml_use_internal_errors( true );
		$this->dom = new DOMDocument();
		$this->dom->loadHTML( '<?xml encoding="UTF-8">' . $this->html, LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		$this->xpath = new DOMXPath( $this->dom );

		$this->meta = array(
			'url'           => $this->url,
			'final_url'     => $this->final_url,
			'host'          => $this->host,
			'page_title'    => $this->text( '//title' ),
			'response_time' => round( $this->time, 2 ),
			'html_kb'       => round( strlen( $this->html ) / 1024 ),
			'technologies'  => $this->detect_tech(),
			'scanned_at'    => gmdate( 'c' ),
		);

		$this->check_security();
		$this->check_seo();
		$this->check_speed_server();
		$this->check_mobile();
		$this->check_conversion();

		return array(
			'checks' => $this->checks,
			'meta'   => $this->meta,
		);
	}

	/* ---------------------------------------------------------------------
	 * DOM helpers
	 * ------------------------------------------------------------------- */

	protected function nodes( $query ) {
		$list = $this->xpath->query( $query );
		return $list ? iterator_to_array( $list ) : array();
	}

	protected function count_nodes( $query ) {
		$list = $this->xpath->query( $query );
		return $list ? $list->length : 0;
	}

	protected function text( $query ) {
		$list = $this->xpath->query( $query );
		return ( $list && $list->length ) ? trim( preg_replace( '/\s+/u', ' ', $list->item( 0 )->textContent ) ) : '';
	}

	protected function attr( $query, $attr ) {
		$list = $this->xpath->query( $query );
		return ( $list && $list->length ) ? trim( $list->item( 0 )->getAttribute( $attr ) ) : '';
	}

	/** Case-insensitive attribute match helper for XPath. */
	protected static function lc( $expr ) {
		return "translate($expr,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')";
	}

	protected function visible_text() {
		$clone = $this->dom->cloneNode( true );
		$xp    = new DOMXPath( $clone );
		foreach ( $xp->query( '//script|//style|//noscript|//svg|//template' ) as $n ) {
			$n->parentNode->removeChild( $n );
		}
		$body = $xp->query( '//body' );
		$txt  = ( $body && $body->length ) ? $body->item( 0 )->textContent : $clone->textContent;
		return trim( preg_replace( '/\s+/u', ' ', $txt ) );
	}

	protected function base_url() {
		$p = parse_url( $this->final_url );
		return $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
	}

	protected function detect_tech() {
		$h    = $this->html;
		$tech = array();
		$map  = array(
			'WordPress'   => '#/wp-content/|/wp-includes/|content="WordPress#i',
			'Elementor'   => '#/plugins/elementor/|elementor-kit-\d#i',
			'WooCommerce' => '#/plugins/woocommerce/|woocommerce-(?:page|js|no-js)#i',
			'Divi'        => '#et_pb_|/Divi/#',
			'Shopify'     => '#cdn\.shopify\.com|Shopify\.theme#i',
			'Wix'         => '#static\.wixstatic\.com|static\.parastorage\.com#i',
			'Squarespace' => '#static1\.squarespace\.com|squarespace-cdn\.com#i',
			'Webflow'     => '#data-wf-site|website-files\.com|webflow\.js#i',
			'Framer'      => '#framerusercontent\.com#i',
			'Next.js'     => '#__NEXT_DATA__|/_next/static#',
			'HubSpot'     => '#js\.hs-scripts\.com|hs-analytics#i',
			'jQuery'      => '#jquery(\.min)?\.js#i',
			'Google Tag Manager' => '#googletagmanager\.com#i',
		);
		foreach ( $map as $name => $re ) {
			if ( preg_match( $re, $h ) ) {
				$tech[] = $name;
			}
		}
		if ( isset( $this->headers['cf-ray'] ) || ( isset( $this->headers['server'] ) && stripos( $this->headers['server'], 'cloudflare' ) !== false ) ) {
			$tech[] = 'Cloudflare';
		}
		return $tech;
	}

	/* ---------------------------------------------------------------------
	 * Security
	 * ------------------------------------------------------------------- */

	protected function check_security() {
		$is_https = 0 === stripos( $this->final_url, 'https://' );

		if ( $is_https ) {
			$this->add( 'security', 'https', 'pass', 'Secure connection (HTTPS)', 'Your site loads over an encrypted HTTPS connection.', '', '', 3 );
		} else {
			$this->add(
				'security', 'https', 'fail', 'Secure connection (HTTPS)',
				'Your site loads over plain HTTP. Browsers label it "Not secure".',
				'Visitors see a warning next to your address and many leave before filling in a form. Google also ranks HTTPS sites higher.',
				'Install a free SSL certificate (Let\'s Encrypt or Cloudflare) and force all traffic to HTTPS.', 3
			);
		}

		// HTTP -> HTTPS redirect.
		if ( $is_https ) {
			$http = $this->request( 'http://' . $this->host . '/', 'GET', 10, false );
			$loc  = isset( $http['headers']['location'] ) ? $http['headers']['location'] : '';
			if ( $http['status'] >= 300 && $http['status'] < 400 && 0 === stripos( $loc, 'https://' ) ) {
				$this->add( 'security', 'redirect', 'pass', 'HTTP redirects to HTTPS', 'Visitors who type the old http:// address are sent to the secure version.', '', '', 2 );
			} elseif ( $http['ok'] ) {
				$this->add(
					'security', 'redirect', 'warn', 'HTTP redirects to HTTPS',
					'The http:// version of your site does not redirect to https://.',
					'Some visitors and old links land on an insecure copy of your site, and search engines may index duplicate pages.',
					'Add a permanent 301 redirect from HTTP to HTTPS at server or Cloudflare level.', 2
				);
			}
		}

		// SSL certificate validity.
		if ( $is_https && function_exists( 'openssl_x509_parse' ) && function_exists( 'stream_socket_client' ) ) {
			$ctx    = stream_context_create( array( 'ssl' => array( 'capture_peer_cert' => true, 'verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true, 'peer_name' => $this->host ) ) );
			$errno  = 0;
			$errstr = '';
			$sock   = @stream_socket_client( 'ssl://' . $this->host . ':443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $ctx );
			if ( ! $sock ) {
				$this->add(
					'security', 'ssl_cert', 'fail', 'SSL certificate',
					'The SSL certificate could not be verified (it may be expired, self-signed or issued for another domain).',
					'Browsers show a full-page security warning, which stops almost every visitor.',
					'Renew or reissue the certificate for this exact domain and enable auto-renewal.', 3
				);
			} else {
				$params = stream_context_get_params( $sock );
				$cert   = isset( $params['options']['ssl']['peer_certificate'] ) ? openssl_x509_parse( $params['options']['ssl']['peer_certificate'] ) : false;
				fclose( $sock );
				if ( $cert && ! empty( $cert['validTo_time_t'] ) ) {
					$days   = (int) floor( ( $cert['validTo_time_t'] - time() ) / DAY_IN_SECONDS );
					$issuer = isset( $cert['issuer']['O'] ) ? $cert['issuer']['O'] : 'a certificate authority';
					if ( $days < 14 ) {
						$this->add(
							'security', 'ssl_cert', 'warn', 'SSL certificate',
							sprintf( 'Your certificate from %s expires in %d days.', $issuer, $days ),
							'If it lapses, visitors get a full-page security warning.',
							'Confirm auto-renewal is active with your host or Cloudflare.', 3
						);
					} else {
						$this->add( 'security', 'ssl_cert', 'pass', 'SSL certificate', sprintf( 'Valid certificate from %s, %d days until renewal.', $issuer, $days ), '', '', 3 );
					}
				}
			}
		}

		// Security headers.
		$h       = $this->headers;
		$csp     = isset( $h['content-security-policy'] ) ? $h['content-security-policy'] : '';
		$wanted  = array(
			'Strict-Transport-Security' => isset( $h['strict-transport-security'] ),
			'X-Content-Type-Options'    => isset( $h['x-content-type-options'] ),
			'X-Frame-Options'           => isset( $h['x-frame-options'] ) || false !== stripos( $csp, 'frame-ancestors' ),
			'Content-Security-Policy'   => '' !== $csp,
			'Referrer-Policy'           => isset( $h['referrer-policy'] ),
		);
		$present = array_keys( array_filter( $wanted ) );
		$missing = array_keys( array_diff_key( $wanted, array_filter( $wanted ) ) );
		$n       = count( $present );
		$status  = $n >= 4 ? 'pass' : ( $n >= 2 ? 'warn' : 'fail' );
		$this->add(
			'security', 'headers', $status, 'Security headers',
			'pass' === $status ? sprintf( '%d of 5 recommended security headers are set.', $n ) : sprintf( '%d of 5 recommended security headers are set. Missing: %s.', $n, implode( ', ', $missing ) ),
			'Without these headers your site is easier to embed in phishing pages, hijack with injected scripts, or downgrade to an insecure connection.',
			'Add the missing headers in your server config, a security plugin, or Cloudflare Transform Rules.', 2
		);

		// Mixed content.
		if ( $is_https ) {
			$mixed = $this->count_nodes( '//script[starts-with(@src,"http://")]|//img[starts-with(@src,"http://")]|//iframe[starts-with(@src,"http://")]|//link[' . self::lc( '@rel' ) . '="stylesheet" and starts-with(@href,"http://")]' );
			if ( $mixed > 0 ) {
				$this->add(
					'security', 'mixed', 'fail', 'Mixed content',
					sprintf( '%d file(s) on the page still load over insecure http://.', $mixed ),
					'Browsers block or flag insecure files on secure pages, which breaks images, scripts or the padlock icon.',
					'Update those file links to https:// (a search-and-replace on the database usually fixes it).', 2
				);
			} else {
				$this->add( 'security', 'mixed', 'pass', 'Mixed content', 'All images, scripts and styles load securely.', '', '', 2 );
			}
		}

		// Version disclosure.
		$leaks     = array();
		$generator = $this->attr( '//meta[' . self::lc( '@name' ) . '="generator"]', 'content' );
		if ( $generator && preg_match( '/\d+\.\d+/', $generator ) && preg_match( '/wordpress|joomla|drupal/i', $generator ) ) {
			$leaks[] = $generator;
		}
		if ( isset( $h['x-powered-by'] ) && preg_match( '/\d+\.\d+/', $h['x-powered-by'] ) ) {
			$leaks[] = 'X-Powered-By: ' . $h['x-powered-by'];
		}
		if ( $leaks ) {
			$this->add(
				'security', 'versions', 'warn', 'Software versions exposed',
				'Your site publicly reveals software versions: ' . implode( '; ', $leaks ) . '.',
				'Attackers scan for exact versions with known vulnerabilities, so this makes your site an easier target.',
				'Hide the generator tag and X-Powered-By header, and keep core, themes and plugins updated.', 1
			);
		} else {
			$this->add( 'security', 'versions', 'pass', 'Software versions exposed', 'No CMS or server version numbers are publicly exposed.', '', '', 1 );
		}
	}

	/* ---------------------------------------------------------------------
	 * SEO
	 * ------------------------------------------------------------------- */

	protected function check_seo() {
		// Title.
		$title = $this->text( '//head/title' );
		if ( '' === $title ) {
			$title = $this->text( '//title' );
		}
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( $title ) : strlen( $title );
		if ( '' === $title ) {
			$this->add( 'seo', 'title', 'fail', 'Page title', 'Your homepage has no title tag.', 'The title is the blue headline people click in Google. Without it, Google invents one and fewer people click.', 'Add a unique title of 50 to 60 characters that names your service and location.', 3 );
		} elseif ( $len < 30 || $len > 65 ) {
			$this->add( 'seo', 'title', 'warn', 'Page title', sprintf( 'Your title is %d characters: "%s". The ideal range is 30 to 65.', $len, $this->clip( $title, 90 ) ), $len > 65 ? 'Google cuts off long titles, hiding your key message.' : 'A short title wastes space you could use for keywords people search for.', 'Rewrite the title to 50 to 60 characters with your main service first.', 3 );
		} else {
			$this->add( 'seo', 'title', 'pass', 'Page title', sprintf( 'Good length (%d characters): "%s".', $len, $this->clip( $title, 90 ) ), '', '', 3 );
		}

		// Meta description.
		$desc = $this->attr( '//meta[' . self::lc( '@name' ) . '="description"]', 'content' );
		$dlen = function_exists( 'mb_strlen' ) ? mb_strlen( $desc ) : strlen( $desc );
		if ( '' === $desc ) {
			$this->add( 'seo', 'description', 'fail', 'Meta description', 'There is no meta description.', 'This is the sales text under your link in Google. Without it, Google shows random page text and fewer people click.', 'Write a 120 to 155 character description with a clear benefit and call to action.', 2 );
		} elseif ( $dlen < 70 || $dlen > 160 ) {
			$this->add( 'seo', 'description', 'warn', 'Meta description', sprintf( 'Your description is %d characters. The ideal range is 70 to 160.', $dlen ), 'Descriptions outside this range get cut off or replaced by Google.', 'Rewrite it to around 150 characters with a clear benefit.', 2 );
		} else {
			$this->add( 'seo', 'description', 'pass', 'Meta description', sprintf( 'Good length (%d characters).', $dlen ), '', '', 2 );
		}

		// H1.
		$h1 = $this->count_nodes( '//h1' );
		if ( 0 === $h1 ) {
			$this->add( 'seo', 'h1', 'fail', 'Main heading (H1)', 'Your homepage has no H1 heading.', 'The H1 tells Google and visitors what the page is about. Missing it weakens rankings for your main service.', 'Mark your main headline as an H1 and include your core service in it.', 2 );
		} elseif ( $h1 > 1 ) {
			$this->add( 'seo', 'h1', 'warn', 'Main heading (H1)', sprintf( 'Your homepage has %d H1 headings. One is recommended.', $h1 ), 'Several H1s dilute the main topic of the page for search engines.', 'Keep one H1 for the main headline and change the others to H2 or H3.', 2 );
		} else {
			$this->add( 'seo', 'h1', 'pass', 'Main heading (H1)', 'One clear H1: "' . $this->clip( $this->text( '//h1' ), 80 ) . '".', '', '', 2 );
		}

		// Subheadings.
		$h2 = $this->count_nodes( '//h2' );
		if ( 0 === $h2 ) {
			$this->add( 'seo', 'h2', 'warn', 'Content structure', 'No H2 subheadings were found.', 'Subheadings help Google understand each section and help visitors scan the page.', 'Break the page into sections with descriptive H2 subheadings.', 1 );
		} else {
			$this->add( 'seo', 'h2', 'pass', 'Content structure', sprintf( '%d H2 subheadings organise the page.', $h2 ), '', '', 1 );
		}

		// Indexability.
		$robots_meta = strtolower( $this->attr( '//meta[' . self::lc( '@name' ) . '="robots"]', 'content' ) );
		$x_robots    = isset( $this->headers['x-robots-tag'] ) ? strtolower( $this->headers['x-robots-tag'] ) : '';
		if ( false !== strpos( $robots_meta, 'noindex' ) || false !== strpos( $x_robots, 'noindex' ) ) {
			$this->add( 'seo', 'index', 'fail', 'Search engine indexing', 'Your homepage tells search engines not to index it (noindex).', 'Google will remove this page from search results, so nobody can find you there.', 'Remove the noindex setting (in WordPress: Settings > Reading, and your SEO plugin).', 4 );
		} else {
			$this->add( 'seo', 'index', 'pass', 'Search engine indexing', 'Search engines are allowed to index your homepage.', '', '', 4 );
		}

		// Canonical.
		if ( $this->attr( '//link[' . self::lc( '@rel' ) . '="canonical"]', 'href' ) ) {
			$this->add( 'seo', 'canonical', 'pass', 'Canonical URL', 'A canonical URL is set to prevent duplicate content.', '', '', 1 );
		} else {
			$this->add( 'seo', 'canonical', 'warn', 'Canonical URL', 'No canonical URL is set.', 'Google may treat versions of the same page as duplicates and split your ranking power.', 'Set a canonical link tag (any SEO plugin such as Rank Math or Yoast does this).', 1 );
		}

		// Language.
		if ( $this->attr( '//html', 'lang' ) ) {
			$this->add( 'seo', 'lang', 'pass', 'Language declared', 'The page language is declared (' . $this->attr( '//html', 'lang' ) . ').', '', '', 1 );
		} else {
			$this->add( 'seo', 'lang', 'warn', 'Language declared', 'The page language is not declared.', 'Search engines and screen readers may misread your content or show it to the wrong audience.', 'Add a lang attribute to the html tag, for example lang="en".', 1 );
		}

		// Structured data.
		$jsonld = $this->count_nodes( '//script[' . self::lc( '@type' ) . '="application/ld+json"]' );
		if ( $jsonld > 0 || $this->count_nodes( '//*[@itemtype]' ) > 0 ) {
			$this->add( 'seo', 'schema', 'pass', 'Structured data (schema)', 'Structured data is present, helping Google and AI assistants understand your business.', '', '', 2 );
		} else {
			$this->add( 'seo', 'schema', 'warn', 'Structured data (schema)', 'No structured data was found.', 'Schema powers rich results (stars, FAQs, business info) and helps AI tools like ChatGPT and Google AI Mode describe your business correctly.', 'Add Organization or LocalBusiness schema, plus FAQ schema where relevant.', 2 );
		}

		// Social sharing.
		$og_title = $this->attr( '//meta[@property="og:title"]', 'content' );
		$og_image = $this->attr( '//meta[@property="og:image"]', 'content' );
		if ( $og_title && $og_image ) {
			$this->add( 'seo', 'og', 'pass', 'Social sharing preview', 'Open Graph title and image are set, so links look good on WhatsApp, LinkedIn and Facebook.', '', '', 1 );
		} else {
			$this->add( 'seo', 'og', $og_title || $og_image ? 'warn' : 'fail', 'Social sharing preview', $og_title || $og_image ? 'Open Graph tags are incomplete (missing ' . ( $og_title ? 'image' : 'title' ) . ').' : 'No Open Graph tags were found.', 'When someone shares your link on WhatsApp, LinkedIn or Facebook, it shows a blank or random preview that few people click.', 'Set og:title, og:description and a 1200x630 og:image.', 1 );
		}

		// Image alt text.
		$imgs = $this->count_nodes( '//img' );
		if ( $imgs > 0 ) {
			$no_alt = $this->count_nodes( '//img[not(@alt) or normalize-space(@alt)=""]' );
			$ratio  = $no_alt / $imgs;
			$status = $ratio <= 0.1 ? 'pass' : ( $ratio <= 0.35 ? 'warn' : 'fail' );
			$this->add(
				'seo', 'alt', $status, 'Image alt text',
				'pass' === $status ? sprintf( '%d of %d images have alt text.', $imgs - $no_alt, $imgs ) : sprintf( '%d of %d images are missing alt text.', $no_alt, $imgs ),
				'Alt text lets your images appear in Google Images and makes the site usable for people with screen readers.',
				'Add short, descriptive alt text to every meaningful image in the media library.', 2
			);
		}

		// Content depth.
		$words = str_word_count( strip_tags( $this->visible_text() ) );
		if ( $words < 250 ) {
			$this->add( 'seo', 'content', 'warn', 'Amount of content', sprintf( 'Your homepage has about %d words of text.', $words ), 'Thin pages give Google little to rank and give visitors little reason to trust you.', 'Expand the page with your services, process, proof and FAQs (aim for 600+ words).', 1 );
		} else {
			$this->add( 'seo', 'content', 'pass', 'Amount of content', sprintf( 'About %d words of content on the homepage.', $words ), '', '', 1 );
		}

		// robots.txt and sitemap.
		$base    = $this->base_url();
		$robots  = $this->request( $base . '/robots.txt', 'GET', 10 );
		$sitemap = '';
		if ( 200 === $robots['status'] && false === stripos( $robots['body'], '<html' ) ) {
			if ( preg_match( '/^\s*sitemap:\s*(\S+)/im', $robots['body'], $m ) ) {
				$sitemap = $m[1];
			}
			if ( self::robots_blocks_all( $robots['body'] ) ) {
				$this->add( 'seo', 'robots', 'fail', 'robots.txt', 'robots.txt blocks search engines from the entire site.', 'Google cannot crawl your pages, so they will not rank.', 'Remove the "Disallow: /" rule for all user agents from robots.txt.', 3 );
			} else {
				$this->add( 'seo', 'robots', 'pass', 'robots.txt', 'robots.txt is present and allows crawling.', '', '', 1 );
			}
		} else {
			$this->add( 'seo', 'robots', 'warn', 'robots.txt', 'No robots.txt file was found.', 'Search engines get no guidance on what to crawl or where your sitemap is.', 'Create a robots.txt that allows crawling and links to your sitemap.', 1 );
		}

		$candidates = array_filter( array( $sitemap, $base . '/sitemap.xml', $base . '/sitemap_index.xml', $base . '/wp-sitemap.xml' ) );
		$found      = false;
		foreach ( array_unique( $candidates ) as $candidate ) {
			$r = $this->request( $candidate, 'GET', 10 );
			if ( 200 === $r['status'] && preg_match( '/<(urlset|sitemapindex)/i', $r['body'] ) ) {
				$found = $candidate;
				break;
			}
		}
		if ( $found ) {
			$this->add( 'seo', 'sitemap', 'pass', 'XML sitemap', 'An XML sitemap was found, so Google can discover all your pages.', '', '', 2 );
		} else {
			$this->add( 'seo', 'sitemap', 'warn', 'XML sitemap', 'No XML sitemap was found.', 'New pages and blog posts take longer to show up in Google, or never do.', 'Generate a sitemap (built into WordPress and SEO plugins) and submit it in Google Search Console.', 2 );
		}
	}

	/* ---------------------------------------------------------------------
	 * Speed (server-side, before Lighthouse)
	 * ------------------------------------------------------------------- */

	protected function check_speed_server() {
		$t = $this->time;
		if ( $t <= 0.8 ) {
			$this->add( 'speed', 'response', 'pass', 'Server response time', sprintf( 'Your homepage HTML downloaded in %.2f seconds.', $t ), '', '', 2 );
		} else {
			$this->add( 'speed', 'response', $t <= 1.8 ? 'warn' : 'fail', 'Server response time', sprintf( 'Your homepage HTML took %.2f seconds to download, before any images or scripts.', $t ), 'A slow server delays everything else. Every extra second of load time loses a noticeable share of visitors.', 'Enable page caching, use a faster host, and put the site behind a CDN such as Cloudflare.', 2 );
		}

		$enc = isset( $this->headers['content-encoding'] ) ? strtolower( $this->headers['content-encoding'] ) : '';
		if ( preg_match( '/gzip|br|deflate|zstd/', $enc ) ) {
			$this->add( 'speed', 'compression', 'pass', 'Text compression', 'Pages are compressed (' . $enc . ') before sending.', '', '', 2 );
		} else {
			$this->add( 'speed', 'compression', 'fail', 'Text compression', 'Pages are sent without Gzip or Brotli compression.', 'Uncompressed pages are often 3 to 5 times larger, which is especially slow on mobile data.', 'Turn on Gzip or Brotli in your hosting panel, caching plugin or Cloudflare.', 2 );
		}

		$kb = strlen( $this->html ) / 1024;
		if ( $kb <= 150 ) {
			$this->add( 'speed', 'html_size', 'pass', 'Page code size', sprintf( 'The HTML is %d KB.', $kb ), '', '', 1 );
		} else {
			$this->add( 'speed', 'html_size', $kb <= 400 ? 'warn' : 'fail', 'Page code size', sprintf( 'The HTML alone is %d KB, which is heavy.', $kb ), 'Bloated page code (common with page builders) takes longer to download and process on phones.', 'Remove unused sections and widgets, and avoid inline CSS and SVG where possible.', 1 );
		}

		$scripts = $this->count_nodes( '//script[@src]' );
		$styles  = $this->count_nodes( '//link[' . self::lc( '@rel' ) . '="stylesheet"]' );
		$files   = $scripts + $styles;
		if ( $files <= 20 ) {
			$this->add( 'speed', 'requests', 'pass', 'Script and style files', sprintf( '%d JavaScript and %d CSS files load on the homepage.', $scripts, $styles ), '', '', 2 );
		} else {
			$this->add( 'speed', 'requests', $files <= 40 ? 'warn' : 'fail', 'Script and style files', sprintf( '%d JavaScript and %d CSS files load on the homepage.', $scripts, $styles ), 'Every file is a separate download. Too many plugins and add-ons slow the page and hurt Core Web Vitals.', 'Remove unused plugins, and combine and defer files with a performance plugin.', 2 );
		}

		$blocking = $this->count_nodes( '//head/script[@src and not(@async) and not(@defer) and not(' . self::lc( '@type' ) . '="module")]' );
		if ( $blocking <= 2 ) {
			$this->add( 'speed', 'blocking', 'pass', 'Render-blocking scripts', sprintf( '%d script(s) block the page from rendering.', $blocking ), '', '', 1 );
		} else {
			$this->add( 'speed', 'blocking', $blocking <= 6 ? 'warn' : 'fail', 'Render-blocking scripts', sprintf( '%d scripts in the page head block the page from appearing.', $blocking ), 'Visitors stare at a blank screen while these scripts load.', 'Add defer or async to non-critical scripts, or delay them until user interaction.', 1 );
		}

		$imgs = $this->count_nodes( '//img' );
		if ( $imgs > 4 ) {
			$lazy = $this->count_nodes( '//img[' . self::lc( '@loading' ) . '="lazy" or @data-src or @data-lazy-src or contains(@class,"lazy")]' );
			if ( 0 === $lazy ) {
				$this->add( 'speed', 'lazy', 'warn', 'Image lazy loading', sprintf( 'None of the %d images use lazy loading.', $imgs ), 'All images download at once, even ones far down the page that visitors may never see.', 'Enable lazy loading for below-the-fold images.', 1 );
			} else {
				$this->add( 'speed', 'lazy', 'pass', 'Image lazy loading', sprintf( '%d of %d images are lazy loaded.', $lazy, $imgs ), '', '', 1 );
			}
		}
	}

	/* ---------------------------------------------------------------------
	 * Mobile
	 * ------------------------------------------------------------------- */

	protected function check_mobile() {
		$viewport = strtolower( $this->attr( '//meta[' . self::lc( '@name' ) . '="viewport"]', 'content' ) );
		if ( false !== strpos( $viewport, 'width=device-width' ) ) {
			$this->add( 'mobile', 'viewport', 'pass', 'Mobile-friendly layout', 'The page is set up to adapt to phone screens.', '', '', 3 );
		} else {
			$this->add( 'mobile', 'viewport', 'fail', 'Mobile-friendly layout', 'No mobile viewport is set, so phones show a shrunken desktop page.', 'Most visitors browse on phones. A tiny, zoomed-out page makes them leave, and Google ranks mobile-first.', 'Add <meta name="viewport" content="width=device-width, initial-scale=1"> and use a responsive theme.', 3 );
		}

		if ( preg_match( '/user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*1(\.0)?\b/', $viewport ) ) {
			$this->add( 'mobile', 'zoom', 'warn', 'Pinch to zoom', 'Zooming is disabled on mobile.', 'People with low vision cannot enlarge text, which is an accessibility failure.', 'Remove user-scalable=no and maximum-scale=1 from the viewport tag.', 1 );
		}

		$icon = $this->count_nodes( '//link[contains(' . self::lc( '@rel' ) . ',"icon")]' );
		if ( ! $icon ) {
			$fav  = $this->request( $this->base_url() . '/favicon.ico', 'GET', 8 );
			$icon = 200 === $fav['status'] && strlen( $fav['body'] ) > 0;
		}
		if ( $icon ) {
			$this->add( 'mobile', 'favicon', 'pass', 'Site icon', 'A site icon (favicon) is set for browser tabs and home screens.', '', '', 1 );
		} else {
			$this->add( 'mobile', 'favicon', 'warn', 'Site icon', 'No site icon (favicon) was found.', 'Your tab and bookmarks show a generic icon, which looks unfinished and less trustworthy.', 'Upload a square site icon under Appearance > Customize > Site Identity.', 1 );
		}
	}

	/* ---------------------------------------------------------------------
	 * Conversion (the agency angle)
	 * ------------------------------------------------------------------- */

	protected function check_conversion() {
		$h = $this->html;

		$has_form = $this->count_nodes( '//form[.//input[' . self::lc( '@type' ) . '="email"] or .//textarea]' ) > 0
			|| preg_match( '/wpcf7|wpforms|gform_wrapper|elementor-form|hs-form|hbspt\.forms|embed\.typeform\.com|form\.typeform\.com|assets\.calendly\.com|calendly\.com\/[a-z0-9_-]+|fluentform|ninja-forms|jotform\.com|tally\.so\/(?:embed|r)\//i', $h );
		if ( $has_form ) {
			$this->add( 'conversion', 'form', 'pass', 'Lead capture form', 'Visitors can contact you or book directly from the homepage.', '', '', 3 );
		} else {
			$this->add( 'conversion', 'form', 'fail', 'Lead capture form', 'No contact form, quote form or booking widget was found on the homepage.', 'Interested visitors have to hunt for a way to reach you. Most will not bother, so ready buyers leave without a trace.', 'Add a short form (name, email, one question) or a booking widget above the fold and again near the bottom.', 3 );
		}

		$cta_re = '/\b(contact|get (a|your|started|in touch)|quote|book|schedule|call( us| now)?|consult|free (audit|trial|estimate)|demo|sign ?up|start (a|your|now)|hire|enquire|inquire|request|talk to|let\'?s talk|shop now|buy now|order)\b/i';
		$ctas   = 0;
		foreach ( $this->nodes( '//a|//button|//input[@type="submit"]' ) as $node ) {
			$label = $node->textContent . ' ' . $node->getAttribute( 'value' ) . ' ' . $node->getAttribute( 'aria-label' );
			if ( preg_match( $cta_re, $label ) ) {
				$ctas++;
			}
		}
		if ( $ctas >= 3 ) {
			$this->add( 'conversion', 'cta', 'pass', 'Calls to action', sprintf( '%d clear calls to action (like "Contact" or "Get a quote") guide visitors.', $ctas ), '', '', 3 );
		} else {
			$this->add( 'conversion', 'cta', $ctas ? 'warn' : 'fail', 'Calls to action', $ctas ? sprintf( 'Only %d clear call to action was found.', $ctas ) : 'No clear call-to-action buttons were found.', 'Visitors need to be told what to do next. Pages without clear buttons convert far fewer visitors into enquiries.', 'Add action-focused buttons ("Get a free quote", "Book a call") in the hero, mid-page and footer.', 3 );
		}

		if ( $this->count_nodes( '//a[starts-with(' . self::lc( '@href' ) . ',"tel:")]' ) ) {
			$this->add( 'conversion', 'phone', 'pass', 'Tap-to-call phone link', 'Mobile visitors can call you with one tap.', '', '', 2 );
		} else {
			$this->add( 'conversion', 'phone', 'warn', 'Tap-to-call phone link', 'No tap-to-call phone link was found.', 'High-intent mobile visitors often prefer to call. Without a clickable number, many will not copy it by hand.', 'Add your phone number as a tel: link in the header and contact section.', 2 );
		}

		if ( preg_match( '/wa\.me\/|api\.whatsapp\.com|whatsapp:\/\/|embed\.tawk\.to|client\.crisp\.chat|widget\.intercom\.io|js\.driftt\.com|cdn\.livechatinc\.com|code\.tidio\.co|static\.zdassets\.com|js\.hs-scripts\.com|wchat\.freshchat\.com|call\.chatra\.io|smartsuppchat\.com|customerchat|m\.me\//i', $h ) ) {
			$this->add( 'conversion', 'chat', 'pass', 'Instant contact (WhatsApp or chat)', 'Visitors can reach you instantly via WhatsApp or live chat.', '', '', 1 );
		} else {
			$this->add( 'conversion', 'chat', 'warn', 'Instant contact (WhatsApp or chat)', 'No WhatsApp button or live chat was found.', 'Many visitors will not fill in a form but will send a quick message. Instant chat captures leads that would otherwise leave.', 'Add a WhatsApp click-to-chat button or a free live chat tool.', 1 );
		}

		$text = $this->visible_text();
		if ( preg_match( '/testimonial|review|rated|trustpilot|clients say|what (our )?(clients|customers) say|case stud|\bstars?\b|★|trusted by|google reviews|clutch/i', $text ) ) {
			$this->add( 'conversion', 'proof', 'pass', 'Social proof', 'The page shows trust signals such as reviews, testimonials or case studies.', '', '', 2 );
		} else {
			$this->add( 'conversion', 'proof', 'warn', 'Social proof', 'No testimonials, reviews or case studies were found on the homepage.', 'People rarely contact a business they cannot verify. Real reviews are one of the strongest drivers of enquiries.', 'Add 3 to 5 named testimonials, Google review stars or short case studies.', 2 );
		}

		if ( preg_match( '/googletagmanager\.com|google-analytics\.com|gtag\(|fbq\(|connect\.facebook\.net|clarity\.ms|static\.hotjar\.com|plausible\.io\/js|matomo\.js|posthog\.com|cdn\.segment\.com|analytics\.tiktok\.com|googlesitekit|cdn\.usefathom\.com|umami\.is|data-website-id|snap\.licdn\.com/i', $h ) ) {
			$this->add( 'conversion', 'analytics', 'pass', 'Visitor and lead tracking', 'Analytics or ad tracking is installed, so you can measure visitors and leads.', '', '', 2 );
		} else {
			$this->add( 'conversion', 'analytics', 'fail', 'Visitor and lead tracking', 'No common analytics tool (Google Analytics, Tag Manager, Meta Pixel, Microsoft Clarity, Hotjar) was detected.', 'You cannot see how many people visit, where they come from, or which pages bring leads, so marketing spend is guesswork.', 'Install Google Analytics 4 (via Site Kit or Tag Manager) and set up form-submission conversions.', 2 );
		}

		if ( $this->count_nodes( '//a[contains(' . self::lc( '@href' ) . ',"privacy") or contains(' . self::lc( '.' ) . ',"privacy")]' ) ) {
			$this->add( 'conversion', 'privacy', 'pass', 'Privacy policy', 'A privacy policy is linked, which builds trust when people share details.', '', '', 1 );
		} else {
			$this->add( 'conversion', 'privacy', 'warn', 'Privacy policy', 'No privacy policy link was found.', 'Visitors are more hesitant to submit details, and collecting data without a policy can breach GDPR and other privacy laws.', 'Publish a privacy policy and link it in the footer and next to your forms.', 1 );
		}
	}

	/* ---------------------------------------------------------------------
	 * Step 2: Google PageSpeed Insights (Lighthouse, mobile)
	 * ------------------------------------------------------------------- */

	/**
	 * @return array { checks: array, meta: array, error?: string }
	 */
	public function run_psi( $api_key = '', $url = null ) {
		$target   = $url ? $url : $this->url;
		$endpoint = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . rawurlencode( $target ) . '&strategy=mobile&category=performance&category=accessibility&category=best-practices&category=seo';
		if ( $api_key ) {
			$endpoint .= '&key=' . rawurlencode( $api_key );
		}

		$res = $this->request( $endpoint, 'GET', 90 );
		if ( ! $res['ok'] || 200 !== $res['status'] ) {
			$msg  = 'Google PageSpeed test could not run.';
			$body = json_decode( $res['body'], true );
			if ( ! empty( $body['error']['message'] ) ) {
				$msg .= ' ' . $body['error']['message'];
			} elseif ( $res['error'] ) {
				$msg .= ' ' . $res['error'];
			}
			return array( 'checks' => array(), 'meta' => array(), 'error' => $msg );
		}

		$data = json_decode( $res['body'], true );
		if ( empty( $data['lighthouseResult'] ) ) {
			return array( 'checks' => array(), 'meta' => array(), 'error' => 'Google PageSpeed returned no data.' );
		}
		$lh     = $data['lighthouseResult'];
		$audits = isset( $lh['audits'] ) ? $lh['audits'] : array();
		$cats   = isset( $lh['categories'] ) ? $lh['categories'] : array();
		$score  = function ( $key ) use ( $cats ) {
			return isset( $cats[ $key ]['score'] ) ? (int) round( $cats[ $key ]['score'] * 100 ) : null;
		};
		$num    = function ( $key ) use ( $audits ) {
			return isset( $audits[ $key ]['numericValue'] ) ? (float) $audits[ $key ]['numericValue'] : null;
		};

		$this->checks = array();
		$perf         = $score( 'performance' );
		$lcp          = $num( 'largest-contentful-paint' );
		$cls          = $num( 'cumulative-layout-shift' );
		$tbt          = $num( 'total-blocking-time' );
		$fcp          = $num( 'first-contentful-paint' );
		$si           = $num( 'speed-index' );

		if ( null !== $perf ) {
			$st = $perf >= 90 ? 'pass' : ( $perf >= 50 ? 'warn' : 'fail' );
			$this->add( 'speed', 'psi_perf', $st, 'Google mobile performance score', sprintf( 'Google Lighthouse scores your mobile performance %d out of 100.', $perf ), 'This is the same test Google uses to judge page experience. Low scores mean slow loading on phones, fewer enquiries and weaker rankings.', 'Compress and resize images (WebP/AVIF), remove unused plugins and scripts, and use caching plus a CDN.', 5 );
		}
		if ( null !== $lcp ) {
			$s = $lcp / 1000;
			$this->add( 'speed', 'lcp', $s <= 2.5 ? 'pass' : ( $s <= 4 ? 'warn' : 'fail' ), 'Largest Contentful Paint (main content visible)', sprintf( 'Your main content appears after %.1f seconds on mobile. Google\'s target is 2.5 seconds or less.', $s ), 'This is when visitors feel the page has loaded. Past 3 seconds, a large share of mobile visitors give up.', 'Optimise the hero image (preload it, serve WebP, correct size) and reduce server response time.', 3 );
		}
		if ( null !== $cls ) {
			$this->add( 'speed', 'cls', $cls <= 0.1 ? 'pass' : ( $cls <= 0.25 ? 'warn' : 'fail' ), 'Cumulative Layout Shift (visual stability)', sprintf( 'Layout shift score is %.2f. Google\'s target is 0.1 or less.', $cls ), 'Content that jumps while loading causes mis-taps and makes the site feel broken.', 'Set width and height on images and embeds, and reserve space for banners and fonts.', 2 );
		}
		if ( null !== $tbt ) {
			$this->add( 'speed', 'tbt', $tbt <= 200 ? 'pass' : ( $tbt <= 600 ? 'warn' : 'fail' ), 'Total Blocking Time (responsiveness)', sprintf( 'The page is frozen for %d ms while scripts run. The target is 200 ms or less.', $tbt ), 'Buttons and menus do not respond while the browser is busy, so visitors think the site is broken.', 'Delay or remove heavy third-party scripts (chat, sliders, trackers) and unused JavaScript.', 2 );
		}
		if ( null !== $fcp ) {
			$s = $fcp / 1000;
			$this->add( 'speed', 'fcp', $s <= 1.8 ? 'pass' : ( $s <= 3 ? 'warn' : 'fail' ), 'First Contentful Paint', sprintf( 'Something first appears on screen after %.1f seconds. The target is 1.8 seconds or less.', $s ), 'A long blank screen makes visitors hit the back button.', 'Inline critical CSS, defer non-essential scripts and enable caching.', 1 );
		}

		$a11y = $score( 'accessibility' );
		if ( null !== $a11y ) {
			$this->add( 'mobile', 'psi_a11y', $a11y >= 90 ? 'pass' : ( $a11y >= 70 ? 'warn' : 'fail' ), 'Accessibility score', sprintf( 'Google Lighthouse scores accessibility %d out of 100.', $a11y ), 'Poor contrast, missing labels and small tap targets make the site hard to use for many people and can create legal risk.', 'Fix colour contrast, add labels to form fields and buttons, and enlarge small tap targets.', 3 );
		}
		$bp = $score( 'best-practices' );
		if ( null !== $bp ) {
			$this->add( 'security', 'psi_bp', $bp >= 90 ? 'pass' : ( $bp >= 70 ? 'warn' : 'fail' ), 'Web best practices', sprintf( 'Google Lighthouse scores best practices %d out of 100.', $bp ), 'This covers browser errors, outdated libraries and insecure code that erode reliability and trust.', 'Fix console errors, update outdated JavaScript libraries and serve images at the correct size.', 1 );
		}
		$seo = $score( 'seo' );
		if ( null !== $seo ) {
			$this->add( 'seo', 'psi_seo', $seo >= 90 ? 'pass' : ( $seo >= 70 ? 'warn' : 'fail' ), 'Google technical SEO score', sprintf( 'Google Lighthouse scores technical SEO %d out of 100.', $seo ), 'Technical SEO problems stop Google from properly crawling and understanding your page.', 'Review crawlability, link text, tap target and structured data issues flagged by Lighthouse.', 2 );
		}

		// Biggest opportunities from Lighthouse.
		$opps = array();
		foreach ( $audits as $audit ) {
			if ( isset( $audit['details']['type'] ) && 'opportunity' === $audit['details']['type'] && isset( $audit['score'] ) && $audit['score'] < 0.9 && ! empty( $audit['details']['overallSavingsMs'] ) ) {
				$opps[] = array(
					'title'   => $audit['title'],
					'savings' => round( $audit['details']['overallSavingsMs'] / 1000, 1 ),
				);
			}
		}
		usort( $opps, function ( $a, $b ) {
			return $b['savings'] <=> $a['savings'];
		} );

		$field = null;
		if ( ! empty( $data['loadingExperience']['overall_category'] ) && empty( $data['loadingExperience']['origin_fallback'] ) ) {
			$field = $data['loadingExperience']['overall_category'];
		}

		$screenshot = '';
		if ( ! empty( $audits['final-screenshot']['details']['data'] ) ) {
			$screenshot = $audits['final-screenshot']['details']['data']; // data:image/jpeg;base64,...
		}

		return array(
			'checks' => $this->checks,
			'meta'   => array(
				'psi' => array(
					'performance'    => $perf,
					'accessibility'  => $a11y,
					'best_practices' => $bp,
					'seo'            => $seo,
					'lcp'            => $lcp,
					'cls'            => $cls,
					'tbt'            => $tbt,
					'fcp'            => $fcp,
					'si'             => $si,
					'field'          => $field,
					'opportunities'  => array_slice( $opps, 0, 5 ),
				),
				'screenshot' => $screenshot,
			),
		);
	}

	/* ---------------------------------------------------------------------
	 * Scoring
	 * ------------------------------------------------------------------- */

	public static function score( array $checks ) {
		$factor = array( 'pass' => 1, 'warn' => 0.5, 'fail' => 0 );
		$cats   = array();
		foreach ( self::CATEGORIES as $key => $cfg ) {
			$cats[ $key ] = array( 'label' => $cfg['label'], 'score' => null, 'pass' => 0, 'warn' => 0, 'fail' => 0, 'w' => 0, 'got' => 0 );
		}
		foreach ( $checks as $c ) {
			if ( ! isset( $cats[ $c['category'] ], $factor[ $c['status'] ] ) ) {
				continue;
			}
			$cats[ $c['category'] ][ $c['status'] ]++;
			$cats[ $c['category'] ]['w']   += $c['weight'];
			$cats[ $c['category'] ]['got'] += $c['weight'] * $factor[ $c['status'] ];
		}

		$total_w = 0;
		$total   = 0;
		foreach ( $cats as $key => &$cat ) {
			if ( $cat['w'] > 0 ) {
				$cat['score'] = (int) round( $cat['got'] / $cat['w'] * 100 );
				$total       += $cat['score'] * self::CATEGORIES[ $key ]['weight'];
				$total_w     += self::CATEGORIES[ $key ]['weight'];
			}
			unset( $cat['w'], $cat['got'] );
		}
		unset( $cat );

		$overall = $total_w ? (int) round( $total / $total_w ) : 0;
		$grade   = $overall >= 90 ? 'A' : ( $overall >= 80 ? 'B' : ( $overall >= 70 ? 'C' : ( $overall >= 55 ? 'D' : 'F' ) ) );

		// Priorities: failures first, heaviest weight first.
		$issues = array_values( array_filter( $checks, function ( $c ) {
			return in_array( $c['status'], array( 'fail', 'warn' ), true );
		} ) );
		usort( $issues, function ( $a, $b ) {
			$rank = array( 'fail' => 0, 'warn' => 1 );
			return array( $rank[ $a['status'] ], -$a['weight'] ) <=> array( $rank[ $b['status'] ], -$b['weight'] );
		} );

		$counts = array( 'pass' => 0, 'warn' => 0, 'fail' => 0 );
		foreach ( $checks as $c ) {
			if ( isset( $counts[ $c['status'] ] ) ) {
				$counts[ $c['status'] ]++;
			}
		}

		return array(
			'overall'    => $overall,
			'grade'      => $grade,
			'categories' => $cats,
			'priorities' => array_slice( $issues, 0, 5 ),
			'counts'     => $counts,
		);
	}

	/** True when the "User-agent: *" group contains "Disallow: /". */
	public static function robots_blocks_all( $body ) {
		$agents   = array();
		$in_rules = false;
		foreach ( preg_split( '/\r\n|\r|\n/', $body ) as $line ) {
			$line = trim( preg_replace( '/#.*/', '', $line ) );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $field, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$field                 = strtolower( $field );
			if ( 'user-agent' === $field ) {
				if ( $in_rules ) {
					$agents   = array();
					$in_rules = false;
				}
				$agents[] = $value;
			} elseif ( in_array( $field, array( 'disallow', 'allow' ), true ) ) {
				$in_rules = true;
				if ( 'disallow' === $field && '/' === $value && in_array( '*', $agents, true ) ) {
					return true;
				}
			}
		}
		return false;
	}

	protected function clip( $s, $n ) {
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $s ) > $n ) {
			return mb_substr( $s, 0, $n - 1 ) . '…';
		}
		return strlen( $s ) > $n ? substr( $s, 0, $n - 1 ) . '...' : $s;
	}
}

if ( ! function_exists( 'wp_parse_url_safe' ) ) {
	function wp_parse_url_safe( $url, $component ) {
		return function_exists( 'wp_parse_url' ) ? wp_parse_url( $url, $component ) : parse_url( $url, $component );
	}
}
