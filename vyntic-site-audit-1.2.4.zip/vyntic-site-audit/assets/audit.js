(function () {
	'use strict';

	if (typeof window.VSA === 'undefined') { return; }
	var cfg = window.VSA;

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		Object.keys(data || {}).forEach(function (k) { body.append(k, data[k]); });
		return fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (res) {
				return res.json().catch(function () {
					throw new Error('The server returned an unexpected response (HTTP ' + res.status + '). Please try again.');
				});
			})
			.then(function (json) {
				if (!json || !json.success) {
					var err = new Error((json && json.data && json.data.message) || 'Something went wrong. Please try again.');
					err.data = (json && json.data) || {};
					throw err;
				}
				return json.data;
			});
	}

	function esc(s) {
		var d = document.createElement('div');
		d.textContent = s == null ? '' : String(s);
		return d.innerHTML;
	}

	function colorFor(score) {
		return score >= 80 ? 'var(--vsa-pass)' : (score >= 55 ? 'var(--vsa-warn)' : 'var(--vsa-fail)');
	}

	function verdict(score) {
		if (score >= 90) { return 'Excellent'; }
		if (score >= 80) { return 'Good, with room to grow'; }
		if (score >= 70) { return 'Fair'; }
		if (score >= 55) { return 'Underperforming'; }
		return 'Losing you customers';
	}

	function init(root) {
		var form = root.querySelector('.vsa-form');
		var btn = form.querySelector('.vsa-btn');
		var errorBox = form.querySelector('.vsa-error');
		var progress = root.querySelector('.vsa-progress');
		var result = root.querySelector('.vsa-result');
		var btnLabel = btn.textContent;
		var question = form.querySelector('.vsa-captcha-q');
		var nonce = null;
		var captchaToken = null;

		function setCaptcha(c) {
			if (!c) { return; }
			captchaToken = c.token;
			question.textContent = c.question;
			form.elements.captcha.value = '';
		}

		/* A fresh nonce and maths question, loaded after the page so page caching never breaks the form. */
		function loadChallenge() {
			return post('vsa_nonce', {}).then(function (d) {
				nonce = d.nonce;
				setCaptcha(d.captcha);
				return d;
			});
		}
		loadChallenge().catch(function () {});

		function showError(msg, field) {
			errorBox.textContent = msg;
			errorBox.hidden = false;
			form.querySelectorAll('[aria-invalid]').forEach(function (el) { el.removeAttribute('aria-invalid'); });
			if (field) {
				field.setAttribute('aria-invalid', 'true');
				field.focus();
			}
		}

		var steps = ['connect', 'security', 'seo', 'conversion', 'speed', 'finish'];
		var meterBar = progress.querySelector('.vsa-meter-bar');
		var meterNum = progress.querySelector('.vsa-meter-num b');
		var meterTime = progress.querySelector('.vsa-meter-time');
		var feedList = progress.querySelector('.vsa-feed ul');
		var techBox = progress.querySelector('.vsa-tech');
		var subLine = progress.querySelector('.vsa-scan-sub');
		var shown = 0, target = 0, cap = 0, rate = 0.03, t0 = 0, clock = null, rotate = null, queue = [];

		function step(name, state, detail) {
			var li = progress.querySelector('[data-step="' + name + '"]');
			if (!li) { return; }
			li.classList.remove('is-active', 'is-done', 'is-skipped', 'is-warn');
			if (state) { li.classList.add('is-' + state); }
			if (detail !== undefined) { li.querySelector('em').textContent = detail; }
		}

		/* The meter moves towards the current phase's ceiling and only reaches it when the phase really ends. */
		function phase(from, to, speed) {
			target = Math.max(target, from);
			cap = to;
			rate = speed || 0.03;
		}
		function tick() {
			var secs = Math.round((Date.now() - t0) / 1000);
			meterTime.textContent = secs + 's elapsed';
			if (target < cap) { target += (cap - target) * rate; }
			shown += (target - shown) * 0.25;
			var v = Math.min(100, Math.round(shown));
			meterNum.textContent = v;
			meterBar.style.strokeDashoffset = (100 - shown).toFixed(2);
		}
		function later(fn, ms) { queue.push(setTimeout(fn, ms)); }
		function stopAll() {
			clearInterval(clock); clearInterval(rotate);
			queue.forEach(clearTimeout); queue = [];
		}

		function feed(item) {
			var li = document.createElement('li');
			li.className = 'is-' + item.status;
			li.innerHTML = '<i></i><span>' + esc(item.title) + '</span><small>' + esc(item.area) + '</small>';
			feedList.insertBefore(li, feedList.firstChild);
			while (feedList.children.length > 6) { feedList.removeChild(feedList.lastChild); }
		}

		function favicon(host) {
			var box = progress.querySelector('.vsa-favicon');
			box.textContent = (host || '?').replace(/^www\./, '').charAt(0).toUpperCase();
			var img = new Image();
			img.alt = '';
			img.onload = function () { if (img.naturalWidth > 16) { box.textContent = ''; box.appendChild(img); } };
			img.src = 'https://www.google.com/s2/favicons?sz=64&domain=' + encodeURIComponent(host);
		}

		function resetToForm(message, field) {
			stopAll();
			progress.hidden = true;
			result.hidden = true;
			form.hidden = false;
			btn.disabled = false;
			btn.textContent = btnLabel;
			steps.forEach(function (s) { step(s, null, ''); });
			feedList.innerHTML = '';
			techBox.hidden = true;
			techBox.innerHTML = '';
			shown = target = cap = 0;
			if (message) { showError(message, field); }
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			errorBox.hidden = true;

			var urlEl = form.elements.website;
			var emailEl = form.elements.email;
			var capEl = form.elements.captcha;
			var site = urlEl.value.trim();

			if (!/^(https?:\/\/)?[^\s\/]+\.[^\s\/]{2,}/i.test(site)) {
				return showError('Enter a valid website address, like yourbusiness.com.', urlEl);
			}
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailEl.value.trim())) {
				return showError('Enter a valid email address. Your report is sent there.', emailEl);
			}
			if (!/^\d{1,3}$/.test(capEl.value.trim())) {
				return showError('Answer the quick maths question.', capEl);
			}

			btn.disabled = true;
			btn.textContent = 'Starting audit...';

			var token;
			var host = site.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');

			(nonce && captchaToken ? Promise.resolve() : loadChallenge())
				.then(function () {
					form.hidden = true;
					progress.hidden = false;
					progress.querySelector('.vsa-progress-site').textContent = host;
					subLine.textContent = 'Connecting…';
					favicon(host);
					t0 = Date.now();
					shown = target = 0;
					phase(2, 34, 0.02);
					clock = setInterval(tick, 100);
					step('connect', 'active', 'Contacting the server');
					later(function () { step('connect', 'active', 'Downloading the page like a real browser'); }, 1500);
					return post('vsa_start', {
						nonce: nonce,
						website: site,
						email: emailEl.value.trim(),
						captcha: capEl.value.trim(),
						captcha_token: captchaToken,
						company_fax: form.elements.company_fax.value,
						source: window.location.href
					});
				})
				.then(function (d) {
					token = d.token;
					queue.forEach(clearTimeout); queue = [];
					progress.querySelector('.vsa-progress-site').textContent = d.host;
					favicon(d.host);
					subLine.textContent = d.title ? d.title : (d.https ? 'Secure connection (HTTPS)' : 'No HTTPS');
					phase(34, 40);

					var A = d.areas || {};
					var said = function (k) { var a = A[k] || { checks: 0, issues: 0 }; return a.checks + ' checks, ' + (a.issues ? a.issues + ' to fix' : 'all passed'); };
					// Reveal the real results step by step, with the findings streaming in.
					step('connect', 'done', d.blocked ? 'Firewall blocked the page scan, Google will test it instead' : ('Loaded in ' + d.time.toFixed(2) + ' s · ' + d.kb + ' KB of HTML'));
					if (d.blocked) { step('connect', 'warn'); }
					var order = [
						['security', function () { return d.blocked ? 'Skipped' : (d.https ? 'HTTPS on · ' : 'No HTTPS · ') + said('security'); }],
						['seo', function () { return d.blocked ? 'Skipped' : said('seo'); }],
						['conversion', function () { return d.blocked ? 'Skipped' : 'Mobile ' + said('mobile') + ' · Leads ' + said('conversion'); }]
					];
					var items = (d.feed || []).slice();
					order.forEach(function (o, i) {
						later(function () { step(o[0], 'active', 'Checking…'); }, i * 650);
						later(function () {
							step(o[0], d.blocked ? 'skipped' : 'done', o[1]());
							items.splice(0, 3).forEach(function (it, j) { later(function () { feed(it); }, j * 180); });
						}, i * 650 + 450);
					});
					if (d.tech && d.tech.length) {
						later(function () {
							techBox.innerHTML = '<span>Built with</span>' + d.tech.map(function (t) { return '<b>' + esc(t) + '</b>'; }).join('');
							techBox.hidden = false;
						}, 900);
					}

					var lh = [
						'Loading your page on a simulated mid-range phone',
						'Measuring when the main content appears (LCP)',
						'Measuring layout shifts while it loads (CLS)',
						'Measuring how long scripts block the page (TBT)',
						'Collecting Google\'s performance score'
					];
					return new Promise(function (resolve) { later(resolve, order.length * 650 + 200); }).then(function () {
						step('speed', 'active', lh[0]);
						phase(42, 90, 0.0035);
						var k = 0;
						rotate = setInterval(function () { k = Math.min(k + 1, lh.length - 1); step('speed', 'active', lh[k]); }, 5500);
						return post('vsa_speed', { nonce: nonce, token: token });
					});
				})
				.then(function (d) {
					clearInterval(rotate);
					if (d.ok) {
						var bits = [];
						if (d.performance !== null) { bits.push('Mobile score ' + d.performance); }
						if (d.lcp !== null && d.lcp !== undefined) { bits.push('LCP ' + (d.lcp / 1000).toFixed(1) + ' s'); }
						if (d.cls !== null && d.cls !== undefined) { bits.push('CLS ' + Number(d.cls).toFixed(2)); }
						if (d.tbt !== null && d.tbt !== undefined) { bits.push('TBT ' + Math.round(d.tbt) + ' ms'); }
						step('speed', 'done', bits.join(' · '));
					} else {
						step('speed', 'skipped', 'Google\'s test was busy, using our server checks');
					}
					step('finish', 'active', 'Scoring 5 areas and writing your fixes');
					phase(91, 98, 0.03);
					return post('vsa_finish', { nonce: nonce, token: token });
				})
				.then(function (d) {
					step('finish', 'done', d.emailed ? 'Sent to ' + d.email : 'Ready');
					phase(100, 100);
					target = 100;
					setTimeout(function () { stopAll(); renderResult(d); }, 700);
				})
				.catch(function (err) {
					var data = err.data || {};
					captchaToken = null;
					resetToForm(err.message, data.field ? form.elements[data.field] : null);
					if (data.captcha) {
						setCaptcha(data.captcha);
					} else {
						loadChallenge().catch(function () {});
					}
				});
		});

		function renderResult(d) {
			var C = 2 * Math.PI * 62;
			var bars = d.categories.map(function (c) {
				return '<div class="vsa-bar"><span>' + esc(c.label) + '</span>' +
					'<div class="vsa-bar-track"><div class="vsa-bar-fill" data-w="' + c.score + '" style="background:' + colorFor(c.score) + '"></div></div>' +
					'<b>' + c.score + '</b></div>';
			}).join('');

			var issues = d.priorities.length ? '<div class="vsa-issues"><h3>Fix these first</h3><ol>' + d.priorities.map(function (p) {
				return '<li style="--vsa-issue:' + (p.status === 'fail' ? 'var(--vsa-fail)' : 'var(--vsa-warn)') + '"><div><strong>' + esc(p.title) + '</strong><span>' + esc(p.finding) + '</span></div></li>';
			}).join('') + '</ol></div>' : '';

			var actions = '';
			if (d.download) { actions += '<a class="vsa-btn" href="' + esc(d.download) + '">Download full PDF report</a>'; }
			if (cfg.booking) { actions += '<a class="' + (d.download ? 'vsa-btn-ghost' : 'vsa-btn') + '" href="' + esc(cfg.booking) + '">Book a free call to fix these</a>'; }

			var note = d.emailed
				? 'We also emailed the full report to ' + esc(d.email) + '. Check your spam folder if it does not arrive in a few minutes.'
				: (cfg.sendEmail && !d.download ? 'Your report is being prepared. If it does not arrive, contact us and we will send it manually.' : '');
			if (d.psiError) {
				note += (note ? ' ' : '') + 'Google\'s speed test was busy, so speed results are based on our server checks only.';
			}

			result.innerHTML =
				'<div class="vsa-result-head">' +
					'<div class="vsa-ring" role="img" aria-label="Overall score ' + d.overall + ' out of 100">' +
						'<svg viewBox="0 0 148 148"><circle class="vsa-ring-track" cx="74" cy="74" r="62"></circle>' +
						'<circle class="vsa-ring-bar" cx="74" cy="74" r="62" stroke="' + colorFor(d.overall) + '" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + C.toFixed(1) + '"></circle></svg>' +
						'<div class="vsa-ring-num">' + d.overall + '<small>out of 100</small></div>' +
					'</div>' +
					'<div>' +
						'<p class="vsa-result-host">' + esc(d.host) + '</p>' +
						'<p class="vsa-result-grade">Grade ' + esc(d.grade) + ': ' + verdict(d.overall) + '</p>' +
						'<ul class="vsa-counts">' +
							'<li><i style="background:var(--vsa-fail)"></i>' + d.counts.fail + ' critical</li>' +
							'<li><i style="background:var(--vsa-warn)"></i>' + d.counts.warn + ' need work</li>' +
							'<li><i style="background:var(--vsa-pass)"></i>' + d.counts.pass + ' passed</li>' +
						'</ul>' +
					'</div>' +
				'</div>' +
				'<div class="vsa-bars">' + bars + '</div>' +
				issues +
				(actions ? '<div class="vsa-result-actions">' + actions + '</div>' : '') +
				(note ? '<p class="vsa-result-note">' + note + '</p>' : '') +
				'<button type="button" class="vsa-link">Audit another website</button>';

			progress.hidden = true;
			result.hidden = false;
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });

			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					var ring = result.querySelector('.vsa-ring-bar');
					ring.style.strokeDashoffset = (C * (1 - d.overall / 100)).toFixed(1);
					result.querySelectorAll('.vsa-bar-fill').forEach(function (el) { el.style.width = el.getAttribute('data-w') + '%'; });
				});
			});

			result.querySelector('.vsa-link').addEventListener('click', function () {
				form.elements.website.value = '';
				resetToForm();
				loadChallenge().catch(function () {});
			});
		}
	}

	function boot() {
		document.querySelectorAll('.vsa').forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
