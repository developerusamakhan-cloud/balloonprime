<?php
/**
 * Admin: dashboard, settings, actions and the "Google" column in post lists.
 *
 * Every button, tab, filter and the settings form work over AJAX. The same
 * actions still work as normal form posts when JavaScript is off.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI.
 */
class SIA_Admin {

	/**
	 * Admin page slug (one page, with tabs).
	 */
	const SLUG = 'vyntic-index-assistant';

	/**
	 * Actions a button can run.
	 */
	const ACTIONS = array( 'run', 'test', 'resume', 'requested', 'recheck', 'recheck_all' );

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'post_columns' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( self::ACTIONS as $action ) {
			add_action( 'admin_post_sia_' . $action, array( __CLASS__, 'post_action' ) );
		}
		add_action( 'wp_ajax_sia_action', array( __CLASS__, 'ajax_action' ) );
		add_action( 'wp_ajax_sia_view', array( __CLASS__, 'ajax_view' ) );
		add_action( 'wp_ajax_sia_save_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( SIA_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * URL of a tab.
	 *
	 * @param string $tab  dashboard|settings.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function url( $tab = 'dashboard', array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Menu: one item inside the shared "Vyntic" menu.
	 */
	public static function menu() {
		if ( class_exists( 'Vyntic_Client' ) ) {
			add_submenu_page( Vyntic_Client::MENU, __( 'Vyntic Index Assistant', 'vyntic-index-assistant' ), __( 'Index Assistant', 'vyntic-index-assistant' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
			return;
		}
		add_menu_page( __( 'Vyntic Index Assistant', 'vyntic-index-assistant' ), __( 'Index Assistant', 'vyntic-index-assistant' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ), 'dashicons-search', 59 );
	}

	/**
	 * Settings link on the plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url( 'settings' ) ) . '">' . esc_html__( 'Settings', 'vyntic-index-assistant' ) . '</a>' );
		return $links;
	}

	/**
	 * Admin CSS and JS.
	 *
	 * @param string $hook Page hook.
	 */
	public static function assets( $hook ) {
		$ours = false !== strpos( (string) $hook, self::SLUG );
		if ( $ours ) {
			wp_enqueue_style( 'sia-brand', SIA_URL . 'assets/css/vyntic-brand.css', array(), SIA_VERSION );
			wp_enqueue_script( 'sia-admin', SIA_URL . 'assets/js/sia-admin.js', array(), SIA_VERSION, true );
			wp_localize_script(
				'sia-admin',
				'SIA',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'sia_ajax' ),
					'i18n'    => array(
						'working' => __( 'Working...', 'vyntic-index-assistant' ),
						'running' => __( 'Checking pages with Google. This can take up to a minute...', 'vyntic-index-assistant' ),
						'saving'  => __( 'Saving...', 'vyntic-index-assistant' ),
						'failed'  => __( 'Something went wrong. Please reload the page and try again.', 'vyntic-index-assistant' ),
						'expired' => __( 'Your session has expired. Please reload the page and log in again.', 'vyntic-index-assistant' ),
						'close'   => __( 'Dismiss', 'vyntic-index-assistant' ),
					),
				)
			);
		}
		if ( $ours || 'edit.php' === $hook ) {
			wp_enqueue_style( 'sia-admin', SIA_URL . 'assets/css/sia-admin.css', array(), SIA_VERSION );
		}
	}

	/* ---------------------------------------------------------------------
	 * Page shell
	 * ------------------------------------------------------------------- */

	/**
	 * Branded page with Dashboard and Settings tabs.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tabs = array(
			'dashboard' => __( 'Dashboard', 'vyntic-index-assistant' ),
			'settings'  => __( 'Settings', 'vyntic-index-assistant' ),
		);
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view arguments.
		$tab  = isset( $_GET['tab'] ) && 'settings' === $_GET['tab'] ? 'settings' : 'dashboard';
		$args = self::view_args( $_GET );
		// phpcs:enable
		$title = __( 'Vyntic Index Assistant', 'vyntic-index-assistant' );
		?>
		<div class="wrap vy-wrap sia-app" data-tab="<?php echo esc_attr( $tab ); ?>">
			<div class="vy-header">
				<div class="vy-brand">
					<span class="vy-logo" aria-hidden="true"><svg viewBox="0 0 108 108" focusable="false"><polygon points="2,12 30,12 62,96 34,96" fill="#ffffff"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>
					<div class="vy-brand-text">
						<p class="vy-title" aria-hidden="true"><?php echo esc_html( $title ); ?></p>
						<p class="vy-tagline"><?php esc_html_e( 'Find what Google has not indexed, see why, and fix it the safe way.', 'vyntic-index-assistant' ); ?>
							<span class="vy-by"><?php esc_html_e( 'by', 'vyntic-index-assistant' ); ?> <a href="https://vyntic.studio/" target="_blank" rel="noopener">Vyntic Studio</a></span></p>
					</div>
				</div>
				<div class="vy-header-actions">
					<a class="vy-link" href="https://vyntic.studio/plugins/safe-index-assistant/" target="_blank" rel="noopener"><?php esc_html_e( 'Guide', 'vyntic-index-assistant' ); ?> &#8599;</a>
					<a class="vy-link" href="https://search.google.com/search-console" target="_blank" rel="noopener"><?php esc_html_e( 'Search Console', 'vyntic-index-assistant' ); ?> &#8599;</a>
					<a class="vy-link" href="https://vyntic.studio/" target="_blank" rel="noopener">vyntic.studio &#8599;</a>
				</div>
			</div>
			<?php
			// The page heading sits below the banner on purpose. WordPress and other plugins place
			// their notices after the first heading or after .wp-header-end, so both now land here
			// instead of inside the banner.
			?>
			<h1 class="screen-reader-text"><?php echo esc_html( $title ); ?></h1>
			<hr class="wp-header-end">
			<nav class="vy-tabs" aria-label="<?php esc_attr_e( 'Index Assistant sections', 'vyntic-index-assistant' ); ?>">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="vy-tab <?php echo $key === $tab ? 'is-active' : ''; ?>" data-sia-tab="<?php echo esc_attr( $key ); ?>" href="<?php echo esc_url( self::url( $key ) ); ?>"<?php echo $key === $tab ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<?php if ( class_exists( 'Vyntic_Client' ) && method_exists( 'Vyntic_Client', 'updates_link' ) ) : ?>
					<?php $vy_upd = Vyntic_Client::updates_link( self::SLUG ); ?>
					<a class="vy-tab vy-tab--updates" href="<?php echo esc_url( $vy_upd['url'] ); ?>"><?php echo esc_html( $vy_upd['label'] ); ?><?php if ( $vy_upd['count'] ) : ?> <span class="vy-tab-count"><?php echo (int) $vy_upd['count']; ?></span><?php endif; ?></a>
				<?php endif; ?>
			</nav>
			<div class="vy-body sia-body" id="sia-body">
				<?php echo self::view_html( $tab, $args ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the views. ?>
			</div>
			<div class="vy-footer">
				<span><?php esc_html_e( 'Pages still not indexed? Vyntic Studio fixes the content, links and technical issues that hold them back.', 'vyntic-index-assistant' ); ?></span>
				<span><a href="https://vyntic.studio/services/seo-services/" target="_blank" rel="noopener"><?php esc_html_e( 'SEO services', 'vyntic-index-assistant' ); ?></a> · <a href="https://vyntic.studio/plugins/" target="_blank" rel="noopener"><?php esc_html_e( 'More free plugins', 'vyntic-index-assistant' ); ?></a></span>
			</div>
			<div class="sia-toasts" role="status" aria-live="polite"></div>
		</div>
		<?php
	}

	/**
	 * Dashboard filter and page number from a request array.
	 *
	 * @param array $src $_GET or $_POST.
	 * @return array{status:string,paged:int}
	 */
	private static function view_args( $src ) {
		$valid  = array( 'not_indexed', 'error', 'pending', 'indexed', 'excluded', 'all' );
		$status = isset( $src['status'] ) ? sanitize_key( wp_unslash( $src['status'] ) ) : 'not_indexed';
		return array(
			'status' => in_array( $status, $valid, true ) ? $status : 'not_indexed',
			'paged'  => isset( $src['paged'] ) ? max( 1, absint( $src['paged'] ) ) : 1,
		);
	}

	/**
	 * HTML of one tab.
	 *
	 * @param string $tab    dashboard|settings.
	 * @param array  $args   View arguments.
	 * @param array  $notice Optional message shown at the top (no-JS fallback).
	 * @return string
	 */
	private static function view_html( $tab, array $args, $notice = null ) {
		ob_start();
		if ( 'settings' === $tab ) {
			self::settings_view();
		} else {
			self::dashboard_view( $args, $notice );
		}
		return (string) ob_get_clean();
	}

	/**
	 * Inline alert inside the page body. Not a WordPress .notice, so nothing moves it around.
	 *
	 * @param string $type    success|warning|error|info.
	 * @param string $html    Message, already escaped.
	 * @param string $actions Extra HTML (buttons), already escaped.
	 */
	private static function alert( $type, $html, $actions = '' ) {
		printf(
			'<div class="sia-alert sia-alert--%1$s"><span class="sia-alert__icon" aria-hidden="true"></span><div class="sia-alert__text">%2$s</div>%3$s</div>',
			esc_attr( $type ),
			$html, // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by the caller.
			$actions ? '<div class="sia-alert__actions">' . $actions . '</div>' : '' // phpcs:ignore WordPress.Security.EscapeOutput -- escaped by the caller.
		);
	}

	/* ---------------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------------- */

	/**
	 * Settings API registration.
	 */
	public static function register_settings() {
		register_setting(
			'sia_settings_group',
			SIA_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => SIA_Settings::defaults(),
			)
		);
	}

	/**
	 * Sanitize settings and handle the service account key field.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- options.php or the AJAX handler checks the nonce.
		if ( ! empty( $_POST['sia_remove_credentials'] ) ) {
			delete_option( SIA_Settings::CREDENTIALS_OPTION );
		}
		$raw = isset( $_POST['sia_credentials'] ) ? trim( wp_unslash( $_POST['sia_credentials'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON key, validated below.
		// phpcs:enable
		if ( '' !== $raw ) {
			$json = SIA_Settings::validate_credentials( $raw );
			if ( is_wp_error( $json ) ) {
				add_settings_error( SIA_Settings::OPTION, 'sia_credentials', $json->get_error_message() );
			} else {
				update_option( SIA_Settings::CREDENTIALS_OPTION, $json, false );
				SIA_Quota::resume();
			}
		}
		return SIA_Settings::sanitize( $input );
	}

	/**
	 * Settings tab.
	 */
	private static function settings_view() {
		$s     = SIA_Settings::all();
		$creds = SIA_Settings::credentials();
		$name  = SIA_Settings::OPTION;
		$types = get_post_types( array( 'public' => true ), 'objects' );
		unset( $types['attachment'] );
		foreach ( get_settings_errors( SIA_Settings::OPTION ) as $error ) {
			self::alert( 'error' === $error['type'] ? 'error' : 'success', esc_html( $error['message'] ) );
		}
		?>
		<form method="post" action="options.php" class="sia-settings" id="sia-settings-form">
			<?php settings_fields( 'sia_settings_group' ); ?>

			<section class="sia-panel">
				<header class="sia-panel__head">
					<h2><span class="sia-step">1</span><?php esc_html_e( 'Connect Google Search Console', 'vyntic-index-assistant' ); ?></h2>
					<?php if ( $creds || defined( 'SIA_SERVICE_ACCOUNT_JSON' ) ) : ?>
						<span class="sia-badge sia-good"><?php esc_html_e( 'Connected', 'vyntic-index-assistant' ); ?></span>
					<?php else : ?>
						<span class="sia-badge sia-warn"><?php esc_html_e( 'Not connected', 'vyntic-index-assistant' ); ?></span>
					<?php endif; ?>
				</header>
				<ol class="sia-steps">
					<li><?php echo wp_kses_post( __( 'In <a href="https://console.cloud.google.com/" target="_blank" rel="noopener">Google Cloud Console</a> create a project and enable the <strong>Google Search Console API</strong>.', 'vyntic-index-assistant' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'IAM &amp; Admin → Service Accounts → Create service account → Keys → Add key → <strong>JSON</strong>. Paste the file contents below.', 'vyntic-index-assistant' ) ); ?></li>
					<li><?php echo wp_kses_post( __( 'In <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> → Settings → Users and permissions → Add user: the service account email, permission <strong>Full</strong>.', 'vyntic-index-assistant' ) ); ?></li>
				</ol>
				<div class="sia-fields">
					<div class="sia-field">
						<label for="sia_credentials"><?php esc_html_e( 'Service account key (JSON)', 'vyntic-index-assistant' ); ?></label>
						<?php if ( defined( 'SIA_SERVICE_ACCOUNT_JSON' ) ) : ?>
							<p class="sia-ok"><?php esc_html_e( 'Set in wp-config.php (SIA_SERVICE_ACCOUNT_JSON).', 'vyntic-index-assistant' ); ?></p>
						<?php else : ?>
							<?php if ( $creds ) : ?>
								<p class="sia-ok"><?php echo esc_html( sprintf( /* translators: %s: email */ __( 'Saved: %s', 'vyntic-index-assistant' ), $creds['client_email'] ) ); ?></p>
								<label class="sia-check"><input type="checkbox" name="sia_remove_credentials" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-index-assistant' ); ?></label>
							<?php endif; ?>
							<textarea id="sia_credentials" name="sia_credentials" rows="5" class="large-text code" autocomplete="off" spellcheck="false" placeholder="<?php echo esc_attr( $creds ? __( 'Paste a new key only if you want to replace the saved one.', 'vyntic-index-assistant' ) : '{ "type": "service_account", ... }' ); ?>"></textarea>
							<p class="description"><?php esc_html_e( 'Stored in your database (not autoloaded) and never shown again. For extra safety define SIA_SERVICE_ACCOUNT_JSON in wp-config.php instead.', 'vyntic-index-assistant' ); ?></p>
						<?php endif; ?>
					</div>
					<div class="sia-field">
						<label for="sia_property"><?php esc_html_e( 'Search Console property', 'vyntic-index-assistant' ); ?></label>
						<input type="text" id="sia_property" class="regular-text" name="<?php echo esc_attr( $name ); ?>[property]" value="<?php echo esc_attr( $s['property'] ); ?>" placeholder="<?php echo esc_attr( trailingslashit( home_url() ) ); ?>">
						<p class="description"><?php esc_html_e( 'Exactly as in Search Console: "https://example.com/" for a URL-prefix property or "sc-domain:example.com" for a domain property. Empty = this site\'s URL.', 'vyntic-index-assistant' ); ?></p>
					</div>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><span class="sia-step">2</span><?php esc_html_e( 'Daily limits', 'vyntic-index-assistant' ); ?></h2></header>
				<p class="sia-muted">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: hard cap, 2: per run, 3: manual cap */
							__( 'Google allows 2,000 URL checks per day per property. This plugin never does more than %1$d, at most %2$d per 15-minute run with a pause between calls, and suggests at most %3$d manual "Request indexing" clicks per day.', 'vyntic-index-assistant' ),
							SIA_Settings::HARD_DAILY_INSPECTIONS,
							SIA_Settings::HARD_PER_RUN,
							SIA_Settings::HARD_MANUAL_PER_DAY
						)
					);
					?>
				</p>
				<div class="sia-fields sia-fields--grid">
					<?php
					self::number_field( 'daily_limit', __( 'URL checks per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_DAILY_INSPECTIONS, __( 'Recommended: 100 for small sites, up to 500 for large ones. Spread evenly over the day.', 'vyntic-index-assistant' ) );
					self::number_field( 'manual_daily', __( 'Manual requests per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_MANUAL_PER_DAY, __( 'How many URLs appear in "Today\'s request list". Max 10.', 'vyntic-index-assistant' ) );
					self::number_field( 'first_check_days', __( 'Wait before first check (days)', 'vyntic-index-assistant' ), $s, 1, 30, __( 'New posts need a few days before Google finds them; checking earlier wastes quota.', 'vyntic-index-assistant' ) );
					self::number_field( 'recheck_unindexed_days', __( 'Re-check not-indexed pages every (days)', 'vyntic-index-assistant' ), $s, 3, 60, '' );
					self::number_field( 'recheck_indexed_days', __( 'Re-check indexed pages every (days)', 'vyntic-index-assistant' ), $s, 7, 180, '' );
					?>
				</div>
				<div class="sia-field">
					<span class="sia-label"><?php esc_html_e( 'Post types to track', 'vyntic-index-assistant' ); ?></span>
					<div class="sia-chips">
						<?php foreach ( $types as $type ) : ?>
							<label class="sia-chip"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[post_types][]" value="<?php echo esc_attr( $type->name ); ?>" <?php checked( in_array( $type->name, (array) $s['post_types'], true ) ); ?>> <span><?php echo esc_html( $type->labels->name ); ?></span></label>
						<?php endforeach; ?>
					</div>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><span class="sia-step">3</span><?php esc_html_e( 'Sitemap', 'vyntic-index-assistant' ); ?></h2></header>
				<div class="sia-fields">
					<span class="sia-label"><?php esc_html_e( 'Resubmit sitemap', 'vyntic-index-assistant' ); ?></span>
					<label class="sia-check"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[sitemap_auto]" value="1" <?php checked( $s['sitemap_auto'] ); ?>> <?php esc_html_e( 'Submit the sitemap to Google at most once per 24 hours, only when posts were published or updated.', 'vyntic-index-assistant' ); ?></label>
					<div class="sia-field">
						<label for="sia_sitemap_url"><?php esc_html_e( 'Sitemap URL', 'vyntic-index-assistant' ); ?></label>
						<input type="url" id="sia_sitemap_url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[sitemap_url]" value="<?php echo esc_attr( $s['sitemap_url'] ); ?>" placeholder="<?php echo esc_attr( SIA_Settings::sitemap_url() ); ?>">
						<p class="description"><?php esc_html_e( 'Empty = detected automatically (Yoast, Rank Math, SEOPress, AIOSEO or WordPress core).', 'vyntic-index-assistant' ); ?></p>
					</div>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><span class="sia-step">4</span><?php esc_html_e( 'IndexNow (Bing, Yandex, Seznam, Naver)', 'vyntic-index-assistant' ); ?></h2></header>
				<p class="sia-muted"><?php esc_html_e( 'Google does not use IndexNow; this only helps other search engines. Turn it off if your SEO plugin already sends IndexNow pings.', 'vyntic-index-assistant' ); ?></p>
				<div class="sia-fields">
					<span class="sia-label"><?php esc_html_e( 'Enable IndexNow', 'vyntic-index-assistant' ); ?></span>
					<label class="sia-check"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[indexnow_enabled]" value="1" <?php checked( $s['indexnow_enabled'] ); ?>> <?php esc_html_e( 'Notify IndexNow when a post is published or its content changes (each URL max once per 24 hours).', 'vyntic-index-assistant' ); ?></label>
					<?php if ( $s['indexnow_enabled'] ) : ?>
						<p class="description"><?php esc_html_e( 'Key file:', 'vyntic-index-assistant' ); ?> <a href="<?php echo esc_url( SIA_IndexNow::key_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( SIA_IndexNow::key_url() ); ?></a></p>
					<?php endif; ?>
					<div class="sia-fields sia-fields--grid">
						<?php self::number_field( 'indexnow_daily', __( 'IndexNow URLs per day', 'vyntic-index-assistant' ), $s, 1, SIA_Settings::HARD_INDEXNOW_PER_DAY, '' ); ?>
					</div>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><span class="sia-step">5</span><?php esc_html_e( 'Client report', 'vyntic-index-assistant' ); ?></h2></header>
				<p class="sia-muted"><?php esc_html_e( 'Shown at the top of the client report. Leave empty to leave it out.', 'vyntic-index-assistant' ); ?></p>
				<div class="sia-fields sia-fields--grid">
					<div class="sia-field">
						<label for="sia_report_by"><?php esc_html_e( 'Prepared by', 'vyntic-index-assistant' ); ?></label>
						<input type="text" id="sia_report_by" class="regular-text" maxlength="120" name="<?php echo esc_attr( $name ); ?>[report_by]" value="<?php echo esc_attr( $s['report_by'] ); ?>" placeholder="<?php esc_attr_e( 'Your agency or name', 'vyntic-index-assistant' ); ?>">
					</div>
					<div class="sia-field">
						<label for="sia_report_contact"><?php esc_html_e( 'Contact line', 'vyntic-index-assistant' ); ?></label>
						<input type="text" id="sia_report_contact" class="regular-text" maxlength="120" name="<?php echo esc_attr( $name ); ?>[report_contact]" value="<?php echo esc_attr( $s['report_contact'] ); ?>" placeholder="<?php esc_attr_e( 'Email or website', 'vyntic-index-assistant' ); ?>">
					</div>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><span class="sia-step">6</span><?php esc_html_e( 'Other', 'vyntic-index-assistant' ); ?></h2></header>
				<div class="sia-fields">
					<div class="sia-fields sia-fields--grid">
						<?php self::number_field( 'thin_words', __( 'Thin content below (words)', 'vyntic-index-assistant' ), $s, 0, 2000, __( 'Not-indexed pages shorter than this get a "thin content" hint. 0 = off.', 'vyntic-index-assistant' ) ); ?>
					</div>
					<div class="sia-field">
						<span class="sia-label"><?php esc_html_e( 'Delete all data on uninstall', 'vyntic-index-assistant' ); ?></span>
						<label class="sia-check"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'] ); ?>> <?php esc_html_e( 'Remove the table, settings and the saved key when the plugin is deleted.', 'vyntic-index-assistant' ); ?></label>
					</div>
				</div>
			</section>

			<div class="sia-savebar">
				<button type="submit" class="button button-primary button-hero sia-btn"><?php esc_html_e( 'Save settings', 'vyntic-index-assistant' ); ?></button>
				<span class="sia-muted"><?php esc_html_e( 'Changes apply to the next background run.', 'vyntic-index-assistant' ); ?></span>
			</div>
		</form>
		<?php
	}

	/**
	 * Number field.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Label.
	 * @param array  $s     Settings.
	 * @param int    $min   Min.
	 * @param int    $max   Max.
	 * @param string $help  Help text.
	 */
	private static function number_field( $key, $label, $s, $min, $max, $help ) {
		?>
		<div class="sia-field">
			<label for="sia_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="number" id="sia_<?php echo esc_attr( $key ); ?>" class="small-text" name="<?php echo esc_attr( SIA_Settings::OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>">
			<?php if ( $help ) : ?>
				<p class="description"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Dashboard
	 * ------------------------------------------------------------------- */

	/**
	 * Dashboard tab.
	 *
	 * @param array      $args   status and paged.
	 * @param array|null $notice Message to show first (no-JS fallback).
	 */
	private static function dashboard_view( array $args, $notice = null ) {
		$counts = SIA_Urls::counts();
		$pause  = SIA_Quota::pause_info();
		$last   = get_option( 'sia_last_run', array() );
		$map    = get_option( 'sia_sitemap_last', array() );
		$inow   = get_option( SIA_IndexNow::LOG_OPTION, array() );
		$next   = wp_next_scheduled( SIA_Cron::HOOK );

		if ( ! $notice ) {
			// Message from a form post when JavaScript is off.
			$notice = get_transient( 'sia_notice_' . get_current_user_id() );
			if ( $notice ) {
				delete_transient( 'sia_notice_' . get_current_user_id() );
			}
		}
		if ( $notice ) {
			self::alert( $notice['type'], esc_html( $notice['text'] ) );
		}
		self::status_alerts( $pause );
		?>
		<div class="sia-stats">
			<?php
			$cards = array(
				'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
				'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
				'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
				'error'       => __( 'Errors', 'vyntic-index-assistant' ),
				'excluded'    => __( 'Skipped (noindex)', 'vyntic-index-assistant' ),
			);
			foreach ( $cards as $key => $label ) :
				$active = $key === $args['status'];
				?>
				<a class="sia-stat sia-stat--<?php echo esc_attr( $key ); ?><?php echo $active ? ' is-active' : ''; ?>" data-sia-nav href="<?php echo esc_url( self::url( 'dashboard', array( 'status' => $key ) ) . '#sia-all' ); ?>"<?php echo $active ? ' aria-current="true"' : ''; ?>>
					<span class="sia-stat__label"><span class="sia-dot" aria-hidden="true"></span><?php echo esc_html( $label ); ?></span>
					<strong class="sia-stat__num"><?php echo esc_html( number_format_i18n( $counts[ $key ] ) ); ?></strong>
				</a>
			<?php endforeach; ?>
		</div>

		<div class="sia-grid">
			<section class="sia-panel">
				<header class="sia-panel__head">
					<h2><?php esc_html_e( 'Today\'s usage', 'vyntic-index-assistant' ); ?></h2>
					<span class="sia-badge sia-good"><?php esc_html_e( 'Always within limits', 'vyntic-index-assistant' ); ?></span>
				</header>
				<div class="sia-meters">
					<?php
					self::meter( __( 'Google URL checks', 'vyntic-index-assistant' ), 'inspect', __( 'Google allows 2,000 a day', 'vyntic-index-assistant' ) );
					self::meter( __( 'Manual "Request indexing"', 'vyntic-index-assistant' ), 'manual', __( 'Search Console allows about 10 to 12 a day', 'vyntic-index-assistant' ) );
					if ( SIA_IndexNow::enabled() ) {
						self::meter( __( 'IndexNow URLs', 'vyntic-index-assistant' ), 'indexnow', $inow ? sprintf( /* translators: 1: time, 2: count, 3: HTTP code */ __( 'Last: %1$s, %2$d URLs, HTTP %3$d', 'vyntic-index-assistant' ), self::ago( $inow['time'] ), $inow['count'], $inow['code'] ) : '' );
					}
					?>
				</div>
			</section>

			<section class="sia-panel">
				<header class="sia-panel__head"><h2><?php esc_html_e( 'Activity', 'vyntic-index-assistant' ); ?></h2></header>
				<dl class="sia-facts">
					<dt><?php esc_html_e( 'Background runs', 'vyntic-index-assistant' ); ?></dt>
					<dd>
						<?php
						$parts = array();
						if ( $last ) {
							/* translators: 1: time, 2: number */
							$parts[] = sprintf( __( 'Last run %1$s: %2$d checked.', 'vyntic-index-assistant' ), self::ago( $last['time'] ), $last['inspected'] );
							if ( ! empty( $last['stopped'] ) ) {
								$parts[] = rtrim( $last['stopped'], '.' ) . '.';
							}
						}
						if ( $next ) {
							/* translators: %s: time */
							$parts[] = sprintf( __( 'Next run: %s.', 'vyntic-index-assistant' ), self::ago( $next ) );
						}
						echo esc_html( $parts ? implode( ' ', $parts ) : __( 'No run yet.', 'vyntic-index-assistant' ) );
						?>
					</dd>
					<dt><?php esc_html_e( 'Sitemap', 'vyntic-index-assistant' ); ?></dt>
					<dd>
						<?php
						if ( ! SIA_Settings::get( 'sitemap_auto' ) ) {
							esc_html_e( 'Automatic resubmission is off.', 'vyntic-index-assistant' );
						} elseif ( $map ) {
							echo esc_html( $map['message'] . ' (' . self::ago( $map['time'] ) . ')' );
							echo '<br><a class="sia-url" href="' . esc_url( $map['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $map['url'] ) . '</a>';
						} else {
							esc_html_e( 'Not submitted yet. Max once per 24 hours.', 'vyntic-index-assistant' );
						}
						?>
					</dd>
				</dl>
				<div class="sia-buttons">
					<?php self::action_button( 'run', __( 'Run a batch now', 'vyntic-index-assistant' ), 'button-primary' ); ?>
					<?php self::action_button( 'test', __( 'Test Google connection', 'vyntic-index-assistant' ) ); ?>
					<?php self::action_button( 'recheck_all', __( 'Re-check all pages', 'vyntic-index-assistant' ), '', 0, __( 'Check every page with Google again? They are checked a few at a time over the next background runs, within your daily limit.', 'vyntic-index-assistant' ) ); ?>
					<a class="button sia-btn" href="<?php echo esc_url( SIA_Report::url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Client report', 'vyntic-index-assistant' ); ?></a>
					<a class="button sia-btn" href="<?php echo esc_url( SIA_Report::url( 'csv' ) ); ?>"><?php esc_html_e( 'Download CSV', 'vyntic-index-assistant' ); ?></a>
				</div>
				<p class="sia-muted sia-small"><?php esc_html_e( '"Run a batch now" uses the same daily limit as the background runs.', 'vyntic-index-assistant' ); ?></p>
			</section>
		</div>

		<?php self::manual_list(); ?>
		<?php self::all_urls( $args, $counts ); ?>
		<?php
	}

	/**
	 * Connection, visibility and pause alerts at the top of the dashboard.
	 *
	 * @param array $pause Pause info.
	 */
	private static function status_alerts( $pause ) {
		if ( ! SIA_Settings::credentials() ) {
			self::alert(
				'warning',
				esc_html__( 'Google Search Console is not connected yet.', 'vyntic-index-assistant' ),
				sprintf( '<a class="button" data-sia-tab="settings" href="%1$s">%2$s</a>', esc_url( self::url( 'settings' ) ), esc_html__( 'Open Settings', 'vyntic-index-assistant' ) )
			);
		}
		if ( ! get_option( 'blog_public' ) ) {
			self::alert( 'error', esc_html__( 'Settings → Reading → "Discourage search engines from indexing this site" is ON. Google will not index anything until you switch it off.', 'vyntic-index-assistant' ) );
		}
		if ( $pause['until'] > time() ) {
			$text = esc_html( $pause['reason'] ) . ' ' . esc_html(
				/* translators: %s: time */
				sprintf( __( 'Paused until %s.', 'vyntic-index-assistant' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $pause['until'] ) )
			);
			$button = '';
			if ( 'quota' !== $pause['kind'] ) {
				ob_start();
				self::action_button( 'resume', __( 'Resume', 'vyntic-index-assistant' ) );
				$button = (string) ob_get_clean();
			}
			self::alert( 'error', $text, $button );
		}
	}

	/**
	 * Usage meter.
	 *
	 * @param string $label Label.
	 * @param string $type  Counter.
	 * @param string $note  Note.
	 */
	private static function meter( $label, $type, $note ) {
		$used  = SIA_Quota::used( $type );
		$limit = SIA_Quota::limit( $type );
		$pct   = $limit ? min( 100, round( $used / $limit * 100 ) ) : 0;
		$level = $pct >= 90 ? 'high' : ( $pct >= 60 ? 'mid' : 'low' );
		?>
		<div class="sia-meter sia-meter--<?php echo esc_attr( $level ); ?>">
			<div class="sia-meter__top">
				<span class="sia-meter__label"><?php echo esc_html( $label ); ?></span>
				<span class="sia-meter__value"><?php echo esc_html( sprintf( '%s / %s', number_format_i18n( $used ), number_format_i18n( $limit ) ) ); ?></span>
			</div>
			<div class="sia-meter__track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $pct ); ?>" aria-label="<?php echo esc_attr( $label ); ?>"><span style="width:<?php echo esc_attr( $pct ); ?>%"></span></div>
			<?php if ( $note ) : ?>
				<span class="sia-muted sia-small"><?php echo esc_html( $note ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Today's manual "Request indexing" list.
	 */
	private static function manual_list() {
		$remaining = SIA_Quota::remaining( 'manual' );
		$rows      = $remaining > 0 ? SIA_Urls::manual_candidates( $remaining ) : array();
		?>
		<section class="sia-panel">
			<header class="sia-panel__head">
				<h2><?php esc_html_e( 'Today\'s request list', 'vyntic-index-assistant' ); ?></h2>
				<?php if ( $remaining > 0 ) : ?>
					<span class="sia-badge"><?php echo esc_html( sprintf( /* translators: %d: number */ _n( '%d request left today', '%d requests left today', $remaining, 'vyntic-index-assistant' ), $remaining ) ); ?></span>
				<?php endif; ?>
			</header>
			<p class="sia-muted">
				<?php esc_html_e( 'Google has no allowed API for "Request indexing" on normal pages, so this is done by hand: open each page in Search Console, click "Request indexing", then click "Done". Improve the content and internal links first, requesting indexing for a weak page will not help.', 'vyntic-index-assistant' ); ?>
			</p>
			<?php if ( $remaining <= 0 ) : ?>
				<div class="sia-empty sia-empty--done"><?php esc_html_e( 'Done for today. New suggestions tomorrow.', 'vyntic-index-assistant' ); ?></div>
			<?php elseif ( ! $rows ) : ?>
				<div class="sia-empty"><?php esc_html_e( 'Nothing to request right now.', 'vyntic-index-assistant' ); ?></div>
			<?php else : ?>
				<div class="sia-table-wrap">
					<table class="sia-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th>
								<th><?php esc_html_e( 'Why not indexed / what to do', 'vyntic-index-assistant' ); ?></th>
								<th><?php esc_html_e( 'Link to it from', 'vyntic-index-assistant' ); ?></th>
								<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'vyntic-index-assistant' ); ?></span></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $rows as $row ) : ?>
								<tr>
									<td data-label="<?php esc_attr_e( 'Page', 'vyntic-index-assistant' ); ?>"><?php self::page_cell( $row ); ?></td>
									<td data-label="<?php esc_attr_e( 'Why', 'vyntic-index-assistant' ); ?>"><?php self::reason_cell( SIA_Diagnosis::explain( $row ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Link from', 'vyntic-index-assistant' ); ?>">
										<?php
										$sources = SIA_Diagnosis::link_sources( $row );
										if ( $sources ) {
											echo '<ul class="sia-list">';
											foreach ( $sources as $source ) {
												printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( (string) get_edit_post_link( $source ) ), esc_html( get_the_title( $source ) ) );
											}
											echo '</ul>';
										} else {
											echo '<span class="sia-muted">-</span>';
										}
										?>
									</td>
									<td class="sia-actions">
										<a class="button" href="<?php echo esc_url( self::gsc_link( $row ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Search Console', 'vyntic-index-assistant' ); ?> &#8599;</a>
										<?php self::action_button( 'requested', __( 'Done', 'vyntic-index-assistant' ), 'button-primary', $row->id ); ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * All tracked URLs with filter and paging.
	 *
	 * @param array $args   status and paged.
	 * @param array $counts Status counts.
	 */
	private static function all_urls( array $args, array $counts ) {
		$status = $args['status'];
		$data   = SIA_Urls::page( 'all' === $status ? '' : $status, $args['paged'] );
		$pages  = (int) ceil( $data['total'] / 50 );
		$labels = array(
			'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
			'error'       => __( 'Errors', 'vyntic-index-assistant' ),
			'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
			'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
			'excluded'    => __( 'Skipped', 'vyntic-index-assistant' ),
			'all'         => __( 'All', 'vyntic-index-assistant' ),
		);
		?>
		<section class="sia-panel" id="sia-all">
			<header class="sia-panel__head">
				<h2><?php esc_html_e( 'All pages', 'vyntic-index-assistant' ); ?></h2>
			</header>
			<nav class="sia-filters" aria-label="<?php esc_attr_e( 'Filter pages', 'vyntic-index-assistant' ); ?>">
				<?php foreach ( $labels as $key => $label ) : ?>
					<?php $n = 'all' === $key ? $counts['total'] : $counts[ $key ]; ?>
					<a class="sia-filter<?php echo $key === $status ? ' is-active' : ''; ?>" data-sia-nav href="<?php echo esc_url( self::url( 'dashboard', array( 'status' => $key ) ) . '#sia-all' ); ?>"<?php echo $key === $status ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $label ); ?> <span class="sia-filter__count"><?php echo esc_html( number_format_i18n( $n ) ); ?></span></a>
				<?php endforeach; ?>
			</nav>
			<?php if ( ! $data['rows'] ) : ?>
				<div class="sia-empty"><?php esc_html_e( 'Nothing here.', 'vyntic-index-assistant' ); ?></div>
			<?php else : ?>
				<div class="sia-table-wrap">
					<table class="sia-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th>
								<th><?php esc_html_e( 'Status / what to do', 'vyntic-index-assistant' ); ?></th>
								<th><?php esc_html_e( 'Checked', 'vyntic-index-assistant' ); ?></th>
								<th><?php esc_html_e( 'Next check', 'vyntic-index-assistant' ); ?></th>
								<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'vyntic-index-assistant' ); ?></span></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $data['rows'] as $row ) : ?>
								<tr>
									<td data-label="<?php esc_attr_e( 'Page', 'vyntic-index-assistant' ); ?>"><?php self::page_cell( $row ); ?></td>
									<td data-label="<?php esc_attr_e( 'Status', 'vyntic-index-assistant' ); ?>"><?php self::reason_cell( SIA_Diagnosis::explain( $row ) ); ?></td>
									<td data-label="<?php esc_attr_e( 'Checked', 'vyntic-index-assistant' ); ?>" class="sia-nowrap"><?php echo esc_html( $row->inspected_at ? self::ago( strtotime( $row->inspected_at . ' UTC' ) ) : '-' ); ?></td>
									<td data-label="<?php esc_attr_e( 'Next check', 'vyntic-index-assistant' ); ?>" class="sia-nowrap"><?php echo esc_html( 'excluded' === $row->status ? '-' : self::ago( strtotime( $row->next_check_at . ' UTC' ) ) ); ?></td>
									<td class="sia-actions">
										<?php if ( 'excluded' !== $row->status ) : ?>
											<a class="button button-small" href="<?php echo esc_url( self::gsc_link( $row ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Search Console', 'vyntic-index-assistant' ); ?> &#8599;</a>
											<?php self::action_button( 'recheck', __( 'Check next run', 'vyntic-index-assistant' ), 'button-small', $row->id ); ?>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			<?php if ( $pages > 1 ) : ?>
				<div class="sia-pagination">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( array( 'paged' => '%#%', 'status' => $status ), self::url( 'dashboard' ) ) . '#sia-all',
								'format'    => '',
								'current'   => $args['paged'],
								'total'     => $pages,
								'prev_text' => '&lsaquo;',
								'next_text' => '&rsaquo;',
							)
						)
					);
					?>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Title + URL cell.
	 *
	 * @param object $row Row.
	 */
	private static function page_cell( $row ) {
		$title = get_the_title( $row->post_id );
		printf(
			'<strong class="sia-title"><a href="%1$s">%2$s</a></strong><a class="sia-url" href="%3$s" target="_blank" rel="noopener">%4$s</a>',
			esc_url( (string) get_edit_post_link( $row->post_id ) ),
			esc_html( '' !== $title ? $title : __( '(no title)', 'vyntic-index-assistant' ) ),
			esc_url( $row->url ),
			esc_html( $row->url )
		);
	}

	/**
	 * Diagnosis cell.
	 *
	 * @param array $d Diagnosis.
	 */
	private static function reason_cell( $d ) {
		printf( '<span class="sia-badge sia-%1$s">%2$s</span>', esc_attr( $d['level'] ), esc_html( $d['label'] ) );
		if ( $d['advice'] ) {
			echo '<ul class="sia-list">';
			foreach ( $d['advice'] as $line ) {
				echo '<li>' . esc_html( $line ) . '</li>';
			}
			echo '</ul>';
		}
	}

	/**
	 * Search Console URL inspection link for a row.
	 *
	 * @param object $row Row.
	 * @return string
	 */
	private static function gsc_link( $row ) {
		if ( ! empty( $row->inspect_link ) ) {
			return $row->inspect_link;
		}
		return add_query_arg(
			array(
				'resource_id' => rawurlencode( SIA_Settings::property() ),
				'id'          => rawurlencode( $row->url ),
			),
			'https://search.google.com/search-console/inspect'
		);
	}

	/**
	 * Human time difference ("3 hours ago" / "in 10 mins").
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function ago( $timestamp ) {
		$timestamp = (int) $timestamp;
		$diff      = human_time_diff( $timestamp, time() );
		/* translators: %s: time span */
		return $timestamp > time() ? sprintf( __( 'in %s', 'vyntic-index-assistant' ), $diff ) : sprintf( __( '%s ago', 'vyntic-index-assistant' ), $diff );
	}

	/**
	 * Action button. A normal POST form, which the script sends over AJAX instead.
	 *
	 * @param string $action Action suffix.
	 * @param string $label  Label.
	 * @param string $class  Extra CSS class.
	 * @param int    $id      Optional row ID.
	 * @param string $confirm Optional question to confirm first.
	 */
	private static function action_button( $action, $label, $class = '', $id = 0, $confirm = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="sia-inline-form" data-sia-action="<?php echo esc_attr( $action ); ?>"<?php echo $id ? ' data-sia-id="' . esc_attr( $id ) . '"' : ''; ?><?php echo $confirm ? ' data-sia-confirm="' . esc_attr( $confirm ) . '"' : ''; ?>>
			<input type="hidden" name="action" value="sia_<?php echo esc_attr( $action ); ?>">
			<?php if ( $id ) : ?>
				<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
			<?php endif; ?>
			<?php wp_nonce_field( 'sia_' . $action ); ?>
			<button type="submit" class="button sia-btn <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Actions
	 * ------------------------------------------------------------------- */

	/**
	 * Run an action and describe the result.
	 *
	 * @param string $action One of self::ACTIONS.
	 * @param int    $id     Row ID for row actions.
	 * @return array{type:string,text:string}
	 */
	private static function perform( $action, $id ) {
		switch ( $action ) {
			case 'run':
				$s    = SIA_Cron::run();
				$text = sprintf(
					/* translators: 1: checked, 2: added, 3: IndexNow */
					__( 'Checked %1$d URLs, added %2$d new pages, sent %3$d to IndexNow.', 'vyntic-index-assistant' ),
					$s['inspected'],
					$s['synced'],
					$s['indexnow']
				);
				foreach ( array( 'sitemap', 'stopped' ) as $key ) {
					if ( '' !== $s[ $key ] ) {
						$text .= ' ' . $s[ $key ];
					}
				}
				return self::result( '' !== $s['stopped'] && 0 === $s['inspected'] ? 'warning' : 'success', $text );

			case 'test':
				$result = SIA_Google::test_connection();
				if ( is_wp_error( $result ) ) {
					return self::result( 'error', $result->get_error_message() );
				}
				$ok = in_array( $result['permission'], array( 'siteOwner', 'siteFullUser' ), true );
				return self::result(
					$ok ? 'success' : 'warning',
					sprintf(
						/* translators: 1: property, 2: permission */
						__( 'Connected to %1$s (permission: %2$s).', 'vyntic-index-assistant' ),
						$result['property'],
						$result['permission']
					) . ( $ok ? '' : ' ' . __( 'Give the service account "Full" permission so it can also submit the sitemap.', 'vyntic-index-assistant' ) )
				);

			case 'resume':
				SIA_Quota::resume();
				return self::result( 'success', __( 'Resumed.', 'vyntic-index-assistant' ) );

			case 'requested':
				if ( ! SIA_Quota::reserve( 'manual' ) ) {
					return self::result( 'warning', __( 'Today\'s manual request limit is reached. Continue tomorrow.', 'vyntic-index-assistant' ) );
				}
				SIA_Urls::mark_requested( $id );
				return self::result( 'success', __( 'Marked as requested. It will be checked again in 3 days.', 'vyntic-index-assistant' ) );

			case 'recheck':
				SIA_Urls::recheck( $id );
				return self::result( 'success', __( 'Queued for the next run (within the daily limit).', 'vyntic-index-assistant' ) );

			case 'recheck_all':
				$queued = SIA_Urls::recheck_all();
				if ( ! $queued ) {
					return self::result( 'info', __( 'There are no pages to check yet.', 'vyntic-index-assistant' ) );
				}
				$per   = max( 1, SIA_Cron::batch_size() );
				$today = min( $queued, SIA_Quota::remaining( 'inspect' ) );
				$text  = sprintf(
					/* translators: 1: pages queued, 2: pages per run */
					_n( 'Queued %1$d page for a fresh check with Google. Background runs check %2$d pages every 15 minutes.', 'Queued %1$d pages for a fresh check with Google. Background runs check %2$d pages every 15 minutes.', $queued, 'vyntic-index-assistant' ),
					$queued,
					$per
				);
				if ( $today > 0 ) {
					/* translators: %s: time span */
					$text .= ' ' . sprintf( __( 'Today\'s part takes about %s.', 'vyntic-index-assistant' ), human_time_diff( 0, (int) ceil( $today / $per ) * 15 * MINUTE_IN_SECONDS ) );
				}
				if ( $queued > $today ) {
					/* translators: %d: pages left */
					$text .= ' ' . sprintf( __( 'The other %d continue tomorrow because of your daily limit.', 'vyntic-index-assistant' ), $queued - $today );
				}
				$text .= ' ' . __( 'Click "Run a batch now" to check the next pages straight away.', 'vyntic-index-assistant' );
				return self::result( 'success', $text );
		}
		return self::result( 'error', __( 'Unknown action.', 'vyntic-index-assistant' ) );
	}

	/**
	 * Result array.
	 *
	 * @param string $type success|warning|error|info.
	 * @param string $text Message.
	 * @return array
	 */
	private static function result( $type, $text ) {
		return array(
			'type' => $type,
			'text' => $text,
		);
	}

	/**
	 * Form post fallback (JavaScript off): run the action, then go back to the dashboard.
	 */
	public static function post_action() {
		$action = isset( $_POST['action'] ) ? substr( sanitize_key( wp_unslash( $_POST['action'] ) ), 4 ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked next.
		if ( ! in_array( $action, self::ACTIONS, true ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'vyntic-index-assistant' ), 403 );
		}
		check_admin_referer( 'sia_' . $action );
		set_transient( 'sia_notice_' . get_current_user_id(), self::perform( $action, isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 ), MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url( 'dashboard' ) );
		exit;
	}

	/**
	 * Capability and nonce check for AJAX calls.
	 */
	private static function ajax_guard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( self::result( 'error', __( 'Not allowed.', 'vyntic-index-assistant' ) ), 403 );
		}
		if ( ! check_ajax_referer( 'sia_ajax', 'nonce', false ) ) {
			wp_send_json_error( self::result( 'error', __( 'Your session has expired. Please reload the page and log in again.', 'vyntic-index-assistant' ) ), 403 );
		}
	}

	/**
	 * AJAX: run an action and send back the refreshed dashboard.
	 */
	public static function ajax_action() {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in ajax_guard().
		$action = isset( $_POST['sia_action'] ) ? sanitize_key( wp_unslash( $_POST['sia_action'] ) ) : '';
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			wp_send_json_error( self::result( 'error', __( 'Unknown action.', 'vyntic-index-assistant' ) ), 400 );
		}
		$result         = self::perform( $action, isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 );
		$result['html'] = self::view_html( 'dashboard', self::view_args( $_POST ) );
		// phpcs:enable
		wp_send_json_success( $result );
	}

	/**
	 * AJAX: one tab, filter or page of the list.
	 */
	public static function ajax_view() {
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in ajax_guard().
		$tab = isset( $_POST['tab'] ) && 'settings' === $_POST['tab'] ? 'settings' : 'dashboard';
		wp_send_json_success(
			array(
				'tab'  => $tab,
				'html' => self::view_html( $tab, self::view_args( $_POST ) ),
			)
		);
		// phpcs:enable
	}

	/**
	 * AJAX: save the settings form (same checks as options.php).
	 */
	public static function ajax_save_settings() {
		global $wp_settings_errors;
		self::ajax_guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in ajax_guard().
		$value = isset( $_POST[ SIA_Settings::OPTION ] ) && is_array( $_POST[ SIA_Settings::OPTION ] ) ? wp_unslash( $_POST[ SIA_Settings::OPTION ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by the registered callback.
		// phpcs:enable
		update_option( SIA_Settings::OPTION, $value );

		$errors = get_settings_errors( SIA_Settings::OPTION );
		$wp_settings_errors = array(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- shown once, as the toast below.
		$result = $errors
			? self::result( 'error', implode( ' ', wp_list_pluck( $errors, 'message' ) ) )
			: self::result( 'success', __( 'Settings saved.', 'vyntic-index-assistant' ) );
		$result['html'] = self::view_html( 'settings', array() );
		wp_send_json_success( $result );
	}

	/* ---------------------------------------------------------------------
	 * Post list column
	 * ------------------------------------------------------------------- */

	/**
	 * Register the "Google" column for tracked post types.
	 */
	public static function post_columns() {
		foreach ( SIA_Settings::post_types() as $type ) {
			add_filter( "manage_{$type}_posts_columns", array( __CLASS__, 'add_column' ) );
			add_action( "manage_{$type}_posts_custom_column", array( __CLASS__, 'render_column' ), 10, 2 );
		}
	}

	/**
	 * Add the column.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		$columns['sia_index'] = __( 'Google', 'vyntic-index-assistant' );
		return $columns;
	}

	/**
	 * Render the column.
	 *
	 * @param string $column  Column.
	 * @param int    $post_id Post.
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'sia_index' !== $column ) {
			return;
		}
		$row = SIA_Urls::by_post( $post_id );
		if ( ! $row ) {
			echo '-';
			return;
		}
		$d = SIA_Diagnosis::explain( $row );
		printf( '<span class="sia-badge sia-%1$s" title="%2$s">%3$s</span>', esc_attr( $d['level'] ), esc_attr( implode( ' ', $d['advice'] ) ), esc_html( $d['label'] ) );
	}
}
