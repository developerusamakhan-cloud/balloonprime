<?php
/**
 * Client report: a print-ready page (save as PDF from the browser) and a CSV
 * with every tracked URL, its Google index status, the reason and the fix.
 * Everything shown comes from the stored URL Inspection results.
 *
 * @package VynticIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Report output.
 */
class SIA_Report {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_post_sia_report', array( __CLASS__, 'render' ) );
		add_action( 'admin_post_sia_report_csv', array( __CLASS__, 'csv' ) );
	}

	/**
	 * Link to the report (or its CSV).
	 *
	 * @param string $format html|csv.
	 * @return string
	 */
	public static function url( $format = 'html' ) {
		$action = 'csv' === $format ? 'sia_report_csv' : 'sia_report';
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action ), $action );
	}

	/**
	 * Capability and nonce check.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'vyntic-index-assistant' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Every tracked row, not-indexed first.
	 *
	 * @return object[]
	 */
	private static function rows() {
		global $wpdb;
		$table = SIA_Install::table();
		return (array) $wpdb->get_results( "SELECT * FROM {$table} ORDER BY FIELD(status,'not_indexed','error','pending','indexed','excluded'), url ASC" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Rows touched in the last N days for a date column.
	 *
	 * @param string $column Column.
	 * @param int    $days   Days.
	 * @return int
	 */
	private static function count_since( $column, $days ) {
		global $wpdb;
		$table = SIA_Install::table();
		if ( ! in_array( $column, array( 'inspected_at', 'manual_requested_at', 'indexnow_at' ), true ) ) {
			return 0;
		}
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$column} >= %s", SIA_Urls::now( -$days * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * A stored UTC datetime in the site's date format, or a dash.
	 *
	 * @param string|null $gmt UTC datetime.
	 * @return string
	 */
	private static function date( $gmt ) {
		if ( empty( $gmt ) || '0000-00-00 00:00:00' === $gmt ) {
			return '-';
		}
		return wp_date( get_option( 'date_format' ), strtotime( $gmt . ' UTC' ) );
	}

	/**
	 * Page title for a row, or the path when the post is gone.
	 *
	 * @param object $row Row.
	 * @return string
	 */
	private static function title( $row ) {
		$title = get_the_title( (int) $row->post_id );
		if ( '' !== trim( (string) $title ) ) {
			return html_entity_decode( wp_strip_all_tags( $title ), ENT_QUOTES, 'UTF-8' );
		}
		$path = wp_parse_url( $row->url, PHP_URL_PATH );
		return $path ? $path : $row->url;
	}

	/**
	 * Groups rows by status and counts not-indexed reasons.
	 *
	 * @param object[] $rows Rows.
	 * @return array
	 */
	private static function summarize( array $rows ) {
		$groups  = array(
			'not_indexed' => array(),
			'error'       => array(),
			'pending'     => array(),
			'indexed'     => array(),
			'excluded'    => array(),
		);
		$reasons = array();
		foreach ( $rows as $row ) {
			$status = isset( $groups[ $row->status ] ) ? $row->status : 'pending';
			$row->d = SIA_Diagnosis::explain( $row );
			$groups[ $status ][] = $row;
			if ( 'not_indexed' === $status ) {
				$label             = $row->d['label'];
				$reasons[ $label ] = isset( $reasons[ $label ] ) ? $reasons[ $label ] + 1 : 1;
			}
		}
		arsort( $reasons );
		$checked = count( $groups['indexed'] ) + count( $groups['not_indexed'] ) + count( $groups['error'] );
		return array(
			'groups'  => $groups,
			'reasons' => $reasons,
			'checked' => $checked,
			'percent' => $checked ? (int) round( count( $groups['indexed'] ) / $checked * 100 ) : 0,
			'total'   => count( $rows ),
		);
	}

	/**
	 * CSV with every tracked URL.
	 */
	public static function csv() {
		self::guard( 'sia_report_csv' );
		$labels = array(
			'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
			'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
			'error'       => __( 'Check failed', 'vyntic-index-assistant' ),
			'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
			'excluded'    => __( 'Skipped (noindex)', 'vyntic-index-assistant' ),
		);
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$name = sanitize_file_name( 'indexing-report-' . $host . '-' . wp_date( 'Y-m-d' ) . '.csv' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // BOM so Excel reads UTF-8. phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv(
			$out,
			array(
				__( 'Page', 'vyntic-index-assistant' ),
				__( 'URL', 'vyntic-index-assistant' ),
				__( 'Status', 'vyntic-index-assistant' ),
				__( 'Reason', 'vyntic-index-assistant' ),
				__( 'Google coverage state', 'vyntic-index-assistant' ),
				__( 'What to do', 'vyntic-index-assistant' ),
				__( 'Last crawled by Google', 'vyntic-index-assistant' ),
				__( 'Last checked', 'vyntic-index-assistant' ),
				__( 'Words', 'vyntic-index-assistant' ),
				__( 'Internal links to it', 'vyntic-index-assistant' ),
				__( 'Indexing requested', 'vyntic-index-assistant' ),
			)
		);
		foreach ( self::rows() as $row ) {
			$d    = SIA_Diagnosis::explain( $row );
			$cell = static function ( $value ) {
				// Keep spreadsheet apps from running cell text as a formula.
				$value = (string) $value;
				return preg_match( '/^[=+\-@\t\r]/', $value ) ? "'" . $value : $value;
			};
			fputcsv(
				$out,
				array_map(
					$cell,
					array(
						self::title( $row ),
						$row->url,
						isset( $labels[ $row->status ] ) ? $labels[ $row->status ] : $row->status,
						'indexed' === $row->status ? '' : $d['label'],
						$row->coverage_state,
						implode( ' ', $d['advice'] ),
						'-' === self::date( $row->last_crawl ) ? '' : self::date( $row->last_crawl ),
						'-' === self::date( $row->inspected_at ) ? '' : self::date( $row->inspected_at ),
						'indexed' === $row->status ? '' : (int) $row->word_count,
						'indexed' === $row->status ? '' : (int) $row->inbound_links,
						'-' === self::date( $row->manual_requested_at ) ? '' : self::date( $row->manual_requested_at ),
					)
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/**
	 * The report page.
	 */
	public static function render() {
		self::guard( 'sia_report' );
		$s        = self::summarize( self::rows() );
		$g        = $s['groups'];
		$site     = get_bloginfo( 'name' );
		$by       = trim( (string) SIA_Settings::get( 'report_by', '' ) );
		$contact  = trim( (string) SIA_Settings::get( 'report_contact', '' ) );
		$property = SIA_Settings::property();
		$map      = get_option( 'sia_sitemap_last', array() );
		$newest   = '';
		foreach ( array( 'indexed', 'not_indexed', 'error' ) as $key ) {
			foreach ( $g[ $key ] as $row ) {
				if ( $row->inspected_at && $row->inspected_at > $newest ) {
					$newest = $row->inspected_at;
				}
			}
		}
		$tiles = array(
			'indexed'     => __( 'Indexed', 'vyntic-index-assistant' ),
			'not_indexed' => __( 'Not indexed', 'vyntic-index-assistant' ),
			'error'       => __( 'Check failed', 'vyntic-index-assistant' ),
			'pending'     => __( 'Not checked yet', 'vyntic-index-assistant' ),
			'excluded'    => __( 'Skipped (noindex)', 'vyntic-index-assistant' ),
		);
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>
		<?php
		/* translators: %s: site name */
		echo esc_html( sprintf( __( 'Google indexing report: %s', 'vyntic-index-assistant' ), $site ) );
		?>
</title>
<style>
:root{--ink:#0f2b2e;--muted:#4a6266;--line:#d5e0dd;--mist:#eef3f1;--good:#0e9f6a;--warn:#c77c00;--bad:#d6322e;--accent:#c7431f}
*{box-sizing:border-box}
body{margin:0;background:#e9eeec;color:var(--ink);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.bar{position:sticky;top:0;z-index:2;display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;padding:10px 16px;background:var(--ink);color:#fff}
.bar span{opacity:.8}
.bar a,.bar button{display:inline-flex;align-items:center;min-height:36px;padding:0 16px;border:1px solid rgba(255,255,255,.35);border-radius:999px;background:transparent;color:#fff;font:600 13px/1 inherit;text-decoration:none;cursor:pointer}
.bar .primary{background:#fff;border-color:#fff;color:var(--ink)}
.bar div{display:flex;flex-wrap:wrap;gap:8px}
.sheet{max-width:960px;margin:24px auto;padding:40px 44px;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(15,43,46,.08)}
header.top{display:flex;flex-wrap:wrap;justify-content:space-between;gap:16px;padding-bottom:20px;border-bottom:2px solid var(--ink)}
.kicker{margin:0 0 4px;color:var(--accent);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
h1{margin:0;font-size:26px;line-height:1.2}
.site{margin:4px 0 0;color:var(--muted)}
.meta{margin:0;color:var(--muted);font-size:13px;text-align:right}
.meta strong{color:var(--ink)}
h2{margin:32px 0 12px;font-size:17px}
.hero{display:flex;flex-wrap:wrap;align-items:center;gap:24px;margin-top:24px;padding:20px 24px;border-radius:12px;background:var(--mist)}
.ring{--p:0;flex:none;display:grid;place-items:center;width:112px;height:112px;border-radius:50%;background:conic-gradient(var(--good) calc(var(--p)*1%),#d9e4e1 0)}
.ring b{display:grid;place-items:center;width:84px;height:84px;border-radius:50%;background:#fff;font-size:24px}
.hero>div:last-child{flex:1;min-width:220px}
.hero p{margin:0;font-size:16px}
.hero .sub{margin-top:4px;color:var(--muted);font-size:13px}
.tiles{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:16px}
.tile{padding:12px 14px;border:1px solid var(--line);border-radius:10px}
.tile span{display:block;color:var(--muted);font-size:12px}
.tile strong{font-size:22px}
.tile--indexed strong{color:var(--good)}.tile--not_indexed strong{color:var(--warn)}.tile--error strong{color:var(--bad)}
.facts{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.facts div{padding:12px 14px;border-radius:10px;background:var(--mist)}
.facts strong{display:block;font-size:20px}
.facts span{color:var(--muted);font-size:12px}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{background:var(--mist);font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
tr{break-inside:avoid}
th.num,td.num{text-align:right;white-space:nowrap}
td.date{white-space:nowrap}
.wide td:first-child{width:26%}
.wide td:nth-child(2){width:1%}
.scroll{overflow-x:auto}
.url{display:block;color:var(--muted);font-size:12px;word-break:break-all}
.tag{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:600;white-space:nowrap}
.tag--warn{background:#fff4e0;color:#8a5600}.tag--bad{background:#fdebe9;color:#a3241f}.tag--good{background:#e5f6ee;color:#0b6e49}.tag--muted{background:#eef0ef;color:#50575e}
.advice{margin:0;padding-left:16px}
.empty{padding:14px;border:1px dashed var(--line);border-radius:10px;color:var(--muted)}
.note{margin-top:32px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
@media screen and (max-width:760px){.sheet{margin:0;padding:24px 16px;border-radius:0}.scroll table{min-width:560px}.tiles{grid-template-columns:repeat(2,1fr)}.facts{grid-template-columns:repeat(2,1fr)}.meta{text-align:left}table{font-size:12px}}
@media print{@page{size:A4;margin:14mm}body{background:#fff}.bar{display:none}.sheet{max-width:none;margin:0;padding:0;box-shadow:none}.hero,.facts div,th{-webkit-print-color-adjust:exact;print-color-adjust:exact}.ring,.tag{-webkit-print-color-adjust:exact;print-color-adjust:exact}h2{break-after:avoid}.hero,.tiles,.facts,.tile,.facts div{break-inside:avoid}.scroll{overflow:visible}}
</style>
</head>
<body>
<div class="bar">
	<span><?php esc_html_e( 'Client report preview', 'vyntic-index-assistant' ); ?></span>
	<div>
		<a href="<?php echo esc_url( SIA_Admin::url( 'dashboard' ) ); ?>">&larr; <?php esc_html_e( 'Back', 'vyntic-index-assistant' ); ?></a>
		<a href="<?php echo esc_url( self::url( 'csv' ) ); ?>"><?php esc_html_e( 'Download CSV', 'vyntic-index-assistant' ); ?></a>
		<button type="button" class="primary" onclick="window.print()"><?php esc_html_e( 'Print / Save as PDF', 'vyntic-index-assistant' ); ?></button>
	</div>
</div>
<main class="sheet">
	<header class="top">
		<div>
			<p class="kicker"><?php esc_html_e( 'Google indexing report', 'vyntic-index-assistant' ); ?></p>
			<h1><?php echo esc_html( $site ); ?></h1>
			<p class="site"><?php echo esc_html( home_url( '/' ) ); ?></p>
		</div>
		<p class="meta">
			<?php
			/* translators: %s: date */
			echo esc_html( sprintf( __( 'Report date: %s', 'vyntic-index-assistant' ), wp_date( get_option( 'date_format' ) ) ) );
			if ( $by ) {
				echo '<br>';
				/* translators: %s: agency or person */
				echo wp_kses( sprintf( __( 'Prepared by %s', 'vyntic-index-assistant' ), '<strong>' . esc_html( $by ) . '</strong>' ), array( 'strong' => array() ) );
			}
			if ( $contact ) {
				echo '<br>' . esc_html( $contact );
			}
			?>
		</p>
	</header>

	<section class="hero">
		<div class="ring" style="--p:<?php echo (int) $s['percent']; ?>"><b><?php echo (int) $s['percent']; ?>%</b></div>
		<div>
			<?php if ( $s['checked'] ) : ?>
				<p>
					<?php
					/* translators: 1: indexed pages, 2: checked pages */
					echo wp_kses( sprintf( __( '<strong>%1$s of %2$s</strong> checked pages are indexed by Google.', 'vyntic-index-assistant' ), number_format_i18n( count( $g['indexed'] ) ), number_format_i18n( $s['checked'] ) ), array( 'strong' => array() ) );
					?>
				</p>
			<?php else : ?>
				<p><?php esc_html_e( 'No pages have been checked with Google yet.', 'vyntic-index-assistant' ); ?></p>
			<?php endif; ?>
			<p class="sub">
				<?php
				/* translators: %s: number of pages */
				$parts = array( sprintf( _n( '%s page tracked in total.', '%s pages tracked in total.', $s['total'], 'vyntic-index-assistant' ), number_format_i18n( $s['total'] ) ) );
				if ( $newest ) {
					/* translators: %s: date */
					$parts[] = sprintf( __( 'Latest check with Google: %s.', 'vyntic-index-assistant' ), self::date( $newest ) );
				}
				if ( $property ) {
					/* translators: %s: Search Console property */
					$parts[] = sprintf( __( 'Search Console property: %s', 'vyntic-index-assistant' ), $property );
				}
				echo esc_html( implode( ' ', $parts ) );
				?>
			</p>
		</div>
	</section>

	<div class="tiles">
		<?php foreach ( $tiles as $key => $label ) : ?>
			<div class="tile tile--<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( number_format_i18n( count( $g[ $key ] ) ) ); ?></strong></div>
		<?php endforeach; ?>
	</div>

	<h2><?php esc_html_e( 'Why pages are not indexed', 'vyntic-index-assistant' ); ?></h2>
	<?php if ( $s['reasons'] ) : ?>
		<div class="scroll"><table>
			<thead><tr><th><?php esc_html_e( 'Reason', 'vyntic-index-assistant' ); ?></th><th class="num"><?php esc_html_e( 'Pages', 'vyntic-index-assistant' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $s['reasons'] as $label => $n ) : ?>
					<tr><td><?php echo esc_html( $label ); ?></td><td class="num"><?php echo esc_html( number_format_i18n( $n ) ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php else : ?>
		<p class="empty"><?php esc_html_e( 'Every checked page is indexed. Nothing is waiting on a fix.', 'vyntic-index-assistant' ); ?></p>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Work in the last 30 days', 'vyntic-index-assistant' ); ?></h2>
	<div class="facts">
		<div><strong><?php echo esc_html( number_format_i18n( self::count_since( 'inspected_at', 30 ) ) ); ?></strong><span><?php esc_html_e( 'Pages checked with Google', 'vyntic-index-assistant' ); ?></span></div>
		<div><strong><?php echo esc_html( number_format_i18n( self::count_since( 'manual_requested_at', 30 ) ) ); ?></strong><span><?php esc_html_e( 'Indexing requests in Search Console', 'vyntic-index-assistant' ); ?></span></div>
		<div><strong><?php echo esc_html( number_format_i18n( self::count_since( 'indexnow_at', 30 ) ) ); ?></strong><span><?php esc_html_e( 'Pages sent to Bing and others (IndexNow)', 'vyntic-index-assistant' ); ?></span></div>
		<div>
			<strong><?php echo ! empty( $map['time'] ) && ! empty( $map['ok'] ) ? esc_html( wp_date( get_option( 'date_format' ), (int) $map['time'] ) ) : '-'; ?></strong>
			<span><?php esc_html_e( 'Sitemap last submitted to Google', 'vyntic-index-assistant' ); ?></span>
		</div>
	</div>

	<h2>
		<?php
		/* translators: %s: number of pages */
		echo esc_html( sprintf( __( 'Pages not indexed (%s)', 'vyntic-index-assistant' ), number_format_i18n( count( $g['not_indexed'] ) ) ) );
		?>
	</h2>
	<?php if ( $g['not_indexed'] ) : ?>
		<div class="scroll"><table class="wide">
			<thead><tr><th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Reason', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'What to do', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Last crawl', 'vyntic-index-assistant' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $g['not_indexed'] as $row ) : ?>
					<tr>
						<td><?php echo esc_html( self::title( $row ) ); ?><span class="url"><?php echo esc_html( $row->url ); ?></span></td>
						<td><span class="tag tag--<?php echo esc_attr( $row->d['level'] ); ?>"><?php echo esc_html( $row->d['label'] ); ?></span></td>
						<td><ul class="advice"><?php foreach ( $row->d['advice'] as $line ) : ?><li><?php echo esc_html( $line ); ?></li><?php endforeach; ?></ul></td>
						<td class="date"><?php echo esc_html( self::date( $row->last_crawl ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php else : ?>
		<p class="empty"><?php esc_html_e( 'None.', 'vyntic-index-assistant' ); ?></p>
	<?php endif; ?>

	<?php if ( $g['error'] ) : ?>
		<h2>
			<?php
			/* translators: %s: number of pages */
			echo esc_html( sprintf( __( 'Pages Google could not check (%s)', 'vyntic-index-assistant' ), number_format_i18n( count( $g['error'] ) ) ) );
			?>
		</h2>
		<div class="scroll"><table>
			<thead><tr><th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Message', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Checked', 'vyntic-index-assistant' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $g['error'] as $row ) : ?>
					<tr><td><?php echo esc_html( self::title( $row ) ); ?><span class="url"><?php echo esc_html( $row->url ); ?></span></td><td><?php echo esc_html( (string) $row->error ); ?></td><td class="date"><?php echo esc_html( self::date( $row->inspected_at ) ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php endif; ?>

	<h2>
		<?php
		/* translators: %s: number of pages */
		echo esc_html( sprintf( __( 'Indexed pages (%s)', 'vyntic-index-assistant' ), number_format_i18n( count( $g['indexed'] ) ) ) );
		?>
	</h2>
	<?php if ( $g['indexed'] ) : ?>
		<div class="scroll"><table>
			<thead><tr><th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Last crawl', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Checked', 'vyntic-index-assistant' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $g['indexed'] as $row ) : ?>
					<tr><td><?php echo esc_html( self::title( $row ) ); ?><span class="url"><?php echo esc_html( $row->url ); ?></span></td><td class="date"><?php echo esc_html( self::date( $row->last_crawl ) ); ?></td><td class="date"><?php echo esc_html( self::date( $row->inspected_at ) ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php else : ?>
		<p class="empty"><?php esc_html_e( 'None yet.', 'vyntic-index-assistant' ); ?></p>
	<?php endif; ?>

	<?php if ( $g['pending'] || $g['excluded'] ) : ?>
		<h2><?php esc_html_e( 'Not checked', 'vyntic-index-assistant' ); ?></h2>
		<div class="scroll"><table>
			<thead><tr><th><?php esc_html_e( 'Page', 'vyntic-index-assistant' ); ?></th><th><?php esc_html_e( 'Status', 'vyntic-index-assistant' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( array_merge( $g['pending'], $g['excluded'] ) as $row ) : ?>
					<tr><td><?php echo esc_html( self::title( $row ) ); ?><span class="url"><?php echo esc_html( $row->url ); ?></span></td><td><span class="tag tag--muted"><?php echo esc_html( $row->d['label'] ); ?></span></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table></div>
	<?php endif; ?>

	<p class="note">
		<?php esc_html_e( 'Source: Google Search Console URL Inspection API. Each page shows Google\'s answer from the date it was last checked. "Not checked yet" pages are queued and checked a few at a time within Google\'s daily limits. "Skipped (noindex)" pages are set to stay out of search on purpose.', 'vyntic-index-assistant' ); ?>
	</p>
</main>
</body>
</html>
		<?php
		exit;
	}
}
