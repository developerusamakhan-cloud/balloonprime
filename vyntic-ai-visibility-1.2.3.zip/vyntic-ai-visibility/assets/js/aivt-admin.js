/* global jQuery, aivtAdmin */
( function ( $ ) {
	'use strict';

	var i18n = aivtAdmin.i18n;

	function format( str ) {
		var args = Array.prototype.slice.call( arguments, 1 );
		return str.replace( /%(\d+)\$[sd]|%[sd]/g, function ( match, index ) {
			return index ? args[ index - 1 ] : args.shift();
		} );
	}

	function post( action, data ) {
		return $.post( aivtAdmin.ajaxUrl, $.extend( { action: action, nonce: aivtAdmin.nonce }, data || {} ) );
	}

	/* Run checks one request at a time so no single request times out. */
	$( document ).on( 'click', '.aivt-run', function () {
		var $btn = $( this );
		var $progress = $( '.aivt-progress' );
		var $bar = $progress.find( '.aivt-progress-bar span' );
		var $text = $progress.find( '.aivt-progress-text' );
		var promptId = $btn.data( 'prompt' ) || 0;

		$( '.aivt-run' ).prop( 'disabled', true );

		post( 'aivt_jobs', { prompt_id: promptId } ).done( function ( res ) {
			var jobs = res && res.success ? res.data.jobs : [];
			var failed = 0;
			var i = 0;

			if ( ! jobs.length ) {
				window.alert( i18n.noJobs );
				$( '.aivt-run' ).prop( 'disabled', false );
				return;
			}
			if ( ! promptId && ! window.confirm( format( i18n.confirmRun, jobs.length ) ) ) {
				$( '.aivt-run' ).prop( 'disabled', false );
				return;
			}

			$progress.prop( 'hidden', false );
			window.scrollTo( { top: 0, behavior: 'smooth' } );

			( function next() {
				if ( i >= jobs.length ) {
					$bar.css( 'width', '100%' );
					$text.text( format( i18n.done, jobs.length - failed, failed ) );
					window.setTimeout( function () {
						window.location.reload();
					}, 1200 );
					return;
				}
				$text.text( format( i18n.running, i + 1, jobs.length ) );
				$bar.css( 'width', Math.round( ( 100 * i ) / jobs.length ) + '%' );

				post( 'aivt_run_job', jobs[ i ] )
					.done( function ( r ) {
						if ( ! r || ! r.success ) {
							failed++;
							if ( r && r.data && r.data.message && window.console ) {
								window.console.warn( '[AI Visibility]', r.data.message );
							}
						}
					} )
					.fail( function () {
						failed++;
					} )
					.always( function () {
						i++;
						next();
					} );
			} )();
		} ).fail( function () {
			window.alert( i18n.error );
			$( '.aivt-run' ).prop( 'disabled', false );
		} );
	} );

	/* Prompt ideas from AI, appended to the textarea. */
	$( document ).on( 'click', '.aivt-suggest', function () {
		var $btn = $( this ).prop( 'disabled', true );
		var $status = $( '.aivt-suggest-status' ).text( i18n.suggesting );
		var $input = $( '#aivt-prompts-input' );

		post( 'aivt_suggest_prompts' )
			.done( function ( res ) {
				if ( ! res || ! res.success ) {
					$status.text( res && res.data && res.data.message ? res.data.message : i18n.error );
					return;
				}
				var current = $.trim( $input.val() );
				$input.val( ( current ? current + '\n' : '' ) + res.data.ideas.join( '\n' ) ).trigger( 'focus' );
				$status.text( '' );
			} )
			.fail( function () {
				$status.text( i18n.error );
			} )
			.always( function () {
				$btn.prop( 'disabled', false );
			} );
	} );

	/* Settings: test an engine with the key in the field (or the saved key). */
	$( document ).on( 'click', '.aivt-test-engine', function () {
		var $btn = $( this ).prop( 'disabled', true );
		var engine = $btn.data( 'engine' );
		var $cell = $btn.closest( '.aivt-engine-card' );
		var $out = $cell.find( '.aivt-test-result' ).removeAttr( 'hidden' ).removeClass( 'is-ok is-bad is-warn' ).text( i18n.testing );

		post( 'aivt_test_engine', {
			engine: engine,
			key: $cell.find( '.aivt-key' ).val(),
			model: $cell.find( '.aivt-model' ).val()
		} )
			.done( function ( res ) {
				var data = res && res.data ? res.data : {};
				if ( data.badge ) {
					$cell.find( '.aivt-badge' ).replaceWith( data.badge );
				}
				if ( ! res || ! res.success ) {
					$out.addClass( 'is-bad' ).text( data.message || i18n.error );
					return;
				}
				$out.addClass( data.warn ? 'is-warn' : 'is-ok' ).empty()
					.append( $( '<strong>' ).text( data.message ) )
					.append( $( '<span>' ).text( data.answer ) );
			} )
			.fail( function () {
				$out.addClass( 'is-bad' ).text( i18n.error );
			} )
			.always( function () {
				$btn.prop( 'disabled', false );
			} );
	} );
} )( jQuery );
