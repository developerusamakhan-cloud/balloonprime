<?php
/**
 * Site header.
 *
 * @package Vyntic
 */

$vyntic_minimal = is_page_template( 'page-templates/landing.php' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'vyntic' ); ?></a>

<header class="site-header<?php echo $vyntic_minimal ? ' site-header--minimal' : ''; ?>" data-header>
	<div class="wrap site-header__inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() && get_theme_mod( 'vyntic_use_custom_logo', false ) ) : ?>
				<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'brand__logo', 'alt' => get_bloginfo( 'name' ) ) ); ?>
			<?php else : ?>
				<img class="brand__logo brand__logo--dark" src="<?php echo esc_url( vyntic_img( 'brand/logo.svg' ) ); ?>" alt="<?php bloginfo( 'name' ); ?>" width="339" height="124">
				<img class="brand__logo brand__logo--light" src="<?php echo esc_url( vyntic_img( 'brand/logo-light.svg' ) ); ?>" alt="" aria-hidden="true" width="339" height="124">
			<?php endif; ?>
		</a>

		<?php if ( ! $vyntic_minimal ) : ?>
			<nav class="nav" id="site-nav" aria-label="<?php esc_attr_e( 'Main', 'vyntic' ); ?>" data-nav data-lenis-prevent>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'nav__list',
						'depth'          => 2,
						'fallback_cb'    => 'vyntic_menu_fallback',
					)
				);
				?>
				<a class="btn btn--primary nav__cta" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
				<?php
				$vyntic_m_email = vyntic_mod( 'email' );
				$vyntic_m_phone = vyntic_mod( 'phone' );
				$vyntic_m_wa    = preg_replace( '/\D+/', '', (string) vyntic_mod( 'whatsapp' ) );
				$vyntic_m_audit = vyntic_template_url( 'page-templates/free-audit.php' );
				$vyntic_m_ico   = function ( $path ) {
					return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' . $path . '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
				};
				$vyntic_m_social = array_filter(
					array(
						'LinkedIn'  => vyntic_mod( 'linkedin' ),
						'Instagram' => vyntic_mod( 'instagram' ),
					)
				);
				?>
				<div class="nav__extra">
					<?php if ( $vyntic_m_audit ) : ?>
						<a class="btn btn--ghost nav__audit" href="<?php echo esc_url( $vyntic_m_audit ); ?>"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Get a free website audit', 'vyntic' ); ?></a>
					<?php endif; ?>
					<div class="nav__contact">
						<p class="nav__contact-title"><?php esc_html_e( 'Talk to us', 'vyntic' ); ?></p>
						<ul>
							<?php if ( $vyntic_m_email ) : ?>
								<li><a href="mailto:<?php echo esc_attr( antispambot( $vyntic_m_email ) ); ?>"><?php echo $vyntic_m_ico( 'M4 6h16v12H4zM4 7l8 6 8-6' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( antispambot( $vyntic_m_email ) ); ?></span></a></li>
							<?php endif; ?>
							<?php if ( $vyntic_m_phone ) : ?>
								<li><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $vyntic_m_phone ) ); ?>"><?php echo $vyntic_m_ico( 'M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1z' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $vyntic_m_phone ); ?></span></a></li>
							<?php endif; ?>
							<?php if ( $vyntic_m_wa ) : ?>
								<li><a href="<?php echo esc_url( 'https://wa.me/' . $vyntic_m_wa ); ?>" rel="noopener" target="_blank"><?php echo $vyntic_m_ico( 'M4 20l1.3-4A8 8 0 1 1 8 18.7zM9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 1a4 4 0 0 1-2-2l1-1-1-2z' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Message us on WhatsApp', 'vyntic' ); ?></span></a></li>
							<?php endif; ?>
							<?php if ( vyntic_mod( 'hours' ) ) : ?>
								<li class="nav__contact-hours"><?php echo $vyntic_m_ico( 'M12 7v5l3 2M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( vyntic_mod( 'hours' ) ); ?></span></li>
							<?php endif; ?>
						</ul>
						<p class="nav__contact-note"><span class="nav__dot" aria-hidden="true"></span><?php esc_html_e( 'We reply within one business day.', 'vyntic' ); ?></p>
					</div>
					<?php if ( $vyntic_m_social ) : ?>
						<ul class="nav__social">
							<?php foreach ( $vyntic_m_social as $vyntic_label => $vyntic_link ) : ?>
								<li><a href="<?php echo esc_url( $vyntic_link ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $vyntic_label ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			</nav>
			<?php
			$vyntic_head_audit = is_page_template( 'page-templates/free-audit.php' ) ? '#free-audit' : vyntic_template_url( 'page-templates/free-audit.php' );
			if ( $vyntic_head_audit ) :
				?>
				<a class="header-audit" href="<?php echo esc_url( $vyntic_head_audit ); ?>"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Free audit', 'vyntic' ); ?></span></a>
			<?php endif; ?>
			<button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false" data-nav-toggle>
				<span class="nav-toggle__open"><?php echo vyntic_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="nav-toggle__close"><?php echo vyntic_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'vyntic' ); ?></span>
			</button>
		<?php else : ?>
			<a class="btn btn--primary" href="#contact-form"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
		<?php endif; ?>
	</div>
</header>

<main id="main" class="site-main" tabindex="-1">
