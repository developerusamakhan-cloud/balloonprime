<?php
/**
 * Contact form handling. No plugin needed. Submissions are saved under Inquiries (inc/submissions.php).
 * Tip: install an SMTP plugin (e.g. WP Mail SMTP) so emails reach your inbox reliably.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_post_nopriv_vyntic_contact', 'vyntic_handle_contact' );
add_action( 'admin_post_vyntic_contact', 'vyntic_handle_contact' );

/** True when the form was sent by the theme's JavaScript and expects JSON back. */
function vyntic_form_is_ajax() {
	return ! empty( $_POST['_ajax'] ); // phpcs:ignore WordPress.Security.NonceVerification
}

/**
 * Finish a contact form request: JSON for JavaScript, a redirect otherwise.
 *
 * @param string $state sent, missing, expired or failed.
 * @param string $back  Page to return to.
 * @param string $name  Visitor name, for the thank-you message.
 */
function vyntic_contact_done( $state, $back, $name = '' ) {
	if ( vyntic_form_is_ajax() ) {
		if ( 'sent' === $state ) {
			wp_send_json_success(
				array(
					'title' => vyntic_form_personalise( vyntic_form_setting( 'thanks_title' ), $name ),
					'text'  => vyntic_form_personalise( vyntic_form_setting( 'thanks_text' ), $name ),
				)
			);
		}
		$notice = vyntic_form_notice( $state );
		wp_send_json_error( array( 'message' => $notice ? $notice['text'] : '' ), 'expired' === $state ? 403 : 400 );
	}
	wp_safe_redirect( add_query_arg( 'form', $state, $back ) . '#contact-form' );
	exit;
}

function vyntic_handle_contact() {
	$back = isset( $_POST['_back'] ) ? esc_url_raw( wp_unslash( $_POST['_back'] ) ) : home_url( '/' );
	$back = wp_validate_redirect( $back, home_url( '/' ) );

	if ( ! isset( $_POST['vyntic_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_contact_nonce'] ) ), 'vyntic_contact' ) ) {
		vyntic_contact_done( 'expired', $back );
	}

	// Honeypot: real people never fill this hidden field.
	if ( ! empty( $_POST['company_website'] ) ) {
		vyntic_contact_done( 'sent', $back );
	}

	$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$website  = isset( $_POST['website'] ) ? sanitize_text_field( wp_unslash( $_POST['website'] ) ) : '';
	$services = isset( $_POST['services'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['services'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$service  = $services ? implode( ', ', $services ) : ( isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : '' );
	$phone    = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$timeline = isset( $_POST['timeline'] ) ? sanitize_text_field( wp_unslash( $_POST['timeline'] ) ) : '';
	$budget   = isset( $_POST['budget'] ) ? sanitize_text_field( wp_unslash( $_POST['budget'] ) ) : '';
	$message  = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		vyntic_contact_done( 'missing', $back );
	}

	$fields = array_filter(
		array(
			__( 'Name', 'vyntic' )     => $name,
			__( 'Email', 'vyntic' )    => $email,
			__( 'Phone', 'vyntic' )    => $phone,
			__( 'Website', 'vyntic' )  => $website,
			__( 'Services', 'vyntic' ) => $service,
			__( 'Budget', 'vyntic' )   => $budget,
			__( 'Timeline', 'vyntic' ) => $timeline,
			__( 'Message', 'vyntic' )  => $message,
		),
		'strlen'
	);
	$saved = vyntic_save_inquiry( 'contact', $fields, array( 'name' => $name, 'email' => $email, 'page' => $back ) );

	$sent = false;
	if ( vyntic_form_setting( 'notify' ) ) {
		/* translators: %s: sender name */
		$subject = sprintf( __( 'New project inquiry from %s', 'vyntic' ), $name );
		$lines   = array();
		foreach ( $fields as $label => $value ) {
			$lines[] = __( 'Message', 'vyntic' ) === $label ? "\n" . $value : $label . ': ' . $value;
		}
		$lines[] = '';
		$lines[] = 'Sent from ' . $back;
		if ( $saved ) {
			$lines[] = 'View in dashboard: ' . admin_url( 'post.php?post=' . $saved . '&action=edit' );
		}
		$sent = wp_mail( vyntic_form_recipient(), $subject, implode( "\n", $lines ), array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
	}

	if ( ! $saved && ! $sent ) {
		vyntic_contact_done( 'failed', $back );
	}
	vyntic_send_autoreply( $email, $name );
	vyntic_contact_done( 'sent', $back, $name );
}

/**
 * Message to show after a form submission, based on ?form= in the URL.
 *
 * @param string $state Optional state instead of reading the URL.
 * @return array|null { type, text }
 */
function vyntic_form_notice( $state = '' ) {
	if ( '' === $state ) {
		if ( empty( $_GET['form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return null;
		}
		$state = sanitize_key( wp_unslash( $_GET['form'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	$messages = array(
		'sent'    => array( 'success', __( 'Message sent. We will reply within 24 hours.', 'vyntic' ) ),
		'missing' => array( 'error', __( 'Add your name, a valid email and a short message, then send again.', 'vyntic' ) ),
		'expired' => array( 'error', __( 'The form timed out. Refresh the page and send again.', 'vyntic' ) ),
		'failed'  => array( 'error', sprintf( /* translators: %s email */ __( 'The message could not be sent. Email us directly at %s.', 'vyntic' ), vyntic_mod( 'email' ) ) ),
	);
	if ( ! isset( $messages[ $state ] ) ) {
		return null;
	}
	return array(
		'type' => $messages[ $state ][0],
		'text' => $messages[ $state ][1],
	);
}

/*
 * Free audit request form (used until you paste your own tool in Customize → Free audit).
 */
add_action( 'admin_post_nopriv_vyntic_audit', 'vyntic_handle_audit' );
add_action( 'admin_post_vyntic_audit', 'vyntic_handle_audit' );

function vyntic_handle_audit() {
	$back = isset( $_POST['_back'] ) ? esc_url_raw( wp_unslash( $_POST['_back'] ) ) : home_url( '/' );
	$back = wp_validate_redirect( $back, home_url( '/' ) );

	if ( ! isset( $_POST['vyntic_audit_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_audit_nonce'] ) ), 'vyntic_audit' ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'expired', $back ) . '#free-audit' );
		exit;
	}
	if ( ! empty( $_POST['company_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'sent', $back ) . '#free-audit' );
		exit;
	}

	$site  = isset( $_POST['site'] ) ? esc_url_raw( wp_unslash( $_POST['site'] ) ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

	if ( ! vyntic_captcha_ok( isset( $_POST['captcha'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha'] ) ) : '', isset( $_POST['captcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['captcha_token'] ) ) : '' ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'captcha', $back ) . '#free-audit' );
		exit;
	}

	if ( '' === $site || ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'missing', $back ) . '#free-audit' );
		exit;
	}

	$saved = vyntic_save_inquiry( 'audit', array( __( 'Website', 'vyntic' ) => $site, __( 'Email', 'vyntic' ) => $email ), array( 'name' => '', 'email' => $email, 'page' => $back ) );
	$sent  = vyntic_form_setting( 'notify' ) && wp_mail(
		vyntic_form_recipient(),
		/* translators: %s website */
		sprintf( __( 'Free audit request: %s', 'vyntic' ), $site ),
		"Website: {$site}\nEmail: {$email}\n\nSent from {$back}",
		array( 'Reply-To: ' . $email )
	);

	wp_safe_redirect( add_query_arg( 'audit', ( $saved || $sent ) ? 'sent' : 'failed', $back ) . '#free-audit' );
	exit;
}

/** Message after an audit request, based on ?audit= in the URL. */
function vyntic_audit_notice() {
	if ( empty( $_GET['audit'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return null;
	}
	$state    = sanitize_key( wp_unslash( $_GET['audit'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array(
		'sent'    => array( 'success', __( 'Request received. Your audit will arrive by email within two business days.', 'vyntic' ) ),
		'missing' => array( 'error', __( 'Add your website address and a valid email, then send again.', 'vyntic' ) ),
		'captcha' => array( 'error', __( 'That answer was not right. Please try the new question.', 'vyntic' ) ),
		'expired' => array( 'error', __( 'The form timed out. Refresh the page and send again.', 'vyntic' ) ),
		'failed'  => array( 'error', sprintf( /* translators: %s email */ __( 'The request could not be sent. Email us at %s.', 'vyntic' ), vyntic_mod( 'email' ) ) ),
	);
	return isset( $messages[ $state ] ) ? array( 'type' => $messages[ $state ][0], 'text' => $messages[ $state ][1] ) : null;
}

/**
 * Simple maths question for forms. The answer is signed, not stored, so it works on cached pages.
 * Questions stay valid for two days.
 *
 * @return array { question, token }
 */
function vyntic_captcha() {
	$a    = wp_rand( 2, 9 );
	$b    = wp_rand( 1, 9 );
	$time = time();
	return array(
		/* translators: 1, 2: numbers to add */
		'question' => sprintf( __( 'Quick check: what is %1$d + %2$d?', 'vyntic' ), $a, $b ),
		'token'    => $time . '.' . wp_hash( 'vyntic_captcha|' . $time . '|' . ( $a + $b ) ),
	);
}

/** True when the answer matches its signed token and the token is recent and unused. */
function vyntic_captcha_ok( $answer, $token ) {
	if ( ! preg_match( '/^(\d{9,11})\.([a-f0-9]{32})$/', (string) $token, $m ) || ! preg_match( '/^\d{1,3}$/', trim( (string) $answer ) ) ) {
		return false;
	}
	if ( (int) $m[1] < time() - 2 * DAY_IN_SECONDS ) {
		return false;
	}
	if ( ! hash_equals( wp_hash( 'vyntic_captcha|' . $m[1] . '|' . (int) trim( $answer ) ), $m[2] ) ) {
		return false;
	}
	$used = 'vyntic_cap_' . md5( $token . '|' . (int) trim( $answer ) );
	if ( get_transient( $used ) ) {
		return false;
	}
	set_transient( $used, 1, 2 * DAY_IN_SECONDS );
	return true;
}

