<?php
/**
 * Admin UI: dashboard, settings tabs, admin bar, meta box, AJAX tools.
 *
 * @package VynticSpeedOptimizer
 */

defined( 'ABSPATH' ) || exit;

class VSO_Admin {

	const SLUG = 'vyntic-speed';

	/** Plugins that do the same job; running two optimizers breaks sites. */
	const CONFLICTS = array(
		'wp-rocket/wp-rocket.php'                             => 'WP Rocket',
		'w3-total-cache/w3-total-cache.php'                   => 'W3 Total Cache',
		'wp-super-cache/wp-cache.php'                         => 'WP Super Cache',
		'wp-fastest-cache/wpFastestCache.php'                 => 'WP Fastest Cache',
		'litespeed-cache/litespeed-cache.php'                 => 'LiteSpeed Cache',
		'autoptimize/autoptimize.php'                         => 'Autoptimize',
		'tenweb-speed-optimizer/tenweb_speed_optimizer.php'   => '10Web Booster',
		'sg-cachepress/sg-cachepress.php'                     => 'SiteGround Optimizer',
		'breeze/breeze.php'                                   => 'Breeze',
		'hummingbird-performance/wp-hummingbird.php'          => 'Hummingbird',
		'swift-performance-lite/performance.php'              => 'Swift Performance',
		'nitropack/main.php'                                  => 'NitroPack',
		'flying-press/flying-press.php'                       => 'FlyingPress',
		'perfmatters/perfmatters.php'                         => 'Perfmatters',
		'wp-optimize/wp-optimize.php'                         => 'WP-Optimize',
		'cache-enabler/cache-enabler.php'                     => 'Cache Enabler',
	);

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_vso_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_vso_preset', array( __CLASS__, 'handle_preset' ) );
		add_action( 'admin_post_vso_clear', array( __CLASS__, 'handle_clear' ) );
		add_action( 'admin_post_vso_preload', array( __CLASS__, 'handle_preload' ) );
		add_action( 'admin_post_vso_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_vso_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_vso_reset', array( __CLASS__, 'handle_reset' ) );
		add_action( 'wp_ajax_vso_psi', array( __CLASS__, 'ajax_psi' ) );
		add_action( 'wp_ajax_vso_webp_batch', array( __CLASS__, 'ajax_webp' ) );
		add_action( 'wp_ajax_vso_db_clean', array( __CLASS__, 'ajax_db' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta_box' ), 5 );
		add_filter( 'plugin_action_links_' . plugin_basename( VSO_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function url( $tab = 'dashboard', $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	public static function menu() {
		// Lives inside the shared "Vyntic" menu, so all Vyntic plugins take one menu item.
		if ( class_exists( 'Vyntic_Client' ) ) {
			add_submenu_page( Vyntic_Client::MENU, __( 'Vyntic Speed Optimizer', 'vyntic-speed-optimizer' ), __( 'Speed Optimizer', 'vyntic-speed-optimizer' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
			return;
		}
		add_menu_page( __( 'Vyntic Speed Optimizer', 'vyntic-speed-optimizer' ), __( 'Vyntic Speed', 'vyntic-speed-optimizer' ), 'manage_options', self::SLUG, array( __CLASS__, 'render' ), 'dashicons-performance', 81 );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Settings', 'vyntic-speed-optimizer' ) . '</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'vso-admin', VSO_URL . 'assets/css/admin.css', array(), VSO_VERSION );
		wp_enqueue_script( 'vso-admin', VSO_URL . 'assets/js/admin.js', array(), VSO_VERSION, true );
		wp_localize_script(
			'vso-admin',
			'vsoAdmin',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'vso_ajax' ),
				'home'  => home_url( '/' ),
				'locale' => str_replace( '_', '-', get_user_locale() ),
				'i18n'  => array(
					'testing'   => __( 'Testing, this takes 20 to 60 seconds...', 'vyntic-speed-optimizer' ),
					'psi'       => array(
						'mobile'   => __( 'Mobile', 'vyntic-speed-optimizer' ),
						'desktop'  => __( 'Desktop', 'vyntic-speed-optimizer' ),
						'good'     => __( 'Good', 'vyntic-speed-optimizer' ),
						'avg'      => __( 'Needs work', 'vyntic-speed-optimizer' ),
						'poor'     => __( 'Poor', 'vyntic-speed-optimizer' ),
						'testingM' => __( 'Testing mobile (1 of 2), this takes 20 to 60 seconds...', 'vyntic-speed-optimizer' ),
						'testingD' => __( 'Testing desktop (2 of 2)...', 'vyntic-speed-optimizer' ),
						'saved'    => __( 'Report saved.', 'vyntic-speed-optimizer' ),
						'last'     => __( 'Last test', 'vyntic-speed-optimizer' ),
						'next'     => __( 'Next automatic check', 'vyntic-speed-optimizer' ),
						'off'      => __( 'Weekly check is off (Tools tab).', 'vyntic-speed-optimizer' ),
						'auto'     => __( 'Weekly check', 'vyntic-speed-optimizer' ),
						'manual'   => __( 'Manual', 'vyntic-speed-optimizer' ),
						'history'  => __( 'Recent tests', 'vyntic-speed-optimizer' ),
						'date'     => __( 'Date', 'vyntic-speed-optimizer' ),
						'page'     => __( 'Page', 'vyntic-speed-optimizer' ),
						'source'   => __( 'Type', 'vyntic-speed-optimizer' ),
						'fixes'    => __( 'Biggest wins on mobile', 'vyntic-speed-optimizer' ),
						'save'     => __( 'save', 'vyntic-speed-optimizer' ),
						'empty'    => __( 'No report yet. Click Test now. After that the home page is checked automatically once a week.', 'vyntic-speed-optimizer' ),
						'legend'   => __( '90 to 100 good, 50 to 89 needs work, 0 to 49 poor', 'vyntic-speed-optimizer' ),
						'names'    => array(
							'FCP' => __( 'First Contentful Paint', 'vyntic-speed-optimizer' ),
							'LCP' => __( 'Largest Contentful Paint', 'vyntic-speed-optimizer' ),
							'TBT' => __( 'Total Blocking Time', 'vyntic-speed-optimizer' ),
							'CLS' => __( 'Cumulative Layout Shift', 'vyntic-speed-optimizer' ),
							'SI'  => __( 'Speed Index', 'vyntic-speed-optimizer' ),
						),
					),
					'error'     => __( 'Something went wrong:', 'vyntic-speed-optimizer' ),
					'converted' => __( 'Converted', 'vyntic-speed-optimizer' ),
					'done'      => __( 'All images converted.', 'vyntic-speed-optimizer' ),
					'cleaned'   => __( 'Cleaned', 'vyntic-speed-optimizer' ),
				),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------------- */

	public static function tabs() {
		return array(
			'dashboard' => __( 'Overview', 'vyntic-speed-optimizer' ),
			'cache'     => __( 'Cache', 'vyntic-speed-optimizer' ),
			'files'     => __( 'CSS & JavaScript', 'vyntic-speed-optimizer' ),
			'media'     => __( 'Images & Media', 'vyntic-speed-optimizer' ),
			'fonts'     => __( 'Fonts & Preload', 'vyntic-speed-optimizer' ),
			'tweaks'    => __( 'Tweaks', 'vyntic-speed-optimizer' ),
			'database'  => __( 'Database', 'vyntic-speed-optimizer' ),
			'tools'     => __( 'Tools', 'vyntic-speed-optimizer' ),
		);
	}

	/**
	 * One-line description shown under the page title of each section.
	 */
	private static function tab_intro( $tab ) {
		$intro = array(
			'dashboard' => __( 'Your speed profile, PageSpeed scores and what is switched on.', 'vyntic-speed-optimizer' ),
			'cache'     => __( 'Ready-made HTML copies of your pages, served without PHP or database work.', 'vyntic-speed-optimizer' ),
			'files'     => __( 'Delay, defer and trim the scripts and styles every page loads.', 'vyntic-speed-optimizer' ),
			'media'     => __( 'Lazy loading, WebP and the main image that decides your LCP.', 'vyntic-speed-optimizer' ),
			'fonts'     => __( 'Faster fonts and hints that help the browser fetch the right files first.', 'vyntic-speed-optimizer' ),
			'tweaks'    => __( 'Remove WordPress features most sites never use.', 'vyntic-speed-optimizer' ),
			'database'  => __( 'Clear out data WordPress no longer needs.', 'vyntic-speed-optimizer' ),
			'tools'     => __( 'Pause, API key, weekly checks, import, export and reset.', 'vyntic-speed-optimizer' ),
		);
		return isset( $intro[ $tab ] ) ? $intro[ $tab ] : '';
	}

	/**
	 * Small stroke icons for the side menu.
	 */
	private static function icon( $name ) {
		$paths = array(
			'dashboard' => '<path d="M4 15a8 8 0 1 1 16 0"/><path d="M12 15l4-5"/><circle cx="12" cy="15" r="1.5"/>',
			'cache'     => '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
			'files'     => '<path d="M9 7l-5 5 5 5"/><path d="M15 7l5 5-5 5"/>',
			'media'     => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>',
			'fonts'     => '<path d="M4 19l5-14 5 14"/><path d="M6 14h6"/><path d="M15 19v-5a2.5 2.5 0 0 1 5 0v5"/><path d="M15 16.5h5"/>',
			'tweaks'    => '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
			'database'  => '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>',
			'tools'     => '<path d="M14.5 5.5a4 4 0 0 0-5 5L4 16v4h4l5.5-5.5a4 4 0 0 0 5-5l-2.5 2.5-2.5-.5-.5-2.5 2.5-2.5z"/>',
			'updates'   => '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8"/><path d="M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.3 4.9L20 16"/><path d="M20 20v-4h-4"/>',
			'bolt'      => '<path d="M13 3L5 13h6l-1 8 8-10h-6l1-8z"/>',
			'pause'     => '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
			'check'     => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
		);
		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}
		return '<svg class="vso-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $paths[ $name ] . '</svg>';
	}

	/**
	 * Human name of the current level.
	 */
	private static function level_name( $level ) {
		$names = array(
			'safe'     => __( 'Safe', 'vyntic-speed-optimizer' ),
			'balanced' => __( 'Balanced', 'vyntic-speed-optimizer' ),
			'extreme'  => __( 'Extreme', 'vyntic-speed-optimizer' ),
			'custom'   => __( 'Custom', 'vyntic-speed-optimizer' ),
			'off'      => __( 'Paused', 'vyntic-speed-optimizer' ),
		);
		return isset( $names[ $level ] ) ? $names[ $level ] : $level;
	}

	/**
	 * Preset form button (the same vso_preset action the plugin always used).
	 */
	private static function preset_form( $level, $label, $class = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-inline">
			<?php wp_nonce_field( 'vso_preset' ); ?>
			<input type="hidden" name="action" value="vso_preset">
			<input type="hidden" name="level" value="<?php echo esc_attr( $level ); ?>">
			<button type="submit" class="vso-btn <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tabs = self::tabs();
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'dashboard';
		}
		$level  = VSO_Settings::get( 'level' );
		$paused = 'off' === $level;
		?>
		<div class="wrap vso-wrap">
			<div class="vso-shell">
				<aside class="vso-side">
					<a class="vso-brand" href="<?php echo esc_url( self::url() ); ?>">
						<span class="vso-mark" aria-hidden="true"><svg viewBox="0 0 108 108" focusable="false"><polygon points="2,12 30,12 62,96 34,96" fill="currentColor"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>
						<span class="vso-brand-text"><strong><?php esc_html_e( 'Speed Optimizer', 'vyntic-speed-optimizer' ); ?></strong><small>Vyntic &middot; v<?php echo esc_html( VSO_VERSION ); ?></small></span>
					</a>

					<div class="vso-state <?php echo $paused ? 'is-paused' : 'is-on'; ?>">
						<span class="vso-state-dot" aria-hidden="true"></span>
						<span>
							<strong><?php echo $paused ? esc_html__( 'Paused', 'vyntic-speed-optimizer' ) : esc_html__( 'Optimizing', 'vyntic-speed-optimizer' ); ?></strong>
							<?php if ( ! $paused ) : ?>
								<small>
									<?php
									/* translators: %s: profile name */
									echo esc_html( sprintf( __( 'Profile: %s', 'vyntic-speed-optimizer' ), self::level_name( $level ) ) );
									?>
								</small>
							<?php endif; ?>
						</span>
					</div>

					<nav class="vso-nav" aria-label="<?php esc_attr_e( 'Speed Optimizer sections', 'vyntic-speed-optimizer' ); ?>">
						<?php foreach ( $tabs as $key => $label ) : ?>
							<a class="vso-nav-item<?php echo $key === $tab ? ' is-active' : ''; ?>" href="<?php echo esc_url( self::url( $key ) ); ?>"<?php echo $key === $tab ? ' aria-current="page"' : ''; ?>><?php echo self::icon( $key ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $label ); ?></span></a>
						<?php endforeach; ?>
						<?php if ( class_exists( 'Vyntic_Client' ) && method_exists( 'Vyntic_Client', 'updates_link' ) ) : ?>
							<?php $vso_upd = Vyntic_Client::updates_link( self::SLUG ); ?>
							<a class="vso-nav-item vso-nav-item--updates" href="<?php echo esc_url( $vso_upd['url'] ); ?>"><?php echo self::icon( 'updates' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $vso_upd['label'] ); ?></span><?php if ( $vso_upd['count'] ) : ?><em class="vso-count"><?php echo (int) $vso_upd['count']; ?></em><?php endif; ?></a>
						<?php endif; ?>
					</nav>

					<div class="vso-side-foot">
						<p><?php esc_html_e( 'Runs 100% on your server. No account, no login.', 'vyntic-speed-optimizer' ); ?></p>
						<a href="https://vyntic.studio/free-website-audit/" target="_blank" rel="noopener"><?php esc_html_e( 'Free website audit', 'vyntic-speed-optimizer' ); ?></a>
						<a href="https://vyntic.studio/plugins/" target="_blank" rel="noopener"><?php esc_html_e( 'More free plugins', 'vyntic-speed-optimizer' ); ?></a>
						<a href="https://vyntic.studio/contact/" target="_blank" rel="noopener"><?php esc_html_e( 'Support', 'vyntic-speed-optimizer' ); ?></a>
					</div>
				</aside>

				<main class="vso-main">
					<div class="vso-top">
						<div>
							<p class="vso-crumb"><?php esc_html_e( 'Vyntic Speed Optimizer', 'vyntic-speed-optimizer' ); ?></p>
							<p class="vso-page-title" aria-hidden="true"><?php echo esc_html( $tabs[ $tab ] ); ?></p>
							<p class="vso-page-intro"><?php echo esc_html( self::tab_intro( $tab ) ); ?></p>
						</div>
						<div class="vso-top-actions">
							<a class="vso-btn vso-btn--dark" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vso_clear' ), 'vso_clear' ) ); ?>"><?php echo self::icon( 'bolt' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Clear all cache', 'vyntic-speed-optimizer' ); ?></a>
						</div>
					</div>
					<?php
					// The real page heading sits here, below the top bar. WordPress and other plugins
					// place their notices after the first heading or after .wp-header-end.
					?>
					<h1 class="screen-reader-text"><?php echo esc_html( $tabs[ $tab ] . ' - ' . __( 'Vyntic Speed Optimizer', 'vyntic-speed-optimizer' ) ); ?></h1>
					<hr class="wp-header-end">

					<?php self::flash(); ?>

					<?php if ( $paused && 'dashboard' !== $tab && 'tools' !== $tab ) : ?>
						<div class="vso-banner vso-banner--paused">
							<?php echo self::icon( 'pause' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<p><?php esc_html_e( 'All optimizations and caching are paused, so these settings have no effect right now.', 'vyntic-speed-optimizer' ); ?></p>
							<a class="vso-btn vso-btn--ghost" href="<?php echo esc_url( self::url( 'dashboard' ) ); ?>"><?php esc_html_e( 'Resume', 'vyntic-speed-optimizer' ); ?></a>
						</div>
					<?php endif; ?>

					<div class="vso-body">
						<?php
						switch ( $tab ) {
							case 'dashboard':
								self::tab_dashboard();
								break;
							case 'database':
								self::tab_database();
								break;
							case 'tools':
								self::tab_tools();
								break;
							default:
								self::settings_form( $tab );
						}
						?>
					</div>
				</main>
			</div>
		</div>
		<?php
	}

	private static function flash() {
		$msg = isset( $_GET['vso_msg'] ) ? sanitize_key( wp_unslash( $_GET['vso_msg'] ) ) : ''; // phpcs:ignore
		$map = array(
			'saved'    => __( 'Settings saved. Cache cleared so changes show right away.', 'vyntic-speed-optimizer' ),
			'preset'   => __( 'Speed profile applied. Cache cleared and preloading started.', 'vyntic-speed-optimizer' ),
			'paused'   => __( 'All optimizations and caching are paused. Your visitors now get the original, unoptimized site.', 'vyntic-speed-optimizer' ),
			'cleared'  => __( 'All cache cleared.', 'vyntic-speed-optimizer' ),
			'preload'  => __( 'Cache preload started in the background.', 'vyntic-speed-optimizer' ),
			'imported' => __( 'Settings imported.', 'vyntic-speed-optimizer' ),
			'reset'    => __( 'Settings reset to the recommended defaults.', 'vyntic-speed-optimizer' ),
			'badfile'  => __( 'That file is not a valid Vyntic settings export.', 'vyntic-speed-optimizer' ),
		);
		if ( isset( $map[ $msg ] ) ) {
			$type = 'badfile' === $msg ? 'error' : ( 'paused' === $msg ? 'warning' : 'success' );
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $map[ $msg ] ) . '</p></div>';
		}
	}

	private static function tab_dashboard() {
		$level    = VSO_Settings::get( 'level' );
		$status   = VSO_Page_Cache::status();
		$webp     = VSO_WebP::stats();
		$last     = VSO_PSI::last();
		$profiles = array(
			'safe'     => array(
				__( 'Safe', 'vyntic-speed-optimizer' ),
				__( 'Page cache, minify, defer JS, lazy load and WebP. Works on every site.', 'vyntic-speed-optimizer' ),
			),
			'balanced' => array(
				__( 'Balanced', 'vyntic-speed-optimizer' ),
				__( 'Safe, plus JavaScript delayed until the first interaction, YouTube click-to-load and local Google Fonts.', 'vyntic-speed-optimizer' ),
			),
			'extreme'  => array(
				__( 'Extreme', 'vyntic-speed-optimizer' ),
				__( 'Balanced, plus unused CSS removed per page. Highest scores; check your pages after switching.', 'vyntic-speed-optimizer' ),
			),
		);
		$features = array(
			'page_cache'         => array( __( 'Page cache', 'vyntic-speed-optimizer' ), 'cache' ),
			'delay_js'           => array( __( 'Delay JavaScript', 'vyntic-speed-optimizer' ), 'files' ),
			'remove_unused_css'  => array( __( 'Remove unused CSS', 'vyntic-speed-optimizer' ), 'files' ),
			'minify_css'         => array( __( 'Minify CSS, JS and HTML', 'vyntic-speed-optimizer' ), 'files' ),
			'lazy_images'        => array( __( 'Lazy load images', 'vyntic-speed-optimizer' ), 'media' ),
			'webp'               => array( __( 'WebP images', 'vyntic-speed-optimizer' ), 'media' ),
			'local_google_fonts' => array( __( 'Local Google Fonts', 'vyntic-speed-optimizer' ), 'fonts' ),
		);
		$on_count = 0;
		foreach ( array_keys( $features ) as $key ) {
			$on_count += VSO_Settings::enabled( $key ) ? 1 : 0;
		}
		$cache_ok = $status['enabled'] && $status['dropin'] && $status['wp_cache'];
		?>
		<?php if ( 'off' === $level ) : ?>
			<section class="vso-banner vso-banner--paused vso-banner--big">
				<?php echo self::icon( 'pause' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<div>
					<p class="vso-banner-title"><?php esc_html_e( 'Optimizations are paused', 'vyntic-speed-optimizer' ); ?></p>
					<p><?php esc_html_e( 'Caching and every optimization are switched off. Pick a speed profile to switch them back on.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
				<?php self::preset_form( 'balanced', __( 'Resume with Balanced', 'vyntic-speed-optimizer' ), 'vso-btn--accent' ); ?>
			</section>
		<?php endif; ?>

		<div class="vso-kpis">
			<div class="vso-kpi">
				<span class="vso-kpi-label"><?php esc_html_e( 'Page cache', 'vyntic-speed-optimizer' ); ?></span>
				<?php if ( $cache_ok ) : ?>
					<strong class="vso-kpi-value is-good"><?php esc_html_e( 'Active', 'vyntic-speed-optimizer' ); ?></strong>
				<?php elseif ( $status['enabled'] ) : ?>
					<strong class="vso-kpi-value is-warn"><?php esc_html_e( 'Not installed', 'vyntic-speed-optimizer' ); ?></strong>
				<?php else : ?>
					<strong class="vso-kpi-value is-muted"><?php esc_html_e( 'Off', 'vyntic-speed-optimizer' ); ?></strong>
				<?php endif; ?>
				<span class="vso-kpi-note">
					<?php
					/* translators: 1: number of cached pages, 2: size */
					echo esc_html( sprintf( __( '%1$s pages cached, %2$s', 'vyntic-speed-optimizer' ), number_format_i18n( $status['stats'][0] ), VSO_Utils::format_bytes( $status['stats'][1] ) ) );
					?>
				</span>
			</div>
			<div class="vso-kpi">
				<span class="vso-kpi-label"><?php esc_html_e( 'WebP images', 'vyntic-speed-optimizer' ); ?></span>
				<strong class="vso-kpi-value"><?php echo esc_html( number_format_i18n( $webp['converted'] ) ); ?><small> / <?php echo esc_html( number_format_i18n( $webp['total'] ) ); ?></small></strong>
				<span class="vso-kpi-note">
					<?php
					/* translators: %s: bytes saved */
					echo esc_html( sprintf( __( '%s saved', 'vyntic-speed-optimizer' ), VSO_Utils::format_bytes( $webp['bytes'] ) ) );
					?>
				</span>
			</div>
			<div class="vso-kpi">
				<span class="vso-kpi-label"><?php esc_html_e( 'Speed profile', 'vyntic-speed-optimizer' ); ?></span>
				<strong class="vso-kpi-value"><?php echo esc_html( self::level_name( $level ) ); ?></strong>
				<span class="vso-kpi-note">
					<?php
					/* translators: 1: features on, 2: total features */
					echo esc_html( sprintf( __( '%1$d of %2$d key features on', 'vyntic-speed-optimizer' ), $on_count, count( $features ) ) );
					?>
				</span>
			</div>
		</div>

		<section class="vso-panel">
			<header class="vso-panel-head">
				<div>
					<h2><?php esc_html_e( 'Speed profile', 'vyntic-speed-optimizer' ); ?></h2>
					<p><?php esc_html_e( 'One click sets every option. You can still fine-tune afterwards; the profile then shows as Custom.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
			</header>
			<div class="vso-profiles" role="list">
				<?php foreach ( $profiles as $key => $info ) : ?>
					<?php $current = $key === $level; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-profile<?php echo $current ? ' is-current' : ''; ?>" role="listitem">
						<?php wp_nonce_field( 'vso_preset' ); ?>
						<input type="hidden" name="action" value="vso_preset">
						<input type="hidden" name="level" value="<?php echo esc_attr( $key ); ?>">
						<div class="vso-profile-top">
							<span class="vso-profile-name"><?php echo esc_html( $info[0] ); ?></span>
							<?php if ( 'balanced' === $key ) : ?>
								<span class="vso-tag"><?php esc_html_e( 'Recommended', 'vyntic-speed-optimizer' ); ?></span>
							<?php endif; ?>
						</div>
						<p><?php echo esc_html( $info[1] ); ?></p>
						<?php if ( $current ) : ?>
							<span class="vso-profile-on"><?php echo self::icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'In use', 'vyntic-speed-optimizer' ); ?></span>
						<?php else : ?>
							<button type="submit" class="vso-btn vso-btn--ghost"><?php esc_html_e( 'Use this profile', 'vyntic-speed-optimizer' ); ?></button>
						<?php endif; ?>
					</form>
				<?php endforeach; ?>
			</div>
			<?php if ( 'custom' === $level ) : ?>
				<p class="vso-note"><?php esc_html_e( 'You changed settings by hand, so the profile is Custom. Pick a profile above to go back to a preset.', 'vyntic-speed-optimizer' ); ?></p>
			<?php endif; ?>
		</section>

		<section class="vso-panel vso-psi" id="vso-psi">
			<header class="vso-panel-head">
				<div>
					<h2><?php esc_html_e( 'PageSpeed score', 'vyntic-speed-optimizer' ); ?></h2>
					<p class="vso-psi-sub"><?php esc_html_e( 'Google PageSpeed Insights, the same engine as pagespeed.web.dev. Every report is saved here and on your WordPress Dashboard.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
				<div class="vso-psi-form">
					<input type="url" id="vso-psi-url" value="<?php echo esc_attr( ! empty( $last['url'] ) ? $last['url'] : home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Page to test', 'vyntic-speed-optimizer' ); ?>">
					<button type="button" class="vso-btn vso-btn--accent" id="vso-psi-run"><?php esc_html_e( 'Test now', 'vyntic-speed-optimizer' ); ?></button>
				</div>
			</header>
			<div class="vso-psi-status" id="vso-psi-status" role="status" aria-live="polite"></div>
			<div id="vso-psi-results" data-state="<?php echo esc_attr( wp_json_encode( VSO_PSI::state() ) ); ?>"></div>
		</section>

		<div class="vso-split">
			<section class="vso-panel">
				<header class="vso-panel-head"><div><h2><?php esc_html_e( 'What is switched on', 'vyntic-speed-optimizer' ); ?></h2></div></header>
				<ul class="vso-feature-list">
					<?php foreach ( $features as $key => $info ) : ?>
						<?php $on = VSO_Settings::enabled( $key ); ?>
						<li class="<?php echo $on ? 'is-on' : 'is-off'; ?>">
							<span class="vso-feature-dot" aria-hidden="true"></span>
							<span class="vso-feature-name"><?php echo esc_html( $info[0] ); ?></span>
							<span class="vso-feature-state"><?php echo $on ? esc_html__( 'On', 'vyntic-speed-optimizer' ) : esc_html__( 'Off', 'vyntic-speed-optimizer' ); ?></span>
							<a href="<?php echo esc_url( self::url( $info[1] ) ); ?>"><?php esc_html_e( 'Settings', 'vyntic-speed-optimizer' ); ?></a>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
			<section class="vso-panel">
				<header class="vso-panel-head"><div><h2><?php esc_html_e( 'Quick actions', 'vyntic-speed-optimizer' ); ?></h2></div></header>
				<div class="vso-actions">
					<div class="vso-action">
						<div>
							<strong><?php esc_html_e( 'Preload cache', 'vyntic-speed-optimizer' ); ?></strong>
							<p>
								<?php
								echo VSO_Preload::remaining()
									? esc_html( sprintf( /* translators: %d: number of URLs */ __( '%d URLs waiting to be preloaded.', 'vyntic-speed-optimizer' ), (int) VSO_Preload::remaining() ) )
									: esc_html__( 'Visit every page in the background so the first visitor gets a cached copy.', 'vyntic-speed-optimizer' );
								?>
							</p>
						</div>
						<a class="vso-btn vso-btn--ghost" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vso_preload' ), 'vso_preload' ) ); ?>"><?php esc_html_e( 'Preload now', 'vyntic-speed-optimizer' ); ?></a>
					</div>
					<div class="vso-action">
						<div>
							<strong><?php esc_html_e( 'Convert images to WebP', 'vyntic-speed-optimizer' ); ?></strong>
							<p><?php echo VSO_WebP::supported() ? esc_html__( 'Convert the images already in your media library.', 'vyntic-speed-optimizer' ) : esc_html__( 'Your server has no WebP support (GD or Imagick). Ask your host to enable it.', 'vyntic-speed-optimizer' ); ?></p>
						</div>
						<a class="vso-btn vso-btn--ghost" href="<?php echo esc_url( self::url( 'media' ) ); ?>#vso-webp-bulk"><?php esc_html_e( 'Open', 'vyntic-speed-optimizer' ); ?></a>
					</div>
					<div class="vso-action">
						<div>
							<strong><?php esc_html_e( 'Something looks broken?', 'vyntic-speed-optimizer' ); ?></strong>
							<p><?php esc_html_e( 'Pause everything in one click, or see the troubleshooting tips.', 'vyntic-speed-optimizer' ); ?></p>
						</div>
						<a class="vso-btn vso-btn--ghost" href="<?php echo esc_url( self::url( 'tools' ) ); ?>#vso-pause"><?php esc_html_e( 'Tools', 'vyntic-speed-optimizer' ); ?></a>
					</div>
				</div>
			</section>
		</div>
		<?php
	}

	/**
	 * Field definitions per settings tab.
	 */
	private static function fields() {
		return array(
			'cache'  => array(
				array( 'section', __( 'Page cache', 'vyntic-speed-optimizer' ), __( 'Stores a ready-made HTML copy of every page. Visitors get it instantly without PHP or database work. This is the biggest win for server response time (TTFB).', 'vyntic-speed-optimizer' ) ),
				array( 'page_cache', 'toggle', __( 'Enable page cache', 'vyntic-speed-optimizer' ) ),
				array( 'cache_lifespan', 'number', __( 'Cache lifespan (hours)', 'vyntic-speed-optimizer' ), __( '0 = never expires (cache is still cleared automatically whenever you edit content).', 'vyntic-speed-optimizer' ) ),
				array( 'cache_preload', 'toggle', __( 'Preload cache', 'vyntic-speed-optimizer' ), __( 'Automatically visits your pages in the background after the cache is cleared.', 'vyntic-speed-optimizer' ) ),
				array( 'cache_mobile', 'toggle', __( 'Separate cache for mobile', 'vyntic-speed-optimizer' ), __( 'Only needed if your theme shows different HTML on phones.', 'vyntic-speed-optimizer' ) ),
				array( 'cache_exclude_urls', 'textarea', __( 'Never cache these URLs', 'vyntic-speed-optimizer' ), __( 'One per line. Partial match, "*" wildcard allowed. Example: /cart/', 'vyntic-speed-optimizer' ) ),
				array( 'cache_exclude_cookies', 'textarea', __( 'Never cache when these cookies exist', 'vyntic-speed-optimizer' ), __( 'Cookie name prefixes, one per line. Logged-in users and WooCommerce carts are always excluded.', 'vyntic-speed-optimizer' ) ),
				array( 'cache_ignore_params', 'textarea', __( 'Ignored query parameters', 'vyntic-speed-optimizer' ), __( 'URLs with only these parameters are still served from cache (tracking tags).', 'vyntic-speed-optimizer' ) ),
				array( 'section', __( 'Browser cache', 'vyntic-speed-optimizer' ), '' ),
				array( 'browser_cache', 'toggle', __( 'Browser caching + GZIP rules (.htaccess)', 'vyntic-speed-optimizer' ), __( 'Adds long cache headers for images, CSS, JS and fonts on Apache/LiteSpeed servers.', 'vyntic-speed-optimizer' ) ),
			),
			'files'  => array(
				array( 'section', __( 'JavaScript', 'vyntic-speed-optimizer' ), '' ),
				array( 'delay_js', 'toggle', __( 'Delay all JavaScript until user interaction', 'vyntic-speed-optimizer' ), __( 'Scripts run on the first scroll, tap, mouse move or key press. Removes almost all Total Blocking Time, which is the main reason scores turn green.', 'vyntic-speed-optimizer' ) ),
				array( 'delay_js_timeout', 'number', __( 'Also run scripts after (seconds)', 'vyntic-speed-optimizer' ), __( '0 = only on interaction (best score). Set e.g. 8 if you have auto-playing sliders.', 'vyntic-speed-optimizer' ) ),
				array( 'delay_js_exclude', 'textarea', __( 'Do not delay scripts containing', 'vyntic-speed-optimizer' ), __( 'One per line: part of a file URL, script id or inline code. Example: jquery.min.js', 'vyntic-speed-optimizer' ) ),
				array( 'section', __( 'Compatibility', 'vyntic-speed-optimizer' ), __( 'Built-in exclusions for well-known plugins. When a script is excluded, everything it needs (for example jQuery) is excluded with it automatically, so nothing runs in the wrong order. Checkout, cart, account and order-received pages never delay scripts, so purchase events are always tracked.', 'vyntic-speed-optimizer' ) ),
				array( 'compat_detected', 'compat_detected', __( 'Detected on your site', 'vyntic-speed-optimizer' ) ),
				array( 'compat_cookie', 'toggle', __( 'Cookie / GDPR consent banners', 'vyntic-speed-optimizer' ), __( 'CookieYes, Complianz, Cookiebot, Borlabs, iubenda, OneTrust and more. The banner must show right away (legal requirement).', 'vyntic-speed-optimizer' ) ),
				array( 'compat_sliders', 'toggle', __( 'Sliders', 'vyntic-speed-optimizer' ), __( 'Slider Revolution, Smart Slider, LayerSlider, MetaSlider and more. These are usually the first thing on the page and stay blank until their script runs.', 'vyntic-speed-optimizer' ) ),
				array( 'compat_lazyload', 'toggle', __( 'JavaScript lazy loaders', 'vyntic-speed-optimizer' ), __( 'Smush, a3 Lazy Load, Jetpack, theme lazy load, Elementor background lazy load. Without this, those images stay empty.', 'vyntic-speed-optimizer' ) ),
				array( 'tracking_mode', 'select', __( 'Tracking & pixels', 'vyntic-speed-optimizer' ), __( 'Meta/Facebook Pixel, Google Analytics, Tag Manager, Google Ads, TikTok, Clarity, Hotjar, PixelYourSite and more. "Delay" gives the best score; visitors who leave without scrolling or tapping are not counted. "Load normally" tracks every visit but lowers the score (often 10 to 25 points on mobile).', 'vyntic-speed-optimizer' ), array( 'delay' => __( 'Delay until interaction (best score)', 'vyntic-speed-optimizer' ), 'normal' => __( 'Load normally (track every visit)', 'vyntic-speed-optimizer' ) ) ),
				array( 'section', __( 'More JavaScript options', 'vyntic-speed-optimizer' ), '' ),
				array( 'defer_js', 'toggle', __( 'Defer JavaScript', 'vyntic-speed-optimizer' ), __( 'Adds "defer" to scripts that are not delayed (jQuery is kept in place for compatibility).', 'vyntic-speed-optimizer' ) ),
				array( 'defer_exclude', 'textarea', __( 'Do not defer scripts containing', 'vyntic-speed-optimizer' ), '' ),
				array( 'minify_js', 'toggle', __( 'Minify JavaScript files', 'vyntic-speed-optimizer' ) ),
				array( 'section', __( 'CSS', 'vyntic-speed-optimizer' ), '' ),
				array( 'minify_css', 'toggle', __( 'Minify CSS', 'vyntic-speed-optimizer' ) ),
				array( 'remove_unused_css', 'toggle', __( 'Remove unused CSS', 'vyntic-speed-optimizer' ), __( 'For every page, only the CSS rules it actually uses are inlined; full stylesheets load later. Eliminates render-blocking CSS. Calculated locally, no external service.', 'vyntic-speed-optimizer' ) ),
				array( 'full_css_load', 'select', __( 'Load full CSS', 'vyntic-speed-optimizer' ), '', array( 'interaction' => __( 'On user interaction (best score)', 'vyntic-speed-optimizer' ), 'onload' => __( 'After page load', 'vyntic-speed-optimizer' ) ) ),
				array( 'unused_css_safelist', 'textarea', __( 'Always keep these selectors', 'vyntic-speed-optimizer' ), __( 'Class/ID names, one per line, "*" wildcard allowed (e.g. slick-*). Use for things added by JavaScript that must look right before interaction.', 'vyntic-speed-optimizer' ) ),
				array( 'async_css', 'toggle', __( 'Load CSS asynchronously', 'vyntic-speed-optimizer' ), __( 'Alternative to "Remove unused CSS". Needs Critical CSS below or the page may flash unstyled.', 'vyntic-speed-optimizer' ) ),
				array( 'critical_css', 'code', __( 'Critical CSS', 'vyntic-speed-optimizer' ), __( 'Used with async CSS: styles for the above-the-fold area.', 'vyntic-speed-optimizer' ) ),
				array( 'css_exclude', 'textarea', __( 'Exclude stylesheets containing', 'vyntic-speed-optimizer' ), '' ),
				array( 'section', __( 'HTML', 'vyntic-speed-optimizer' ), '' ),
				array( 'minify_html', 'toggle', __( 'Minify HTML', 'vyntic-speed-optimizer' ) ),
			),
			'media'  => array(
				array( 'section', __( 'Lazy loading', 'vyntic-speed-optimizer' ), '' ),
				array( 'lazy_images', 'toggle', __( 'Lazy load images', 'vyntic-speed-optimizer' ) ),
				array( 'lazy_skip', 'number', __( 'Skip the first N images', 'vyntic-speed-optimizer' ), __( 'Images at the top of the page (logo, hero) must load immediately for a good LCP.', 'vyntic-speed-optimizer' ) ),
				array( 'lcp_priority', 'toggle', __( 'High priority for the main (LCP) image', 'vyntic-speed-optimizer' ), __( 'Adds fetchpriority="high" to the first image.', 'vyntic-speed-optimizer' ) ),
				array( 'lazy_iframes', 'toggle', __( 'Lazy load iframes', 'vyntic-speed-optimizer' ) ),
				array( 'youtube_facade', 'toggle', __( 'YouTube click-to-load', 'vyntic-speed-optimizer' ), __( 'Shows a thumbnail; the heavy YouTube player loads only when clicked.', 'vyntic-speed-optimizer' ) ),
				array( 'lazy_exclude', 'textarea', __( 'Never lazy load images containing', 'vyntic-speed-optimizer' ), '' ),
				array( 'section', __( 'Images', 'vyntic-speed-optimizer' ), '' ),
				array( 'add_dimensions', 'toggle', __( 'Add missing width/height', 'vyntic-speed-optimizer' ), __( 'Prevents layout shift (CLS).', 'vyntic-speed-optimizer' ) ),
				array( 'webp', 'toggle', __( 'Convert & serve WebP', 'vyntic-speed-optimizer' ), __( 'New uploads are converted automatically on your server. Originals are never changed.', 'vyntic-speed-optimizer' ) ),
				array( 'webp_quality', 'number', __( 'WebP quality (30 to 100)', 'vyntic-speed-optimizer' ) ),
				array( 'webp_bulk', 'webp_bulk', __( 'Bulk convert existing images', 'vyntic-speed-optimizer' ) ),
			),
			'fonts'  => array(
				array( 'section', __( 'Fonts', 'vyntic-speed-optimizer' ), '' ),
				array( 'font_display_swap', 'toggle', __( 'Font display: swap', 'vyntic-speed-optimizer' ), __( 'Text shows immediately while web fonts load.', 'vyntic-speed-optimizer' ) ),
				array( 'local_google_fonts', 'toggle', __( 'Host Google Fonts locally', 'vyntic-speed-optimizer' ), __( 'Downloads fonts to your server: no third-party connection, faster and GDPR-friendly.', 'vyntic-speed-optimizer' ) ),
				array( 'section', __( 'Resource hints', 'vyntic-speed-optimizer' ), '' ),
				array( 'link_prefetch', 'toggle', __( 'Instant page navigation', 'vyntic-speed-optimizer' ), __( 'Prefetches a page when the visitor hovers a link, so it opens instantly.', 'vyntic-speed-optimizer' ) ),
				array( 'preconnect', 'textarea', __( 'Preconnect to domains', 'vyntic-speed-optimizer' ), __( 'One per line, e.g. https://cdn.example.com', 'vyntic-speed-optimizer' ) ),
				array( 'preload', 'textarea', __( 'Preload files', 'vyntic-speed-optimizer' ), __( 'Full URLs of key fonts or the hero image, one per line.', 'vyntic-speed-optimizer' ) ),
			),
			'tweaks' => array(
				array( 'section', __( 'Remove WordPress bloat', 'vyntic-speed-optimizer' ), '' ),
				array( 'disable_emojis', 'toggle', __( 'Disable emojis script', 'vyntic-speed-optimizer' ) ),
				array( 'disable_embeds', 'toggle', __( 'Disable WordPress embeds', 'vyntic-speed-optimizer' ) ),
				array( 'disable_dashicons', 'toggle', __( 'Remove Dashicons for visitors', 'vyntic-speed-optimizer' ) ),
				array( 'remove_jquery_migrate', 'toggle', __( 'Remove jQuery Migrate', 'vyntic-speed-optimizer' ), __( 'Only if no plugin needs old jQuery code.', 'vyntic-speed-optimizer' ) ),
				array( 'remove_query_strings', 'toggle', __( 'Remove ?ver= from CSS/JS', 'vyntic-speed-optimizer' ) ),
				array( 'remove_wp_meta', 'toggle', __( 'Remove generator, WLW and shortlink tags', 'vyntic-speed-optimizer' ) ),
				array( 'disable_xmlrpc', 'toggle', __( 'Disable XML-RPC', 'vyntic-speed-optimizer' ) ),
				array( 'heartbeat', 'select', __( 'Heartbeat API', 'vyntic-speed-optimizer' ), '', array( 'default' => __( 'WordPress default', 'vyntic-speed-optimizer' ), 'reduce' => __( 'Reduce (60s) and off on the front end', 'vyntic-speed-optimizer' ), 'disable' => __( 'Disable (except post editor)', 'vyntic-speed-optimizer' ) ) ),
				array( 'section', __( 'Scope', 'vyntic-speed-optimizer' ), '' ),
				array( 'optimize_logged_in', 'toggle', __( 'Optimize for logged-in users too', 'vyntic-speed-optimizer' ), __( 'Off = admins always see the original site, which is safer while editing.', 'vyntic-speed-optimizer' ) ),
				array( 'exclude_urls', 'textarea', __( 'Never optimize these URLs', 'vyntic-speed-optimizer' ), __( 'One per line, partial match. Single pages can also be excluded from the editor sidebar.', 'vyntic-speed-optimizer' ) ),
			),
		);
	}

	private static function settings_form( $tab ) {
		$fields = self::fields();
		if ( empty( $fields[ $tab ] ) ) {
			return;
		}
		$s    = VSO_Settings::all();
		$open = false;
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-form">
			<?php wp_nonce_field( 'vso_save' ); ?>
			<input type="hidden" name="action" value="vso_save">
			<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>">
			<?php
			foreach ( $fields[ $tab ] as $field ) {
				if ( 'section' === $field[0] ) {
					if ( $open ) {
						echo '</div></section>';
					}
					echo '<section class="vso-panel"><header class="vso-panel-head"><div><h2>' . esc_html( $field[1] ) . '</h2>';
					if ( ! empty( $field[2] ) ) {
						echo '<p>' . esc_html( $field[2] ) . '</p>';
					}
					echo '</div></header><div class="vso-rows">';
					$open = true;
					continue;
				}
				list( $key, $type, $label ) = $field;
				$help  = isset( $field[3] ) ? $field[3] : '';
				$value = isset( $s[ $key ] ) ? $s[ $key ] : '';
				$id    = 'vso-' . $key;
				echo '<div class="vso-row vso-row--' . esc_attr( $type ) . '">';
				echo '<div class="vso-row-label"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
				if ( $help ) {
					echo '<p>' . esc_html( $help ) . '</p>';
				}
				echo '</div><div class="vso-row-control">';
				switch ( $type ) {
					case 'toggle':
						echo '<input type="hidden" name="vso[' . esc_attr( $key ) . ']" value="0">';
						echo '<label class="vso-switch"><input type="checkbox" id="' . esc_attr( $id ) . '" name="vso[' . esc_attr( $key ) . ']" value="1" ' . checked( ! empty( $value ), true, false ) . '><span></span></label>';
						break;
					case 'number':
						echo '<input type="number" min="0" class="vso-input vso-input--num" id="' . esc_attr( $id ) . '" name="vso[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '">';
						break;
					case 'textarea':
						echo '<textarea rows="4" class="vso-input code" id="' . esc_attr( $id ) . '" name="vso[' . esc_attr( $key ) . ']">' . esc_textarea( $value ) . '</textarea>';
						break;
					case 'code':
						echo '<textarea rows="8" class="vso-input code" id="' . esc_attr( $id ) . '" name="vso[' . esc_attr( $key ) . ']">' . esc_textarea( $value ) . '</textarea>';
						break;
					case 'select':
						echo '<select class="vso-input" id="' . esc_attr( $id ) . '" name="vso[' . esc_attr( $key ) . ']">';
						foreach ( $field[4] as $opt => $opt_label ) {
							echo '<option value="' . esc_attr( $opt ) . '" ' . selected( $value, $opt, false ) . '>' . esc_html( $opt_label ) . '</option>';
						}
						echo '</select>';
						break;
					case 'compat_detected':
						$found  = VSO_Compat::detected();
						$groups = VSO_Compat::groups();
						if ( ! $found ) {
							echo '<p class="vso-muted">' . esc_html__( 'No known cookie banner, slider, lazy-load or tracking plugin found. Scripts added by your theme or by hand are still matched.', 'vyntic-speed-optimizer' ) . '</p>';
						} else {
							echo '<ul class="vso-detected">';
							foreach ( $found as $group => $names ) {
								echo '<li><strong>' . esc_html( $groups[ $group ]['label'] ) . ':</strong> ' . esc_html( implode( ', ', array_unique( $names ) ) ) . '</li>';
							}
							echo '</ul>';
						}
						break;
					case 'webp_bulk':
						$stats = VSO_WebP::stats();
						echo '<div id="vso-webp-bulk" data-remaining="' . esc_attr( $stats['remaining'] ) . '">';
						echo '<div class="vso-progress"><span style="width:' . esc_attr( $stats['total'] ? round( $stats['converted'] / $stats['total'] * 100 ) : 100 ) . '%"></span></div>';
						echo '<p class="vso-muted" id="vso-webp-text">' . esc_html( sprintf( /* translators: 1: converted, 2: total */ __( '%1$d of %2$d images processed', 'vyntic-speed-optimizer' ), $stats['converted'], $stats['total'] ) ) . '</p>';
						echo '<button type="button" class="vso-btn vso-btn--ghost" id="vso-webp-run" ' . disabled( VSO_WebP::supported(), false, false ) . '>' . esc_html__( 'Convert all images', 'vyntic-speed-optimizer' ) . '</button>';
						echo '</div>';
						break;
				}
				echo '</div></div>';
			}
			if ( $open ) {
				echo '</div></section>';
			}
			?>
			<div class="vso-savebar">
				<span><?php esc_html_e( 'Saving clears the cache so changes show right away.', 'vyntic-speed-optimizer' ); ?></span>
				<button type="submit" class="vso-btn vso-btn--accent"><?php esc_html_e( 'Save changes', 'vyntic-speed-optimizer' ); ?></button>
			</div>
		</form>
		<?php
	}

	private static function tab_database() {
		$counts = VSO_Database::counts();
		?>
		<section class="vso-panel">
			<header class="vso-panel-head">
				<div>
					<h2><?php esc_html_e( 'Database cleanup', 'vyntic-speed-optimizer' ); ?></h2>
					<p><?php esc_html_e( 'Removes data WordPress no longer needs. Take a backup first if you are unsure.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
			</header>
			<div class="vso-rows">
				<?php foreach ( VSO_Database::items() as $key => $label ) : ?>
					<div class="vso-row vso-row--db">
						<div class="vso-row-label"><label><?php echo esc_html( $label ); ?></label></div>
						<div class="vso-row-control">
							<span class="vso-db-count" data-item="<?php echo esc_attr( $key ); ?>"><?php echo 'optimize' === $key ? '-' : esc_html( number_format_i18n( $counts[ $key ] ) ); ?></span>
							<button type="button" class="vso-btn vso-btn--ghost vso-db-clean" data-item="<?php echo esc_attr( $key ); ?>"><?php echo 'optimize' === $key ? esc_html__( 'Optimize', 'vyntic-speed-optimizer' ) : esc_html__( 'Clean', 'vyntic-speed-optimizer' ); ?></button>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
		<section class="vso-panel">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-row vso-row--inline">
				<?php wp_nonce_field( 'vso_save' ); ?>
				<input type="hidden" name="action" value="vso_save">
				<input type="hidden" name="tab" value="database">
				<input type="hidden" name="vso[db_auto_clean]" value="0">
				<div class="vso-row-label">
					<label for="vso-db-auto"><?php esc_html_e( 'Automatic weekly cleanup', 'vyntic-speed-optimizer' ); ?></label>
					<p><?php esc_html_e( 'Revisions, auto drafts, spam and trashed comments and expired transients, every week.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
				<div class="vso-row-control">
					<label class="vso-switch"><input type="checkbox" id="vso-db-auto" name="vso[db_auto_clean]" value="1" <?php checked( VSO_Settings::enabled( 'db_auto_clean' ) ); ?>><span></span></label>
					<button type="submit" class="vso-btn vso-btn--ghost"><?php esc_html_e( 'Save', 'vyntic-speed-optimizer' ); ?></button>
				</div>
			</form>
		</section>
		<?php
	}

	/**
	 * AIza....UiDk style preview of a secret.
	 */
	private static function mask( $key ) {
		$key = (string) $key;
		if ( strlen( $key ) <= 10 ) {
			return str_repeat( '*', 8 );
		}
		return substr( $key, 0, 4 ) . str_repeat( "\u{2022}", 12 ) . substr( $key, -4 );
	}

	private static function tab_tools() {
		$level  = VSO_Settings::get( 'level' );
		$paused = 'off' === $level;
		?>
		<section class="vso-panel vso-pause<?php echo $paused ? ' is-paused' : ''; ?>" id="vso-pause">
			<header class="vso-panel-head">
				<div>
					<h2><?php esc_html_e( 'Pause optimizations', 'vyntic-speed-optimizer' ); ?></h2>
					<p><?php esc_html_e( 'For troubleshooting: switch off caching and every optimization at once, so visitors get the original site. Resuming applies the speed profile you pick.', 'vyntic-speed-optimizer' ); ?></p>
				</div>
			</header>
			<div class="vso-pause-body">
				<?php if ( $paused ) : ?>
					<p class="vso-pause-state"><?php echo self::icon( 'pause' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Paused right now.', 'vyntic-speed-optimizer' ); ?></p>
					<div class="vso-pause-actions">
						<?php
						self::preset_form( 'balanced', __( 'Resume with Balanced', 'vyntic-speed-optimizer' ), 'vso-btn--accent' );
						self::preset_form( 'safe', __( 'Resume with Safe', 'vyntic-speed-optimizer' ), 'vso-btn--ghost' );
						?>
					</div>
				<?php else : ?>
					<p class="vso-pause-state is-on">
						<?php
						/* translators: %s: profile name */
						echo esc_html( sprintf( __( 'Running with the %s profile.', 'vyntic-speed-optimizer' ), self::level_name( $level ) ) );
						?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-inline" onsubmit="return confirm('<?php echo esc_js( __( 'Pause all optimizations and caching? Your custom settings are replaced; you pick a profile again when you resume.', 'vyntic-speed-optimizer' ) ); ?>');">
						<?php wp_nonce_field( 'vso_preset' ); ?>
						<input type="hidden" name="action" value="vso_preset">
						<input type="hidden" name="level" value="off">
						<button type="submit" class="vso-btn vso-btn--danger"><?php echo self::icon( 'pause' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Pause everything', 'vyntic-speed-optimizer' ); ?></button>
					</form>
				<?php endif; ?>
			</div>
		</section>

		<div class="vso-split">
			<section class="vso-panel">
				<header class="vso-panel-head">
					<div>
						<h2><?php esc_html_e( 'PageSpeed API key', 'vyntic-speed-optimizer' ); ?> <span class="vso-tag vso-tag--muted"><?php esc_html_e( 'optional', 'vyntic-speed-optimizer' ); ?></span></h2>
						<p><?php esc_html_e( 'The score test works without a key, but Google limits anonymous requests. A free key from Google Cloud (PageSpeed Insights API) removes the limit.', 'vyntic-speed-optimizer' ); ?></p>
					</div>
				</header>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'vso_save' ); ?>
					<input type="hidden" name="action" value="vso_save">
					<input type="hidden" name="tab" value="tools">
					<?php $key = (string) VSO_Settings::get( 'psi_api_key' ); ?>
					<?php if ( '' !== $key ) : ?>
						<div class="vso-key" id="vso-key">
							<span class="vso-key-mask"><?php echo esc_html( self::mask( $key ) ); ?></span>
							<span class="vso-tag vso-tag--ok"><?php esc_html_e( 'Key saved', 'vyntic-speed-optimizer' ); ?></span>
							<button type="button" class="vso-btn vso-btn--ghost" id="vso-key-change"><?php esc_html_e( 'Replace key', 'vyntic-speed-optimizer' ); ?></button>
							<button type="submit" class="vso-link-danger vso-key-remove" name="vso_remove_key" value="1" onclick="return confirm('<?php echo esc_js( __( 'Remove the saved API key?', 'vyntic-speed-optimizer' ) ); ?>');"><?php esc_html_e( 'Remove', 'vyntic-speed-optimizer' ); ?></button>
						</div>
					<?php endif; ?>
					<div class="vso-key-edit" id="vso-key-edit"<?php echo '' !== $key ? ' hidden' : ''; ?>>
						<input type="password" class="vso-input" name="vso[psi_api_key]" value="" autocomplete="new-password" spellcheck="false" placeholder="<?php esc_attr_e( 'Paste your API key', 'vyntic-speed-optimizer' ); ?>">
						<button type="submit" class="vso-btn vso-btn--accent"><?php esc_html_e( 'Save key', 'vyntic-speed-optimizer' ); ?></button>
					</div>
				</form>
			</section>

			<section class="vso-panel">
				<header class="vso-panel-head"><div><h2><?php esc_html_e( 'Weekly PageSpeed check', 'vyntic-speed-optimizer' ); ?></h2></div></header>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-row vso-row--inline">
					<?php wp_nonce_field( 'vso_save' ); ?>
					<input type="hidden" name="action" value="vso_save">
					<input type="hidden" name="tab" value="tools">
					<input type="hidden" name="vso[psi_weekly]" value="0">
					<div class="vso-row-label">
						<label for="vso-psi-weekly"><?php esc_html_e( 'Test the home page every week', 'vyntic-speed-optimizer' ); ?></label>
						<p>
							<?php
							$next = wp_next_scheduled( VSO_PSI::HOOK );
							echo $next
								? esc_html( sprintf( /* translators: %s: date and time */ __( 'Mobile and desktop, saved to the report. Next check: %s', 'vyntic-speed-optimizer' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $next ) ) )
								: esc_html__( 'Mobile and desktop, saved to the report.', 'vyntic-speed-optimizer' );
							?>
						</p>
					</div>
					<div class="vso-row-control">
						<label class="vso-switch"><input type="checkbox" id="vso-psi-weekly" name="vso[psi_weekly]" value="1" <?php checked( VSO_Settings::enabled( 'psi_weekly' ) ); ?>><span></span></label>
						<button type="submit" class="vso-btn vso-btn--ghost"><?php esc_html_e( 'Save', 'vyntic-speed-optimizer' ); ?></button>
					</div>
				</form>
			</section>
		</div>

		<div class="vso-split">
			<section class="vso-panel">
				<header class="vso-panel-head">
					<div>
						<h2><?php esc_html_e( 'Export and import', 'vyntic-speed-optimizer' ); ?></h2>
						<p><?php esc_html_e( 'Copy your exact setup to another site. The API key is never exported.', 'vyntic-speed-optimizer' ); ?></p>
					</div>
				</header>
				<p><a class="vso-btn vso-btn--ghost" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vso_export' ), 'vso_export' ) ); ?>"><?php esc_html_e( 'Download settings (.json)', 'vyntic-speed-optimizer' ); ?></a></p>
				<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="vso-import">
					<?php wp_nonce_field( 'vso_import' ); ?>
					<input type="hidden" name="action" value="vso_import">
					<input type="file" name="vso_file" accept=".json,application/json" required>
					<button type="submit" class="vso-btn vso-btn--ghost"><?php esc_html_e( 'Import', 'vyntic-speed-optimizer' ); ?></button>
				</form>
			</section>

			<section class="vso-panel">
				<header class="vso-panel-head">
					<div>
						<h2><?php esc_html_e( 'Reset', 'vyntic-speed-optimizer' ); ?></h2>
						<p><?php esc_html_e( 'Go back to the recommended defaults.', 'vyntic-speed-optimizer' ); ?></p>
					</div>
				</header>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Reset all settings?', 'vyntic-speed-optimizer' ) ); ?>');">
					<?php wp_nonce_field( 'vso_reset' ); ?>
					<input type="hidden" name="action" value="vso_reset">
					<button type="submit" class="vso-btn vso-btn--ghost"><?php esc_html_e( 'Reset to recommended defaults', 'vyntic-speed-optimizer' ); ?></button>
				</form>
			</section>
		</div>

		<section class="vso-panel">
			<header class="vso-panel-head"><div><h2><?php esc_html_e( 'Troubleshooting tips', 'vyntic-speed-optimizer' ); ?></h2></div></header>
			<ol class="vso-tips">
				<li><?php esc_html_e( 'Before trusting a change, check pages while logged in with ?vso_preview=1 at the end of the URL (or "Preview optimized page" in the admin bar). Admins normally see the original site.', 'vyntic-speed-optimizer' ); ?></li>
				<li><?php esc_html_e( 'Something looks broken? Open the page with ?vso_off=1 at the end of the URL to see it without any optimization.', 'vyntic-speed-optimizer' ); ?></li>
				<li><?php esc_html_e( 'A slider, menu or popup only works after scrolling? Add part of its script URL to "Do not delay scripts containing".', 'vyntic-speed-optimizer' ); ?></li>
				<li><?php esc_html_e( 'Styles missing before the first scroll with "Remove unused CSS"? Add the class names to "Always keep these selectors".', 'vyntic-speed-optimizer' ); ?></li>
				<li><?php esc_html_e( 'Response header "X-Vyntic-Cache: HIT" means the page came from cache.', 'vyntic-speed-optimizer' ); ?></li>
			</ol>
		</section>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Handlers
	 * ------------------------------------------------------------------- */

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'vyntic-speed-optimizer' ), 403 );
		}
		check_admin_referer( $nonce );
	}

	private static function back( $tab, $msg ) {
		wp_safe_redirect( self::url( $tab, array( 'vso_msg' => $msg ) ) );
		exit;
	}

	public static function handle_save() {
		self::guard( 'vso_save' );
		$tab    = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'dashboard';
		$input  = isset( $_POST['vso'] ) && is_array( $_POST['vso'] ) ? wp_unslash( $_POST['vso'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized in VSO_Settings::sanitize().
		$values = array_intersect_key( $input, VSO_Settings::defaults() );

		// The saved API key is never printed back, so an empty field keeps it.
		if ( ! empty( $_POST['vso_remove_key'] ) ) {
			$values['psi_api_key'] = '';
		} elseif ( isset( $values['psi_api_key'] ) && '' === trim( (string) $values['psi_api_key'] ) ) {
			unset( $values['psi_api_key'] );
		}

		// Anything that changes optimization behaviour turns the level into "custom".
		$presets  = VSO_Settings::presets();
		$level    = VSO_Settings::get( 'level' );
		$compare  = isset( $presets[ $level ] ) ? $presets[ $level ] : array();
		foreach ( $values as $key => $value ) {
			if ( isset( $compare[ $key ] ) && (string) $compare[ $key ] !== (string) $value ) {
				$values['level'] = 'custom';
				break;
			}
		}
		VSO_Settings::update( $values );
		self::back( $tab, 'saved' );
	}

	public static function handle_preset() {
		self::guard( 'vso_preset' );
		$level = isset( $_POST['level'] ) ? sanitize_key( wp_unslash( $_POST['level'] ) ) : 'balanced';
		VSO_Settings::apply_preset( $level );
		self::back( 'dashboard', 'off' === $level ? 'paused' : 'preset' );
	}

	public static function handle_clear() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'vyntic-speed-optimizer' ), 403 );
		}
		check_admin_referer( 'vso_clear' );
		$url = isset( $_GET['vso_url'] ) ? esc_url_raw( wp_unslash( $_GET['vso_url'] ) ) : '';
		if ( $url ) {
			VSO_Page_Cache::purge_url( $url );
			wp_safe_redirect( $url );
			exit;
		}
		VSO_Page_Cache::purge_all();
		VSO_Utils::rrmdir( VSO_CACHE_DIR . 'assets' );
		VSO_Preload::schedule();
		$referer = wp_get_referer();
		if ( $referer && false === strpos( $referer, self::SLUG ) ) {
			wp_safe_redirect( add_query_arg( 'vso_cleared', 1, $referer ) );
			exit;
		}
		self::back( 'dashboard', 'cleared' );
	}

	public static function handle_preload() {
		self::guard( 'vso_preload' );
		VSO_Preload::schedule();
		self::back( 'dashboard', 'preload' );
	}

	public static function handle_export() {
		self::guard( 'vso_export' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=vyntic-speed-settings-' . gmdate( 'Y-m-d' ) . '.json' );
		$settings = VSO_Settings::all();
		unset( $settings['psi_api_key'] );
		echo wp_json_encode( array( 'vyntic_speed_optimizer' => VSO_VERSION, 'settings' => $settings ), JSON_PRETTY_PRINT );
		exit;
	}

	public static function handle_import() {
		self::guard( 'vso_import' );
		if ( empty( $_FILES['vso_file']['tmp_name'] ) || ! is_uploaded_file( $_FILES['vso_file']['tmp_name'] ) ) { // phpcs:ignore
			self::back( 'tools', 'badfile' );
		}
		$data = json_decode( (string) file_get_contents( $_FILES['vso_file']['tmp_name'] ), true ); // phpcs:ignore
		if ( ! is_array( $data ) || empty( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
			self::back( 'tools', 'badfile' );
		}
		VSO_Settings::update( array_intersect_key( $data['settings'], VSO_Settings::defaults() ) );
		self::back( 'tools', 'imported' );
	}

	public static function handle_reset() {
		self::guard( 'vso_reset' );
		delete_option( VSO_Settings::OPTION );
		VSO_Settings::update( array_merge( VSO_Settings::defaults(), VSO_Settings::presets()['balanced'], array( 'level' => 'balanced' ) ) );
		self::back( 'tools', 'reset' );
	}

	/* ---------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------- */

	private static function ajax_guard() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'vso_ajax', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'vyntic-speed-optimizer' ) ), 403 );
		}
	}

	public static function ajax_psi() {
		self::ajax_guard();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore -- PageSpeed Insights can take up to a minute.
		}
		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url( '/' );
		$strategy = isset( $_POST['strategy'] ) && 'desktop' === $_POST['strategy'] ? 'desktop' : 'mobile';

		$run    = isset( $_POST['run'] ) ? sanitize_key( wp_unslash( $_POST['run'] ) ) : (string) time();
		$result = VSO_PSI::run( $url, $strategy );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		VSO_PSI::save( $url, $strategy, $result, $run, 'manual' );
		wp_send_json_success(
			array(
				'result' => $result,
				'state'  => VSO_PSI::state(),
			)
		);
	}

	public static function ajax_webp() {
		self::ajax_guard();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore
		}
		if ( ! empty( $_POST['reset'] ) ) {
			VSO_WebP::reset();
		}
		wp_send_json_success( VSO_WebP::bulk_batch( 5 ) );
	}

	public static function ajax_db() {
		self::ajax_guard();
		$item = isset( $_POST['item'] ) ? sanitize_key( wp_unslash( $_POST['item'] ) ) : '';
		if ( ! array_key_exists( $item, VSO_Database::items() ) ) {
			wp_send_json_error( array( 'message' => 'Unknown item' ) );
		}
		$removed = VSO_Database::clean( $item );
		$counts  = VSO_Database::counts();
		wp_send_json_success(
			array(
				'removed' => $removed,
				'count'   => isset( $counts[ $item ] ) ? $counts[ $item ] : 0,
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Notices & meta box
	 * ------------------------------------------------------------------- */

	public static function notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( get_transient( 'vso_activated' ) ) {
			delete_transient( 'vso_activated' );
			echo '<div class="notice notice-success is-dismissible"><p><strong>' . esc_html__( 'Vyntic Speed Optimizer is active with the Balanced level.', 'vyntic-speed-optimizer' ) . '</strong> <a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open the dashboard and test your score', 'vyntic-speed-optimizer' ) . '</a></p></div>';
		}

		$active = array();
		foreach ( self::CONFLICTS as $file => $name ) {
			if ( is_plugin_active( $file ) ) {
				$active[] = $name;
			}
		}
		if ( $active ) {
			/* translators: %s: plugin names */
			echo '<div class="notice notice-warning"><p>' . esc_html( sprintf( __( 'Vyntic Speed Optimizer: please deactivate %s. Running two speed/cache plugins at once usually breaks pages or slows them down.', 'vyntic-speed-optimizer' ), implode( ', ', $active ) ) ) . '</p></div>';
		}

		if ( VSO_Settings::enabled( 'page_cache' ) ) {
			if ( VSO_Page_Cache::dropin_conflict() ) {
				echo '<div class="notice notice-warning"><p>' . esc_html__( 'Vyntic Speed Optimizer: wp-content/advanced-cache.php belongs to another cache plugin, so page cache cannot start. Deactivate that plugin, delete the file, then save Vyntic settings again.', 'vyntic-speed-optimizer' ) . '</p></div>';
			} elseif ( ! ( defined( 'WP_CACHE' ) && WP_CACHE ) && ! VSO_Page_Cache::set_wp_cache( true ) ) {
				echo '<div class="notice notice-warning"><p>' . wp_kses( __( 'Vyntic Speed Optimizer: could not edit wp-config.php. Add <code>define( \'WP_CACHE\', true );</code> near the top of wp-config.php to turn on page cache.', 'vyntic-speed-optimizer' ), array( 'code' => array() ) ) . '</p></div>';
			}
		}
	}

	public static function meta_box() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$types = get_post_types( array( 'public' => true ) );
		unset( $types['attachment'] );
		add_meta_box( 'vso-meta', __( 'Vyntic Speed', 'vyntic-speed-optimizer' ), array( __CLASS__, 'render_meta_box' ), array_values( $types ), 'side', 'low' );
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'vso_meta', 'vso_meta_nonce' );
		?>
		<p><label><input type="checkbox" name="vso_disable" value="1" <?php checked( (bool) get_post_meta( $post->ID, '_vso_disable', true ) ); ?>> <?php esc_html_e( 'Disable optimizations on this page', 'vyntic-speed-optimizer' ); ?></label></p>
		<p><label><input type="checkbox" name="vso_no_cache" value="1" <?php checked( (bool) get_post_meta( $post->ID, '_vso_no_cache', true ) ); ?>> <?php esc_html_e( 'Never cache this page', 'vyntic-speed-optimizer' ); ?></label></p>
		<?php
	}

	public static function save_meta_box( $post_id ) {
		if ( ! isset( $_POST['vso_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vso_meta_nonce'] ) ), 'vso_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		foreach ( array( 'vso_disable' => '_vso_disable', 'vso_no_cache' => '_vso_no_cache' ) as $field => $meta ) {
			if ( ! empty( $_POST[ $field ] ) ) {
				update_post_meta( $post_id, $meta, 1 );
			} else {
				delete_post_meta( $post_id, $meta );
			}
		}
	}
}
