VYNTIC STUDIO: SOCIAL MEDIA PACK, WEEK 2 (OCT 19 TO OCT 25)
Part of the 30-day plan (12 Oct to 10 Nov 2026)

THIS WEEK
Day 08  Mon 19 Oct  Carousel: AI Overviews are taking your clicks: what to do now
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 08 Mon Oct 19 Carousel AI Overviews are taking your clicks
         LinkedIn        9:00 AM ET (6:00 PM PKT)  upload linkedin-carousel.pdf
         Instagram       12:00 PM ET (9:00 PM PKT)  upload slide-1.png to slide-7.png
         Facebook        1:00 PM ET (10:00 PM PKT)  upload slide-1.png to slide-7.png
Day 09  Tue 20 Oct  Pin: How to Get Recommended by ChatGPT
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 09 Tue Oct 20 Pin How to Get Recommended by ChatGPT
         Pinterest       10:00 AM ET (7:00 PM PKT)  upload pin.png
Day 10  Wed 21 Oct  Reel: Is ChatGPT recommending your business?
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 10 Wed Oct 21 Reel Is ChatGPT recommending your business
         LinkedIn        9:00 AM ET (6:00 PM PKT)  upload reel-voiceover.mp4
         YouTube Shorts  11:00 AM ET (8:00 PM PKT)  upload reel-voiceover.mp4
         Instagram       12:00 PM ET (9:00 PM PKT)  upload reel-voiceover.mp4 + reel-cover.jpg
         Facebook        1:00 PM ET (10:00 PM PKT)  upload reel-voiceover.mp4
Day 11  Thu 22 Oct  Pin: Local SEO Guide for Small Businesses
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 11 Thu Oct 22 Pin Local SEO Guide for Small Businesses
         Pinterest       10:00 AM ET (7:00 PM PKT)  upload pin.png
Day 12  Fri 23 Oct  Carousel: SEO vs GEO in 2026: what actually changed
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 12 Fri Oct 23 Carousel SEO vs GEO in 2026 what actually changed
         LinkedIn        9:00 AM ET (6:00 PM PKT)  upload linkedin-carousel.pdf
         Instagram       12:00 PM ET (9:00 PM PKT)  upload slide-1.png to slide-7.png
         Facebook        1:00 PM ET (10:00 PM PKT)  upload slide-1.png to slide-7.png
Day 13  Sat 24 Oct  Spotlight: Service spotlight: local SEO and lead follow-up
         Folder: Media/Week 2 (Oct 19 to Oct 25)/Day 13 Sat Oct 24 Spotlight Service spotlight local SEO and lead
         LinkedIn        9:00 AM ET (6:00 PM PKT)  upload spotlight.png
         Instagram       12:00 PM ET (9:00 PM PKT)  upload spotlight.png
         Facebook        1:00 PM ET (10:00 PM PKT)  upload spotlight.png
Day 14  Sun 25 Oct  Engagement only (no post)

The calendar for all 30 days is included: vyntic-30-day-calendar.xlsx

HOW TO USE THIS PACK
1. Open vyntic-30-day-calendar.xlsx. The "Calendar" tab has one row per upload: date, platform,
   time (US Eastern and Pakistan), files, caption, link and tips.
2. Open the day's folder inside Media. Upload the files listed for that platform.
3. Copy the caption from captions.txt in the same folder (or from the Calendar tab) and paste it.
4. After posting, set Status to Posted in the Calendar tab and paste the post link.
5. Save time: schedule the whole week on Sunday. Meta Business Suite (Instagram + Facebook),
   LinkedIn's scheduler, YouTube Studio and Pinterest's scheduler are all free.

WEEKLY RHYTHM
Mon  Carousel          LinkedIn (PDF), Instagram, Facebook
Tue  Pinterest pin     Pinterest
Wed  Reel              LinkedIn, YouTube Shorts, Instagram, Facebook
Thu  Pinterest pin     Pinterest
Fri  Carousel          LinkedIn (PDF), Instagram, Facebook
Sat  Service spotlight LinkedIn, Instagram, Facebook
Sun  No post. 15 minutes of engagement only.

POSTING TIMES (US Eastern, Pakistan time in brackets)
LinkedIn 9:00 AM | Pinterest 10:00 AM | YouTube Shorts 11:00 AM | Instagram 12:00 PM | Facebook 1:00 PM
Until 31 Oct Pakistan is 9 hours ahead (9:00 AM ET = 6:00 PM PKT).
From 2 Nov (US clocks change on 1 Nov) Pakistan is 10 hours ahead (9:00 AM ET = 7:00 PM PKT).
captions.txt and the Calendar already show the right Pakistan time for each day.

FILES IN EACH DAY FOLDER
captions.txt           Caption, time, link and tip for every platform that day
slide-1.png ...        Carousel slides, 1080 x 1350. Upload in number order (Instagram, Facebook)
linkedin-carousel.pdf  Same slides as one PDF. On LinkedIn choose "Add a document"
pin.png                Pinterest pin, 1000 x 1500. Paste the link in the pin's "Link" field
reel-voiceover.mp4     Reel with English voiceover and music, 1080 x 1920 (recommended)
reel-silent.mp4        Same reel with music only
reel-cover.jpg         Cover image for the reel (choose it as the cover / thumbnail)
spotlight.png          Service spotlight image, 1080 x 1350

DAILY 15-MINUTE ENGAGEMENT (every day)
- Reply to every comment and DM, especially in the first hour after a post.
- Comment helpfully on 5 posts from small business owners, marketers and WordPress users.
- Answer 1 question in a Facebook group, Quora or Reddit; link a vyntic.studio article only when it helps.
- When someone comments a keyword (SPEED, AI, CHECKOUT), reply and send the link by DM the same day.

BEFORE YOU POST
- Open the link once to make sure the page is live.
- Watch reel-voiceover.mp4 once with sound.
- Instagram captions say "Link in bio": point the bio link to the page named in that day's captions.txt.
- Numbers in the posts come from public sources (Ahrefs, Google, WordPress.org) and the prices on
  vyntic.studio. Only replace them with client results if the results are real.

OUR SERVICES IN THIS PLAN
Service spotlights (Saturdays):
  17 Oct  Website design and development        vyntic.studio/services/web-design/
  24 Oct  Local SEO + Google Business Profile    vyntic.studio/services/local-seo/
          + GoHighLevel lead follow-up
  31 Oct  Website redesign and migration          vyntic.studio/services/website-redesign/
  07 Nov  WordPress, WooCommerce and Shopify      vyntic.studio/services/wordpress-development/
Also promoted at the end of posts: care plans (Day 5), AI search visibility (Days 8, 26), SEO services
(Day 12), free audit (Day 15), speed optimization (Day 17), Google Business Profile optimization (Day 19),
landing pages (Day 22), online stores (Day 24), website cost calculator (Day 29), free plugins (Days 1, 3, 4).
Every Pinterest pin description also names the matching service.
