VYNTIC STUDIO: SOCIAL MEDIA PACK, WEEK 5 (NOV 09 TO NOV 10)
Part of the 30-day plan (12 Oct to 10 Nov 2026)

THIS WEEK
Day 29  Mon 09 Nov  Reel: How much does a website cost in 2026?
         Folder: Media/Week 5 (Nov 09 to Nov 10)/Day 29 Mon Nov 09 Reel How much does a website cost in 2026
         LinkedIn        9:00 AM ET (7:00 PM PKT)  upload reel-voiceover.mp4
         YouTube Shorts  11:00 AM ET (9:00 PM PKT)  upload reel-voiceover.mp4
         Instagram       12:00 PM ET (10:00 PM PKT)  upload reel-voiceover.mp4 + reel-cover.jpg
         Facebook        1:00 PM ET (11:00 PM PKT)  upload reel-voiceover.mp4
Day 30  Tue 10 Nov  Pin: How Much Does a Website Redesign Cost?
         Folder: Media/Week 5 (Nov 09 to Nov 10)/Day 30 Tue Nov 10 Pin How Much Does a Website Redesign Cost
         Pinterest       10:00 AM ET (8:00 PM PKT)  upload pin.png

The calendar for all 30 days is included: vyntic-30-day-calendar.xlsx

HOW TO USE THIS PACK
1. Open vyntic-30-day-calendar.xlsx. The "Calendar" tab has one row per upload: date, platform,
   time (US Eastern and Pakistan), files, caption, link and tips.
2. Open the day's folder inside Media. Upload the files listed for that platform.
3. Copy the caption from captions.txt in the same folder (or from the Calendar tab) and paste it.
4. After posting, set Status to Posted in the Calendar tab and paste the post link.
5. Save time: schedule the whole week on Sunday. Meta Business Suite (Instagram + Facebook),
   LinkedIn's scheduler, YouTube Studio and Pinterest's scheduler are all free.

WEEKLY RHYTHM
Mon  Carousel          LinkedIn (PDF), Instagram, Facebook
Tue  Pinterest pin     Pinterest
Wed  Reel              LinkedIn, YouTube Shorts, Instagram, Facebook
Thu  Pinterest pin     Pinterest
Fri  Carousel          LinkedIn (PDF), Instagram, Facebook
Sat  Service spotlight LinkedIn, Instagram, Facebook
Sun  No post. 15 minutes of engagement only.

POSTING TIMES (US Eastern, Pakistan time in brackets)
LinkedIn 9:00 AM | Pinterest 10:00 AM | YouTube Shorts 11:00 AM | Instagram 12:00 PM | Facebook 1:00 PM
Until 31 Oct Pakistan is 9 hours ahead (9:00 AM ET = 6:00 PM PKT).
From 2 Nov (US clocks change on 1 Nov) Pakistan is 10 hours ahead (9:00 AM ET = 7:00 PM PKT).
captions.txt and the Calendar already show the right Pakistan time for each day.

FILES IN EACH DAY FOLDER
captions.txt           Caption, time, link and tip for every platform that day
slide-1.png ...        Carousel slides, 1080 x 1350. Upload in number order (Instagram, Facebook)
linkedin-carousel.pdf  Same slides as one PDF. On LinkedIn choose "Add a document"
pin.png                Pinterest pin, 1000 x 1500. Paste the link in the pin's "Link" field
reel-voiceover.mp4     Reel with English voiceover and music, 1080 x 1920 (recommended)
reel-silent.mp4        Same reel with music only
reel-cover.jpg         Cover image for the reel (choose it as the cover / thumbnail)
spotlight.png          Service spotlight image, 1080 x 1350

DAILY 15-MINUTE ENGAGEMENT (every day)
- Reply to every comment and DM, especially in the first hour after a post.
- Comment helpfully on 5 posts from small business owners, marketers and WordPress users.
- Answer 1 question in a Facebook group, Quora or Reddit; link a vyntic.studio article only when it helps.
- When someone comments a keyword (SPEED, AI, CHECKOUT), reply and send the link by DM the same day.

BEFORE YOU POST
- Open the link once to make sure the page is live.
- Watch reel-voiceover.mp4 once with sound.
- Instagram captions say "Link in bio": point the bio link to the page named in that day's captions.txt.
- Numbers in the posts come from public sources (Ahrefs, Google, WordPress.org) and the prices on
  vyntic.studio. Only replace them with client results if the results are real.

OUR SERVICES IN THIS PLAN
Service spotlights (Saturdays):
  17 Oct  Website design and development        vyntic.studio/services/web-design/
  24 Oct  Local SEO + Google Business Profile    vyntic.studio/services/local-seo/
          + GoHighLevel lead follow-up
  31 Oct  Website redesign and migration          vyntic.studio/services/website-redesign/
  07 Nov  WordPress, WooCommerce and Shopify      vyntic.studio/services/wordpress-development/
Also promoted at the end of posts: care plans (Day 5), AI search visibility (Days 8, 26), SEO services
(Day 12), free audit (Day 15), speed optimization (Day 17), Google Business Profile optimization (Day 19),
landing pages (Day 22), online stores (Day 24), website cost calculator (Day 29), free plugins (Days 1, 3, 4).
Every Pinterest pin description also names the matching service.
