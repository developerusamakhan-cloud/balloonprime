<?php
/**
 * Ready-made service and industry pages.
 *
 * The copy lives in inc/data/landing.json (plain text, easy to edit).
 * Each page template in page-templates/ (e.g. "Service: Local SEO")
 * renders one entry. Text you add in the page editor appears after the
 * "What you get" section, so you can add extra detail without touching code.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All landing page data, or one entry by key.
 *
 * @param string|null $key Entry key, e.g. 'local-seo'.
 * @return array|null
 */
function vyntic_landing( $key = null ) {
	static $data = null;
	if ( null === $data ) {
		$file = VYNTIC_DIR . '/inc/data/landing.json';
		$raw  = file_exists( $file ) ? file_get_contents( $file ) : '{}'; // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = apply_filters( 'vyntic_landing_data', (array) json_decode( $raw, true ) );
	}
	if ( null === $key ) {
		return $data;
	}
	return isset( $data[ $key ] ) ? $data[ $key ] : null;
}

/** Template file for a landing key. */
function vyntic_landing_template( $key ) {
	$entry = vyntic_landing( $key );
	if ( ! $entry ) {
		return '';
	}
	return 'page-templates/' . ( 'industry' === $entry['kind'] ? 'industry-' : 'service-' ) . $key . '.php';
}

/** URL of the page using a landing key's template (or a page with that slug). */
function vyntic_landing_url( $key ) {
	$url = vyntic_template_url( vyntic_landing_template( $key ) );
	return $url ? $url : vyntic_page_url( $key );
}

/**
 * Service links: prefer a page that uses the matching ready-made template.
 */
add_filter( 'vyntic_services', function ( $services ) {
	foreach ( $services as &$service ) {
		if ( vyntic_landing( $service['page'] ) ) {
			$url = vyntic_template_url( vyntic_landing_template( $service['page'] ) );
			if ( $url ) {
				$service['url'] = $url;
			}
		}
	}
	return $services;
}, 20 );

/**
 * Industry pages that exist, as array( label, url ).
 *
 * @return array
 */
function vyntic_industry_links() {
	$out = array();
	foreach ( vyntic_landing() as $key => $d ) {
		if ( 'industry' !== $d['kind'] || ! empty( $d['group'] ) ) {
			continue;
		}
		$url = vyntic_template_url( vyntic_landing_template( $key ) );
		if ( $url ) {
			$out[] = array( $d['label'], $url );
		}
	}
	return $out;
}

/**
 * Render a long-form article from inc/data/articles.json straight into the template,
 * with anchored headings and a contents list. Links use the same {{key|text}} tokens.
 *
 * @param string $key   Article key.
 * @param string $title Optional section heading above the article.
 */
function vyntic_render_article( $key, $title = '' ) {
	if ( ! function_exists( 'vyntic_setup_articles' ) ) {
		return;
	}
	$articles = vyntic_setup_articles();
	if ( empty( $articles[ $key ]['body'] ) ) {
		return;
	}
	$body   = $articles[ $key ]['body'];
	$toc    = array();
	$html   = '';
	$first  = true;
	$in_faq = false; // Inside a questions section: h3 + answer become accordion items.
	$list   = false;
	$item   = false;
	$close  = function () use ( &$html, &$list, &$item ) {
		if ( $item ) {
			$html .= '</details>';
			$item  = false;
		}
		if ( $list ) {
			$html .= '</div>';
			$list  = false;
		}
	};
	foreach ( $body as $block ) {
		list( $type, $value ) = $block;
		if ( 'h2' === $type ) {
			$close();
			$in_faq = (bool) preg_match( '/^(frequently asked questions|questions\b)/i', $value );
			$id     = sanitize_title( $value );
			$toc[]  = array( $id, $value );
			$html  .= '<h2 id="' . esc_attr( $id ) . '">' . esc_html( $value ) . '</h2>';
		} elseif ( 'h3' === $type && $in_faq ) {
			if ( $item ) {
				$html .= '</details>';
			}
			if ( ! $list ) {
				$html .= '<div class="faq__list faq__list--inline">';
				$list  = true;
			}
			$html .= '<details class="faq__item"><summary>' . esc_html( $value ) . '<span class="faq__icon" aria-hidden="true"></span></summary>';
			$item  = true;
		} elseif ( 'h3' === $type ) {
			$html .= '<h3>' . esc_html( $value ) . '</h3>';
		} elseif ( 'ul' === $type || 'ol' === $type ) {
			$html .= '<' . $type . '>';
			foreach ( $value as $li ) {
				$html .= '<li>' . vyntic_setup_inline( $li ) . '</li>';
			}
			$html .= '</' . $type . '>';
		} else {
			$html .= '<p' . ( $first ? ' class="guide__lead"' : '' ) . '>' . vyntic_setup_inline( $value ) . '</p>';
			$first = false;
		}
	}
	$close();
	if ( ! empty( $articles[ $key ]['faq'] ) ) {
		$html .= '<h2 id="faq">' . esc_html__( 'Frequently asked questions', 'vyntic' ) . '</h2><div class="faq__list faq__list--inline">';
		foreach ( $articles[ $key ]['faq'] as $q ) {
			$html .= '<details class="faq__item"><summary>' . esc_html( $q[0] ) . '<span class="faq__icon" aria-hidden="true"></span></summary><p>' . esc_html( $q[1] ) . '</p></details>';
		}
		$html .= '</div>';
	}
	?>
	<section class="section guide" aria-label="<?php echo esc_attr( $title ? $title : __( 'Guide', 'vyntic' ) ); ?>">
		<div class="wrap guide__inner">
			<?php if ( count( $toc ) > 2 ) : ?>
				<aside class="guide__toc">
					<p class="toc__title"><?php esc_html_e( 'On this page', 'vyntic' ); ?></p>
					<ol class="toc__list">
						<?php foreach ( $toc as $t ) : ?>
							<li><a href="#<?php echo esc_attr( $t[0] ); ?>"><?php echo esc_html( $t[1] ); ?></a></li>
						<?php endforeach; ?>
					</ol>
				</aside>
			<?php endif; ?>
			<div class="guide__body prose">
				<?php if ( $title ) : ?><p class="guide__kicker"><?php echo esc_html( $title ); ?></p><?php endif; ?>
				<?php echo wp_kses_post( $html ); ?>
			</div>
		</div>
	</section>
	<?php
}

/** Setup key whose template (or location city) matches the current page. */
/**
 * Page H1: the "h1" set for the page in inc/data/articles.json, else the page title.
 * Lets the H1 carry the target keyword while the page keeps a short name in menus.
 */
function vyntic_page_h1() {
	$key = vyntic_current_article_key();
	if ( $key && function_exists( 'vyntic_setup_articles' ) ) {
		$a = vyntic_setup_articles();
		if ( ! empty( $a[ $key ]['h1'] ) ) {
			return $a[ $key ]['h1'];
		}
	}
	return get_the_title();
}

function vyntic_current_article_key( $post_id = null ) {
	if ( ! function_exists( 'vyntic_setup_pages' ) ) {
		return '';
	}
	$post_id  = $post_id ? $post_id : get_the_ID();
	$template = get_page_template_slug( $post_id );
	$city     = get_post_meta( $post_id, 'location_city', true );
	foreach ( vyntic_setup_pages() as $key => $p ) {
		if ( empty( $p[7] ) ) {
			continue;
		}
		if ( 'page-templates/location.php' === $template ) {
			if ( ! empty( $p[8]['meta']['location_city'] ) && $p[8]['meta']['location_city'] === $city ) {
				return $p[7];
			}
			continue;
		}
		if ( $template && $p[3] === $template ) {
			return $p[7];
		}
	}
	return '';
}

/**
 * Pins for the world map: every published Location page with known coordinates.
 * Add custom fields location_lat and location_lng on a Location page for any other country or city.
 *
 * @return array[] { label, url, x, y, type }
 */
function vyntic_map_pins() {
	$known = array(
		'usa' => array( -98.5, 39.5 ), 'the usa' => array( -98.5, 39.5 ), 'uk' => array( -2.0, 53.5 ), 'the uk' => array( -2.0, 53.5 ),
		'canada' => array( -100, 56 ), 'australia' => array( 134, -25 ), 'germany' => array( 10.4, 51.2 ), 'france' => array( 2.4, 46.6 ),
		'netherlands' => array( 5.3, 52.2 ), 'the netherlands' => array( 5.3, 52.2 ), 'singapore' => array( 103.8, 1.35 ),
		'uae' => array( 54.4, 24.4 ), 'the uae' => array( 54.4, 24.4 ), 'united arab emirates' => array( 54.4, 24.4 ), 'the united arab emirates' => array( 54.4, 24.4 ),
		'new zealand' => array( 172.5, -41.5 ), 'united kingdom' => array( -2.0, 53.5 ), 'the united kingdom' => array( -2.0, 53.5 ),
		'ireland' => array( -8, 53.3 ), 'london' => array( -0.13, 51.5 ), 'new york' => array( -74.0, 40.7 ), 'toronto' => array( -79.4, 43.7 ),
		'sydney' => array( 151.2, -33.9 ), 'dubai' => array( 55.3, 25.2 ),
	);
	$countries = array( 'usa', 'uk', 'canada', 'australia', 'germany', 'france', 'netherlands', 'singapore', 'uae', 'united arab emirates', 'new zealand', 'united kingdom', 'ireland' );
	$pins = array();
	foreach ( vyntic_location_countries( 60 ) as $page ) {
		if ( 'publish' !== $page->post_status ) {
			continue;
		}
		$city = vyntic_location_city( $page->ID );
		$lat  = get_post_meta( $page->ID, 'location_lat', true );
		$lng  = get_post_meta( $page->ID, 'location_lng', true );
		if ( '' === $lat || '' === $lng ) {
			$k = strtolower( trim( $city ) );
			if ( ! isset( $known[ $k ] ) ) {
				continue;
			}
			list( $lng, $lat ) = $known[ $k ];
		}
		$is_country = (bool) get_pages( array( 'child_of' => $page->ID, 'parent' => $page->ID, 'number' => 1 ) ) || in_array( preg_replace( '/^the\s+/', '', strtolower( trim( $city ) ) ), $countries, true );
		$pins[]     = array(
			'label' => vyntic_location_label( $page->ID ),
			'url'   => get_permalink( $page ),
			'x'     => round( ( (float) $lng + 180 ) / 360 * 100, 2 ),
			'y'     => round( ( 78 - (float) $lat ) / 136 * 100, 2 ),
			'type'  => $is_country ? 'country' : 'city',
		);
	}
	return apply_filters( 'vyntic_map_pins', $pins );
}

/**
 * Blog posts: turn the question and answer pairs in an FAQ section (h2 "Frequently asked
 * questions" followed by h3 + paragraph) into accordion items. Works on existing posts,
 * so there is no need to regenerate them.
 */
add_filter( 'the_content', function ( $content ) {
	if ( ! is_singular( 'post' ) || false === stripos( $content, '<h2' ) ) {
		return $content;
	}
	return preg_replace_callback(
		'#(<h2[^>]*>\s*(?:Frequently asked questions|FAQs?|Questions[^<]*)</h2>)(.*?)(?=<h2|$)#is',
		function ( $m ) {
			$items = preg_replace_callback(
				'#<h3[^>]*>(.*?)</h3>\s*((?:<p[^>]*>.*?</p>\s*)+)#is',
				function ( $q ) {
					return '<details class="faq__item"><summary>' . $q[1] . '<span class="faq__icon" aria-hidden="true"></span></summary>' . trim( $q[2] ) . '</details>';
				},
				$m[2],
				-1,
				$count
			);
			return $count ? $m[1] . '<div class="faq__list faq__list--inline">' . $items . '</div>' : $m[0];
		},
		$content
	);
}, 20 );


/**
 * Menus: when a dropdown holds both industry pages and industry SEO pages, mark them so the
 * dropdown shows two labelled columns ("Website design" and "SEO by industry") instead of
 * one long list. Works with any menu order; nothing to set up in Appearance → Menus.
 */
add_filter( 'wp_nav_menu_objects', function ( $items, $args ) {
	if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $items;
	}
	$seo_urls = array();
	foreach ( vyntic_landing() as $key => $d ) {
		if ( ! empty( $d['group'] ) && 'seo' === $d['group'] ) {
			$url = vyntic_landing_url( $key );
			if ( $url ) {
				$seo_urls[] = untrailingslashit( $url );
			}
		}
	}
	if ( ! $seo_urls ) {
		return $items;
	}
	$groups = array(); // parent id => array( 'seo' => ids, 'other' => ids ).
	foreach ( $items as $item ) {
		if ( ! $item->menu_item_parent ) {
			continue;
		}
		$is_seo = in_array( untrailingslashit( $item->url ), $seo_urls, true );
		$groups[ $item->menu_item_parent ][ $is_seo ? 'seo' : 'other' ][] = $item->ID;
	}
	foreach ( $items as $item ) {
		$p = $item->menu_item_parent;
		if ( isset( $groups[ $item->ID ]['seo'], $groups[ $item->ID ]['other'] ) ) {
			$item->classes[] = 'menu-item--split';
		}
		if ( $p && isset( $groups[ $p ]['seo'], $groups[ $p ]['other'] ) ) {
			$is_seo          = in_array( $item->ID, $groups[ $p ]['seo'], true );
			$item->classes[] = $is_seo ? 'menu-item--seo' : 'menu-item--design';
			if ( $item->ID === $groups[ $p ][ $is_seo ? 'seo' : 'other' ][0] ) {
				$item->classes[] = 'menu-item--group-first';
			}
		}
	}
	return $items;
}, 10, 2 );
