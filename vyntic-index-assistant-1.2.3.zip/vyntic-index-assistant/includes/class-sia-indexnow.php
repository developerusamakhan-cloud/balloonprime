<?php
/**
 * IndexNow (Bing, Yandex, Seznam, Naver, Yep). Google does not use IndexNow.
 *
 * Only new or changed URLs are sent, each URL at most once per 24 hours,
 * batched, and capped per day.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * IndexNow client.
 */
class SIA_IndexNow {

	const ENDPOINT     = 'https://api.indexnow.org/indexnow';
	const KEY_OPTION   = 'sia_indexnow_key';
	const QUEUE_OPTION = 'sia_indexnow_queue';
	const LOG_OPTION   = 'sia_indexnow_last';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve_key_file' ), 0 );
	}

	/**
	 * Whether IndexNow is switched on.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) SIA_Settings::get( 'indexnow_enabled' );
	}

	/**
	 * The site's IndexNow key (created once).
	 *
	 * @return string
	 */
	public static function key() {
		$key = get_option( self::KEY_OPTION, '' );
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $key ) ) {
			$key = md5( wp_generate_password( 64, true, true ) );
			update_option( self::KEY_OPTION, $key );
		}
		return $key;
	}

	/**
	 * Public URL of the key file.
	 *
	 * @return string
	 */
	public static function key_url() {
		return home_url( '/' . self::key() . '.txt' );
	}

	/**
	 * Answer requests for /{key}.txt so search engines can verify ownership.
	 */
	public static function serve_key_file() {
		if ( ! self::enabled() || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH );
		if ( $path === wp_parse_url( self::key_url(), PHP_URL_PATH ) ) {
			status_header( 200 );
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo esc_html( self::key() );
			exit;
		}
	}

	/**
	 * Add a post to the queue (sent on the next cron run).
	 *
	 * @param int $post_id Post.
	 */
	public static function queue( $post_id ) {
		if ( ! self::enabled() ) {
			return;
		}
		$queue = (array) get_option( self::QUEUE_OPTION, array() );
		if ( ! in_array( (int) $post_id, $queue, true ) ) {
			$queue[] = (int) $post_id;
			update_option( self::QUEUE_OPTION, array_slice( $queue, -2000 ), false );
		}
	}

	/**
	 * Send queued URLs, within today's limit. URLs sent in the last 24 hours are skipped.
	 *
	 * @return int Number of URLs sent.
	 */
	public static function flush() {
		$queue = array_map( 'intval', (array) get_option( self::QUEUE_OPTION, array() ) );
		if ( ! self::enabled() || ! $queue ) {
			return 0;
		}

		$remaining = SIA_Quota::remaining( 'indexnow' );
		if ( $remaining <= 0 ) {
			return 0;
		}

		$cutoff = SIA_Urls::now( -DAY_IN_SECONDS );
		$send   = array();
		$keep   = array();
		foreach ( $queue as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post || ! SIA_Urls::is_tracked( $post ) || SIA_Urls::is_excluded( $post ) ) {
				continue; // Drop: no longer public.
			}
			$row = SIA_Urls::by_post( $post_id );
			if ( $row && $row->indexnow_at && $row->indexnow_at > $cutoff ) {
				continue; // Drop: already sent in the last 24 h.
			}
			if ( count( $send ) < $remaining ) {
				$send[ $post_id ] = get_permalink( $post );
			} else {
				$keep[] = $post_id; // Over today's limit: try tomorrow.
			}
		}

		if ( ! $send ) {
			update_option( self::QUEUE_OPTION, $keep, false );
			return 0;
		}
		if ( ! SIA_Quota::reserve( 'indexnow', count( $send ) ) ) {
			return 0;
		}

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 20,
				'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'    => wp_json_encode(
					array(
						'host'        => wp_parse_url( home_url(), PHP_URL_HOST ),
						'key'         => self::key(),
						'keyLocation' => self::key_url(),
						'urlList'     => array_values( $send ),
					)
				),
			)
		);

		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		update_option(
			self::LOG_OPTION,
			array(
				'time'    => time(),
				'count'   => count( $send ),
				'code'    => $code,
				'message' => is_wp_error( $response ) ? $response->get_error_message() : '',
			),
			false
		);

		if ( 200 === $code || 202 === $code ) {
			global $wpdb;
			$ids = implode( ',', array_map( 'intval', array_keys( $send ) ) );
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . SIA_Install::table() . " SET indexnow_at = %s WHERE post_id IN ({$ids})", SIA_Urls::now() ) ); // phpcs:ignore WordPress.DB
			update_option( self::QUEUE_OPTION, $keep, false );
			return count( $send );
		}

		if ( 429 === $code ) {
			// Too many requests: keep everything and stop IndexNow for the rest of the day.
			$state             = SIA_Quota::state();
			$state['indexnow'] = SIA_Quota::limit( 'indexnow' );
			update_option( SIA_Quota::OPTION, $state, false );
		}
		if ( in_array( $code, array( 0, 429 ), true ) || $code >= 500 ) {
			update_option( self::QUEUE_OPTION, array_merge( array_keys( $send ), $keep ), false );
		} else {
			// 400/403/422: the request itself is wrong (e.g. key not reachable). Don't retry the same batch.
			update_option( self::QUEUE_OPTION, $keep, false );
		}
		return 0;
	}
}
