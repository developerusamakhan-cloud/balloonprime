<?php
/**
 * Turns Google's inspection result into a plain reason + what to do about it.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Diagnosis helpers.
 */
class SIA_Diagnosis {

	/**
	 * Reason and advice for a row.
	 *
	 * @param object $row Table row.
	 * @return array{label:string,level:string,advice:string[]}
	 */
	public static function explain( $row ) {
		switch ( $row->status ) {
			case 'indexed':
				return self::out( __( 'Indexed', 'vyntic-index-assistant' ), 'good', array() );
			case 'pending':
				return self::out( __( 'Not checked yet', 'vyntic-index-assistant' ), 'muted', array( __( 'Will be checked automatically within the daily limit.', 'vyntic-index-assistant' ) ) );
			case 'excluded':
				return self::out( __( 'Skipped (noindex)', 'vyntic-index-assistant' ), 'muted', array( __( 'Your SEO plugin, a password or "Discourage search engines" (Settings → Reading) tells Google not to index this page, so it is not checked. Remove the noindex if it should be in Google.', 'vyntic-index-assistant' ) ) );
			case 'error':
				return self::out( __( 'Check failed', 'vyntic-index-assistant' ), 'bad', array( (string) $row->error ) );
		}

		// Technical blockers first: nothing else helps until these are fixed.
		if ( in_array( $row->indexing_state, array( 'BLOCKED_BY_META_TAG', 'BLOCKED_BY_HTTP_HEADER' ), true ) ) {
			return self::out( __( 'Blocked by noindex', 'vyntic-index-assistant' ), 'bad', array( __( 'Google saw a noindex tag/header on this page. Remove it in your SEO plugin (Advanced → robots meta) if the page should be indexed.', 'vyntic-index-assistant' ) ) );
		}
		if ( 'DISALLOWED' === $row->robots_state || 'BLOCKED_BY_ROBOTS_TXT' === $row->indexing_state ) {
			return self::out( __( 'Blocked by robots.txt', 'vyntic-index-assistant' ), 'bad', array( __( 'Your robots.txt does not allow Google to crawl this URL. Remove the Disallow rule that matches it.', 'vyntic-index-assistant' ) ) );
		}
		$fetch = array(
			'SOFT_404'             => __( 'Google thinks this page is empty or an error page (soft 404). Add real, useful content or redirect it.', 'vyntic-index-assistant' ),
			'NOT_FOUND'            => __( 'Google got a 404 for this URL. Check the permalink and fix or redirect it.', 'vyntic-index-assistant' ),
			'SERVER_ERROR'         => __( 'Your server returned a 5xx error to Google. Check hosting, caching and security plugins.', 'vyntic-index-assistant' ),
			'ACCESS_DENIED'        => __( 'Google was refused access (401). Remove login or firewall protection for this page.', 'vyntic-index-assistant' ),
			'ACCESS_FORBIDDEN'     => __( 'Google was blocked (403). A firewall or security plugin may be blocking Googlebot.', 'vyntic-index-assistant' ),
			'BLOCKED_4XX'          => __( 'Google got a 4xx error for this URL.', 'vyntic-index-assistant' ),
			'REDIRECT_ERROR'       => __( 'Redirect problem (loop, chain or bad target). Point links and the sitemap at the final URL.', 'vyntic-index-assistant' ),
			'BLOCKED_ROBOTS_TXT'   => __( 'Blocked by robots.txt.', 'vyntic-index-assistant' ),
			'INTERNAL_CRAWL_ERROR' => __( 'Google had an internal crawl error. It usually fixes itself; it will be checked again later.', 'vyntic-index-assistant' ),
		);
		if ( isset( $fetch[ $row->fetch_state ] ) ) {
			return self::out( __( 'Crawl problem', 'vyntic-index-assistant' ), 'bad', array( $fetch[ $row->fetch_state ] ) );
		}

		$state  = strtolower( (string) $row->coverage_state );
		$advice = array();
		$level  = 'warn';

		if ( false !== strpos( $state, 'duplicate' ) || false !== strpos( $state, 'alternate' ) || ( $row->google_canonical && $row->user_canonical && untrailingslashit( $row->google_canonical ) !== untrailingslashit( $row->user_canonical ) ) ) {
			$label    = __( 'Duplicate / canonical', 'vyntic-index-assistant' );
			$advice[] = $row->google_canonical
				? sprintf( /* translators: %s: URL */ __( 'Google picked another page as the main version: %s. Make this page clearly different, or merge it into that page and redirect.', 'vyntic-index-assistant' ), $row->google_canonical )
				: __( 'Google sees this page as a duplicate. Make it clearly different or set the right canonical URL.', 'vyntic-index-assistant' );
		} elseif ( false !== strpos( $state, 'crawled' ) ) {
			$label    = __( 'Crawled, not indexed', 'vyntic-index-assistant' );
			$advice[] = __( 'Google read the page but decided it is not worth indexing yet. This is about quality: make it more complete and more useful than what already ranks, add original information, images and FAQs.', 'vyntic-index-assistant' );
		} elseif ( false !== strpos( $state, 'discovered' ) ) {
			$label    = __( 'Discovered, not crawled', 'vyntic-index-assistant' );
			$advice[] = __( 'Google knows the URL but has not visited it yet. Add internal links from your strong, indexed pages so Google sees it as important.', 'vyntic-index-assistant' );
		} elseif ( false !== strpos( $state, 'unknown' ) ) {
			$label    = __( 'Unknown to Google', 'vyntic-index-assistant' );
			$advice[] = __( 'Google has never seen this URL. Make sure it is in your sitemap and linked from other pages (menus, categories, related posts).', 'vyntic-index-assistant' );
		} else {
			$label    = $row->coverage_state ? $row->coverage_state : __( 'Not indexed', 'vyntic-index-assistant' );
			$advice[] = __( 'Open the page in Search Console for details.', 'vyntic-index-assistant' );
		}

		$thin = absint( SIA_Settings::get( 'thin_words', 300 ) );
		if ( $thin && $row->word_count && $row->word_count < $thin ) {
			/* translators: %d: words */
			$advice[] = sprintf( __( 'Thin content: only %d words. Expand it with genuinely useful information.', 'vyntic-index-assistant' ), $row->word_count );
		}
		if ( 0 === (int) $row->inbound_links ) {
			$advice[] = __( 'No other post or page links to this page in its content (menus are not counted). Add 2 or 3 internal links from related, indexed posts.', 'vyntic-index-assistant' );
		}

		return self::out( $label, $level, $advice );
	}

	/**
	 * Result shape.
	 *
	 * @param string   $label  Label.
	 * @param string   $level  good|warn|bad|muted.
	 * @param string[] $advice Advice lines.
	 * @return array
	 */
	private static function out( $label, $level, $advice ) {
		return array(
			'label'  => $label,
			'level'  => $level,
			'advice' => array_filter( $advice ),
		);
	}

	/**
	 * Words in a post's content.
	 *
	 * @param int $post_id Post.
	 * @return int
	 */
	public static function word_count( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return 0;
		}
		$text = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
		return count( preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
	}

	/**
	 * How many other published posts link to this URL.
	 *
	 * @param int    $post_id Post.
	 * @param string $url     Permalink.
	 * @return int
	 */
	public static function inbound_links( $post_id, $url ) {
		global $wpdb;
		$path = wp_make_link_relative( $url );
		if ( '' === trim( $path, '/' ) ) {
			return 1; // Home page: linked from everywhere.
		}
		$types = SIA_Settings::post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$path  = untrailingslashit( $path );
		$sql   = "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$in}) AND ID <> %d AND post_content LIKE %s";
		$count = (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( $types, array( $post_id, '%' . $wpdb->esc_like( $path ) . '%' ) ) ) ); // phpcs:ignore WordPress.DB

		// Elementor keeps the real layout in post meta as JSON, where "/" is written as "\/".
		$count += (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT m.post_id) FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id
				WHERE m.meta_key = '_elementor_data' AND p.post_status = 'publish' AND m.post_id <> %d AND (m.meta_value LIKE %s OR m.meta_value LIKE %s)",
				$post_id,
				'%' . $wpdb->esc_like( $path ) . '%',
				'%' . $wpdb->esc_like( str_replace( '/', '\\/', $path ) ) . '%'
			)
		);
		return $count;
	}

	/**
	 * Indexed posts that could link to this one (same category first) and don't yet.
	 *
	 * @param object $row   Row.
	 * @param int    $limit Max.
	 * @return WP_Post[]
	 */
	public static function link_sources( $row, $limit = 3 ) {
		global $wpdb;
		$table = SIA_Install::table();
		$path  = untrailingslashit( wp_make_link_relative( $row->url ) );

		$terms = wp_get_post_terms( $row->post_id, 'category', array( 'fields' => 'ids' ) );
		$terms = is_wp_error( $terms ) ? array() : array_map( 'intval', $terms );

		// phpcs:disable WordPress.DB
		$base = "SELECT p.ID FROM {$table} t JOIN {$wpdb->posts} p ON p.ID = t.post_id";
		$cond = $wpdb->prepare( " WHERE t.status = 'indexed' AND p.ID <> %d AND p.post_content NOT LIKE %s", $row->post_id, '%' . $wpdb->esc_like( $path ) . '%' );
		$ids  = array();
		if ( $terms ) {
			$ids = $wpdb->get_col( $base . " JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id" . $cond . ' AND tt.taxonomy = \'category\' AND tt.term_id IN (' . implode( ',', $terms ) . ') GROUP BY p.ID ORDER BY p.post_date_gmt DESC LIMIT ' . (int) $limit );
		}
		if ( count( $ids ) < $limit ) {
			$more = $wpdb->get_col( $base . $cond . ' ORDER BY p.comment_count DESC, p.post_date_gmt DESC LIMIT ' . (int) ( $limit * 2 ) );
			$ids  = array_slice( array_unique( array_merge( $ids, $more ) ), 0, $limit );
		}
		// phpcs:enable

		return array_filter( array_map( 'get_post', $ids ) );
	}
}
