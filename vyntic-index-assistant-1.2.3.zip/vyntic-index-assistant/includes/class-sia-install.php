<?php
/**
 * Activation / DB schema.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Creates the URL tracking table.
 */
class SIA_Install {

	/**
	 * Table name with prefix.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'sia_urls';
	}

	/**
	 * Activation hook.
	 */
	public static function activate() {
		self::create_table();
		if ( false === get_option( SIA_Settings::OPTION ) ) {
			add_option( SIA_Settings::OPTION, SIA_Settings::defaults() );
		}
		SIA_Cron::schedule();
	}

	/**
	 * Deactivation hook: stop all background work.
	 */
	public static function deactivate() {
		SIA_Cron::unschedule();
	}

	/**
	 * Re-run schema when the DB version changes (covers updates without re-activation).
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'sia_db_version' ) !== SIA_DB_VERSION ) {
			self::create_table();
		}
	}

	/**
	 * Create / update the table using dbDelta.
	 */
	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			url varchar(500) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			verdict varchar(30) NOT NULL DEFAULT '',
			coverage_state varchar(190) NOT NULL DEFAULT '',
			indexing_state varchar(40) NOT NULL DEFAULT '',
			robots_state varchar(40) NOT NULL DEFAULT '',
			fetch_state varchar(40) NOT NULL DEFAULT '',
			google_canonical varchar(500) NOT NULL DEFAULT '',
			user_canonical varchar(500) NOT NULL DEFAULT '',
			inspect_link varchar(700) NOT NULL DEFAULT '',
			last_crawl datetime NULL DEFAULT NULL,
			word_count int(10) unsigned NOT NULL DEFAULT 0,
			inbound_links int(10) unsigned NOT NULL DEFAULT 0,
			error text NULL,
			inspected_at datetime NULL DEFAULT NULL,
			next_check_at datetime NOT NULL,
			manual_requested_at datetime NULL DEFAULT NULL,
			indexnow_at datetime NULL DEFAULT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY post_id (post_id),
			KEY status (status),
			KEY next_check_at (next_check_at)
		) {$charset};";

		dbDelta( $sql );
		update_option( 'sia_db_version', SIA_DB_VERSION );
	}
}
