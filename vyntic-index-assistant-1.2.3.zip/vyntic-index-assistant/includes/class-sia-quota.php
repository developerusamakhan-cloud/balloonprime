<?php
/**
 * Daily usage counters and the pause switch.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Counts every outgoing call per day and refuses once a limit is reached.
 *
 * Google's API quotas reset at midnight Pacific time, so the "day" here is a
 * Pacific day too. Calls are counted *before* they are made, so a crash halfway
 * through can only ever under-use the quota, never over-use it.
 */
class SIA_Quota {

	const OPTION = 'sia_quota';

	/**
	 * Today's key in Pacific time, e.g. "2026-10-13".
	 *
	 * @return string
	 */
	public static function today() {
		$now = new DateTime( 'now', new DateTimeZone( 'America/Los_Angeles' ) );
		return $now->format( 'Y-m-d' );
	}

	/**
	 * Unix timestamp of the next Pacific midnight (when Google's quota resets).
	 *
	 * @return int
	 */
	public static function next_reset() {
		$next = new DateTime( 'tomorrow', new DateTimeZone( 'America/Los_Angeles' ) );
		return $next->getTimestamp() + 5 * MINUTE_IN_SECONDS;
	}

	/**
	 * Current state, reset when the day has changed.
	 *
	 * @return array
	 */
	public static function state() {
		$state = get_option( self::OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		$today = self::today();

		if ( ! isset( $state['day'] ) || $state['day'] !== $today ) {
			$state = array(
				'day'          => $today,
				'inspect'      => 0,
				'manual'       => 0,
				'indexnow'     => 0,
				'paused_until' => isset( $state['paused_until'] ) ? (int) $state['paused_until'] : 0,
				'pause_reason' => isset( $state['pause_reason'] ) ? (string) $state['pause_reason'] : '',
				'pause_kind'   => isset( $state['pause_kind'] ) ? (string) $state['pause_kind'] : '',
			);
			update_option( self::OPTION, $state, false );
		}
		return $state;
	}

	/**
	 * Daily limit for a counter.
	 *
	 * @param string $type inspect|manual|indexnow.
	 * @return int
	 */
	public static function limit( $type ) {
		switch ( $type ) {
			case 'inspect':
				return SIA_Settings::daily_limit();
			case 'manual':
				return SIA_Settings::manual_daily();
			case 'indexnow':
				return SIA_Settings::indexnow_daily();
		}
		return 0;
	}

	/**
	 * Amount used today.
	 *
	 * @param string $type Counter.
	 * @return int
	 */
	public static function used( $type ) {
		$state = self::state();
		return isset( $state[ $type ] ) ? (int) $state[ $type ] : 0;
	}

	/**
	 * Amount left today.
	 *
	 * @param string $type Counter.
	 * @return int
	 */
	public static function remaining( $type ) {
		return max( 0, self::limit( $type ) - self::used( $type ) );
	}

	/**
	 * Reserve $amount of today's quota. Returns false (and reserves nothing) if that
	 * would go over the limit or the plugin is paused.
	 *
	 * @param string $type   Counter.
	 * @param int    $amount Units.
	 * @return bool
	 */
	public static function reserve( $type, $amount = 1 ) {
		if ( 'manual' !== $type && self::is_paused() ) {
			return false;
		}
		$state = self::state();
		$used  = isset( $state[ $type ] ) ? (int) $state[ $type ] : 0;
		if ( $used + $amount > self::limit( $type ) ) {
			return false;
		}
		$state[ $type ] = $used + $amount;
		update_option( self::OPTION, $state, false );
		return true;
	}

	/**
	 * Stop all Google calls until $until.
	 *
	 * @param int    $until  Unix timestamp.
	 * @param string $reason Shown in the dashboard.
	 * @param string $kind   quota (Google said "too many", cannot be resumed early) or access.
	 */
	public static function pause( $until, $reason, $kind = 'access' ) {
		$state                 = self::state();
		$state['paused_until'] = (int) $until;
		$state['pause_reason'] = (string) $reason;
		$state['pause_kind']   = (string) $kind;
		update_option( self::OPTION, $state, false );
	}

	/**
	 * Lift an access pause (e.g. after fixing permissions). Quota pauses can't be lifted early.
	 */
	public static function resume() {
		if ( 'quota' !== self::pause_info()['kind'] ) {
			self::pause( 0, '', '' );
		}
	}

	/**
	 * Whether Google calls are currently paused.
	 *
	 * @return bool
	 */
	public static function is_paused() {
		$state = self::state();
		return ! empty( $state['paused_until'] ) && (int) $state['paused_until'] > time();
	}

	/**
	 * Pause details for display.
	 *
	 * @return array{until:int,reason:string,kind:string}
	 */
	public static function pause_info() {
		$state = self::state();
		return array(
			'until'  => (int) $state['paused_until'],
			'reason' => (string) $state['pause_reason'],
			'kind'   => isset( $state['pause_kind'] ) ? (string) $state['pause_kind'] : '',
		);
	}
}
