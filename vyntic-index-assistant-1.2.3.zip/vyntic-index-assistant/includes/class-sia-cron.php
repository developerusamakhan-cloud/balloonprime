<?php
/**
 * Background runner: small batches every 15 minutes, spread over the day.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cron.
 */
class SIA_Cron {

	const HOOK     = 'sia_run';
	const SCHEDULE = 'sia_15min';
	const LOCK     = 'sia_lock';

	/**
	 * Stop a run after this many seconds so it never hits PHP time limits.
	 */
	const MAX_RUN_SECONDS = 25;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			self::schedule();
		}
	}

	/**
	 * Custom interval.
	 *
	 * @param array $schedules Schedules.
	 * @return array
	 */
	public static function schedules( $schedules ) {
		$schedules[ self::SCHEDULE ] = array(
			'interval' => 15 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 15 minutes (Safe Index Assistant)', 'vyntic-index-assistant' ),
		);
		return $schedules;
	}

	/**
	 * Schedule the event.
	 */
	public static function schedule() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::SCHEDULE, self::HOOK );
		}
	}

	/**
	 * Remove the event.
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * How many URLs this run may check: the daily limit spread over ~48 runs,
	 * never more than HARD_PER_RUN and never more than what is left today.
	 *
	 * @return int
	 */
	public static function batch_size() {
		$spread = (int) ceil( SIA_Settings::daily_limit() / 48 );
		return max( 0, min( SIA_Settings::HARD_PER_RUN, max( 1, $spread ), SIA_Quota::remaining( 'inspect' ) ) );
	}

	/**
	 * One run. Also used by the "Run a batch now" button (same limits apply).
	 *
	 * @return array Summary for display.
	 */
	public static function run() {
		$summary = array(
			'synced'    => 0,
			'inspected' => 0,
			'indexnow'  => 0,
			'sitemap'   => '',
			'stopped'   => '',
		);

		if ( get_transient( self::LOCK ) ) {
			$summary['stopped'] = __( 'Another run is already in progress.', 'vyntic-index-assistant' );
			return $summary;
		}
		set_transient( self::LOCK, 1, 5 * MINUTE_IN_SECONDS );
		$start = microtime( true );

		$summary['synced']   = SIA_Urls::sync();
		$summary['indexnow'] = SIA_IndexNow::flush();

		if ( ! SIA_Settings::credentials() ) {
			$summary['stopped'] = __( 'Connect Google in Settings first.', 'vyntic-index-assistant' );
		} elseif ( SIA_Quota::is_paused() ) {
			$summary['stopped'] = __( 'Paused (see the notice on the dashboard).', 'vyntic-index-assistant' );
		} else {
			$summary['sitemap'] = self::maybe_submit_sitemap();
			self::inspect_batch( $summary, $start );
		}

		delete_transient( self::LOCK );
		update_option( 'sia_last_run', array_merge( $summary, array( 'time' => time() ) ), false );
		return $summary;
	}

	/**
	 * Inspect due URLs one by one with a pause between calls.
	 *
	 * @param array $summary Summary (by reference).
	 * @param float $start   Run start time.
	 */
	private static function inspect_batch( &$summary, $start ) {
		$size = self::batch_size();
		if ( $size <= 0 ) {
			$summary['stopped'] = __( 'Daily inspection limit reached. Continues tomorrow.', 'vyntic-index-assistant' );
			return;
		}

		foreach ( SIA_Urls::due( $size ) as $i => $row ) {
			if ( microtime( true ) - $start > self::MAX_RUN_SECONDS ) {
				break;
			}
			if ( $i > 0 ) {
				usleep( (int) ( SIA_Settings::PAUSE_BETWEEN_CALLS * 1000000 ) );
			}
			if ( ! SIA_Quota::reserve( 'inspect' ) ) {
				$summary['stopped'] = __( 'Daily inspection limit reached. Continues tomorrow.', 'vyntic-index-assistant' );
				return;
			}

			$result = SIA_Google::inspect( $row->url );
			if ( ! is_wp_error( $result ) ) {
				SIA_Urls::save_result( $row, $result );
				++$summary['inspected'];
				continue;
			}

			$data   = (array) $result->get_error_data();
			$status = isset( $data['status'] ) ? (int) $data['status'] : 0;
			$gstat  = isset( $data['google_status'] ) ? $data['google_status'] : '';

			if ( 429 === $status || 'RESOURCE_EXHAUSTED' === $gstat ) {
				// Google says we used too much: stop everything until its quota resets.
				SIA_Quota::pause( SIA_Quota::next_reset(), __( 'Google reported the quota as used up. Paused until it resets (midnight Pacific time).', 'vyntic-index-assistant' ), 'quota' );
				$summary['stopped'] = __( 'Google quota reached; paused until tomorrow.', 'vyntic-index-assistant' );
				return;
			}
			if ( in_array( $status, array( 401, 403 ), true ) || 'sia_auth' === $result->get_error_code() || 'sia_no_credentials' === $result->get_error_code() ) {
				SIA_Quota::pause( time() + 6 * HOUR_IN_SECONDS, sprintf( /* translators: %s: error */ __( 'Google refused access: %s Fix the service account permissions, then click "Resume".', 'vyntic-index-assistant' ), $result->get_error_message() ) );
				$summary['stopped'] = $result->get_error_message();
				return;
			}
			if ( 400 === $status || 404 === $status ) {
				// Problem with this URL only (e.g. not inside the property). Try again in a week.
				SIA_Urls::save_error( $row, $result->get_error_message(), 7 * DAY_IN_SECONDS );
				continue;
			}
			// Network / 5xx: stop this run, try again next run.
			$summary['stopped'] = $result->get_error_message();
			return;
		}
	}

	/**
	 * Resubmit the sitemap at most once per 24 h, and only if something was published or updated since.
	 *
	 * @return string Status message ('' when nothing happened).
	 */
	private static function maybe_submit_sitemap() {
		if ( ! SIA_Settings::get( 'sitemap_auto' ) ) {
			return '';
		}
		$last = get_option( 'sia_sitemap_last', array() );
		$time = isset( $last['time'] ) ? (int) $last['time'] : 0;
		// After a failed submission, retry after an hour instead of a day.
		$wait = ( isset( $last['ok'] ) && ! $last['ok'] ) ? HOUR_IN_SECONDS : SIA_Settings::SITEMAP_MIN_HOURS * HOUR_IN_SECONDS;
		if ( time() - $time < $wait ) {
			return '';
		}

		global $wpdb;
		$types   = SIA_Settings::post_types();
		$in      = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$changed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$in}) AND post_modified_gmt > %s", array_merge( $types, array( gmdate( 'Y-m-d H:i:s', $time ) ) ) ) ); // phpcs:ignore WordPress.DB
		if ( $time && ! $changed && ! empty( $last['ok'] ) ) {
			return '';
		}

		$sitemap = SIA_Settings::sitemap_url();
		$result  = SIA_Google::submit_sitemap( $sitemap );
		$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'Sitemap submitted to Google.', 'vyntic-index-assistant' );
		update_option(
			'sia_sitemap_last',
			array(
				'time'    => time(),
				'url'     => $sitemap,
				'ok'      => ! is_wp_error( $result ),
				'message' => $message,
			),
			false
		);
		return $message;
	}
}
