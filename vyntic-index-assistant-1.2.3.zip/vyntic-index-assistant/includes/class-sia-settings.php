<?php
/**
 * Plugin settings access and the hard safety limits.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads and normalises the `sia_settings` option.
 *
 * The HARD_* constants are the ceilings the plugin never goes above, whatever is
 * typed in Settings. They are deliberately far below Google's published quotas.
 */
class SIA_Settings {

	const OPTION = 'sia_settings';

	/**
	 * Service account JSON lives in its own non-autoloaded option.
	 */
	const CREDENTIALS_OPTION = 'sia_service_account';

	/**
	 * URL Inspection checks per day. Google allows 2,000 per property; we stop at half.
	 */
	const HARD_DAILY_INSPECTIONS = 1000;

	/**
	 * URL Inspection checks per cron run (every 15 minutes). With a 1.5 s pause between
	 * calls this is at most ~40 calls a minute, Google allows 600.
	 */
	const HARD_PER_RUN = 10;

	/**
	 * Seconds to wait between two Google API calls.
	 */
	const PAUSE_BETWEEN_CALLS = 1.5;

	/**
	 * Manual "Request indexing" suggestions per day. Search Console's own button allows roughly 10 to 12.
	 */
	const HARD_MANUAL_PER_DAY = 10;

	/**
	 * IndexNow URLs per day.
	 */
	const HARD_INDEXNOW_PER_DAY = 1000;

	/**
	 * Minimum hours between two sitemap submissions to Google.
	 */
	const SITEMAP_MIN_HOURS = 24;

	/**
	 * Default values for every setting.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'property'               => '',
			'daily_limit'            => 100,
			'post_types'             => array( 'post', 'page' ),
			'first_check_days'       => 3,
			'recheck_indexed_days'   => 30,
			'recheck_unindexed_days' => 7,
			'sitemap_auto'           => 1,
			'sitemap_url'            => '',
			'manual_daily'           => 10,
			'indexnow_enabled'       => 0,
			'indexnow_daily'         => 100,
			'thin_words'             => 300,
			'delete_on_uninstall'    => 0,
		);
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * Single setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Daily inspection limit, never above the hard cap.
	 *
	 * @return int
	 */
	public static function daily_limit() {
		return min( self::HARD_DAILY_INSPECTIONS, max( 1, absint( self::get( 'daily_limit' ) ) ) );
	}

	/**
	 * Daily manual-request list size, never above the hard cap.
	 *
	 * @return int
	 */
	public static function manual_daily() {
		return min( self::HARD_MANUAL_PER_DAY, max( 1, absint( self::get( 'manual_daily' ) ) ) );
	}

	/**
	 * Daily IndexNow URL limit, never above the hard cap.
	 *
	 * @return int
	 */
	public static function indexnow_daily() {
		return min( self::HARD_INDEXNOW_PER_DAY, max( 1, absint( self::get( 'indexnow_daily' ) ) ) );
	}

	/**
	 * Post types that are tracked.
	 *
	 * @return string[]
	 */
	public static function post_types() {
		$types = (array) self::get( 'post_types', array() );
		$types = array_values( array_filter( $types, 'post_type_exists' ) );
		return $types ? $types : array( 'post' );
	}

	/**
	 * Sitemap URL: the saved one, or the one from Yoast / Rank Math / WordPress core.
	 *
	 * @return string
	 */
	public static function sitemap_url() {
		$url = (string) self::get( 'sitemap_url', '' );
		if ( '' !== $url ) {
			return $url;
		}
		if ( defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'SEOPRESS_VERSION' ) ) {
			return home_url( '/sitemap_index.xml' );
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			return home_url( '/sitemap.xml' );
		}
		return home_url( '/wp-sitemap.xml' );
	}

	/**
	 * Search Console property: the saved one, or the site's URL-prefix property.
	 *
	 * @return string
	 */
	public static function property() {
		$property = trim( (string) self::get( 'property', '' ) );
		return '' !== $property ? $property : trailingslashit( home_url() );
	}

	/**
	 * Saved service account credentials, or null. A `SIA_SERVICE_ACCOUNT_JSON`
	 * constant in wp-config.php takes precedence over the database.
	 *
	 * @return array|null
	 */
	public static function credentials() {
		$json = defined( 'SIA_SERVICE_ACCOUNT_JSON' ) ? SIA_SERVICE_ACCOUNT_JSON : get_option( self::CREDENTIALS_OPTION, '' );
		$data = is_string( $json ) && '' !== $json ? json_decode( $json, true ) : null;
		if ( ! is_array( $data ) || empty( $data['client_email'] ) || empty( $data['private_key'] ) ) {
			return null;
		}
		return $data;
	}

	/**
	 * Validate service account JSON pasted in Settings.
	 *
	 * @param string $json Raw JSON.
	 * @return string|WP_Error Normalised JSON or error.
	 */
	public static function validate_credentials( $json ) {
		$data = json_decode( trim( $json ), true );
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'sia_json', __( 'The service account key is not valid JSON.', 'vyntic-index-assistant' ) );
		}
		if ( empty( $data['type'] ) || 'service_account' !== $data['type'] || empty( $data['client_email'] ) || empty( $data['private_key'] ) ) {
			return new WP_Error( 'sia_json', __( 'This is not a service account key. Download a JSON key for a service account in Google Cloud Console.', 'vyntic-index-assistant' ) );
		}
		if ( ! function_exists( 'openssl_sign' ) || false === openssl_pkey_get_private( $data['private_key'] ) ) {
			return new WP_Error( 'sia_json', __( 'The private key in this file cannot be read (is the PHP OpenSSL extension enabled?).', 'vyntic-index-assistant' ) );
		}
		return wp_json_encode(
			array(
				'type'         => 'service_account',
				'client_email' => sanitize_email( $data['client_email'] ),
				'private_key'  => $data['private_key'],
			)
		);
	}

	/**
	 * Sanitize callback for register_setting().
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input    = is_array( $input ) ? $input : array();
		$defaults = self::defaults();
		$out      = array();

		$out['property'] = isset( $input['property'] ) ? self::sanitize_property( wp_unslash( $input['property'] ) ) : '';

		$numbers = array(
			'daily_limit'            => array( 1, self::HARD_DAILY_INSPECTIONS ),
			'first_check_days'       => array( 1, 30 ),
			'recheck_indexed_days'   => array( 7, 180 ),
			'recheck_unindexed_days' => array( 3, 60 ),
			'manual_daily'           => array( 1, self::HARD_MANUAL_PER_DAY ),
			'indexnow_daily'         => array( 1, self::HARD_INDEXNOW_PER_DAY ),
			'thin_words'             => array( 0, 2000 ),
		);
		foreach ( $numbers as $key => $range ) {
			$value       = isset( $input[ $key ] ) ? absint( $input[ $key ] ) : $defaults[ $key ];
			$out[ $key ] = min( $range[1], max( $range[0], $value ) );
		}

		$types             = isset( $input['post_types'] ) ? array_map( 'sanitize_key', (array) $input['post_types'] ) : array();
		$out['post_types'] = array_values( array_filter( $types, 'post_type_exists' ) );
		if ( ! $out['post_types'] ) {
			$out['post_types'] = array( 'post' );
		}

		$out['sitemap_url'] = isset( $input['sitemap_url'] ) ? esc_url_raw( wp_unslash( $input['sitemap_url'] ) ) : '';

		foreach ( array( 'sitemap_auto', 'indexnow_enabled', 'delete_on_uninstall' ) as $key ) {
			$out[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
		}

		return $out;
	}

	/**
	 * Accepts "sc-domain:example.com" or a URL-prefix property ending in "/".
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	public static function sanitize_property( $value ) {
		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return '';
		}
		if ( 0 === stripos( $value, 'sc-domain:' ) ) {
			return 'sc-domain:' . strtolower( preg_replace( '/[^a-z0-9.\-]/i', '', substr( $value, 10 ) ) );
		}
		$url = esc_url_raw( $value, array( 'http', 'https' ) );
		return '' !== $url ? trailingslashit( $url ) : '';
	}
}
