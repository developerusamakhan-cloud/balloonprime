<?php
/**
 * Google Search Console API client (service account auth).
 *
 * Only two Search Console endpoints are used, both allowed for every website:
 * URL Inspection (read-only status check) and Sitemaps (submit your sitemap).
 * The Indexing API is deliberately NOT used: Google only allows it for
 * JobPosting and BroadcastEvent pages.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Minimal API client.
 */
class SIA_Google {

	const TOKEN_URL   = 'https://oauth2.googleapis.com/token';
	const SCOPE       = 'https://www.googleapis.com/auth/webmasters';
	const INSPECT_URL = 'https://searchconsole.googleapis.com/v1/urlInspection/index:inspect';
	const SITES_URL   = 'https://www.googleapis.com/webmasters/v3/sites';

	/**
	 * Access token for the saved service account (cached ~50 minutes).
	 *
	 * @return string|WP_Error
	 */
	public static function token() {
		$creds = SIA_Settings::credentials();
		if ( ! $creds ) {
			return new WP_Error( 'sia_no_credentials', __( 'No Google service account key saved yet.', 'vyntic-index-assistant' ) );
		}

		$cache_key = 'sia_token_' . md5( $creds['client_email'] );
		$cached    = get_transient( $cache_key );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$now    = time();
		$header = self::b64( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
		$claims = self::b64(
			wp_json_encode(
				array(
					'iss'   => $creds['client_email'],
					'scope' => self::SCOPE,
					'aud'   => self::TOKEN_URL,
					'iat'   => $now,
					'exp'   => $now + HOUR_IN_SECONDS,
				)
			)
		);

		$signature = '';
		$key       = openssl_pkey_get_private( $creds['private_key'] );
		if ( false === $key || ! openssl_sign( $header . '.' . $claims, $signature, $key, 'sha256WithRSAEncryption' ) ) {
			return new WP_Error( 'sia_sign', __( 'Could not sign the Google login request. Check the service account key.', 'vyntic-index-assistant' ) );
		}

		$response = wp_remote_post(
			self::TOKEN_URL,
			array(
				'timeout' => 20,
				'body'    => array(
					'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
					'assertion'  => $header . '.' . $claims . '.' . self::b64( $signature ),
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['access_token'] ) ) {
			$message = isset( $body['error_description'] ) ? $body['error_description'] : __( 'Google refused the service account login.', 'vyntic-index-assistant' );
			return new WP_Error( 'sia_auth', $message, array( 'status' => wp_remote_retrieve_response_code( $response ) ) );
		}

		$ttl = isset( $body['expires_in'] ) ? max( 60, (int) $body['expires_in'] - 600 ) : 50 * MINUTE_IN_SECONDS;
		set_transient( $cache_key, $body['access_token'], $ttl );
		return $body['access_token'];
	}

	/**
	 * Inspect one URL. The caller must have reserved quota first.
	 *
	 * @param string $url URL inside the property.
	 * @return array|WP_Error The `inspectionResult` object.
	 */
	public static function inspect( $url ) {
		$body = array(
			'inspectionUrl' => $url,
			'siteUrl'       => SIA_Settings::property(),
			'languageCode'  => 'en-US',
		);
		$result = self::request( 'POST', self::INSPECT_URL, $body );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( empty( $result['inspectionResult'] ) ) {
			return new WP_Error( 'sia_empty', __( 'Google returned an empty inspection result.', 'vyntic-index-assistant' ) );
		}
		return $result['inspectionResult'];
	}

	/**
	 * Submit (resubmit) the sitemap to Search Console.
	 *
	 * @param string $sitemap_url Full sitemap URL.
	 * @return true|WP_Error
	 */
	public static function submit_sitemap( $sitemap_url ) {
		$url    = self::SITES_URL . '/' . rawurlencode( SIA_Settings::property() ) . '/sitemaps/' . rawurlencode( $sitemap_url );
		$result = self::request( 'PUT', $url );
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Check that the service account can see the property (no inspection quota used).
	 *
	 * @return array|WP_Error {property, permission}
	 */
	public static function test_connection() {
		$result = self::request( 'GET', self::SITES_URL );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$property = SIA_Settings::property();
		$sites    = isset( $result['siteEntry'] ) ? (array) $result['siteEntry'] : array();
		foreach ( $sites as $site ) {
			if ( isset( $site['siteUrl'] ) && $site['siteUrl'] === $property ) {
				return array(
					'property'   => $property,
					'permission' => isset( $site['permissionLevel'] ) ? $site['permissionLevel'] : '',
				);
			}
		}
		$creds   = SIA_Settings::credentials();
		$visible = array_filter( wp_list_pluck( $sites, 'siteUrl' ) );
		if ( $visible ) {
			return new WP_Error(
				'sia_property',
				sprintf(
					/* translators: 1: property, 2: list of properties */
					__( 'The property %1$s was not found, but the service account can see: %2$s. Copy one of these exactly into Settings → Search Console property.', 'vyntic-index-assistant' ),
					$property,
					implode( ', ', $visible )
				)
			);
		}
		return new WP_Error(
			'sia_property',
			sprintf(
				/* translators: 1: property, 2: service account email */
				__( 'The service account cannot see any Search Console property yet (looking for %1$s). In Search Console → Settings → Users and permissions, add %2$s as a user (Full). It can take a few minutes to work.', 'vyntic-index-assistant' ),
				$property,
				$creds ? $creds['client_email'] : ''
			)
		);
	}

	/**
	 * Authenticated JSON request.
	 *
	 * @param string     $method HTTP method.
	 * @param string     $url    Endpoint.
	 * @param array|null $body   JSON body.
	 * @return array|WP_Error Decoded body. WP_Error data carries the HTTP status.
	 */
	private static function request( $method, $url, $body = null ) {
		$token = self::token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$args = array(
			'method'  => $method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		} elseif ( 'GET' !== $method ) {
			// Google answers 411 to a body-less PUT/POST without an explicit length.
			$args['body']                      = '';
			$args['headers']['Content-Length'] = '0';
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();

		if ( $code < 200 || $code >= 300 ) {
			$message = isset( $data['error']['message'] ) ? $data['error']['message'] : sprintf( 'HTTP %d', $code );
			$status  = isset( $data['error']['status'] ) ? $data['error']['status'] : '';
			return new WP_Error(
				'sia_http',
				$message,
				array(
					'status'        => $code,
					'google_status' => $status,
				)
			);
		}
		return $data;
	}

	/**
	 * Base64url without padding.
	 *
	 * @param string $data Raw bytes.
	 * @return string
	 */
	private static function b64( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}
}
