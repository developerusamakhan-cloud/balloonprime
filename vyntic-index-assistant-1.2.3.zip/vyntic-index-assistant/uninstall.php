<?php
/**
 * Uninstall: only removes data when the "Delete all data on uninstall" setting is enabled.
 *
 * @package SafeIndexAssistant
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

wp_clear_scheduled_hook( 'sia_run' );

// The Google private key is always removed; it should never outlive the plugin.
delete_option( 'sia_service_account' );

$sia_settings = get_option( 'sia_settings', array() );

if ( ! empty( $sia_settings['delete_on_uninstall'] ) ) {
	global $wpdb;
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}sia_urls" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( array( 'sia_settings', 'sia_db_version', 'sia_quota', 'sia_last_run', 'sia_sitemap_last', 'sia_indexnow_key', 'sia_indexnow_queue', 'sia_indexnow_last' ) as $sia_option ) {
		delete_option( $sia_option );
	}
}
