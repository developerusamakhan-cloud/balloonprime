=== Vyntic AI Planner ===
Stable tag: 1.0.6
Requires at least: 6.3
Requires PHP: 7.4
License: GPLv2 or later

AI homepage planner that turns website visitors into leads.

== How it works ==
1. The visitor describes their business and picks a goal.
2. They enter their name (optional) and email, and tick the consent box.
3. The AI writes a homepage plan: headline, 5 sections, 3 features and one quick win.
4. The plan appears on the page, a copy is emailed to the visitor, and you get a lead alert.
Every request is saved under AI Planner, Leads (with CSV export), even if the AI fails.

== Setup (5 minutes) ==
1. Upload and activate the plugin.
2. Get a free API key at https://aistudio.google.com/apikey
3. AI Planner, Settings: paste the key, keep the model on a Flash model, save.
4. Click "Test connection".
5. The Vyntic theme shows the planner on the homepage automatically.
   On any other page use the shortcode [vyntic_planner] or [vyntic_planner theme="light"].

== Free tier notes ==
* Google's free Gemini tier has daily limits that change from time to time. Keep
  "Plans per day for the whole site" below your limit.
* On the free tier Google may use prompts to improve its models. Visitors only
  share a short business description, but mention AI processing in your privacy policy.
* Optional backup: add a free Groq key (https://console.groq.com) as the
  OpenAI-compatible provider. If Gemini is busy, the planner uses Groq instead.
* Install an SMTP plugin (for example WP Mail SMTP) so plan emails reach inboxes.

== Security ==
API keys stay on the server and are never shown again after saving. Requests are
protected by a nonce, a honeypot, a minimum fill time, per-visitor and daily limits.

== Changelog ==
= 1.0.6 =
* Leads show a "Plan email" column: Sent, Failed (with the exact error from the mail server)
  or Not sent (with the reason). The lead screen also shows the lead-alert result.
* New "Send test email" button in Settings: sends the real visitor email with a sample plan.
* Optional "Sender email" setting (use an address on your own domain, never Gmail).
* When no SMTP plugin sets a sender name, emails come from your "Email sender name"
  instead of "WordPress".
= 1.0.5 =
* New branded email design for the plan sent to the visitor: logo header, a browser-style
  preview of their new hero, numbered sections, feature cards, a quick-win box and a
  "Want this built for real?" call-to-action panel. Works on phones and in Outlook.
* New lead alert design with the lead's details, a "Reply to" button and the plan they received.
* Both emails now include a plain-text version, which helps them reach the inbox.
= 1.0.4 =
* Fixed "Please try again." for real visitors. Browser autofill or a password manager could fill
  the hidden anti-bot field, which blocked the request. That field alone no longer blocks anyone;
  only very fast submissions (a bot filling everything at once) are stopped.
* The hidden field is hidden with inline styles too, so it stays hidden if a speed plugin delays CSS.
= 1.0.3 =
* When Google or the backup provider retires a model, the planner reads the list of models
  your key can use, picks a current one (Gemini: the model Google suggests, else the newest
  Flash; Groq/OpenRouter: a strong chat model), retries, and saves it. A notice on the
  settings page says which model it switched to.
* New defaults: gemini-flash-latest and openai/gpt-oss-120b.
= 1.0.2 =
* Errors now name every provider that was tried (Gemini, Backup API, WordPress AI Client),
  so the real cause is no longer hidden behind the last one.
* The WordPress AI Client is only used when a provider is connected in Settings, Connectors.
* Gemini keys in the newer "AQ." format are supported (sent as header, as ?key=, then via
  the Vertex AI express endpoint). "models/" in front of the model name is removed.
* Test connection checks each provider separately and shows the result for each one.
* Settings warn when the backup key is the same as the Gemini key or is not a Groq key.
= 1.0.1 =
* Fixed "This page has been open a long time" when you test the planner while logged in,
  and on cached pages. The form now uses a token that does not depend on who is logged in,
  and fetches a fresh one automatically when the page is old.
* Settings: shows "Settings saved" after saving, and shows which API key is saved
  (for example AIza…7890) so you can see the key was stored. Spaces in pasted keys are removed.
