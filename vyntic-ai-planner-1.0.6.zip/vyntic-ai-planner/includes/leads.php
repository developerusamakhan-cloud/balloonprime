<?php
/**
 * Leads: every plan request is saved under AI Planner, Leads.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type(
		'vap_lead',
		array(
			'labels'          => array(
				'name'          => __( 'Leads', 'vyntic-ai-planner' ),
				'singular_name' => __( 'Lead', 'vyntic-ai-planner' ),
				'all_items'     => __( 'Leads', 'vyntic-ai-planner' ),
				'edit_item'     => __( 'Lead', 'vyntic-ai-planner' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'vap-settings',
			'supports'        => array( 'title' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);
} );

/**
 * Save a lead.
 *
 * @param array $lead name, email, business, goal, plan, status, error.
 * @return int Post ID.
 */
function vap_save_lead( $lead ) {
	$id = wp_insert_post(
		array(
			'post_type'   => 'vap_lead',
			'post_status' => 'publish',
			'post_title'  => $lead['email'],
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		foreach ( array( 'name', 'email', 'business', 'goal', 'status', 'error' ) as $k ) {
			if ( isset( $lead[ $k ] ) ) {
				update_post_meta( $id, '_vap_' . $k, $lead[ $k ] );
			}
		}
		if ( ! empty( $lead['plan'] ) ) {
			update_post_meta( $id, '_vap_plan', wp_json_encode( $lead['plan'] ) );
		}
		update_post_meta( $id, '_vap_page', isset( $lead['page'] ) ? esc_url_raw( $lead['page'] ) : '' );
	}
	return (int) $id;
}

/* Admin list columns. */
add_filter( 'manage_vap_lead_posts_columns', function () {
	return array(
		'cb'       => '<input type="checkbox">',
		'title'    => __( 'Email', 'vyntic-ai-planner' ),
		'vap_name' => __( 'Name', 'vyntic-ai-planner' ),
		'vap_biz'  => __( 'Business', 'vyntic-ai-planner' ),
		'vap_goal' => __( 'Goal', 'vyntic-ai-planner' ),
		'vap_stat' => __( 'Plan', 'vyntic-ai-planner' ),
		'vap_mail' => __( 'Plan email', 'vyntic-ai-planner' ),
		'date'     => __( 'Date', 'vyntic-ai-planner' ),
	);
} );

add_action( 'manage_vap_lead_posts_custom_column', function ( $col, $id ) {
	$map = array( 'vap_name' => '_vap_name', 'vap_biz' => '_vap_business', 'vap_goal' => '_vap_goal' );
	if ( isset( $map[ $col ] ) ) {
		echo esc_html( wp_trim_words( (string) get_post_meta( $id, $map[ $col ], true ), 14 ) );
	} elseif ( 'vap_mail' === $col ) {
		echo wp_kses_post( vap_mail_status_html( get_post_meta( $id, '_vap_mail_visitor', true ) ) );
	} elseif ( 'vap_stat' === $col ) {
		echo 'sent' === get_post_meta( $id, '_vap_status', true ) ? esc_html__( 'Delivered', 'vyntic-ai-planner' ) : '<span style="color:#b32d2e">' . esc_html__( 'AI failed, follow up by email', 'vyntic-ai-planner' ) . '</span>';
	}
}, 10, 2 );

/* Lead detail screen: show everything read-only. */
add_action( 'add_meta_boxes_vap_lead', function () {
	add_meta_box(
		'vap_lead_detail',
		__( 'Lead details', 'vyntic-ai-planner' ),
		function ( $post ) {
			$rows = array(
				__( 'Name', 'vyntic-ai-planner' )     => get_post_meta( $post->ID, '_vap_name', true ),
				__( 'Email', 'vyntic-ai-planner' )    => get_post_meta( $post->ID, '_vap_email', true ),
				__( 'Business', 'vyntic-ai-planner' ) => get_post_meta( $post->ID, '_vap_business', true ),
				__( 'Goal', 'vyntic-ai-planner' )     => get_post_meta( $post->ID, '_vap_goal', true ),
				__( 'Page', 'vyntic-ai-planner' )     => get_post_meta( $post->ID, '_vap_page', true ),
				__( 'Error', 'vyntic-ai-planner' )    => get_post_meta( $post->ID, '_vap_error', true ),
			);
			echo '<table class="form-table">';
			foreach ( $rows as $k => $v ) {
				if ( '' !== (string) $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . nl2br( esc_html( $v ) ) . '</td></tr>';
				}
			}
			echo '<tr><th>' . esc_html__( 'Plan email to visitor', 'vyntic-ai-planner' ) . '</th><td>' . wp_kses_post( vap_mail_status_html( get_post_meta( $post->ID, '_vap_mail_visitor', true ) ) ) . '</td></tr>';
			echo '<tr><th>' . esc_html__( 'Lead alert to you', 'vyntic-ai-planner' ) . '</th><td>' . wp_kses_post( vap_mail_status_html( get_post_meta( $post->ID, '_vap_mail_owner', true ) ) ) . '</td></tr>';
			echo '</table>';
			$plan = json_decode( (string) get_post_meta( $post->ID, '_vap_plan', true ), true );
			if ( $plan ) {
				echo '<h3>' . esc_html__( 'Plan sent', 'vyntic-ai-planner' ) . '</h3>' . wp_kses_post( vap_plan_html( $plan ) );
			}
		},
		'vap_lead',
		'normal',
		'high'
	);
	remove_meta_box( 'submitdiv', 'vap_lead', 'side' );
} );

/* CSV export button on the Leads list. */
add_action( 'manage_posts_extra_tablenav', function ( $which ) {
	if ( 'top' === $which && 'vap_lead' === get_current_screen()->post_type ) {
		echo '<a class="button" style="margin-left:6px" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vap_export' ), 'vap_export' ) ) . '">' . esc_html__( 'Export CSV', 'vyntic-ai-planner' ) . '</a>';
	}
} );

add_action( 'admin_post_vap_export', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vap_export' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic-ai-planner' ) );
	}
	$leads = get_posts( array( 'post_type' => 'vap_lead', 'posts_per_page' => -1 ) );
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=planner-leads-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	fputcsv( $out, array( 'Date', 'Name', 'Email', 'Business', 'Goal', 'Plan delivered', 'Headline' ) );
	foreach ( $leads as $l ) {
		$plan = json_decode( (string) get_post_meta( $l->ID, '_vap_plan', true ), true );
		fputcsv(
			$out,
			array(
				get_the_date( 'Y-m-d H:i', $l ),
				get_post_meta( $l->ID, '_vap_name', true ),
				get_post_meta( $l->ID, '_vap_email', true ),
				get_post_meta( $l->ID, '_vap_business', true ),
				get_post_meta( $l->ID, '_vap_goal', true ),
				'sent' === get_post_meta( $l->ID, '_vap_status', true ) ? 'yes' : 'no',
				isset( $plan['headline'] ) ? $plan['headline'] : '',
			)
		);
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/**
 * Plan as simple HTML (used in emails and the lead screen).
 *
 * @param array $p Plan.
 * @return string
 */
function vap_plan_html( $p ) {
	$h  = '<h2 style="margin:0 0 6px;font-size:22px">' . esc_html( $p['headline'] ) . '</h2>';
	$h .= '<p style="margin:0 0 16px;color:#4a6266">' . esc_html( $p['subheadline'] ) . '</p>';
	$h .= '<p style="margin:0 0 6px"><strong>' . esc_html__( 'Homepage sections', 'vyntic-ai-planner' ) . '</strong></p><ol style="margin:0 0 16px;padding-left:20px">';
	foreach ( (array) $p['sections'] as $s ) {
		$h .= '<li style="margin-bottom:6px"><strong>' . esc_html( $s['name'] ) . '</strong>: ' . esc_html( $s['why'] ) . '</li>';
	}
	$h .= '</ol><p style="margin:0 0 6px"><strong>' . esc_html__( 'Must-have features', 'vyntic-ai-planner' ) . '</strong></p><ul style="margin:0 0 16px;padding-left:20px">';
	foreach ( (array) $p['features'] as $f ) {
		$h .= '<li>' . esc_html( $f ) . '</li>';
	}
	$h .= '</ul>';
	if ( ! empty( $p['quick_win'] ) ) {
		$h .= '<p style="margin:0;padding:12px 14px;background:#fdf1ec;border-left:3px solid #c7431f"><strong>' . esc_html__( 'Quick win:', 'vyntic-ai-planner' ) . '</strong> ' . esc_html( $p['quick_win'] ) . '</p>';
	}
	return $h;
}

/**
 * Send the plan to the visitor and a lead alert to the site owner.
 *
 * @param array      $lead Lead data.
 * @param array|null $plan Plan, or null if the AI failed.
 */
function vap_send_emails( $lead, $plan, $lead_id = 0 ) {
	$from_name = vap_opt( 'from_name' ) ? vap_opt( 'from_name' ) : get_bloginfo( 'name' );
	$notify    = vap_opt( 'notify_email' );
	$lead      = wp_parse_args( $lead, array( 'name' => '', 'email' => '', 'goal' => '', 'business' => '', 'page' => '' ) );

	// Record what happened to each email on the lead, so problems are visible under Leads.
	if ( ! $plan ) {
		$visitor = 'skipped:' . __( 'no plan, the AI did not answer', 'vyntic-ai-planner' );
	} elseif ( ! vap_opt( 'send_copy' ) ) {
		$visitor = 'skipped:' . __( '"Email the plan to the visitor" is off in Settings', 'vyntic-ai-planner' );
	} else {
		$h = array();
		if ( $notify ) {
			$h[] = 'Reply-To: ' . $from_name . ' <' . $notify . '>';
		}
		$visitor = vap_mail( $lead['email'], __( 'Your homepage plan is ready', 'vyntic-ai-planner' ), vap_mail_visitor_html( $lead, $plan ), vap_mail_visitor_text( $lead, $plan ), $h )
			? 'sent'
			: 'failed:' . vap_mail_error();
	}

	$owner = 'skipped:' . __( 'no "Send new leads to" email in Settings', 'vyntic-ai-planner' );
	if ( $notify ) {
		$h = array( 'Reply-To: ' . ( $lead['name'] ? $lead['name'] : $lead['email'] ) . ' <' . $lead['email'] . '>' );
		/* translators: %s email */
		$owner = vap_mail( $notify, sprintf( __( 'New planner lead: %s', 'vyntic-ai-planner' ), $lead['email'] ), vap_mail_owner_html( $lead, $plan ), vap_mail_owner_text( $lead, $plan ), $h )
			? 'sent'
			: 'failed:' . vap_mail_error();
	}

	if ( $lead_id ) {
		update_post_meta( $lead_id, '_vap_mail_visitor', $visitor );
		update_post_meta( $lead_id, '_vap_mail_owner', $owner );
	}
}

/**
 * Readable email status.
 *
 * @param string $status sent, failed:reason or skipped:reason.
 * @return string HTML.
 */
function vap_mail_status_html( $status ) {
	if ( '' === (string) $status ) {
		return '<span style="color:#646970">-</span>';
	}
	if ( 'sent' === $status ) {
		return '<span style="color:#008a20;font-weight:600">&#10003; ' . esc_html__( 'Sent', 'vyntic-ai-planner' ) . '</span>';
	}
	list( $kind, $why ) = array_pad( explode( ':', $status, 2 ), 2, '' );
	return 'failed' === $kind
		? '<span style="color:#b32d2e;font-weight:600">&#10007; ' . esc_html__( 'Failed', 'vyntic-ai-planner' ) . '</span><br><small>' . esc_html( $why ) . '</small>'
		: '<span style="color:#646970">' . esc_html__( 'Not sent', 'vyntic-ai-planner' ) . '</span><br><small>' . esc_html( $why ) . '</small>';
}
