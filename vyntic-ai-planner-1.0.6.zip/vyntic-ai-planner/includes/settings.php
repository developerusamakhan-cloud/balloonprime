<?php
/**
 * Settings: AI Planner → Settings.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Default settings. */
function vap_defaults() {
	return array(
		'provider'       => 'gemini',
		'gemini_key'     => '',
		'gemini_model'   => 'gemini-flash-latest',
		'oa_base'        => 'https://api.groq.com/openai/v1',
		'oa_key'         => '',
		'oa_model'       => 'openai/gpt-oss-120b',
		'fallback'       => 1,
		'per_visitor'    => 3,
		'daily_cap'      => 200,
		'notify_email'   => get_option( 'admin_email' ),
		'send_copy'      => 1,
		'from_name'      => get_bloginfo( 'name' ),
		'from_email'     => '',
		'cta_url'        => '',
		'cta_label'      => 'Book a free project call',
		'consent_text'   => 'Send me my plan by email and contact me about my project. No spam, unsubscribe anytime.',
		'privacy_url'    => '',
		'agency_context' => 'Vyntic Studio is a web design, SEO and AI search studio. It builds fast websites on WordPress, Webflow, Shopify, Wix and GoHighLevel, and offers local SEO, AI search visibility and care plans.',
	);
}

/** Get one setting. */
function vap_opt( $key ) {
	$all = wp_parse_args( (array) get_option( 'vap_settings', array() ), vap_defaults() );
	return isset( $all[ $key ] ) ? $all[ $key ] : '';
}

add_action( 'admin_menu', function () {
	add_menu_page( __( 'AI Planner', 'vyntic-ai-planner' ), __( 'AI Planner', 'vyntic-ai-planner' ), 'manage_options', 'vap-settings', 'vap_settings_screen', 'dashicons-lightbulb', 58 );
	add_submenu_page( 'vap-settings', __( 'Settings', 'vyntic-ai-planner' ), __( 'Settings', 'vyntic-ai-planner' ), 'manage_options', 'vap-settings', 'vap_settings_screen' );
} );

add_action( 'admin_init', function () {
	register_setting(
		'vap_settings_group',
		'vap_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'vap_sanitize_settings',
		)
	);
} );

/**
 * Sanitize settings. Saved API keys are kept when the field is left empty,
 * because keys are never printed back into the form.
 *
 * @param array $in Raw input.
 * @return array
 */
function vap_sanitize_settings( $in ) {
	$in  = (array) $in;
	$d   = vap_defaults();
	$old = (array) get_option( 'vap_settings', array() );
	$get = function ( $k, $fallback = '' ) use ( $in ) {
		return isset( $in[ $k ] ) ? $in[ $k ] : $fallback;
	};
	$out                 = array();
	$out['provider']     = in_array( $get( 'provider' ), array( 'gemini', 'openai', 'wp' ), true ) ? $get( 'provider' ) : 'gemini';
	$out['gemini_key']   = trim( (string) $get( 'gemini_key' ) ) ? preg_replace( '/\s+/', '', sanitize_text_field( $get( 'gemini_key' ) ) ) : ( isset( $old['gemini_key'] ) ? $old['gemini_key'] : '' );
	$out['oa_key']       = trim( (string) $get( 'oa_key' ) ) ? preg_replace( '/\s+/', '', sanitize_text_field( $get( 'oa_key' ) ) ) : ( isset( $old['oa_key'] ) ? $old['oa_key'] : '' );
	if ( $get( 'clear_gemini' ) ) {
		$out['gemini_key'] = '';
	}
	if ( $get( 'clear_oa' ) ) {
		$out['oa_key'] = '';
	}
	$out['gemini_model']   = sanitize_text_field( $get( 'gemini_model' ) ? $get( 'gemini_model' ) : $d['gemini_model'] );
	$out['oa_base']        = esc_url_raw( untrailingslashit( $get( 'oa_base' ) ? $get( 'oa_base' ) : $d['oa_base'] ) );
	$out['oa_model']       = sanitize_text_field( $get( 'oa_model' ) ? $get( 'oa_model' ) : $d['oa_model'] );
	$out['fallback']       = $get( 'fallback' ) ? 1 : 0;
	$out['per_visitor']    = max( 1, min( 50, absint( $get( 'per_visitor', 3 ) ) ) );
	$out['daily_cap']      = max( 1, min( 5000, absint( $get( 'daily_cap', 200 ) ) ) );
	$out['notify_email']   = sanitize_email( $get( 'notify_email' ) );
	$out['send_copy']      = $get( 'send_copy' ) ? 1 : 0;
	$out['from_name']      = sanitize_text_field( $get( 'from_name' ) );
	$out['from_email']     = sanitize_email( $get( 'from_email' ) );
	$out['cta_url']        = esc_url_raw( $get( 'cta_url' ) );
	$out['cta_label']      = sanitize_text_field( $get( 'cta_label', $d['cta_label'] ) );
	$out['consent_text']   = sanitize_text_field( $get( 'consent_text', $d['consent_text'] ) );
	$out['privacy_url']    = esc_url_raw( $get( 'privacy_url' ) );
	$out['agency_context'] = sanitize_textarea_field( $get( 'agency_context', $d['agency_context'] ) );
	return $out;
}

/** "Send test email" button: sends the real visitor email with a sample plan. */
add_action( 'admin_post_vap_test_mail', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vap_test_mail' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic-ai-planner' ) );
	}
	$to = isset( $_POST['vap_to'] ) ? sanitize_email( wp_unslash( $_POST['vap_to'] ) ) : '';
	if ( ! is_email( $to ) ) {
		$msg = 'error:' . __( 'Enter a valid email address to send the test to.', 'vyntic-ai-planner' );
	} else {
		$lead = array( 'name' => 'Test', 'email' => $to, 'goal' => 'Online bookings', 'business' => 'Test', 'page' => '' );
		$h    = vap_opt( 'notify_email' ) ? array( 'Reply-To: ' . ( vap_opt( 'from_name' ) ? vap_opt( 'from_name' ) : get_bloginfo( 'name' ) ) . ' <' . vap_opt( 'notify_email' ) . '>' ) : array();
		$ok   = vap_mail( $to, __( 'Your homepage plan is ready', 'vyntic-ai-planner' ) . ' (test)', vap_mail_visitor_html( $lead, vap_sample_plan() ), vap_mail_visitor_text( $lead, vap_sample_plan() ), $h );
		/* translators: %s email */
		$msg  = $ok ? 'ok:' . sprintf( __( 'WordPress handed the test email to your mail server for %s. If it does not arrive within a few minutes, check Spam and Promotions, then your SMTP plugin\'s email log.', 'vyntic-ai-planner' ), $to ) : 'error:' . vap_mail_error();
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'vap-settings', 'vap_mail' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
	exit;
} );

/** "Test connection" button. */
add_action( 'admin_post_vap_test', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'vap_test' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic-ai-planner' ) );
	}
	$lines = array();
	$all_ok = false;
	foreach ( array( 'gemini', 'openai', 'wp' ) as $p ) {
		if ( ! vap_provider_ready( $p ) ) {
			continue;
		}
		$fn  = 'vap_call_' . $p;
		$res = $fn( 'Reply with JSON only, exactly: {"ok": true}', 'Test' );
		$ok  = ! is_wp_error( $res ) && '' !== trim( (string) $res );
		$all_ok  = $all_ok || $ok;
		$lines[] = ( $ok ? 'OK ' : 'FAIL ' ) . vap_provider_label( $p ) . ( $ok ? '' : ': ' . $res->get_error_message() );
	}
	$msg = $lines ? ( $all_ok ? 'ok:' : 'error:' ) . implode( " ;; ", $lines ) : 'error:' . __( 'No AI provider is set up yet. Add an API key first.', 'vyntic-ai-planner' );
	wp_safe_redirect( add_query_arg( array( 'page' => 'vap-settings', 'vap_test' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
	exit;
} );

/**
 * Short, safe preview of a saved key, e.g. "AIza…7890".
 *
 * @param string $key Key.
 * @return string
 */
function vap_key_preview( $key ) {
	$key = (string) $key;
	return strlen( $key ) > 10 ? substr( $key, 0, 4 ) . '…' . substr( $key, -4 ) : str_repeat( '•', 6 );
}

/**
 * "Key saved" line under a key field.
 *
 * @param string $key Saved key.
 */
function vap_key_status( $key ) {
	if ( $key ) {
		/* translators: %s key preview */
		echo '<p class="description" style="color:#008a20;font-weight:600">&#10003; ' . esc_html( sprintf( __( 'Key saved: %s. Leave the field empty to keep it, or paste a new key to replace it.', 'vyntic-ai-planner' ), vap_key_preview( $key ) ) ) . '</p>';
	} else {
		echo '<p class="description" style="color:#b32d2e;font-weight:600">' . esc_html__( 'No key saved yet.', 'vyntic-ai-planner' ) . '</p>';
	}
}

function vap_settings_screen() {
	$o = wp_parse_args( (array) get_option( 'vap_settings', array() ), vap_defaults() );
	$f = function ( $k ) {
		return 'vap_settings[' . $k . ']';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Vyntic AI Planner', 'vyntic-ai-planner' ); ?></h1>
		<?php settings_errors(); ?>
		<?php
		$vap_note = get_option( 'vap_model_note' );
		if ( is_array( $vap_note ) && ! empty( $vap_note['model'] ) && time() - (int) $vap_note['time'] < WEEK_IN_SECONDS ) :
			?>
			<div class="notice notice-info"><p>
				<?php
				/* translators: 1: Gemini or Backup, 2: model name */
				echo esc_html( sprintf( __( 'The %1$s model you had was retired, so the planner switched to %2$s by itself. Nothing to do.', 'vyntic-ai-planner' ), 'gemini_model' === $vap_note['field'] ? 'Gemini' : __( 'backup', 'vyntic-ai-planner' ), $vap_note['model'] ) );
				?>
			</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['vap_mail'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<?php $vap_m = sanitize_text_field( wp_unslash( $_GET['vap_mail'] ) ); // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice <?php echo 0 === strpos( $vap_m, 'error:' ) ? 'notice-error' : 'notice-success'; ?>"><p>
				<strong><?php echo 0 === strpos( $vap_m, 'error:' ) ? esc_html__( 'Test email failed:', 'vyntic-ai-planner' ) : esc_html__( 'Test email sent.', 'vyntic-ai-planner' ); ?></strong>
				<?php echo esc_html( substr( $vap_m, strpos( $vap_m, ':' ) + 1 ) ); ?>
			</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['vap_test'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<?php $vap_t = sanitize_textarea_field( wp_unslash( $_GET['vap_test'] ) ); // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice <?php echo 0 === strpos( $vap_t, 'error:' ) ? 'notice-error' : 'notice-success'; ?>">
				<p><strong><?php echo 0 === strpos( $vap_t, 'error:' ) ? esc_html__( 'Connection failed.', 'vyntic-ai-planner' ) : esc_html__( 'Connection works. The planner is ready.', 'vyntic-ai-planner' ); ?></strong></p>
				<?php foreach ( array_filter( explode( " ;; ", substr( $vap_t, strpos( $vap_t, ':' ) + 1 ) ) ) as $vap_line ) : ?>
					<p><?php echo 0 === strpos( $vap_line, 'OK ' ) ? '&#10003; ' . esc_html( substr( $vap_line, 3 ) ) : ( 0 === strpos( $vap_line, 'FAIL ' ) ? '&#10007; ' . esc_html( substr( $vap_line, 5 ) ) : esc_html( $vap_line ) ); ?></p>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<p><?php echo wp_kses_post( __( 'Add the planner anywhere with the shortcode <code>[vyntic_planner]</code>. The Vyntic theme shows it on the homepage automatically.', 'vyntic-ai-planner' ) ); ?></p>

		<form method="post" action="options.php">
			<?php settings_fields( 'vap_settings_group' ); ?>
			<h2><?php esc_html_e( 'AI provider', 'vyntic-ai-planner' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Main provider', 'vyntic-ai-planner' ); ?></th><td>
					<select name="<?php echo esc_attr( $f( 'provider' ) ); ?>">
						<option value="gemini" <?php selected( $o['provider'], 'gemini' ); ?>><?php esc_html_e( 'Google Gemini (free tier)', 'vyntic-ai-planner' ); ?></option>
						<option value="openai" <?php selected( $o['provider'], 'openai' ); ?>><?php esc_html_e( 'OpenAI-compatible API (Groq, OpenRouter, OpenAI)', 'vyntic-ai-planner' ); ?></option>
						<option value="wp" <?php selected( $o['provider'], 'wp' ); ?> <?php disabled( ! vap_wp_ai_ready() && 'wp' !== $o['provider'] ); ?>><?php esc_html_e( 'WordPress AI Client (Settings, Connectors)', 'vyntic-ai-planner' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'If the main provider fails or hits its free limit, the planner can try the other provider you set up below.', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Gemini API key', 'vyntic-ai-planner' ); ?></th><td>
					<input type="password" class="regular-text" name="<?php echo esc_attr( $f( 'gemini_key' ) ); ?>" value="" placeholder="<?php echo $o['gemini_key'] ? esc_attr( vap_key_preview( $o['gemini_key'] ) ) : 'AIza...'; ?>" autocomplete="new-password" spellcheck="false">
					<?php vap_key_status( $o['gemini_key'] ); ?>
					<?php if ( $o['gemini_key'] ) : ?><label><input type="checkbox" name="<?php echo esc_attr( $f( 'clear_gemini' ) ); ?>" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-ai-planner' ); ?></label><?php endif; ?>
					<p class="description"><?php echo wp_kses_post( __( 'Get a free key from <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>. No card needed.', 'vyntic-ai-planner' ) ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Gemini model', 'vyntic-ai-planner' ); ?></th><td>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'gemini_model' ) ); ?>" value="<?php echo esc_attr( $o['gemini_model'] ); ?>">
					<p class="description"><?php esc_html_e( 'Use a Flash or Flash-Lite model, which stay on the free tier. gemini-flash-latest always points to the current Flash model. If Google retires a model, the planner picks a current one by itself.', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: API base URL', 'vyntic-ai-planner' ); ?></th><td>
					<input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'oa_base' ) ); ?>" value="<?php echo esc_attr( $o['oa_base'] ); ?>">
					<p class="description"><?php esc_html_e( 'Groq: https://api.groq.com/openai/v1. OpenRouter: https://openrouter.ai/api/v1. OpenAI: https://api.openai.com/v1', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: API key', 'vyntic-ai-planner' ); ?></th><td>
					<input type="password" class="regular-text" name="<?php echo esc_attr( $f( 'oa_key' ) ); ?>" value="" placeholder="<?php echo $o['oa_key'] ? esc_attr( vap_key_preview( $o['oa_key'] ) ) : ''; ?>" autocomplete="new-password" spellcheck="false">
					<?php if ( $o['oa_key'] ) { vap_key_status( $o['oa_key'] ); } ?>
					<?php if ( $o['oa_key'] && $o['oa_key'] === $o['gemini_key'] ) : ?>
						<p class="description" style="color:#b32d2e;font-weight:600"><?php esc_html_e( 'This is the same key as your Gemini key, so the backup cannot work. Paste a Groq key here (it starts with gsk_), or tick "Remove saved key".', 'vyntic-ai-planner' ); ?></p>
					<?php elseif ( $o['oa_key'] && false !== strpos( $o['oa_base'], 'groq.com' ) && 0 !== strpos( $o['oa_key'], 'gsk_' ) ) : ?>
						<p class="description" style="color:#b32d2e;font-weight:600"><?php esc_html_e( 'Groq keys start with gsk_. This key looks like it is from another service.', 'vyntic-ai-planner' ); ?></p>
					<?php endif; ?>
					<p class="description"><?php echo wp_kses_post( __( 'Optional. Free Groq key: <a href="https://console.groq.com/keys" target="_blank" rel="noopener">console.groq.com/keys</a>. Do not paste your Gemini key here.', 'vyntic-ai-planner' ) ); ?></p>
					<?php if ( $o['oa_key'] ) : ?><label><input type="checkbox" name="<?php echo esc_attr( $f( 'clear_oa' ) ); ?>" value="1"> <?php esc_html_e( 'Remove saved key', 'vyntic-ai-planner' ); ?></label><?php endif; ?>
				</td></tr>
				<tr><th><?php esc_html_e( 'Backup: model', 'vyntic-ai-planner' ); ?></th><td>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'oa_model' ) ); ?>" value="<?php echo esc_attr( $o['oa_model'] ); ?>">
					<p class="description"><?php esc_html_e( 'If this model is retired, the planner picks a current one from your provider by itself.', 'vyntic-ai-planner' ); ?></p>
				</td></tr>
				<tr><th><?php esc_html_e( 'Use backup provider', 'vyntic-ai-planner' ); ?></th><td>
					<label><input type="checkbox" name="<?php echo esc_attr( $f( 'fallback' ) ); ?>" value="1" <?php checked( $o['fallback'], 1 ); ?>> <?php esc_html_e( 'Try the other provider if the main one fails', 'vyntic-ai-planner' ); ?></label>
				</td></tr>
			</table>

			<h2><?php esc_html_e( 'Leads and limits', 'vyntic-ai-planner' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Send new leads to', 'vyntic-ai-planner' ); ?></th><td><input type="email" class="regular-text" name="<?php echo esc_attr( $f( 'notify_email' ) ); ?>" value="<?php echo esc_attr( $o['notify_email'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Email the plan to the visitor', 'vyntic-ai-planner' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( $f( 'send_copy' ) ); ?>" value="1" <?php checked( $o['send_copy'], 1 ); ?>> <?php esc_html_e( 'Yes, send a copy of their plan', 'vyntic-ai-planner' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Email sender name', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'from_name' ) ); ?>" value="<?php echo esc_attr( $o['from_name'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Sender email', 'vyntic-ai-planner' ); ?></th><td><input type="email" class="regular-text" name="<?php echo esc_attr( $f( 'from_email' ) ); ?>" value="<?php echo esc_attr( $o['from_email'] ); ?>" placeholder="<?php echo esc_attr( 'hello@' . preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ); ?>">
					<p class="description"><?php esc_html_e( 'Optional. Leave empty to use the sender set by your SMTP plugin or WordPress. If you fill it in, use an address on your own domain (for example hello@vyntic.studio), never a Gmail or Yahoo address: other servers cannot send as those, so inboxes reject the email.', 'vyntic-ai-planner' ); ?></p>
					<?php if ( $o['from_email'] && preg_match( '/@(gmail|googlemail|yahoo|hotmail|outlook|live|icloud|aol)\./i', $o['from_email'] ) ) : ?>
						<p class="description" style="color:#b32d2e;font-weight:600"><?php esc_html_e( 'This is a free email address. Emails sent "from" it by your website are usually rejected or marked as spam. Use an address on your own domain, or leave this empty.', 'vyntic-ai-planner' ); ?></p>
					<?php endif; ?>
				</td></tr>
				<tr><th><?php esc_html_e( 'Plans per visitor per day', 'vyntic-ai-planner' ); ?></th><td><input type="number" min="1" max="50" name="<?php echo esc_attr( $f( 'per_visitor' ) ); ?>" value="<?php echo esc_attr( $o['per_visitor'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Plans per day for the whole site', 'vyntic-ai-planner' ); ?></th><td><input type="number" min="1" max="5000" name="<?php echo esc_attr( $f( 'daily_cap' ) ); ?>" value="<?php echo esc_attr( $o['daily_cap'] ); ?>">
					<p class="description"><?php esc_html_e( 'Keep this below your free API daily limit.', 'vyntic-ai-planner' ); ?></p></td></tr>
				<tr><th><?php esc_html_e( 'Result button link', 'vyntic-ai-planner' ); ?></th><td><input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'cta_url' ) ); ?>" value="<?php echo esc_attr( $o['cta_url'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/contact/' ) ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Result button label', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $f( 'cta_label' ) ); ?>" value="<?php echo esc_attr( $o['cta_label'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Consent text', 'vyntic-ai-planner' ); ?></th><td><input type="text" class="large-text" name="<?php echo esc_attr( $f( 'consent_text' ) ); ?>" value="<?php echo esc_attr( $o['consent_text'] ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Privacy policy URL', 'vyntic-ai-planner' ); ?></th><td><input type="url" class="regular-text" name="<?php echo esc_attr( $f( 'privacy_url' ) ); ?>" value="<?php echo esc_attr( $o['privacy_url'] ); ?>" placeholder="<?php echo esc_attr( get_privacy_policy_url() ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'About your agency (for the AI)', 'vyntic-ai-planner' ); ?></th><td><textarea class="large-text" rows="3" name="<?php echo esc_attr( $f( 'agency_context' ) ); ?>"><?php echo esc_textarea( $o['agency_context'] ); ?></textarea></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vap_test' ); ?>
			<input type="hidden" name="action" value="vap_test">
			<?php submit_button( __( 'Test connection', 'vyntic-ai-planner' ), 'secondary' ); ?>
		</form>

		<h2><?php esc_html_e( 'Send test email', 'vyntic-ai-planner' ); ?></h2>
		<p><?php esc_html_e( 'Sends the email a visitor receives, with a sample plan, so you can check it arrives and how it looks.', 'vyntic-ai-planner' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vap_test_mail' ); ?>
			<input type="hidden" name="action" value="vap_test_mail">
			<input type="email" class="regular-text" name="vap_to" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>" required>
			<?php submit_button( __( 'Send test email', 'vyntic-ai-planner' ), 'secondary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}
