<?php
/**
 * Plugin Name: Vyntic AI Planner
 * Description: AI homepage planner that turns visitors into leads. Visitors describe their business, leave their email and get a homepage plan in seconds. Works with the free Google Gemini API, any OpenAI-compatible API (Groq, OpenRouter, OpenAI) or the WordPress AI Client. Use the shortcode [vyntic_planner].
 * Version: 1.0.6
 * Author: Vyntic Studio
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: vyntic-ai-planner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VAP_VERSION', '1.0.6' );
define( 'VAP_DIR', plugin_dir_path( __FILE__ ) );
define( 'VAP_URL', plugin_dir_url( __FILE__ ) );

require VAP_DIR . 'includes/settings.php';
require VAP_DIR . 'includes/providers.php';
require VAP_DIR . 'includes/email.php';
require VAP_DIR . 'includes/leads.php';
require VAP_DIR . 'includes/rest.php';
require VAP_DIR . 'includes/shortcode.php';

/** Link to settings from the Plugins screen. */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=vap-settings' ) ) . '">' . esc_html__( 'Settings', 'vyntic-ai-planner' ) . '</a>' );
	return $links;
} );
