/* Vyntic Hub: tabs on a plugin page. Without JavaScript every section stays visible. */
(function () {
	'use strict';
	var root = document.querySelector('.vh-pl');
	if (!root) { return; }
	var links = root.querySelectorAll('[data-vh-tab]');
	var panels = root.querySelectorAll('[data-vh-panel]');
	if (!links.length) { return; }
	root.classList.add('has-tabs');

	function show(key, focus) {
		var found = false;
		panels.forEach(function (p) { if (p.getAttribute('data-vh-panel') === key) { found = true; } });
		if (!found) { key = panels[0].getAttribute('data-vh-panel'); }
		panels.forEach(function (p) { p.hidden = p.getAttribute('data-vh-panel') !== key; });
		links.forEach(function (a) {
			var on = a.getAttribute('data-vh-tab') === key;
			a.classList.toggle('is-active', on);
			a.setAttribute('aria-current', on ? 'true' : 'false');
		});
		if (focus) {
			var nav = root.querySelector('.vh-pl-tabs');
			var top = nav.getBoundingClientRect().top + window.pageYOffset - 90;
			if (window.pageYOffset > top) { window.scrollTo({ top: top }); }
		}
	}

	links.forEach(function (a) {
		a.addEventListener('click', function (e) {
			e.preventDefault();
			var key = a.getAttribute('data-vh-tab');
			if (history.replaceState) { history.replaceState(null, '', '#' + key); }
			show(key, true);
		});
	});
	show((location.hash || '').replace('#', ''), false);
	window.addEventListener('hashchange', function () { show(location.hash.replace('#', ''), true); });
})();
