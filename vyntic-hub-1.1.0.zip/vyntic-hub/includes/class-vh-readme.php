<?php
/**
 * Reads a WordPress-style readme.txt into page sections: short description,
 * description, installation, FAQ, changelog (every version) and other notes.
 *
 * @package VynticHub
 */

defined( 'ABSPATH' ) || exit;

class VH_Readme {

	/**
	 * @param string $readme Raw readme.txt.
	 * @return array
	 */
	public static function parse( $readme ) {
		$readme = str_replace( array( "\r\n", "\r" ), "\n", (string) $readme );
		$out    = array(
			'short'        => '',
			'tags'         => array(),
			'description'  => '',
			'installation' => '',
			'faq'          => array(),
			'changelog'    => array(),
			'other'        => array(),
		);
		if ( '' === trim( $readme ) ) {
			return $out;
		}

		if ( preg_match( '/^[ \t]*Tags:(.*)$/mi', $readme, $m ) ) {
			$out['tags'] = array_values( array_filter( array_map( 'trim', explode( ',', $m[1] ) ) ) );
		}

		// Split into "== Section ==" blocks. The text before the first one is the header.
		$parts  = preg_split( '/^==\s*([^=\n]+?)\s*==\s*$/m', $readme, -1, PREG_SPLIT_DELIM_CAPTURE );
		$header = array_shift( $parts );

		// Short description: the first plain line after the header fields.
		foreach ( explode( "\n", $header ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || preg_match( '/^===.*===$/', $line ) || preg_match( '/^[A-Za-z ]+:\s/', $line ) ) {
				continue;
			}
			$out['short'] = $line;
			break;
		}

		for ( $i = 0; $i + 1 < count( $parts ); $i += 2 ) {
			$title = trim( $parts[ $i ] );
			$body  = trim( $parts[ $i + 1 ] );
			$key   = strtolower( $title );
			if ( 'description' === $key ) {
				$out['description'] = self::to_html( $body );
			} elseif ( 'installation' === $key ) {
				$out['installation'] = self::to_html( $body );
			} elseif ( in_array( $key, array( 'frequently asked questions', 'faq' ), true ) ) {
				$out['faq'] = self::faq( $body );
			} elseif ( 'changelog' === $key ) {
				$out['changelog'] = self::changelog( $body );
			} elseif ( ! in_array( $key, array( 'upgrade notice', 'screenshots' ), true ) && '' !== $body ) {
				$out['other'][ $title ] = self::to_html( $body );
			}
		}
		return $out;
	}

	/**
	 * "= Question =" followed by the answer.
	 */
	private static function faq( $body ) {
		$items = array();
		$parts = preg_split( '/^=\s*(.+?)\s*=\s*$/m', $body, -1, PREG_SPLIT_DELIM_CAPTURE );
		array_shift( $parts );
		for ( $i = 0; $i + 1 < count( $parts ); $i += 2 ) {
			$q = trim( $parts[ $i ] );
			$a = trim( $parts[ $i + 1 ] );
			if ( '' !== $q && '' !== $a ) {
				$items[] = array(
					'q'    => $q,
					'a'    => self::to_html( $a ),
					'text' => wp_strip_all_tags( self::inline( $a ) ),
				);
			}
		}
		return $items;
	}

	/**
	 * "= 1.2.0 =" blocks, newest first as written.
	 */
	private static function changelog( $body ) {
		$out   = array();
		$parts = preg_split( '/^=\s*(.+?)\s*=\s*$/m', $body, -1, PREG_SPLIT_DELIM_CAPTURE );
		array_shift( $parts );
		for ( $i = 0; $i + 1 < count( $parts ); $i += 2 ) {
			$version = trim( $parts[ $i ] );
			if ( '' !== $version ) {
				$out[ $version ] = self::to_html( trim( $parts[ $i + 1 ] ) );
			}
		}
		return $out;
	}

	/**
	 * The small Markdown subset readme.txt files use: paragraphs, "* " and "1. "
	 * lists, "= Sub heading =", **bold**, *italic*, `code`, [text](url) and
	 * indented code blocks.
	 */
	public static function to_html( $text ) {
		$lines = explode( "\n", trim( $text ) );
		$html  = '';
		$para  = array();
		$list  = '';
		$items = array();
		$code  = array();

		$flush = static function () use ( &$para, &$list, &$items, &$code, &$html ) {
			if ( $para ) {
				$html .= '<p>' . self::inline( implode( ' ', $para ) ) . '</p>';
				$para  = array();
			}
			if ( $items ) {
				$html .= '<' . $list . '>' . implode( '', array_map( static function ( $i ) {
					return '<li>' . self::inline( $i ) . '</li>';
				}, $items ) ) . '</' . $list . '>';
				$items = array();
				$list  = '';
			}
			if ( $code ) {
				$html .= '<pre><code>' . esc_html( implode( "\n", $code ) ) . '</code></pre>';
				$code  = array();
			}
		};

		foreach ( $lines as $line ) {
			if ( preg_match( '/^(    |\t)(.*)$/', $line, $m ) && ! $items ) {
				if ( $para ) {
					$flush();
				}
				$code[] = $m[2];
				continue;
			}
			if ( $code && '' !== trim( $line ) ) {
				$flush();
			}
			$t = trim( $line );
			if ( '' === $t ) {
				if ( ! $code ) {
					$flush();
				}
				continue;
			}
			if ( preg_match( '/^=\s*(.+?)\s*=$/', $t, $m ) ) {
				$flush();
				$html .= '<h3>' . self::inline( $m[1] ) . '</h3>';
			} elseif ( preg_match( '/^[*+-]\s+(.*)$/', $t, $m ) ) {
				if ( $para || ( $list && 'ul' !== $list ) ) {
					$flush();
				}
				$list    = 'ul';
				$items[] = $m[1];
			} elseif ( preg_match( '/^\d+[.)]\s+(.*)$/', $t, $m ) ) {
				if ( $para || ( $list && 'ol' !== $list ) ) {
					$flush();
				}
				$list    = 'ol';
				$items[] = $m[1];
			} elseif ( $items ) {
				// A wrapped list line continues the last item.
				$items[ count( $items ) - 1 ] .= ' ' . $t;
			} else {
				$para[] = $t;
			}
		}
		$flush();
		return $html;
	}

	/**
	 * Inline formatting on already plain text.
	 */
	public static function inline( $text ) {
		$text = esc_html( $text );
		$text = preg_replace_callback(
			'/`([^`]+)`/',
			static function ( $m ) {
				return '<code>' . $m[1] . '</code>';
			},
			$text
		);
		$text = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text );
		$text = preg_replace( '/(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])/', '<em>$1</em>', $text );
		$text = preg_replace_callback(
			'/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/',
			static function ( $m ) {
				return '<a href="' . esc_url( html_entity_decode( $m[2] ) ) . '" rel="noopener">' . $m[1] . '</a>';
			},
			$text
		);
		return $text;
	}
}
