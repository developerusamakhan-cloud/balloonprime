<?php
/**
 * Admin: leads list, CSV export and settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VSA_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_vsa_export', array( $this, 'export_csv' ) );
		add_action( 'admin_post_vsa_delete', array( $this, 'delete_lead' ) );
		add_action( 'wp_ajax_vsa_test_psi', array( $this, 'test_psi' ) );
		add_action( 'wp_ajax_vsa_test_email', array( $this, 'test_email' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( VSA_FILE ), array( $this, 'action_links' ) );
	}

	public function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=vsa-settings' ) ) . '">Settings</a>' );
		return $links;
	}

	public function menu() {
		add_menu_page( 'Site Audit Leads', 'Site Audit', 'manage_options', 'vsa-leads', array( $this, 'leads_page' ), 'dashicons-chart-area', 26 );
		add_submenu_page( 'vsa-leads', 'Audit Leads', 'Leads', 'manage_options', 'vsa-leads', array( $this, 'leads_page' ) );
		add_submenu_page( 'vsa-leads', 'Site Audit Settings', 'Settings', 'manage_options', 'vsa-settings', array( $this, 'settings_page' ) );
	}

	/* ---------------------------------------------------------------------
	 * Leads
	 * ------------------------------------------------------------------- */

	public function leads_page() {
		global $wpdb;
		$table    = $wpdb->prefix . Vyntic_Site_Audit::TABLE;
		$per_page = 25;
		$paged    = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$where    = '1=1';
		$args     = array();
		if ( $search ) {
			$like  = '%' . $wpdb->esc_like( $search ) . '%';
			$where = '(email LIKE %s OR website LIKE %s)';
			$args  = array( $like, $like );
		}
		$total = (int) $wpdb->get_var( $args ? $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where}", $args ) : "SELECT COUNT(*) FROM {$table}" );
		$query = "SELECT id, created_at, email, website, score, grade, status, token, email_sent, results FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d";
		$rows  = $wpdb->get_results( $wpdb->prepare( $query, array_merge( $args, array( $per_page, ( $paged - 1 ) * $per_page ) ) ) );
		$pages = max( 1, (int) ceil( $total / $per_page ) );

		$week = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-d H:i:s', time() - WEEK_IN_SECONDS ) ) );
		$avg  = $wpdb->get_var( "SELECT ROUND(AVG(score)) FROM {$table} WHERE score IS NOT NULL" );
		$labels = array(
			'onpage'     => 'Scanning',
			'speed'      => 'Scanning',
			'complete'   => 'Complete',
			'incomplete' => 'Left before finishing',
			'pdf_error'  => 'PDF failed',
			'scanning'   => 'Scanning',
		);
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">Audit leads</h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vsa_export' ), 'vsa_export' ) ); ?>">Export CSV</a>
			<hr class="wp-header-end">

			<?php if ( isset( $_GET['deleted'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>Lead deleted.</p></div>
			<?php endif; ?>

			<p>
				<strong><?php echo esc_html( number_format_i18n( $total ) ); ?></strong> leads in total,
				<strong><?php echo esc_html( number_format_i18n( $week ) ); ?></strong> in the last 7 days<?php echo null !== $avg ? ', average score <strong>' . esc_html( $avg ) . '</strong>' : ''; ?>.
				Place the form anywhere with <code>[vyntic_audit]</code>.
			</p>

			<form method="get">
				<input type="hidden" name="page" value="vsa-leads">
				<p class="search-box">
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Email or website">
					<button class="button">Search leads</button>
				</p>
			</form>

			<table class="widefat striped">
				<thead>
					<tr>
						<th>Date</th><th>Email</th><th>Website</th><th>Score</th><th>Status</th><th>Report</th><th></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="7">No leads yet. Add <code>[vyntic_audit]</code> to your Free Audit page and run a test audit on your own site.</td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<?php
					$color = null === $r->score ? '#8c8f94' : ( $r->score >= 80 ? '#1a8c5e' : ( $r->score >= 55 ? '#c47a00' : '#c93737' ) );
					$dl    = add_query_arg( array( 'action' => 'vsa_download', 'token' => $r->token ), admin_url( 'admin-ajax.php' ) );
					$del   = wp_nonce_url( admin_url( 'admin-post.php?action=vsa_delete&id=' . (int) $r->id ), 'vsa_delete_' . (int) $r->id );
					?>
					<tr>
						<td><?php echo esc_html( get_date_from_gmt( $r->created_at, 'M j, Y g:i a' ) ); ?></td>
						<td><a href="mailto:<?php echo esc_attr( $r->email ); ?>"><?php echo esc_html( $r->email ); ?></a></td>
						<td><a href="<?php echo esc_url( $r->website ); ?>" target="_blank" rel="noopener"><?php echo esc_html( wp_parse_url( $r->website, PHP_URL_HOST ) ); ?></a></td>
						<td><?php echo null === $r->score ? '-' : '<strong style="color:' . esc_attr( $color ) . '">' . (int) $r->score . '</strong> ' . esc_html( $r->grade ); ?></td>
						<?php
						$res_data = $r->results ? json_decode( $r->results, true ) : array();
						$mail     = ! empty( $res_data['meta']['email'] ) ? $res_data['meta']['email'] : null;
						$how      = array( 'attached' => 'Report emailed', 'temp-file' => 'Report emailed (sent from a temporary file)', 'link' => 'Emailed without the PDF (download link only)' );
						?>
						<td>
							<?php echo esc_html( isset( $labels[ $r->status ] ) ? $labels[ $r->status ] : ucfirst( $r->status ) ); ?>
							<?php if ( $r->email_sent ) : ?>
								<span title="<?php echo esc_attr( $mail && isset( $how[ $mail['method'] ] ) ? $how[ $mail['method'] ] : 'Report emailed' ); ?>" class="dashicons dashicons-email-alt" style="color:#0e9f6a"></span>
							<?php elseif ( $mail && ! empty( $mail['error'] ) ) : ?>
								<br><span style="color:#d6322e">Email failed: <?php echo esc_html( wp_trim_words( $mail['error'], 24 ) ); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo 'complete' === $r->status ? '<a href="' . esc_url( $dl ) . '">PDF</a>' : '-'; ?></td>
						<td><a href="<?php echo esc_url( $del ); ?>" onclick="return confirm('Delete this lead and its report?');" style="color:#b32d2e">Delete</a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $pages > 1 ) : ?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'    => add_query_arg( 'paged', '%#%' ),
								'format'  => '',
								'current' => $paged,
								'total'   => $pages,
							)
						)
					);
					?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'vsa_export' );
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT created_at, email, website, score, grade, status, email_sent, results FROM {$wpdb->prefix}" . Vyntic_Site_Audit::TABLE . ' ORDER BY id DESC', ARRAY_A );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="audit-leads-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'Date (UTC)', 'Email', 'Website', 'Score', 'Grade', 'Status', 'Report emailed', 'Technology', 'Critical issues', 'Top 3 problems' ) );
		foreach ( $rows as $r ) {
			$data  = json_decode( (string) $r['results'], true );
			$tech  = isset( $data['meta']['technologies'] ) ? implode( ', ', $data['meta']['technologies'] ) : '';
			$crit  = isset( $data['score']['counts']['fail'] ) ? $data['score']['counts']['fail'] : '';
			$top   = isset( $data['score']['priorities'] ) ? implode( ' | ', wp_list_pluck( array_slice( $data['score']['priorities'], 0, 3 ), 'title' ) ) : '';
			$cells = array( $r['created_at'], $r['email'], $r['website'], $r['score'], $r['grade'], $r['status'], $r['email_sent'] ? 'yes' : 'no', $tech, $crit, $top );
			// Neutralise spreadsheet formula injection.
			$cells = array_map( function ( $v ) {
				return preg_match( '/^[=+\-@]/', (string) $v ) ? "'" . $v : $v;
			}, $cells );
			fputcsv( $out, $cells );
		}
		fclose( $out );
		exit;
	}

	public function delete_lead() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'vsa_delete_' . $id );
		global $wpdb;
		$table = $wpdb->prefix . Vyntic_Site_Audit::TABLE;
		$wpdb->delete( $table, array( 'id' => $id ) );
		wp_safe_redirect( admin_url( 'admin.php?page=vsa-leads&deleted=1' ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------------- */

	public function register_settings() {
		register_setting( 'vsa_settings_group', Vyntic_Site_Audit::OPTION, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );
	}

	public function sanitize( $in ) {
		$d   = Vyntic_Site_Audit::defaults();
		$out = array();
		foreach ( array( 'brand', 'from_name', 'psi_key' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : $d[ $k ];
		}
		foreach ( array( 'website', 'booking_url', 'logo_url', 'privacy_url' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? esc_url_raw( trim( $in[ $k ] ) ) : '';
		}
		foreach ( array( 'contact_email', 'notify_email' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) && is_email( trim( $in[ $k ] ) ) ? sanitize_email( $in[ $k ] ) : '';
		}
		$out['accent']         = isset( $in['accent'] ) ? (string) sanitize_hex_color( $in['accent'] ) : '';
		$out['on_accent']      = isset( $in['on_accent'] ) && sanitize_hex_color( $in['on_accent'] ) ? sanitize_hex_color( $in['on_accent'] ) : '#ffffff';
		$out['radius']         = isset( $in['radius'] ) ? min( 40, absint( $in['radius'] ) ) : 12;
		$out['send_email']     = empty( $in['send_email'] ) ? 0 : 1;
		$out['allow_download'] = empty( $in['allow_download'] ) ? 0 : 1;
		$out['about']          = isset( $in['about'] ) ? sanitize_textarea_field( $in['about'] ) : '';
		$out['consent_text']   = isset( $in['consent_text'] ) ? sanitize_text_field( $in['consent_text'] ) : $d['consent_text'];
		$out['rate_ip']        = isset( $in['rate_ip'] ) ? max( 1, min( 100, absint( $in['rate_ip'] ) ) ) : 5;
		$out['retention_days'] = isset( $in['retention_days'] ) ? max( 1, min( 3650, absint( $in['retention_days'] ) ) ) : 30;
		return $out;
	}

	private function field( $key, $label, $type = 'text', $help = '', $s = array() ) {
		$name = Vyntic_Site_Audit::OPTION . '[' . $key . ']';
		$val  = isset( $s[ $key ] ) ? $s[ $key ] : '';
		echo '<tr><th scope="row"><label for="vsa-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'textarea' === $type ) {
			echo '<textarea class="large-text" rows="3" id="vsa-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( $val ) . '</textarea>';
		} elseif ( 'checkbox' === $type ) {
			echo '<label><input type="checkbox" id="vsa-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( $val, 1, false ) . '> ' . esc_html( $help ) . '</label>';
			$help = '';
		} else {
			$class = 'number' === $type ? 'small-text' : 'regular-text';
			echo '<input class="' . esc_attr( $class ) . '" type="' . esc_attr( $type ) . '" id="vsa-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
		}
		if ( $help ) {
			echo '<p class="description">' . wp_kses( $help, array( 'a' => array( 'href' => array(), 'target' => array() ), 'code' => array(), 'strong' => array() ) ) . '</p>';
		}
		echo '</td></tr>';
	}

	public function settings_page() {
		$s = Vyntic_Site_Audit::settings();
		?>
		<div class="wrap">
			<h1>Site Audit settings</h1>
			<p>Add the audit form to any page with <code>[vyntic_audit]</code>. With the Vyntic theme it also appears automatically in the free audit section on every page. Optional attributes: <code>[vyntic_audit title="Free website audit" subtitle="..." button="Run my free audit" accent="#c7431f"]</code>. Set <code>title=""</code> to hide the heading when your page already has one.</p>
			<p>The form asks for a website, an email and a quick maths question (spam check). PDF reports are built in memory for each download or email and are never saved on your server.</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'vsa_settings_group' ); ?>

				<h2 class="title">Google PageSpeed</h2>
				<table class="form-table" role="presentation">
					<?php $this->field( 'psi_key', 'PageSpeed API key', 'text', 'Free and strongly recommended. Without a key Google heavily rate-limits the speed test. Create one at <a href="https://developers.google.com/speed/docs/insights/v5/get-started" target="_blank">developers.google.com/speed</a> (Get a Key), then restrict it to the PageSpeed Insights API.', $s ); ?>
					<tr><th></th><td><button type="button" class="button" id="vsa-test-psi">Test speed API on this site</button> <span id="vsa-test-out" style="margin-left:8px"></span></td></tr>
				</table>

				<h2 class="title">Brand and report</h2>
				<table class="form-table" role="presentation">
					<?php
					$this->field( 'brand', 'Brand name', 'text', 'Shown on the PDF and in emails.', $s );
					$this->field( 'website', 'Website URL', 'url', '', $s );
					$this->field( 'logo_url', 'PDF logo (PNG or JPG)', 'url', 'Use a <strong>light / white</strong> version: it sits on a dark header. Leave empty to use the built-in Vyntic logo.', $s );
					$this->field( 'booking_url', 'Booking or contact URL', 'url', 'Every "Book a free call" button links here (Calendly, your contact page, etc.).', $s );
					$this->field( 'contact_email', 'Public contact email', 'email', 'Shown in the report and used as Reply-To.', $s );
					$this->field( 'about', 'About text for the PDF', 'textarea', '', $s );
					?>
				</table>

				<h2 class="title">Style</h2>
				<table class="form-table" role="presentation">
					<?php
					$this->field( 'accent', 'Accent colour', 'text', 'Hex, e.g. <code>#c7431f</code> (Vyntic orange). Used on buttons, the PDF and emails. Fonts and text colours are inherited from your theme.', $s );
					$this->field( 'on_accent', 'Button text colour', 'text', 'Text colour on accent buttons, usually <code>#ffffff</code>.', $s );
					$this->field( 'radius', 'Corner radius (px)', 'number', 'Match your site buttons and cards. 0 for square.', $s );
					?>
				</table>

				<h2 class="title">Emails and leads</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Check email delivery</th><td><button type="button" class="button" id="vsa-test-email">Send test email</button> <span id="vsa-test-email-out" style="margin-left:8px"></span><p class="description">Sends a sample report email with a PDF attached to the lead notification address (or your own email). Save settings first.</p></td></tr>
					<?php
					$this->field( 'send_email', 'Email report', 'checkbox', 'Email the PDF to the visitor', $s );
					$this->field( 'allow_download', 'Instant download', 'checkbox', 'Also show a Download PDF button on screen', $s );
					$this->field( 'from_name', 'Email sender name', 'text', 'For reliable delivery install an SMTP plugin (e.g. FluentSMTP or WP Mail SMTP) with your domain email.', $s );
					$this->field( 'notify_email', 'New lead notifications', 'email', 'Receives every new lead with their score and PDF.', $s );
					$this->field( 'consent_text', 'Note under the button', 'text', 'Tells visitors how their email is used. <code>{brand}</code> is replaced with your brand name. The privacy link is added automatically.', $s );
					$this->field( 'privacy_url', 'Privacy policy URL', 'url', '', $s );
					$this->field( 'rate_ip', 'Audits per hour per visitor', 'number', 'Limits abuse. Administrators are not limited.', $s );
					$this->field( 'retention_days', 'Report download link works for (days)', 'number', 'PDFs are never stored: they are built when someone downloads them or when the email is sent. After this many days the download link stops working and the page screenshot is removed; lead details and scores stay.', $s );
					?>
				</table>

				<?php submit_button( 'Save settings' ); ?>
			</form>
		</div>
		<script>
		document.getElementById('vsa-test-email').addEventListener('click', function () {
			var out = document.getElementById('vsa-test-email-out');
			out.textContent = 'Sending...';
			var body = new URLSearchParams({ action: 'vsa_test_email', _wpnonce: '<?php echo esc_js( wp_create_nonce( 'vsa_test_email' ) ); ?>' });
			fetch(ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (r) { out.textContent = r.success ? r.data.message : 'Failed: ' + r.data.message; out.style.color = r.success ? '#0e9f6a' : '#d6322e'; })
				.catch(function () { out.textContent = 'Request failed.'; });
		});
		document.getElementById('vsa-test-psi').addEventListener('click', function () {
			var out = document.getElementById('vsa-test-out');
			var key = document.getElementById('vsa-psi_key').value;
			out.textContent = 'Running Lighthouse, this takes 20 to 60 seconds...';
			var body = new URLSearchParams({ action: 'vsa_test_psi', key: key, _wpnonce: '<?php echo esc_js( wp_create_nonce( 'vsa_test_psi' ) ); ?>' });
			fetch(ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (r) { out.textContent = r.success ? 'Working. Mobile performance score for your site: ' + r.data.score + '/100.' : 'Failed: ' + r.data.message; })
				.catch(function () { out.textContent = 'Request failed or timed out.'; });
		});
		</script>
		<?php
	}

	/** Send a sample report email so the owner can check delivery and see any error. */
	public function test_email() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'vsa_test_email', '_wpnonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
		}
		$s    = Vyntic_Site_Audit::settings();
		$to   = is_email( $s['notify_email'] ) ? $s['notify_email'] : wp_get_current_user()->user_email;
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$data = array(
			'meta'   => array( 'host' => $host, 'final_url' => home_url( '/' ), 'technologies' => array(), 'scanned_at' => gmdate( 'c' ) ),
			'checks' => array(
				array( 'category' => 'speed', 'id' => 'sample', 'status' => 'warn', 'title' => 'Sample check', 'finding' => 'This is a test email from Vyntic Site Audit.', 'impact' => '', 'fix' => '', 'weight' => 2 ),
				array( 'category' => 'seo', 'id' => 'sample2', 'status' => 'pass', 'title' => 'Sample passed check', 'finding' => 'Everything looks fine.', 'impact' => '', 'fix' => '', 'weight' => 2 ),
			),
		);
		$data['score'] = VSA_Auditor::score( $data['checks'] );
		$lead          = (object) array( 'name' => '', 'email' => $to, 'token' => str_repeat( '0', 40 ) );
		$pdf           = Vyntic_Site_Audit::build_pdf( $lead, $data );
		$body          = VSA_Email::lead_html( $data, Vyntic_Site_Audit::email_options( $s ) );
		$res           = Vyntic_Site_Audit::mail_with_pdf( $to, 'Test: website audit email', $body, Vyntic_Site_Audit::mail_headers( $s ), $pdf, 'test-audit-report.pdf', $body );
		if ( ! $res['sent'] ) {
			wp_send_json_error( array( 'message' => $res['error'] ? $res['error'] : 'The email could not be sent.' ) );
		}
		$how = array( 'attached' => 'with the PDF attached', 'temp-file' => 'with the PDF attached (your mail plugin needed a temporary file)', 'link' => 'but WITHOUT the PDF (your mail plugin rejected the attachment)' );
		wp_send_json_success( array( 'message' => sprintf( 'Sent to %s %s. Check the inbox and spam folder.', $to, $how[ $res['method'] ] ) ) );
	}

	public function test_psi() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'vsa_test_psi', '_wpnonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
		}
		@set_time_limit( 150 );
		$key     = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$auditor = new VSA_Auditor( home_url( '/' ) );
		$res     = $auditor->run_psi( $key, home_url( '/' ) );
		if ( ! empty( $res['error'] ) ) {
			wp_send_json_error( array( 'message' => $res['error'] ) );
		}
		wp_send_json_success( array( 'score' => $res['meta']['psi']['performance'] ) );
	}
}
