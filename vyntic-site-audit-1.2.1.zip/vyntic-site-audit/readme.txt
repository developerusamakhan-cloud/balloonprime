=== Vyntic Site Audit ===
Contributors: vynticstudio
Tags: website audit, lead generation, seo audit, pagespeed, lead magnet
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later

A free website audit tool for your site. Visitors enter their website and email, answer a quick maths question and get an instant score plus a branded PDF report. You get the lead. PDFs are built on request and never stored on your server.

== What it checks ==

Speed & performance: Google Lighthouse mobile score, Core Web Vitals (LCP, CLS, TBT, FCP), server response time, compression, page weight, script count, render-blocking scripts, lazy loading, and Google's biggest time-saving opportunities.

SEO & visibility: title, meta description, H1 and headings, indexability, canonical, language, structured data, Open Graph, image alt text, content depth, robots.txt, XML sitemap, Lighthouse SEO score.

Lead conversion: contact or booking form, calls to action, tap-to-call, WhatsApp or live chat, social proof, analytics tracking, privacy policy.

Security & trust: HTTPS, HTTP to HTTPS redirect, SSL certificate expiry, security headers, mixed content, exposed software versions, Lighthouse best practices.

Mobile & accessibility: responsive viewport, pinch-zoom, site icon, Lighthouse accessibility score.

Every issue in the PDF explains what was found, why it matters for the business, and how to fix it, followed by a call to book a call.

== Installation ==

1. Upload the plugin zip in Plugins > Add New > Upload Plugin, then activate.
2. Go to Site Audit > Settings.
3. Add a free Google PageSpeed API key (see below) and click "Test speed API on this site".
4. Check brand name, booking URL, contact email and lead notification email. The Vyntic logo is built in; add your own light/white PNG logo only if you want a different one.
5. With the Vyntic theme, the form appears automatically in the free audit section on every page. On other themes, put [vyntic_audit] on your Free Audit page.
6. Install an SMTP plugin (FluentSMTP or WP Mail SMTP) with your domain email so reports land in the inbox, not spam.
7. Run a test audit on your own site and check Site Audit > Leads.

== Free Google PageSpeed API key ==

1. Open https://developers.google.com/speed/docs/insights/v5/get-started and click "Get a Key" (or create one in Google Cloud Console > APIs & Services > Credentials after enabling "PageSpeed Insights API").
2. Restrict the key to the PageSpeed Insights API.
3. Paste it in Site Audit > Settings. The free quota is 25,000 tests per day.

Without a key the speed test often fails because Google rate-limits anonymous requests. The audit still completes using the other checks.

== Shortcode ==

[vyntic_audit]
[vyntic_audit title="Free website audit" subtitle="Find out what is costing you leads." button="Audit my website" accent="#c7431f"]
Use title="" to hide the heading when the page already has one.

== Styling ==

The form inherits your theme's fonts and text colours, so it works on light and dark sections. The accent colour follows the Vyntic theme (Vyntic orange #c7431f), or the Accent setting / shortcode attribute. Corner radius is adjustable in settings. All classes are prefixed with .vsa for custom CSS.

== Hosting notes ==

* The audit runs in three short requests so it works with typical 30-60 second PHP limits.
* If your server or Cloudflare kills requests after 30 seconds, the speed step may time out on slow sites; the audit still finishes without it.
* Page caching is safe: the form loads a fresh security token and maths question after the page loads.
* PDFs are never saved on the server. They are built in memory when the visitor downloads the report and when the emails are sent (attached directly). The download link works for the number of days set in settings.
* Version 1.1 removes any PDFs saved by version 1.0 from wp-content/uploads/vsa-reports.

== Privacy ==

The plugin stores the email address, audited website, IP address and results in its own database table. No PDF files are stored. Only the visitor's own public homepage is scanned. Private and local network addresses are blocked. Mention the audit tool in your privacy policy.

== Report links ==

Each section of the PDF ends with a link to the matching Vyntic service, and the last page lists services and free guides. With the Vyntic theme the links follow your real page addresses. Change them with the vsa_report_links filter.

== Changelog ==

= 1.2.1 =
* More reliable email delivery: if a mail plugin rejects the in-memory PDF, the report is sent from a temporary file that is deleted straight after sending; if attachments are rejected completely, the email is sent with a download button instead.
* The reason for any failed email is saved and shown in Site Audit > Leads.
* New "Send test email" button in Site Audit > Settings.

= 1.2.0 =
* New branded emails for the visitor and the owner: logo header, score card, scores by area, top fixes, booking panel and guide links. Tables and inline styles for Gmail, Outlook and Apple Mail, with brand fonts where the email app supports them.

= 1.1.0 =
* Form: website, email and a maths question (spam check). No name or consent checkbox.
* PDFs are built in memory for downloads and emails and never stored on the server.
* Vyntic brand colours and logo in the PDF, form and emails.
* Links to Vyntic services and guides in the PDF and the visitor email.
* More accurate technology, chat, analytics and form detection (no longer triggered by words on the page).
* Default booking link now points to the Contact page.

