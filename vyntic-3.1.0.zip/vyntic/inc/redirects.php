<?php
/**
 * 301 redirects for old URLs that Google still shows in search.
 * They only run when the requested URL is a 404, so a page that exists is
 * never redirected. Add more with the vyntic_legacy_redirects filter.
 *
 * @package Vyntic
 */

defined( 'ABSPATH' ) || exit;

/** Old path => new path (both relative to the home URL). */
function vyntic_legacy_redirects() {
	return apply_filters(
		'vyntic_legacy_redirects',
		array(
			'about-vyntic'                                => 'about',
			'portfolio'                                   => 'work',
			'start-a-project'                             => 'contact',
			'cookie-policy'                               => 'privacy-policy',
			'services/e-commerce-development'             => 'services/ecommerce-development',
			'services/website-redesign-revamp'            => 'services/website-redesign',
			'services/website-maintenance-care-plans'     => 'care-plans',
			// Posts merged into a stronger post: trash the old one and its URL redirects here.
			'how-to-migrate-from-shopify-to-wordpress'    => 'shopify-to-wordpress-migration',
			'local-business-seo'                          => 'local-seo-guide',
			'category/performance'                        => 'services/website-speed-optimization',
		)
	);
}

/** Resolves a target path to a live URL, or '' when nothing is published there. */
function vyntic_redirect_target( $path ) {
	$page = get_page_by_path( $path );
	if ( $page && 'publish' === $page->post_status ) {
		return get_permalink( $page );
	}
	$post_id = url_to_postid( home_url( '/' . $path . '/' ) );
	return $post_id && 'publish' === get_post_status( $post_id ) ? get_permalink( $post_id ) : '';
}

add_action(
	'template_redirect',
	static function () {
		if ( ! is_404() ) {
			return;
		}
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $path, $home . '/' ) ) {
			$path = substr( $path, strlen( $home ) + 1 );
		}
		$path = strtolower( $path );

		$map    = vyntic_legacy_redirects();
		$target = '';
		if ( isset( $map[ $path ] ) ) {
			foreach ( (array) $map[ $path ] as $candidate ) {
				$target = vyntic_redirect_target( $candidate );
				if ( $target ) {
					break;
				}
			}
		} elseif ( preg_match( '#^work/[^/]+$#', $path ) ) {
			// A case study that was renamed or removed: send people to all work.
			$target = vyntic_redirect_target( 'work' );
		} elseif ( preg_match( '#^blog/page/\d+$#', $path ) ) {
			// A blog page number that no longer exists.
			$target = vyntic_redirect_target( 'blog' );
		}
		if ( $target ) {
			wp_safe_redirect( $target, 301, 'Vyntic' );
			exit;
		}
	},
	1
);
