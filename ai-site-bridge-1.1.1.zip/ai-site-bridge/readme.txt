=== AI Site Bridge ===
Tags: ai, mcp, claude, chatbot, content management
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.1
License: GPLv2 or later

Manage your WordPress site from an AI chat: connect Claude (or any MCP client) and let it write, edit and publish posts and pages, upload media and moderate comments.

== Description ==

AI Site Bridge turns your site into a connector (a remote MCP server) for AI chat apps. After connecting, you can ask in the chat:

* "List my draft posts."
* "Write a blog post about our summer offer, add it to the News category and keep it as a draft."
* "Change the About page title and add a paragraph about our new office."
* "Upload this image, set it as the featured image of the Services page and add alt text."
* "Approve the pending comments that aren't spam and reply to the question on the pricing post."
* "Use the Home page as the homepage and change the tagline."

= How it works =

1. Install and activate the plugin, then open **AI Site Bridge** in the dashboard and copy the connector URL.
2. In Claude go to **Settings → Connectors → Add custom connector**, paste the URL and click **Connect**.
3. Your site's login page opens. Log in and click **Approve**. Done.

There are no API keys to copy: the connection uses the standard OAuth 2.1 flow that AI apps expect (discovery, dynamic client registration, PKCE), handled entirely by the plugin on your own site.

= What the assistant can do =

* **Read:** site info, posts, pages and custom post types, categories and tags, media, comments.
* **Create and edit:** posts, pages and other content types (drafts, published, scheduled), categories and tags, restore from trash.
* **Delete:** move to trash, or delete permanently when asked.
* **Media:** upload from a link, alt text, captions, featured images.
* **Comments:** approve, unapprove, spam, trash, reply.
* **Site settings:** title, tagline, homepage and posts page.
* **Design:** Additional CSS, navigation menus, and the text of Elementor pages.
* **Themes, plugins & code (advanced, off by default):** read and edit theme and plugin files, create new themes and plugins, and install, update, activate or delete plugins and themes from the WordPress.org directory or a .zip URL. Administrators only.

Each group can be switched off under **AI Site Bridge → Settings**, for example to give the assistant read-only access.

= Build without manual uploads =

With the advanced "Themes, plugins & code" option on, you can ask the assistant to build and change things directly, without exporting a zip and uploading it yourself:

* "Create a child theme of my theme and move the site title to the centre."
* "Add a function to my theme that shows an 'On sale' badge on discounted products."
* "Install WooCommerce and the Astra theme, then activate Astra."
* "Edit style.css so the buttons are rounded and green."

Every file, CSS and Elementor change is backed up first (list_backups / restore_backup to undo). Only the most recent backup of each file, page or CSS is kept, and backups are removed automatically after about a week. Before saving PHP it is syntax-checked, and after changing active code — or activating a plugin or switching the theme — the site is loaded again in the background: if the change broke it, it is undone automatically and the error is reported. Theme changes should go in a child theme so a theme update doesn't overwrite them.

= Safety =

* The assistant always acts as the WordPress user who approved the connection and can never do more than that user can in the dashboard. Editors can't change settings, authors can't edit other people's posts, and so on.
* Choose who may connect: administrators only (default), editors or authors.
* Only apps that return to an allowed domain can connect (claude.ai by default), which blocks look-alike apps.
* Every change, and every failed attempt, is listed under **Activity** for 90 days.
* Disconnect any app at any time; one switch turns all connections off.
* Deleted items go to the trash first, and WordPress keeps revisions of edited content.
* Only hashes of tokens are stored. Access tokens last one hour and are renewed automatically.

= Requirements =

* The site must be online and use HTTPS (cloud AI apps can't reach local sites).
* Pretty permalinks (any setting except "Plain").
* Requests to `/.well-known/oauth-protected-resource` and `/.well-known/oauth-authorization-server` must reach WordPress. The Connect tab checks this for you.

= Requirements for code changes =

The advanced code and install features need the server to let WordPress write its own files directly (the same requirement as WordPress' built-in theme/plugin editor and one-click installs). The Connect tab shows a warning when the server needs FTP details or has file editing disabled; on those hosts the assistant can still read code but not change or install it.

= Page builders =

Pages built with Elementor can have their text edited (get_elementor / update_elementor). Divi, Beaver Builder, Bricks and WPBakery store their layout outside the normal content; the assistant can see that a page uses one of them and will tell you, but editing those layouts is not supported yet. Block editor and classic editor content works fully.

== Installation ==

1. Upload the `ai-site-bridge` folder to `/wp-content/plugins/` (or zip it and use Plugins → Add New → Upload Plugin) and activate it.
2. Open **AI Site Bridge** in the dashboard menu and follow the steps on the Connect tab.

== Frequently Asked Questions ==

= Which AI apps work? =

Claude (claude.ai, desktop and mobile apps, Claude Code) out of the box. Other apps that support remote MCP servers with OAuth work too: add the domain they return to after login under Settings → Allowed apps (for example chatgpt.com).

= Do I need a paid Claude plan? =

Custom connectors are available on Claude's Free plan (one connector) and on paid plans. On Team and Enterprise plans an owner may need to add the connector first.

= The connection fails. What can I check? =

Open the Connect tab: it checks HTTPS, permalinks and whether the connector endpoints are reachable. Security plugins, firewalls or server rules that block `/.well-known/` URLs or strip the `Authorization` header are the usual causes.

= How do I remove access? =

Click Disconnect next to the app on the Connect tab, or untick "Allow AI apps to connect" under Settings. Deleting the plugin removes all its data and connections.

== Changelog ==

= 1.1.1 =
* Fixed: sites installed in a sub-folder (for example example.com/shop) could not connect. The connector now also answers OpenID Connect discovery under the sub-folder, which is where AI apps look when the site is not at the domain root.
* Fixed: a site at the domain root no longer answers discovery requests meant for another site in a sub-folder of the same domain.

= 1.1.0 =
* Added a Design group: custom CSS, navigation menus and Elementor text.
* Added an advanced Themes, plugins & code group (off by default, administrators only): read and edit theme and plugin files, create themes and plugins, and install, update, activate and delete plugins and themes.
* Automatic backups of changed files, CSS and Elementor layouts, with list_backups and restore_backup.
* Safety: PHP syntax check before saving, and an automatic site check that rolls back a change (or a plugin activation / theme switch) if it breaks the site.

= 1.0.0 =
* First release.
