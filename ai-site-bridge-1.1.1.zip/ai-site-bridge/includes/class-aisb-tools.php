<?php
/**
 * MCP tools: what the assistant can do on the site.
 *
 * Most tools run through WordPress' own REST API internally, so the usual permission checks,
 * validation and sanitising (and hooks other plugins add) apply exactly as in the editor.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Error shown to the assistant as a failed tool call.
 */
class AISB_Tool_Error extends Exception {}

/**
 * Tool registry, definitions and handlers.
 */
class AISB_Tools {

	/**
	 * Cached registry.
	 *
	 * @var array|null
	 */
	private static $tools = null;

	/**
	 * Tool definitions for tools/list (only groups the site owner switched on).
	 *
	 * @return array[]
	 */
	public static function definitions() {
		$out = array();
		foreach ( self::registry() as $name => $tool ) {
			if ( ! AISB_Settings::group_enabled( $tool['group'] ) ) {
				continue;
			}
			$out[] = array(
				'name'        => $name,
				'title'       => $tool['title'],
				'description' => $tool['description'],
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => $tool['properties'] ? $tool['properties'] : (object) array(),
					'required'   => $tool['required'],
				),
				'annotations' => array(
					'title'           => $tool['title'],
					'readOnlyHint'    => self::is_read_only( $tool ),
					'destructiveHint' => ! empty( $tool['destructive'] ),
					'idempotentHint'  => ! empty( $tool['idempotent'] ) || self::is_read_only( $tool ),
					'openWorldHint'   => ! empty( $tool['open_world'] ),
				),
			);
		}
		return $out;
	}

	/**
	 * Whether a tool exists.
	 *
	 * @param string $name Tool name.
	 * @return bool
	 */
	public static function exists( $name ) {
		$tools = self::registry();
		return isset( $tools[ $name ] );
	}

	/**
	 * Whether a tool only reads (so it is not written to the activity log).
	 *
	 * @param array $tool Tool definition.
	 * @return bool
	 */
	private static function is_read_only( $tool ) {
		return 'read' === $tool['group'] || ! empty( $tool['read_only'] );
	}

	/**
	 * Run a tool and build the tools/call result.
	 *
	 * @param string $name Tool name.
	 * @param array  $args Arguments.
	 * @return array
	 */
	public static function call( $name, $args ) {
		$tools = self::registry();
		$tool  = $tools[ $name ];

		if ( ! AISB_Settings::group_enabled( $tool['group'] ) ) {
			return self::error_result( __( 'The site owner has turned this action off in AI Site Bridge settings.', 'ai-site-bridge' ) );
		}

		$object_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
		try {
			$result = call_user_func( $tool['handler'], $args );
		} catch ( AISB_Tool_Error $e ) {
			AISB_Log::add( AISB_MCP::$client_id, $name, $object_id, $e->getMessage(), 'error' );
			return self::error_result( $e->getMessage() );
		} catch ( Throwable $e ) {
			AISB_Log::add( AISB_MCP::$client_id, $name, $object_id, $e->getMessage(), 'error' );
			return self::error_result( 'Unexpected error: ' . $e->getMessage() );
		}

		if ( ! self::is_read_only( $tool ) ) {
			$changed = array_diff( array_keys( $args ), array( 'id', 'post_type', 'taxonomy', 'action' ) );
			$label   = '';
			foreach ( array( 'title', 'path', 'plugin', 'theme', 'name', 'target' ) as $key ) {
				if ( isset( $result[ $key ] ) && is_scalar( $result[ $key ] ) && '' !== (string) $result[ $key ] ) {
					$label = '"' . $result[ $key ] . '"';
					break;
				}
			}
			if ( isset( $args['action'] ) && is_scalar( $args['action'] ) ) {
				$label = trim( $args['action'] . ' ' . $label );
			}
			if ( $changed ) {
				$label = trim( $label . ' (' . implode( ', ', $changed ) . ')' );
			}
			$object_id = isset( $result['id'] ) ? (int) $result['id'] : $object_id;
			AISB_Log::add( AISB_MCP::$client_id, $name, $object_id, $label, 'ok' );
		}

		return array(
			'content' => array(
				array(
					'type' => 'text',
					'text' => wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
				),
			),
		);
	}

	/**
	 * Failed tool call result.
	 *
	 * @param string $message Message.
	 * @return array
	 */
	private static function error_result( $message ) {
		return array(
			'content' => array(
				array(
					'type' => 'text',
					'text' => $message,
				),
			),
			'isError' => true,
		);
	}

	/**
	 * All tools.
	 *
	 * @return array
	 */
	private static function registry() {
		if ( null !== self::$tools ) {
			return self::$tools;
		}

		$id      = array(
			'type'        => 'integer',
			'description' => 'Post or page ID.',
		);
		$paging  = array(
			'per_page' => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'maximum'     => 100,
				'description' => 'Items per page (default 20).',
			),
			'page'     => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'description' => 'Page number (default 1).',
			),
		);
		$content = array(
			'title'             => array(
				'type'        => 'string',
				'description' => 'Title.',
			),
			'content'           => array(
				'type'        => 'string',
				'description' => 'Body. Block markup (<!-- wp:paragraph --><p>…</p><!-- /wp:paragraph -->) is best for the block editor; plain HTML also works.',
			),
			'excerpt'           => array(
				'type'        => 'string',
				'description' => 'Short summary.',
			),
			'status'            => array(
				'type'        => 'string',
				'enum'        => array( 'draft', 'publish', 'pending', 'private', 'future' ),
				'description' => 'draft (default when creating), publish, pending review, private, or future (scheduled, needs date).',
			),
			'slug'              => array(
				'type'        => 'string',
				'description' => 'URL slug.',
			),
			'date'              => array(
				'type'        => 'string',
				'description' => 'Publish date in the site timezone, e.g. 2026-05-01T09:00:00. A future date with status future schedules it.',
			),
			'parent'            => array(
				'type'        => 'integer',
				'description' => 'Parent page ID (hierarchical types such as pages).',
			),
			'menu_order'        => array(
				'type'        => 'integer',
				'description' => 'Order among sibling pages.',
			),
			'template'          => array(
				'type'        => 'string',
				'description' => 'Page template file or slug, as listed by the theme.',
			),
			'featured_image_id' => array(
				'type'        => 'integer',
				'description' => 'Media ID to use as featured image (0 removes it).',
			),
			'categories'        => array(
				'type'        => 'array',
				'items'       => array( 'type' => array( 'string', 'integer' ) ),
				'description' => 'Category names or IDs; replaces the current list. Missing names are created.',
			),
			'tags'              => array(
				'type'        => 'array',
				'items'       => array( 'type' => array( 'string', 'integer' ) ),
				'description' => 'Tag names or IDs; replaces the current list. Missing names are created.',
			),
			'terms'             => array(
				'type'                 => 'object',
				'additionalProperties' => array(
					'type'  => 'array',
					'items' => array( 'type' => array( 'string', 'integer' ) ),
				),
				'description'          => 'Other taxonomies, e.g. {"product_cat": ["Shoes"]}; each list replaces the current one.',
			),
			'comment_status'    => array(
				'type' => 'string',
				'enum' => array( 'open', 'closed' ),
			),
		);

		self::$tools = array(
			'get_site_info'        => array(
				'group'       => 'read',
				'title'       => 'Get site info',
				'description' => 'Site name, tagline, URL, theme, page builders, homepage settings, available content types and taxonomies, and the connected user. Call this first.',
				'properties'  => array(),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'get_site_info' ),
			),
			'list_content'         => array(
				'group'       => 'read',
				'title'       => 'List posts or pages',
				'description' => 'List or search posts, pages or another content type. Returns ID, title, status, dates, link and a short excerpt.',
				'properties'  => array_merge(
					array(
						'post_type'  => array(
							'type'        => 'string',
							'description' => 'Content type: post (default), page, or another type from get_site_info.',
						),
						'search'     => array(
							'type'        => 'string',
							'description' => 'Search text.',
						),
						'status'     => array(
							'type'        => 'string',
							'description' => 'any (default, everything but trash), publish, draft, pending, private, future or trash. Comma-separate several.',
						),
						'category'   => array(
							'type'        => 'integer',
							'description' => 'Only items in this category ID.',
						),
						'tag'        => array(
							'type'        => 'integer',
							'description' => 'Only items with this tag ID.',
						),
						'parent'     => array(
							'type'        => 'integer',
							'description' => 'Only children of this page ID (0 for top level).',
						),
						'author'     => array(
							'type'        => 'integer',
							'description' => 'Only items by this user ID.',
						),
						'orderby'    => array(
							'type' => 'string',
							'enum' => array( 'date', 'modified', 'title', 'menu_order', 'id' ),
						),
						'order'      => array(
							'type' => 'string',
							'enum' => array( 'asc', 'desc' ),
						),
					),
					$paging
				),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_content' ),
			),
			'get_content'          => array(
				'group'       => 'read',
				'title'       => 'Get a post or page',
				'description' => 'Full post or page: title, raw content (block markup), excerpt, status, terms, featured image, template, edit link and which editor or page builder it uses.',
				'properties'  => array( 'id' => $id ),
				'required'    => array( 'id' ),
				'handler'     => array( __CLASS__, 'get_content' ),
			),
			'list_terms'           => array(
				'group'       => 'read',
				'title'       => 'List categories or tags',
				'description' => 'List categories, tags or terms of another taxonomy.',
				'properties'  => array_merge(
					array(
						'taxonomy'   => array(
							'type'        => 'string',
							'description' => 'category (default), post_tag, or another taxonomy from get_site_info.',
						),
						'search'     => array( 'type' => 'string' ),
						'hide_empty' => array(
							'type'        => 'boolean',
							'description' => 'Leave out terms with no content.',
						),
					),
					$paging
				),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_terms' ),
			),
			'list_media'           => array(
				'group'       => 'read',
				'title'       => 'List media',
				'description' => 'List or search the media library: ID, title, URL, alt text, type and size.',
				'properties'  => array_merge(
					array(
						'search'     => array( 'type' => 'string' ),
						'media_type' => array(
							'type' => 'string',
							'enum' => array( 'image', 'video', 'audio', 'application' ),
						),
					),
					$paging
				),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_media' ),
			),
			'list_comments'        => array(
				'group'       => 'read',
				'title'       => 'List comments',
				'description' => 'List comments, by default those waiting for approval.',
				'properties'  => array_merge(
					array(
						'status'  => array(
							'type'        => 'string',
							'enum'        => array( 'hold', 'approve', 'spam', 'trash', 'all' ),
							'description' => 'hold (default, awaiting approval), approve, spam, trash or all.',
						),
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Only comments on this post or page.',
						),
						'search'  => array( 'type' => 'string' ),
					),
					$paging
				),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_comments' ),
			),
			'create_content'       => array(
				'group'       => 'write',
				'title'       => 'Create a post or page',
				'description' => 'Create a post, page or other content item. Saved as a draft unless status says otherwise. Returns its ID, link and edit link.',
				'properties'  => array_merge(
					array(
						'post_type' => array(
							'type'        => 'string',
							'description' => 'post (default), page, or another type from get_site_info.',
						),
					),
					$content
				),
				'required'    => array(),
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'create_content' ),
			),
			'update_content'       => array(
				'group'       => 'write',
				'title'       => 'Edit a post or page',
				'description' => 'Change fields of an existing post or page. Only the fields you pass change; content replaces the whole body, so start from get_content.',
				'properties'  => array_merge( array( 'id' => $id ), $content ),
				'required'    => array( 'id' ),
				'destructive' => true,
				'idempotent'  => true,
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'update_content' ),
			),
			'restore_content'      => array(
				'group'       => 'write',
				'title'       => 'Restore from trash',
				'description' => 'Restore a trashed post or page (it comes back as a draft).',
				'properties'  => array( 'id' => $id ),
				'required'    => array( 'id' ),
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'restore_content' ),
			),
			'create_term'          => array(
				'group'       => 'write',
				'title'       => 'Create a category or tag',
				'description' => 'Create a category, tag or term of another taxonomy.',
				'properties'  => array(
					'taxonomy'    => array(
						'type'        => 'string',
						'description' => 'category (default), post_tag, or another taxonomy.',
					),
					'name'        => array( 'type' => 'string' ),
					'slug'        => array( 'type' => 'string' ),
					'parent'      => array(
						'type'        => 'integer',
						'description' => 'Parent term ID (hierarchical taxonomies).',
					),
					'description' => array( 'type' => 'string' ),
				),
				'required'    => array( 'name' ),
				'handler'     => array( __CLASS__, 'create_term' ),
			),
			'delete_content'       => array(
				'group'       => 'delete',
				'title'       => 'Delete a post or page',
				'description' => 'Move a post or page to the trash (can be restored). Set permanently only when the user explicitly asks to delete it for good.',
				'properties'  => array(
					'id'          => $id,
					'permanently' => array(
						'type'        => 'boolean',
						'description' => 'Skip the trash and delete for good.',
					),
				),
				'required'    => array( 'id' ),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'delete_content' ),
			),
			'upload_media'         => array(
				'group'       => 'media',
				'title'       => 'Upload media from a link',
				'description' => 'Download an image or file from a public URL into the media library, optionally with alt text and as the featured image of a post or page.',
				'properties'  => array(
					'url'              => array(
						'type'        => 'string',
						'description' => 'Public http(s) URL of the file.',
					),
					'filename'         => array(
						'type'        => 'string',
						'description' => 'File name to save as, e.g. team-photo.jpg.',
					),
					'title'            => array( 'type' => 'string' ),
					'alt_text'         => array(
						'type'        => 'string',
						'description' => 'Alt text describing the image.',
					),
					'caption'          => array( 'type' => 'string' ),
					'description'      => array( 'type' => 'string' ),
					'attach_to'        => array(
						'type'        => 'integer',
						'description' => 'Post or page ID to attach the file to.',
					),
					'set_featured_for' => array(
						'type'        => 'integer',
						'description' => 'Post or page ID to set this image as featured image of.',
					),
				),
				'required'    => array( 'url' ),
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'upload_media' ),
			),
			'update_media'         => array(
				'group'       => 'media',
				'title'       => 'Edit media details',
				'description' => 'Change the title, alt text, caption or description of a media item.',
				'properties'  => array(
					'id'          => array(
						'type'        => 'integer',
						'description' => 'Media ID.',
					),
					'title'       => array( 'type' => 'string' ),
					'alt_text'    => array( 'type' => 'string' ),
					'caption'     => array( 'type' => 'string' ),
					'description' => array( 'type' => 'string' ),
				),
				'required'    => array( 'id' ),
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'update_media' ),
			),
			'moderate_comment'     => array(
				'group'       => 'comments',
				'title'       => 'Moderate a comment',
				'description' => 'Approve, unapprove, mark as spam, trash or permanently delete a comment.',
				'properties'  => array(
					'id'     => array(
						'type'        => 'integer',
						'description' => 'Comment ID.',
					),
					'action' => array(
						'type' => 'string',
						'enum' => array( 'approve', 'unapprove', 'spam', 'trash', 'delete' ),
					),
				),
				'required'    => array( 'id', 'action' ),
				'destructive' => true,
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'moderate_comment' ),
			),
			'reply_to_comment'     => array(
				'group'       => 'comments',
				'title'       => 'Reply to a comment',
				'description' => 'Post a reply to a comment as the connected user.',
				'properties'  => array(
					'id'      => array(
						'type'        => 'integer',
						'description' => 'Comment ID to reply to.',
					),
					'content' => array( 'type' => 'string' ),
				),
				'required'    => array( 'id', 'content' ),
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'reply_to_comment' ),
			),
			'update_site_settings' => array(
				'group'       => 'site',
				'title'       => 'Change site settings',
				'description' => 'Change the site title, tagline or homepage (latest posts or a static page, and the posts page).',
				'properties'  => array(
					'title'         => array( 'type' => 'string' ),
					'tagline'       => array( 'type' => 'string' ),
					'homepage'      => array(
						'type'        => 'string',
						'enum'        => array( 'posts', 'page' ),
						'description' => 'posts shows the latest posts; page shows front_page_id.',
					),
					'front_page_id' => array(
						'type'        => 'integer',
						'description' => 'Published page to use as the homepage.',
					),
					'posts_page_id' => array(
						'type'        => 'integer',
						'description' => 'Page that lists the blog posts (0 for none).',
					),
				),
				'required'    => array(),
				'destructive' => true,
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'update_site_settings' ),
			),
		);

		self::$tools = array_merge(
			self::$tools,
			AISB_Design::tools(),
			AISB_Files::tools(),
			AISB_Packages::tools(),
			AISB_Backup::tools()
		);

		return self::$tools;
	}

	/*
	 * Handlers.
	 */

	/**
	 * Site overview.
	 *
	 * @return array
	 */
	public static function get_site_info() {
		$user  = wp_get_current_user();
		$theme = wp_get_theme();

		$types = array();
		foreach ( get_post_types( array( 'show_in_rest' => true ), 'objects' ) as $type ) {
			if ( ! $type->public || 'attachment' === $type->name ) {
				continue;
			}
			$taxonomies = array();
			foreach ( get_object_taxonomies( $type->name, 'objects' ) as $taxonomy ) {
				if ( $taxonomy->show_in_rest && $taxonomy->public ) {
					$taxonomies[] = $taxonomy->name;
				}
			}
			$types[] = array(
				'name'         => $type->name,
				'label'        => $type->labels->name,
				'hierarchical' => (bool) $type->hierarchical,
				'taxonomies'   => $taxonomies,
			);
		}

		$info = array(
			'name'              => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'tagline'           => wp_specialchars_decode( get_bloginfo( 'description' ), ENT_QUOTES ),
			'url'               => home_url( '/' ),
			'admin_url'         => admin_url(),
			'language'          => get_locale(),
			'timezone'          => wp_timezone_string(),
			'wordpress_version' => get_bloginfo( 'version' ),
			'theme'             => array(
				'name'        => $theme->get( 'Name' ),
				'parent'      => $theme->parent() ? $theme->parent()->get( 'Name' ) : null,
				'block_theme' => function_exists( 'wp_is_block_theme' ) && wp_is_block_theme(),
			),
			'page_builders'     => self::active_builders(),
			'homepage'          => array(
				'shows'         => 'page' === get_option( 'show_on_front' ) ? 'page' : 'posts',
				'front_page_id' => (int) get_option( 'page_on_front' ),
				'posts_page_id' => (int) get_option( 'page_for_posts' ),
			),
			'content_types'     => $types,
			'connected_user'    => array(
				'id'    => $user->ID,
				'name'  => $user->display_name,
				'roles' => array_values( $user->roles ),
			),
			'enabled_actions'   => array_values( array_filter( array_keys( AISB_Settings::groups() ), array( 'AISB_Settings', 'group_enabled' ) ) ),
		);

		if ( current_user_can( 'activate_plugins' ) ) {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$plugins = get_plugins();
			$active  = array();
			foreach ( (array) get_option( 'active_plugins', array() ) as $file ) {
				if ( isset( $plugins[ $file ] ) ) {
					$active[] = $plugins[ $file ]['Name'] . ' ' . $plugins[ $file ]['Version'];
				}
			}
			$info['active_plugins'] = $active;
		}

		return $info;
	}

	/**
	 * List posts, pages or another type.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function list_content( $args ) {
		$type   = self::post_type( self::str( $args, 'post_type', 'post' ) );
		$params = array_merge(
			self::paging( $args ),
			array(
				'context' => 'edit',
				'status'  => self::statuses( self::str( $args, 'status', 'any' ) ),
			)
		);
		foreach ( array( 'search', 'orderby', 'order' ) as $key ) {
			if ( '' !== self::str( $args, $key ) ) {
				$params[ $key ] = self::str( $args, $key );
			}
		}
		if ( 'title' === self::str( $args, 'orderby' ) && empty( $params['order'] ) ) {
			$params['order'] = 'asc';
		}
		if ( isset( $args['category'] ) ) {
			$params['categories'] = array( absint( $args['category'] ) );
		}
		if ( isset( $args['tag'] ) ) {
			$params['tags'] = array( absint( $args['tag'] ) );
		}
		if ( isset( $args['parent'] ) && $type->hierarchical ) {
			$params['parent'] = array( absint( $args['parent'] ) );
		}
		if ( isset( $args['author'] ) ) {
			$params['author'] = array( absint( $args['author'] ) );
		}

		list( $data, $headers ) = self::rest( 'GET', self::route( $type ), $params );

		$items = array();
		foreach ( (array) $data as $item ) {
			$excerpt = isset( $item['excerpt']['raw'] ) && '' !== $item['excerpt']['raw'] ? $item['excerpt']['raw'] : ( isset( $item['content']['raw'] ) ? $item['content']['raw'] : '' );
			$row     = array(
				'id'       => $item['id'],
				'title'    => self::raw( $item, 'title' ),
				'status'   => $item['status'],
				'date'     => $item['date'],
				'modified' => $item['modified'],
				'link'     => $item['link'],
				'excerpt'  => wp_trim_words( wp_strip_all_tags( strip_shortcodes( $excerpt ) ), 25 ),
			);
			if ( $type->hierarchical ) {
				$row['parent'] = isset( $item['parent'] ) ? $item['parent'] : 0;
			}
			$items[] = $row;
		}

		return array(
			'post_type'   => $type->name,
			'total'       => isset( $headers['X-WP-Total'] ) ? (int) $headers['X-WP-Total'] : count( $items ),
			'total_pages' => isset( $headers['X-WP-TotalPages'] ) ? (int) $headers['X-WP-TotalPages'] : 1,
			'items'       => $items,
		);
	}

	/**
	 * One post or page in full.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function get_content( $args ) {
		$post = self::post( $args );
		$type = self::post_type( $post->post_type );

		list( $data ) = self::rest( 'GET', self::route( $type, $post->ID ), array( 'context' => 'edit' ) );

		$terms = array();
		foreach ( get_object_taxonomies( $post->post_type, 'objects' ) as $taxonomy ) {
			if ( ! $taxonomy->show_in_rest ) {
				continue;
			}
			$list = get_the_terms( $post, $taxonomy->name );
			if ( is_array( $list ) ) {
				foreach ( $list as $term ) {
					$terms[ $taxonomy->name ][] = array(
						'id'   => $term->term_id,
						'name' => $term->name,
					);
				}
			}
		}

		$thumb   = get_post_thumbnail_id( $post );
		$builder = self::builder( $post );
		$result  = array(
			'id'             => $post->ID,
			'post_type'      => $post->post_type,
			'status'         => $data['status'],
			'title'          => self::raw( $data, 'title' ),
			'slug'           => $data['slug'],
			'link'           => $data['link'],
			'edit_url'       => get_edit_post_link( $post->ID, 'raw' ),
			'date'           => $data['date'],
			'modified'       => $data['modified'],
			'author'         => get_the_author_meta( 'display_name', $post->post_author ),
			'parent'         => (int) $post->post_parent,
			'menu_order'     => (int) $post->menu_order,
			'template'       => isset( $data['template'] ) ? $data['template'] : '',
			'excerpt'        => self::raw( $data, 'excerpt' ),
			'content'        => self::raw( $data, 'content' ),
			'terms'          => $terms ? $terms : (object) array(),
			'featured_image' => $thumb ? array(
				'id'  => (int) $thumb,
				'url' => wp_get_attachment_image_url( $thumb, 'full' ),
				'alt' => get_post_meta( $thumb, '_wp_attachment_image_alt', true ),
			) : null,
			'editor'         => $builder ? $builder : ( has_blocks( $post->post_content ) ? 'block editor' : 'classic editor' ),
		);
		if ( $builder ) {
			$result['editor_note'] = sprintf( 'This item is built with %s. Visitors see the %s layout, so changing content here will not change the page; edit it in %s instead.', $builder, $builder, $builder );
		}
		return $result;
	}

	/**
	 * List terms.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function list_terms( $args ) {
		$taxonomy = self::taxonomy( self::str( $args, 'taxonomy', 'category' ) );
		$params   = self::paging( $args );
		if ( '' !== self::str( $args, 'search' ) ) {
			$params['search'] = self::str( $args, 'search' );
		}
		if ( ! empty( $args['hide_empty'] ) ) {
			$params['hide_empty'] = true;
		}

		list( $data, $headers ) = self::rest( 'GET', self::route( $taxonomy ), $params );

		$items = array();
		foreach ( (array) $data as $term ) {
			$items[] = array(
				'id'     => $term['id'],
				'name'   => wp_specialchars_decode( $term['name'], ENT_QUOTES ),
				'slug'   => $term['slug'],
				'count'  => $term['count'],
				'parent' => isset( $term['parent'] ) ? $term['parent'] : 0,
			);
		}
		return array(
			'taxonomy' => $taxonomy->name,
			'total'    => isset( $headers['X-WP-Total'] ) ? (int) $headers['X-WP-Total'] : count( $items ),
			'items'    => $items,
		);
	}

	/**
	 * List media.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function list_media( $args ) {
		$params = self::paging( $args );
		foreach ( array( 'search', 'media_type' ) as $key ) {
			if ( '' !== self::str( $args, $key ) ) {
				$params[ $key ] = self::str( $args, $key );
			}
		}

		list( $data, $headers ) = self::rest( 'GET', '/wp/v2/media', $params );

		$items = array();
		foreach ( (array) $data as $item ) {
			$items[] = self::media_summary( $item );
		}
		return array(
			'total' => isset( $headers['X-WP-Total'] ) ? (int) $headers['X-WP-Total'] : count( $items ),
			'items' => $items,
		);
	}

	/**
	 * List comments.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function list_comments( $args ) {
		$params = array_merge(
			self::paging( $args ),
			array(
				'context' => 'edit',
				'status'  => self::str( $args, 'status', 'hold' ),
			)
		);
		if ( ! empty( $args['post_id'] ) ) {
			$params['post'] = array( absint( $args['post_id'] ) );
		}
		if ( '' !== self::str( $args, 'search' ) ) {
			$params['search'] = self::str( $args, 'search' );
		}

		list( $data, $headers ) = self::rest( 'GET', '/wp/v2/comments', $params );

		$items = array();
		foreach ( (array) $data as $comment ) {
			$items[] = array(
				'id'         => $comment['id'],
				'post_id'    => $comment['post'],
				'post_title' => get_the_title( $comment['post'] ),
				'parent'     => $comment['parent'],
				'author'     => $comment['author_name'],
				'author_url' => $comment['author_url'],
				'date'       => $comment['date'],
				'status'     => $comment['status'],
				'content'    => wp_trim_words( wp_strip_all_tags( self::raw( $comment, 'content' ) ), 80 ),
				'link'       => $comment['link'],
			);
		}
		return array(
			'total' => isset( $headers['X-WP-Total'] ) ? (int) $headers['X-WP-Total'] : count( $items ),
			'items' => $items,
		);
	}

	/**
	 * Create a post or page.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function create_content( $args ) {
		$type   = self::post_type( self::str( $args, 'post_type', 'post' ) );
		$params = self::content_params( $type, $args );
		if ( '' === self::str( $args, 'title' ) && '' === self::str( $args, 'content' ) ) {
			throw new AISB_Tool_Error( 'Give at least a title or content.' );
		}
		if ( empty( $params['status'] ) ) {
			$params['status'] = 'draft';
		}

		list( $data ) = self::rest( 'POST', self::route( $type ), $params );
		return self::saved( $data );
	}

	/**
	 * Edit a post or page.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function update_content( $args ) {
		$post   = self::post( $args );
		$type   = self::post_type( $post->post_type );
		$params = self::content_params( $type, $args );
		if ( ! $params ) {
			throw new AISB_Tool_Error( 'Nothing to change: pass at least one field.' );
		}

		list( $data ) = self::rest( 'POST', self::route( $type, $post->ID ), $params );
		return self::saved( $data );
	}

	/**
	 * Restore a trashed post or page.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function restore_content( $args ) {
		$post = self::post( $args );
		if ( 'trash' !== $post->post_status ) {
			throw new AISB_Tool_Error( 'This item is not in the trash.' );
		}
		if ( ! current_user_can( 'delete_post', $post->ID ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to restore this item.' );
		}
		if ( ! wp_untrash_post( $post->ID ) ) {
			throw new AISB_Tool_Error( 'Could not restore this item.' );
		}
		$post = get_post( $post->ID );
		return array(
			'id'       => $post->ID,
			'title'    => get_the_title( $post ),
			'status'   => $post->post_status,
			'edit_url' => get_edit_post_link( $post->ID, 'raw' ),
		);
	}

	/**
	 * Create a term.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function create_term( $args ) {
		$taxonomy = self::taxonomy( self::str( $args, 'taxonomy', 'category' ) );
		$params   = array( 'name' => self::str( $args, 'name' ) );
		foreach ( array( 'slug', 'description' ) as $key ) {
			if ( isset( $args[ $key ] ) ) {
				$params[ $key ] = self::str( $args, $key );
			}
		}
		if ( isset( $args['parent'] ) && $taxonomy->hierarchical ) {
			$params['parent'] = absint( $args['parent'] );
		}

		list( $data ) = self::rest( 'POST', self::route( $taxonomy ), $params );
		return array(
			'id'       => $data['id'],
			'taxonomy' => $taxonomy->name,
			'title'    => wp_specialchars_decode( $data['name'], ENT_QUOTES ),
			'slug'     => $data['slug'],
			'link'     => $data['link'],
		);
	}

	/**
	 * Trash or delete a post or page.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function delete_content( $args ) {
		$post      = self::post( $args );
		$type      = self::post_type( $post->post_type );
		$permanent = ! empty( $args['permanently'] );
		$title     = get_the_title( $post );

		self::rest( 'DELETE', self::route( $type, $post->ID ), array( 'force' => $permanent ) );
		return array(
			'id'     => $post->ID,
			'title'  => $title,
			'status' => $permanent ? 'deleted permanently' : 'moved to trash (restore_content can bring it back)',
		);
	}

	/**
	 * Sideload a file from a URL.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function upload_media( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to upload files.' );
		}
		$url = esc_url_raw( self::str( $args, 'url' ), array( 'http', 'https' ) );
		if ( '' === $url ) {
			throw new AISB_Tool_Error( 'Give a public http(s) URL.' );
		}
		$attach_to = isset( $args['attach_to'] ) ? absint( $args['attach_to'] ) : 0;
		if ( $attach_to && ! current_user_can( 'edit_post', $attach_to ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to edit the item to attach to.' );
		}
		$featured_for = isset( $args['set_featured_for'] ) ? absint( $args['set_featured_for'] ) : 0;
		if ( $featured_for && ! current_user_can( 'edit_post', $featured_for ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to edit the item to set the featured image of.' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// download_url() refuses private and local network addresses.
		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			throw new AISB_Tool_Error( 'Download failed: ' . $tmp->get_error_message() );
		}

		$name = sanitize_file_name( self::str( $args, 'filename' ) );
		if ( '' === $name ) {
			$name = sanitize_file_name( wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		}
		if ( '' === $name || ! pathinfo( $name, PATHINFO_EXTENSION ) ) {
			$mime = wp_get_image_mime( $tmp );
			$exts = array(
				'image/jpeg' => 'jpg',
				'image/png'  => 'png',
				'image/gif'  => 'gif',
				'image/webp' => 'webp',
				'image/avif' => 'avif',
			);
			$name = ( '' !== $name ? $name : 'upload' ) . '.' . ( isset( $exts[ $mime ] ) ? $exts[ $mime ] : 'jpg' );
		}

		$post_data = array();
		if ( '' !== self::str( $args, 'caption' ) ) {
			$post_data['post_excerpt'] = self::str( $args, 'caption' );
		}
		if ( '' !== self::str( $args, 'description' ) ) {
			$post_data['post_content'] = self::str( $args, 'description' );
		}
		$title = self::str( $args, 'title' );
		if ( '' !== $title ) {
			$post_data['post_title'] = $title;
		}

		$id = media_handle_sideload(
			array(
				'name'     => $name,
				'tmp_name' => $tmp,
			),
			$attach_to,
			null,
			$post_data
		);
		if ( is_wp_error( $id ) ) {
			wp_delete_file( $tmp );
			throw new AISB_Tool_Error( 'Upload failed: ' . $id->get_error_message() );
		}

		if ( '' !== self::str( $args, 'alt_text' ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( self::str( $args, 'alt_text' ) ) );
		}
		if ( $featured_for ) {
			set_post_thumbnail( $featured_for, $id );
		}

		return array(
			'id'          => $id,
			'title'       => get_the_title( $id ),
			'url'         => wp_get_attachment_url( $id ),
			'alt'         => get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'featured_on' => $featured_for ? $featured_for : null,
		);
	}

	/**
	 * Edit media details.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function update_media( $args ) {
		$id     = absint( isset( $args['id'] ) ? $args['id'] : 0 );
		$params = array();
		foreach ( array( 'title', 'alt_text', 'caption', 'description' ) as $key ) {
			if ( isset( $args[ $key ] ) ) {
				$params[ $key ] = self::str( $args, $key );
			}
		}
		if ( ! $params ) {
			throw new AISB_Tool_Error( 'Nothing to change: pass at least one field.' );
		}

		list( $data ) = self::rest( 'POST', '/wp/v2/media/' . $id, $params );
		return self::media_summary( $data );
	}

	/**
	 * Moderate a comment.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function moderate_comment( $args ) {
		$id     = absint( isset( $args['id'] ) ? $args['id'] : 0 );
		$action = self::str( $args, 'action' );
		$map    = array(
			'approve'   => 'approved',
			'unapprove' => 'hold',
			'spam'      => 'spam',
			'trash'     => 'trash',
		);

		if ( 'delete' === $action ) {
			self::rest( 'DELETE', '/wp/v2/comments/' . $id, array( 'force' => true ) );
			return array(
				'id'     => $id,
				'status' => 'deleted permanently',
			);
		}
		if ( ! isset( $map[ $action ] ) ) {
			throw new AISB_Tool_Error( 'action must be approve, unapprove, spam, trash or delete.' );
		}

		list( $data ) = self::rest( 'POST', '/wp/v2/comments/' . $id, array( 'status' => $map[ $action ] ) );
		return array(
			'id'     => $data['id'],
			'status' => $data['status'],
			'link'   => $data['link'],
		);
	}

	/**
	 * Reply to a comment.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function reply_to_comment( $args ) {
		$parent = get_comment( absint( isset( $args['id'] ) ? $args['id'] : 0 ) );
		if ( ! $parent ) {
			throw new AISB_Tool_Error( 'Comment not found.' );
		}

		list( $data ) = self::rest(
			'POST',
			'/wp/v2/comments',
			array(
				'post'    => (int) $parent->comment_post_ID,
				'parent'  => (int) $parent->comment_ID,
				'content' => self::str( $args, 'content' ),
			)
		);
		return array(
			'id'     => $data['id'],
			'status' => $data['status'],
			'link'   => $data['link'],
		);
	}

	/**
	 * Change site title, tagline and homepage.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function update_site_settings( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			throw new AISB_Tool_Error( 'Only administrators can change site settings.' );
		}

		$changed = array();
		if ( isset( $args['title'] ) ) {
			update_option( 'blogname', sanitize_text_field( self::str( $args, 'title' ) ) );
			$changed['title'] = get_option( 'blogname' );
		}
		if ( isset( $args['tagline'] ) ) {
			update_option( 'blogdescription', sanitize_text_field( self::str( $args, 'tagline' ) ) );
			$changed['tagline'] = get_option( 'blogdescription' );
		}
		foreach ( array( 'front_page_id', 'posts_page_id' ) as $key ) {
			if ( ! empty( $args[ $key ] ) ) {
				$page = get_post( absint( $args[ $key ] ) );
				if ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
					throw new AISB_Tool_Error( $key . ' must be the ID of a published page.' );
				}
			}
		}
		if ( isset( $args['front_page_id'] ) ) {
			update_option( 'page_on_front', absint( $args['front_page_id'] ) );
			$changed['front_page_id'] = (int) get_option( 'page_on_front' );
		}
		if ( isset( $args['posts_page_id'] ) ) {
			update_option( 'page_for_posts', absint( $args['posts_page_id'] ) );
			$changed['posts_page_id'] = (int) get_option( 'page_for_posts' );
		}
		if ( isset( $args['homepage'] ) ) {
			$show = 'page' === self::str( $args, 'homepage' ) ? 'page' : 'posts';
			if ( 'page' === $show && ! get_option( 'page_on_front' ) ) {
				throw new AISB_Tool_Error( 'Pass front_page_id to show a static page on the homepage.' );
			}
			update_option( 'show_on_front', $show );
			$changed['homepage'] = $show;
		}
		if ( ! $changed ) {
			throw new AISB_Tool_Error( 'Nothing to change: pass at least one setting.' );
		}
		return $changed;
	}

	/*
	 * Helpers.
	 */

	/**
	 * Run an internal REST API request as the connected user.
	 *
	 * @param string $method HTTP method.
	 * @param string $route  Route.
	 * @param array  $params Parameters.
	 * @return array Response data and headers.
	 * @throws AISB_Tool_Error When the request fails.
	 */
	private static function rest( $method, $route, $params = array() ) {
		$request = new WP_REST_Request( $method, $route );
		foreach ( $params as $key => $value ) {
			$request->set_param( $key, $value );
		}
		$response = rest_do_request( $request );
		$data     = rest_get_server()->response_to_data( $response, false );
		if ( $response->is_error() ) {
			$message = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : 'The request failed.';
			throw new AISB_Tool_Error( wp_strip_all_tags( $message ) );
		}
		return array( $data, $response->get_headers() );
	}

	/**
	 * REST route of a post type or taxonomy.
	 *
	 * @param WP_Post_Type|WP_Taxonomy $object Type object.
	 * @param int                      $id     Item ID.
	 * @return string
	 */
	private static function route( $object, $id = 0 ) {
		$namespace = ! empty( $object->rest_namespace ) ? $object->rest_namespace : 'wp/v2';
		$base      = ! empty( $object->rest_base ) ? $object->rest_base : $object->name;
		return '/' . trim( $namespace, '/' ) . '/' . $base . ( $id ? '/' . (int) $id : '' );
	}

	/**
	 * Post type object the tools may work with.
	 *
	 * @param string $name Post type.
	 * @return WP_Post_Type
	 * @throws AISB_Tool_Error When unknown.
	 */
	private static function post_type( $name ) {
		$type = get_post_type_object( sanitize_key( $name ) );
		if ( ! $type || empty( $type->show_in_rest ) || 'attachment' === $type->name ) {
			throw new AISB_Tool_Error( sprintf( 'Unknown content type "%s". get_site_info lists the available types; use the media tools for media.', $name ) );
		}
		return $type;
	}

	/**
	 * Taxonomy object the tools may work with.
	 *
	 * @param string $name Taxonomy.
	 * @return WP_Taxonomy
	 * @throws AISB_Tool_Error When unknown.
	 */
	private static function taxonomy( $name ) {
		$name     = 'tag' === $name || 'tags' === $name ? 'post_tag' : ( 'categories' === $name ? 'category' : $name );
		$taxonomy = get_taxonomy( sanitize_key( $name ) );
		if ( ! $taxonomy || empty( $taxonomy->show_in_rest ) ) {
			throw new AISB_Tool_Error( sprintf( 'Unknown taxonomy "%s". get_site_info lists the taxonomies of each content type.', $name ) );
		}
		return $taxonomy;
	}

	/**
	 * Post from the `id` argument.
	 *
	 * @param array $args Arguments.
	 * @return WP_Post
	 * @throws AISB_Tool_Error When missing.
	 */
	private static function post( $args ) {
		$post = get_post( absint( isset( $args['id'] ) ? $args['id'] : 0 ) );
		if ( ! $post ) {
			throw new AISB_Tool_Error( 'No post or page with this ID.' );
		}
		return $post;
	}

	/**
	 * String argument.
	 *
	 * @param array  $args    Arguments.
	 * @param string $key     Key.
	 * @param string $default Default.
	 * @return string
	 */
	public static function str( $args, $key, $default = '' ) {
		return isset( $args[ $key ] ) && is_scalar( $args[ $key ] ) && '' !== (string) $args[ $key ] ? (string) $args[ $key ] : $default;
	}

	/**
	 * per_page and page parameters.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	private static function paging( $args ) {
		return array(
			'per_page' => isset( $args['per_page'] ) ? max( 1, min( 100, (int) $args['per_page'] ) ) : 20,
			'page'     => isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1,
		);
	}

	/**
	 * Status filter for list_content.
	 *
	 * @param string $status Comma-separated statuses or "any".
	 * @return array
	 */
	private static function statuses( $status ) {
		$list = array_filter( array_map( 'sanitize_key', explode( ',', $status ) ) );
		return $list ? array_values( $list ) : array( 'any' );
	}

	/**
	 * Raw value of a REST field that has raw/rendered forms.
	 *
	 * @param array  $data  Item.
	 * @param string $field Field.
	 * @return string
	 */
	private static function raw( $data, $field ) {
		if ( ! isset( $data[ $field ] ) ) {
			return '';
		}
		if ( is_array( $data[ $field ] ) ) {
			return isset( $data[ $field ]['raw'] ) ? (string) $data[ $field ]['raw'] : wp_specialchars_decode( wp_strip_all_tags( (string) $data[ $field ]['rendered'] ), ENT_QUOTES );
		}
		return (string) $data[ $field ];
	}

	/**
	 * REST parameters for create_content / update_content.
	 *
	 * @param WP_Post_Type $type Post type.
	 * @param array        $args Arguments.
	 * @return array
	 */
	private static function content_params( $type, $args ) {
		$params = array();
		foreach ( array( 'title', 'content', 'excerpt', 'status', 'slug', 'date', 'template', 'comment_status' ) as $key ) {
			if ( isset( $args[ $key ] ) && is_scalar( $args[ $key ] ) ) {
				$params[ $key ] = (string) $args[ $key ];
			}
		}
		foreach ( array( 'parent', 'menu_order' ) as $key ) {
			if ( isset( $args[ $key ] ) ) {
				$params[ $key ] = (int) $args[ $key ];
			}
		}
		if ( isset( $args['featured_image_id'] ) ) {
			$params['featured_media'] = absint( $args['featured_image_id'] );
		}

		$terms = isset( $args['terms'] ) && is_array( $args['terms'] ) ? $args['terms'] : array();
		if ( isset( $args['categories'] ) ) {
			$terms['category'] = $args['categories'];
		}
		if ( isset( $args['tags'] ) ) {
			$terms['post_tag'] = $args['tags'];
		}
		foreach ( $terms as $name => $values ) {
			$taxonomy = self::taxonomy( (string) $name );
			if ( ! is_object_in_taxonomy( $type->name, $taxonomy->name ) ) {
				throw new AISB_Tool_Error( sprintf( '%s items have no %s.', $type->labels->singular_name, $taxonomy->labels->name ) );
			}
			$params[ $taxonomy->rest_base ? $taxonomy->rest_base : $taxonomy->name ] = self::term_ids( $taxonomy, (array) $values );
		}

		return $params;
	}

	/**
	 * Term IDs for a list of names or IDs, creating missing names when allowed.
	 *
	 * @param WP_Taxonomy $taxonomy Taxonomy.
	 * @param array       $values   Names or IDs.
	 * @return int[]
	 * @throws AISB_Tool_Error When a term is missing and can't be created.
	 */
	private static function term_ids( $taxonomy, $values ) {
		$ids = array();
		foreach ( $values as $value ) {
			if ( is_int( $value ) || ctype_digit( (string) $value ) ) {
				$ids[] = (int) $value;
				continue;
			}
			$value = trim( (string) $value );
			if ( '' === $value ) {
				continue;
			}
			$term = get_term_by( 'name', $value, $taxonomy->name );
			if ( ! $term ) {
				$term = get_term_by( 'slug', sanitize_title( $value ), $taxonomy->name );
			}
			if ( $term ) {
				$ids[] = (int) $term->term_id;
				continue;
			}
			if ( ! current_user_can( $taxonomy->cap->edit_terms ) ) {
				throw new AISB_Tool_Error( sprintf( '%1$s "%2$s" does not exist and you are not allowed to create it.', $taxonomy->labels->singular_name, $value ) );
			}
			$created = wp_insert_term( $value, $taxonomy->name );
			if ( is_wp_error( $created ) ) {
				throw new AISB_Tool_Error( $created->get_error_message() );
			}
			$ids[] = (int) $created['term_id'];
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Result of create_content / update_content.
	 *
	 * @param array $data REST item.
	 * @return array
	 */
	private static function saved( $data ) {
		return array(
			'id'       => $data['id'],
			'title'    => self::raw( $data, 'title' ),
			'status'   => $data['status'],
			'link'     => $data['link'],
			'edit_url' => get_edit_post_link( $data['id'], 'raw' ),
			'modified' => $data['modified'],
		);
	}

	/**
	 * Compact media item.
	 *
	 * @param array $item REST media item.
	 * @return array
	 */
	private static function media_summary( $item ) {
		$details = isset( $item['media_details'] ) && is_array( $item['media_details'] ) ? $item['media_details'] : array();
		return array(
			'id'          => $item['id'],
			'title'       => self::raw( $item, 'title' ),
			'url'         => $item['source_url'],
			'alt'         => $item['alt_text'],
			'mime_type'   => $item['mime_type'],
			'width'       => isset( $details['width'] ) ? $details['width'] : null,
			'height'      => isset( $details['height'] ) ? $details['height'] : null,
			'date'        => $item['date'],
			'attached_to' => isset( $item['post'] ) ? $item['post'] : null,
		);
	}

	/**
	 * Page builders active on the site.
	 *
	 * @return string[]
	 */
	private static function active_builders() {
		$builders = array();
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			$builders[] = 'Elementor';
		}
		if ( defined( 'ET_BUILDER_VERSION' ) ) {
			$builders[] = 'Divi';
		}
		if ( defined( 'WPB_VC_VERSION' ) ) {
			$builders[] = 'WPBakery';
		}
		if ( class_exists( 'FLBuilder' ) ) {
			$builders[] = 'Beaver Builder';
		}
		if ( defined( 'BRICKS_VERSION' ) ) {
			$builders[] = 'Bricks';
		}
		return $builders;
	}

	/**
	 * Page builder a post is built with, if any.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function builder( $post ) {
		if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			return 'Elementor';
		}
		if ( 'on' === get_post_meta( $post->ID, '_et_pb_use_builder', true ) ) {
			return 'Divi';
		}
		if ( get_post_meta( $post->ID, '_fl_builder_enabled', true ) ) {
			return 'Beaver Builder';
		}
		if ( get_post_meta( $post->ID, '_bricks_page_content_2', true ) ) {
			return 'Bricks';
		}
		if ( false !== strpos( $post->post_content, '[vc_row' ) ) {
			return 'WPBakery';
		}
		return '';
	}
}
