<?php
/**
 * Admin screen: connect instructions, settings, connected apps and activity log.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * The "AI Site Bridge" admin menu page.
 */
class AISB_Admin {

	const SLUG = 'ai-site-bridge';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_aisb_disconnect', array( __CLASS__, 'disconnect' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( AISB_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Menu item.
	 */
	public static function menu() {
		add_menu_page(
			__( 'AI Site Bridge', 'ai-site-bridge' ),
			__( 'AI Site Bridge', 'ai-site-bridge' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-format-chat',
			81
		);
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Connect', 'ai-site-bridge' ) . '</a>' );
		return $links;
	}

	/**
	 * Settings API registration.
	 */
	public static function register_settings() {
		register_setting(
			'aisb_settings',
			AISB_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'AISB_Settings', 'sanitize' ),
			)
		);
	}

	/**
	 * Disconnect an app for one user.
	 */
	public static function disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'ai-site-bridge' ) );
		}
		check_admin_referer( 'aisb_disconnect' );

		$client_id = isset( $_POST['client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) : '';
		$user_id   = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		if ( $client_id ) {
			AISB_Store::revoke( $client_id, $user_id );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&disconnected=1' ) );
		exit;
	}

	/**
	 * Page.
	 */
	public static function render() {
		$tabs = array(
			'connect'  => __( 'Connect', 'ai-site-bridge' ),
			'settings' => __( 'Settings', 'ai-site-bridge' ),
			'activity' => __( 'Activity', 'ai-site-bridge' ),
		);
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'connect'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $tabs[ $tab ] ) ? $tab : 'connect';
		?>
		<div class="wrap aisb">
			<h1><?php esc_html_e( 'AI Site Bridge', 'ai-site-bridge' ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $key ) ); ?>" class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>
			<?php
			if ( 'settings' === $tab ) {
				self::render_settings();
			} elseif ( 'activity' === $tab ) {
				self::render_activity();
			} else {
				self::render_connect();
			}
			?>
		</div>
		<style>
			.aisb .card { max-width: 820px; }
			.aisb .aisb-url { display: flex; gap: 8px; margin: 8px 0 4px; }
			.aisb .aisb-url input { flex: 1; font-family: Consolas, Monaco, monospace; }
			.aisb ol li { margin-bottom: 6px; }
			.aisb .aisb-check { margin: 4px 0; }
			.aisb .aisb-check .dashicons { vertical-align: text-bottom; }
			.aisb .aisb-ok { color: #008a20; }
			.aisb .aisb-bad { color: #d63638; }
			.aisb .aisb-warn { color: #996800; }
			.aisb .aisb-groups label { display: block; margin-bottom: 8px; }
			.aisb .aisb-groups small { display: block; margin-left: 24px; color: #646970; }
			.aisb .aisb-groups label.aisb-danger { border-left: 3px solid #dba617; padding-left: 8px; }
		</style>
		<?php
	}

	/**
	 * Connect tab.
	 */
	private static function render_connect() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['disconnected'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'The app was disconnected.', 'ai-site-bridge' ) . '</p></div>';
		}
		$url = AISB_Router::mcp_url();
		?>
		<div class="card">
			<h2><?php esc_html_e( 'Connector URL', 'ai-site-bridge' ); ?></h2>
			<p><?php esc_html_e( 'Paste this URL into your AI app to let it manage this site.', 'ai-site-bridge' ); ?></p>
			<div class="aisb-url">
				<input type="text" id="aisb-mcp-url" class="regular-text" readonly value="<?php echo esc_attr( $url ); ?>" onclick="this.select()">
				<button type="button" class="button button-primary" id="aisb-copy"><?php esc_html_e( 'Copy', 'ai-site-bridge' ); ?></button>
			</div>
			<?php self::render_checks(); ?>
		</div>

		<div class="card">
			<h2><?php esc_html_e( 'Connect Claude', 'ai-site-bridge' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'In Claude (claude.ai, desktop or mobile app) open Settings → Connectors and choose "Add custom connector".', 'ai-site-bridge' ); ?></li>
				<li><?php esc_html_e( 'Enter a name (for example your site name), paste the connector URL above and click Add.', 'ai-site-bridge' ); ?></li>
				<li><?php esc_html_e( 'Click Connect. This site\'s login page opens: log in and click Approve.', 'ai-site-bridge' ); ?></li>
				<li><?php esc_html_e( 'In a chat, make sure the connector is switched on in the tools menu, then ask, for example: "List my draft posts", "Create a page called Services", "Change the heading colour to navy" or (with the code option on) "Install Contact Form 7 and add a contact form to my Contact page".', 'ai-site-bridge' ); ?></li>
			</ol>
			<p class="description"><?php esc_html_e( 'Other apps that support remote MCP servers with OAuth (ChatGPT developer mode, Cursor, VS Code…) connect the same way; add their return address under Settings → Allowed apps first.', 'ai-site-bridge' ); ?></p>
		</div>

		<div class="card">
			<h2><?php esc_html_e( 'Connected apps', 'ai-site-bridge' ); ?></h2>
			<?php self::render_connections(); ?>
		</div>
		<script>
			document.getElementById( 'aisb-copy' ).addEventListener( 'click', function () {
				var input = document.getElementById( 'aisb-mcp-url' ), button = this;
				input.select();
				( navigator.clipboard ? navigator.clipboard.writeText( input.value ) : Promise.reject() ).catch( function () { document.execCommand( 'copy' ); } );
				button.textContent = <?php echo wp_json_encode( __( 'Copied', 'ai-site-bridge' ) ); ?>;
				setTimeout( function () { button.textContent = <?php echo wp_json_encode( __( 'Copy', 'ai-site-bridge' ) ); ?>; }, 2000 );
			} );
		</script>
		<?php
	}

	/**
	 * Checks that the site can accept connections.
	 */
	private static function render_checks() {
		$checks = array();

		if ( ! AISB_Settings::enabled() ) {
			$checks[] = array( 'bad', __( 'Connections are turned off (Settings tab).', 'ai-site-bridge' ) );
		}
		if ( ! get_option( 'permalink_structure' ) ) {
			$checks[] = array( 'bad', __( 'Plain permalinks are on. Choose any other structure under Settings → Permalinks, or the connector URL will not work.', 'ai-site-bridge' ) );
		}
		if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			$checks[] = array( 'warn', __( 'The site does not use HTTPS. AI apps require an https:// address.', 'ai-site-bridge' ) );
		}

		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		if ( in_array( $host, array( 'localhost', '127.0.0.1' ), true ) || preg_match( '/\.(local|test|localhost)$/', $host ) ) {
			$checks[] = array( 'warn', __( 'This looks like a local site. Cloud AI apps such as claude.ai can only reach sites that are online.', 'ai-site-bridge' ) );
		}

		if ( AISB_Settings::group_enabled( 'code' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
				$checks[] = array( 'warn', __( 'Themes, plugins & code is on, but file changes are disabled on this site (DISALLOW_FILE_MODS). The assistant can read code but not change or install it.', 'ai-site-bridge' ) );
			} elseif ( 'direct' !== get_filesystem_method() ) {
				$checks[] = array( 'warn', __( 'Themes, plugins & code is on, but this server needs FTP details to change files, which is not supported. Ask your host to allow direct file writes.', 'ai-site-bridge' ) );
			} else {
				$checks[] = array( 'warn', __( 'Themes, plugins & code is ON: the assistant can edit theme and plugin files and install software. Keep this off unless you want that.', 'ai-site-bridge' ) );
			}
		}

		$discovery = self::discovery_check();
		if ( true === $discovery ) {
			$checks[] = array( 'ok', __( 'Connector endpoints are reachable.', 'ai-site-bridge' ) );
		} else {
			$checks[] = array( 'warn', $discovery );
		}

		$icons = array(
			'ok'   => 'yes-alt',
			'warn' => 'warning',
			'bad'  => 'dismiss',
		);
		foreach ( $checks as $check ) {
			printf(
				'<p class="aisb-check aisb-%1$s"><span class="dashicons dashicons-%2$s"></span> %3$s</p>',
				esc_attr( $check[0] ),
				esc_attr( $icons[ $check[0] ] ),
				esc_html( $check[1] )
			);
		}
	}

	/**
	 * Fetch the discovery document over HTTP like an AI app would (cached for 10 minutes).
	 *
	 * @return true|string True or a problem description.
	 */
	private static function discovery_check() {
		$cached = get_transient( 'aisb_discovery_check' );
		if ( false !== $cached ) {
			return 'ok' === $cached ? true : $cached;
		}

		$url      = home_url( '/.well-known/oauth-protected-resource' );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'   => 8,
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core filter.
			)
		);
		$body     = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ), true );

		if ( is_wp_error( $response ) ) {
			/* translators: %s: error message */
			$result = sprintf( __( 'Could not check the connector endpoints from the server itself (%s). They may still work from outside.', 'ai-site-bridge' ), $response->get_error_message() );
		} elseif ( ! is_array( $body ) || empty( $body['resource'] ) ) {
			/* translators: 1: URL, 2: HTTP status */
			$result = sprintf( __( '%1$s did not return the expected data (HTTP %2$s). A security plugin, firewall or server rule may be blocking /.well-known/ URLs.', 'ai-site-bridge' ), $url, wp_remote_retrieve_response_code( $response ) );
		} else {
			$result = true;
		}

		set_transient( 'aisb_discovery_check', true === $result ? 'ok' : $result, 10 * MINUTE_IN_SECONDS );
		return $result;
	}

	/**
	 * Connected apps table.
	 */
	private static function render_connections() {
		$rows = AISB_Store::connections();
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No app is connected yet.', 'ai-site-bridge' ) . '</p>';
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'App', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'User', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'Connected', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'Last used', 'ai-site-bridge' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<?php
					$user = get_userdata( (int) $row['user_id'] );
					$uris = json_decode( (string) $row['redirect_uris'], true );
					$host = is_array( $uris ) && $uris ? wp_parse_url( $uris[0], PHP_URL_HOST ) : '';
					?>
					<tr>
						<td><strong><?php echo esc_html( $row['client_name'] ? $row['client_name'] : $row['client_id'] ); ?></strong><?php echo $host ? '<br><small>' . esc_html( $host ) . '</small>' : ''; ?></td>
						<td><?php echo esc_html( $user ? $user->display_name : '#' . $row['user_id'] ); ?></td>
						<td><?php echo esc_html( self::date( (int) $row['connected_at'] ) ); ?></td>
						<td><?php echo esc_html( $row['last_used_at'] ? self::date( (int) $row['last_used_at'] ) : '—' ); ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'aisb_disconnect' ); ?>
								<input type="hidden" name="action" value="aisb_disconnect">
								<input type="hidden" name="client_id" value="<?php echo esc_attr( $row['client_id'] ); ?>">
								<input type="hidden" name="user_id" value="<?php echo esc_attr( $row['user_id'] ); ?>">
								<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Disconnect', 'ai-site-bridge' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Settings tab.
	 */
	private static function render_settings() {
		$settings = AISB_Settings::all();
		$name     = AISB_Settings::OPTION;
		?>
		<form method="post" action="options.php">
			<?php settings_fields( 'aisb_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Connections', 'ai-site-bridge' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" value="1" <?php checked( $settings['enabled'] ); ?>>
							<?php esc_html_e( 'Allow AI apps to connect and make changes', 'ai-site-bridge' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Turning this off blocks every connected app immediately.', 'ai-site-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aisb-role"><?php esc_html_e( 'Who can connect', 'ai-site-bridge' ); ?></label></th>
					<td>
						<select id="aisb-role" name="<?php echo esc_attr( $name ); ?>[connect_role]">
							<?php foreach ( AISB_Settings::connect_roles() as $key => $role ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $settings['connect_role'], $key ); ?>><?php echo esc_html( $role[0] ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'The app always acts as the user who approved it, so it can never do more than that user can do in the dashboard.', 'ai-site-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'What the AI can do', 'ai-site-bridge' ); ?></th>
					<td class="aisb-groups">
						<?php
						$dangerous = AISB_Settings::dangerous_groups();
						foreach ( AISB_Settings::groups() as $key => $group ) :
							?>
							<label class="<?php echo in_array( $key, $dangerous, true ) ? 'aisb-danger' : ''; ?>">
								<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[groups][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, (array) $settings['groups'], true ) ); ?>>
								<?php echo esc_html( $group[0] ); ?>
								<small><?php echo esc_html( $group[1] ); ?></small>
							</label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="aisb-hosts"><?php esc_html_e( 'Allowed apps', 'ai-site-bridge' ); ?></label></th>
					<td>
						<textarea id="aisb-hosts" name="<?php echo esc_attr( $name ); ?>[allowed_hosts]" rows="5" class="regular-text code"><?php echo esc_textarea( $settings['allowed_hosts'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One domain per line. Only apps that return to these domains after approval can connect (subdomains included). This stops look-alike apps from tricking an administrator into approving them. Leave empty to allow any app.', 'ai-site-bridge' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Activity tab.
	 */
	private static function render_activity() {
		$rows = AISB_Log::latest( 200 );
		?>
		<p><?php echo esc_html( sprintf( /* translators: %d: days */ __( 'Changes made through connected apps, and failed attempts, from the last %d days.', 'ai-site-bridge' ), AISB_Log::KEEP_DAYS ) ); ?></p>
		<?php if ( ! $rows ) : ?>
			<p><?php esc_html_e( 'Nothing yet.', 'ai-site-bridge' ); ?></p>
			<?php
			return;
		endif;
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'User', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'App', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'Action', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'Item', 'ai-site-bridge' ); ?></th>
					<th><?php esc_html_e( 'Details', 'ai-site-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<?php
					$user = get_userdata( (int) $row['user_id'] );
					$item = '';
					if ( $row['object_id'] && get_post( (int) $row['object_id'] ) ) {
						$link = get_edit_post_link( (int) $row['object_id'] );
						$item = $link ? '<a href="' . esc_url( $link ) . '">#' . (int) $row['object_id'] . '</a>' : '#' . (int) $row['object_id'];
					} elseif ( $row['object_id'] ) {
						$item = '#' . (int) $row['object_id'];
					}
					?>
					<tr>
						<td><?php echo esc_html( self::date( (int) $row['created_at'] ) ); ?></td>
						<td><?php echo esc_html( $user ? $user->display_name : '—' ); ?></td>
						<td><?php echo esc_html( $row['client_name'] ? $row['client_name'] : '—' ); ?></td>
						<td><code><?php echo esc_html( $row['tool'] ); ?></code></td>
						<td><?php echo wp_kses( $item, array( 'a' => array( 'href' => array() ) ) ); ?></td>
						<td>
							<?php if ( 'error' === $row['status'] ) : ?>
								<span class="aisb-bad"><?php esc_html_e( 'Failed:', 'ai-site-bridge' ); ?></span>
							<?php endif; ?>
							<?php echo esc_html( $row['summary'] ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Date in the site's format and timezone.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function date( $timestamp ) {
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	}
}
