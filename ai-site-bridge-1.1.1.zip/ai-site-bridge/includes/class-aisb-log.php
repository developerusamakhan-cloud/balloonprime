<?php
/**
 * Activity log of what the assistant changed.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Stores one row per change (and per failed call) made through the connector.
 */
class AISB_Log {

	/**
	 * Rows older than this are removed by the daily cleanup.
	 */
	const KEEP_DAYS = 90;

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'aisb_log';
	}

	/**
	 * Add a row.
	 *
	 * @param string $client_id App that made the call.
	 * @param string $tool      Tool name.
	 * @param int    $object_id Post, comment or attachment ID, when there is one.
	 * @param string $summary   Short description.
	 * @param string $status    ok or error.
	 */
	public static function add( $client_id, $tool, $object_id, $summary, $status ) {
		global $wpdb;

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::table(),
			array(
				'created_at' => time(),
				'user_id'    => get_current_user_id(),
				'client_id'  => (string) $client_id,
				'tool'       => (string) $tool,
				'object_id'  => (int) $object_id,
				'summary'    => mb_substr( (string) $summary, 0, 255 ),
				'status'     => $status,
			)
		);
	}

	/**
	 * Latest rows with the app name.
	 *
	 * @param int $limit Max rows.
	 * @return array[]
	 */
	public static function latest( $limit = 200 ) {
		global $wpdb;

		$log     = self::table();
		$clients = AISB_Store::clients_table();
		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT l.*, c.client_name FROM {$log} l LEFT JOIN {$clients} c ON c.client_id = l.client_id ORDER BY l.id DESC LIMIT %d",
				(int) $limit
			),
			ARRAY_A
		);
	}

	/**
	 * Remove old rows.
	 */
	public static function prune() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %d", time() - self::KEEP_DAYS * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
	}
}
