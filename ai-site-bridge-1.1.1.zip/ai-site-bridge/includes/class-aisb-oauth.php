<?php
/**
 * OAuth 2.1 authorization server for the connector (as required by the MCP authorization spec).
 *
 * Flow: the AI app finds the endpoints through the discovery documents, registers itself
 * (dynamic client registration), sends the user to the approval page, where they log in to
 * WordPress and approve, then swaps the code for tokens (PKCE S256 required). Tokens act as
 * the WordPress user who approved, so everything the assistant does is limited by that user's role.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Discovery, registration, approval page, token and revocation endpoints.
 */
class AISB_OAuth {

	const SCOPE         = 'site';
	const CODE_TTL      = 600;
	const ACCESS_TTL    = HOUR_IN_SECONDS;
	const REFRESH_TTL   = 60 * DAY_IN_SECONDS;
	const REFRESH_GRACE = 60;

	/**
	 * Max app registrations per IP address per hour.
	 */
	const REGISTER_LIMIT = 20;

	/**
	 * RFC 9728 protected resource metadata.
	 */
	public static function protected_resource_metadata() {
		AISB_Router::json(
			array(
				'resource'                 => AISB_Router::mcp_url(),
				'authorization_servers'    => array( AISB_Router::issuer() ),
				'scopes_supported'         => array( self::SCOPE ),
				'bearer_methods_supported' => array( 'header' ),
				'resource_name'            => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			)
		);
	}

	/**
	 * RFC 8414 authorization server metadata.
	 */
	public static function authorization_server_metadata() {
		AISB_Router::json( self::server_metadata() );
	}

	/**
	 * OpenID Connect discovery document.
	 *
	 * Clients connecting to a site in a sub-folder (issuer with a path) fall back to
	 * {issuer}/.well-known/openid-configuration, the only discovery URL a sub-folder install
	 * can answer. Their parsers require the three OpenID fields below. No ID tokens are issued
	 * (the openid scope is not offered), so the key set is empty.
	 */
	public static function openid_configuration() {
		AISB_Router::json(
			array_merge(
				self::server_metadata(),
				array(
					'jwks_uri'                              => AISB_Router::url( 'oauth/jwks' ),
					'subject_types_supported'               => array( 'public' ),
					'id_token_signing_alg_values_supported' => array( 'RS256' ),
				)
			)
		);
	}

	/**
	 * Empty JSON Web Key Set (see openid_configuration()).
	 */
	public static function jwks() {
		AISB_Router::json( array( 'keys' => array() ) );
	}

	/**
	 * Authorization server metadata fields.
	 *
	 * @return array
	 */
	private static function server_metadata() {
		$auth_methods = array( 'none', 'client_secret_post', 'client_secret_basic' );
		return array(
			'issuer'                                => AISB_Router::issuer(),
			'authorization_endpoint'                => AISB_Router::url( 'oauth/authorize' ),
			'token_endpoint'                        => AISB_Router::url( 'oauth/token' ),
			'registration_endpoint'                 => AISB_Router::url( 'oauth/register' ),
			'revocation_endpoint'                   => AISB_Router::url( 'oauth/revoke' ),
			'response_types_supported'              => array( 'code' ),
			'response_modes_supported'              => array( 'query' ),
			'grant_types_supported'                 => array( 'authorization_code', 'refresh_token' ),
			'code_challenge_methods_supported'      => array( 'S256' ),
			'token_endpoint_auth_methods_supported' => $auth_methods,
			'revocation_endpoint_auth_methods_supported' => $auth_methods,
			'scopes_supported'                      => array( self::SCOPE ),
			'authorization_response_iss_parameter_supported' => true,
		);
	}

	/**
	 * RFC 7591 dynamic client registration.
	 */
	public static function register() {
		if ( 'POST' !== AISB_Router::method() ) {
			AISB_Router::json( array( 'error' => 'invalid_request' ), 405, array( 'Allow' => 'POST' ) );
		}
		if ( ! AISB_Settings::enabled() ) {
			self::error( 'access_denied', __( 'Connections are turned off on this site.', 'ai-site-bridge' ), 403 );
		}

		$ip_key = 'aisb_reg_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' );
		$count  = (int) get_transient( $ip_key );
		if ( $count >= self::REGISTER_LIMIT ) {
			self::error( 'temporarily_unavailable', __( 'Too many registrations. Try again later.', 'ai-site-bridge' ), 429 );
		}
		set_transient( $ip_key, $count + 1, HOUR_IN_SECONDS );

		$body = AISB_Router::body();
		if ( null === $body ) {
			self::error( 'invalid_client_metadata', 'Request body must be JSON.' );
		}

		$uris = isset( $body['redirect_uris'] ) ? (array) $body['redirect_uris'] : array();
		if ( ! $uris ) {
			self::error( 'invalid_redirect_uri', 'At least one redirect_uri is required.' );
		}
		foreach ( $uris as $uri ) {
			if ( ! is_string( $uri ) || ! self::valid_redirect_uri( $uri ) ) {
				self::error( 'invalid_redirect_uri', 'Redirect URIs must use https (http only for localhost), or an app scheme.' );
			}
		}

		$method = isset( $body['token_endpoint_auth_method'] ) ? (string) $body['token_endpoint_auth_method'] : 'client_secret_basic';
		if ( ! in_array( $method, array( 'none', 'client_secret_post', 'client_secret_basic' ), true ) ) {
			self::error( 'invalid_client_metadata', 'Unsupported token_endpoint_auth_method.' );
		}

		$name = isset( $body['client_name'] ) && is_string( $body['client_name'] ) ? sanitize_text_field( $body['client_name'] ) : '';
		if ( '' === $name ) {
			$name = (string) wp_parse_url( $uris[0], PHP_URL_HOST );
		}
		$name = mb_substr( $name, 0, 100 );

		$client = AISB_Store::create_client( $name, $uris, $method );

		$response = array(
			'client_id'                  => $client['client_id'],
			'client_id_issued_at'        => $client['created_at'],
			'client_name'                => $name,
			'redirect_uris'              => array_values( $uris ),
			'grant_types'                => array( 'authorization_code', 'refresh_token' ),
			'response_types'             => array( 'code' ),
			'token_endpoint_auth_method' => $method,
			'scope'                      => self::SCOPE,
		);
		if ( '' !== $client['client_secret'] ) {
			$response['client_secret']            = $client['client_secret'];
			$response['client_secret_expires_at'] = 0;
		}
		AISB_Router::json( $response, 201 );
	}

	/**
	 * Approval page: log in, review and approve or deny the connection.
	 */
	public static function authorize() {
		header( 'X-Frame-Options: DENY' );
		header( "Content-Security-Policy: frame-ancestors 'none'" );

		$post   = 'POST' === AISB_Router::method();
		$source = $post ? wp_unslash( $_POST ) : wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification
		$param  = static function ( $key ) use ( $source ) {
			return isset( $source[ $key ] ) && is_string( $source[ $key ] ) ? $source[ $key ] : '';
		};

		$req = array(
			'response_type'         => $param( 'response_type' ),
			'client_id'             => $param( 'client_id' ),
			'redirect_uri'          => $param( 'redirect_uri' ),
			'state'                 => $param( 'state' ),
			'scope'                 => $param( 'scope' ),
			'code_challenge'        => $param( 'code_challenge' ),
			'code_challenge_method' => $param( 'code_challenge_method' ),
			'resource'              => $param( 'resource' ),
		);

		// Problems with the app itself are shown here: the redirect URI can't be trusted yet.
		$client = AISB_Store::get_client( $req['client_id'] );
		if ( ! $client ) {
			self::page_error( __( 'This app is not registered with this site (or its registration expired). Remove the connector in your AI app and add it again.', 'ai-site-bridge' ) );
		}
		if ( '' === $req['redirect_uri'] && 1 === count( $client['redirect_uris'] ) ) {
			$req['redirect_uri'] = $client['redirect_uris'][0];
		}
		if ( ! in_array( $req['redirect_uri'], $client['redirect_uris'], true ) ) {
			self::page_error( __( 'The app sent an unknown return address. Remove the connector in your AI app and add it again.', 'ai-site-bridge' ) );
		}
		$host = strtolower( (string) wp_parse_url( $req['redirect_uri'], PHP_URL_HOST ) );
		if ( ! self::host_allowed( $host ) ) {
			self::page_error(
				sprintf(
					/* translators: %s: host name */
					__( 'Apps that return to %s are not allowed to connect. An administrator can add it under AI Site Bridge → Settings → Allowed apps.', 'ai-site-bridge' ),
					'<strong>' . esc_html( $host ) . '</strong>'
				)
			);
		}
		if ( ! AISB_Settings::enabled() ) {
			self::page_error( __( 'Connections are turned off on this site. An administrator can turn them on under AI Site Bridge → Settings.', 'ai-site-bridge' ) );
		}

		// From here on, errors go back to the app.
		if ( 'code' !== $req['response_type'] ) {
			self::redirect_error( $req, 'unsupported_response_type', 'Only response_type=code is supported.' );
		}
		if ( '' === $req['code_challenge'] || 'S256' !== $req['code_challenge_method'] ) {
			self::redirect_error( $req, 'invalid_request', 'PKCE with code_challenge_method=S256 is required.' );
		}

		$here = add_query_arg( array_map( 'rawurlencode', array_filter( $req, 'strlen' ) ), AISB_Router::url( 'oauth/authorize' ) );

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $here ) );
			exit;
		}

		$user = wp_get_current_user();
		if ( ! user_can( $user, AISB_Settings::connect_capability() ) ) {
			self::page_error(
				__( 'Your account is not allowed to connect AI apps to this site. Ask an administrator, or log in with another account.', 'ai-site-bridge' ),
				wp_logout_url( $here )
			);
		}

		if ( ! $post ) {
			self::consent_page( $client, $req, $user, $host );
		}

		if ( ! isset( $_POST['_aisb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_aisb_nonce'] ) ), 'aisb_authorize_' . $client['client_id'] ) ) {
			self::page_error( __( 'This approval page expired. Start the connection again from your AI app.', 'ai-site-bridge' ) );
		}
		if ( empty( $_POST['approve'] ) ) {
			self::redirect_error( $req, 'access_denied', 'The user denied the request.' );
		}

		$code = AISB_Store::issue(
			'code',
			$client['client_id'],
			$user->ID,
			self::CODE_TTL,
			array(
				'redirect_uri'   => $req['redirect_uri'],
				'code_challenge' => $req['code_challenge'],
				'resource'       => $req['resource'],
			)
		);
		AISB_Store::touch_client( $client );

		self::redirect(
			$req['redirect_uri'],
			array(
				'code'  => $code,
				'state' => $req['state'],
				'iss'   => AISB_Router::issuer(),
			)
		);
	}

	/**
	 * Token endpoint: authorization_code and refresh_token grants.
	 */
	public static function token() {
		header( 'Pragma: no-cache' );
		if ( 'POST' !== AISB_Router::method() ) {
			AISB_Router::json( array( 'error' => 'invalid_request' ), 405, array( 'Allow' => 'POST' ) );
		}

		$body   = (array) AISB_Router::body();
		$client = self::authenticate_client( $body );
		$grant  = isset( $body['grant_type'] ) ? (string) $body['grant_type'] : '';

		if ( 'authorization_code' === $grant ) {
			$code = AISB_Store::find( isset( $body['code'] ) ? (string) $body['code'] : '', 'code' );
			if ( ! $code || $code['client_id'] !== $client['client_id'] || ! AISB_Store::delete( $code['id'] ) ) {
				self::error( 'invalid_grant', 'The authorization code is invalid, expired or already used.' );
			}
			$redirect_uri = isset( $body['redirect_uri'] ) ? (string) $body['redirect_uri'] : '';
			if ( '' !== $redirect_uri && $redirect_uri !== $code['data']['redirect_uri'] ) {
				self::error( 'invalid_grant', 'redirect_uri does not match the authorization request.' );
			}
			$verifier = isset( $body['code_verifier'] ) ? (string) $body['code_verifier'] : '';
			if ( ! preg_match( '/^[A-Za-z0-9\-._~]{43,128}$/', $verifier ) || ! hash_equals( (string) $code['data']['code_challenge'], self::pkce_challenge( $verifier ) ) ) {
				self::error( 'invalid_grant', 'PKCE verification failed.' );
			}
			self::issue_tokens( $client, (int) $code['user_id'], (string) $code['data']['resource'] );
		}

		if ( 'refresh_token' === $grant ) {
			$refresh = AISB_Store::find( isset( $body['refresh_token'] ) ? (string) $body['refresh_token'] : '', 'refresh' );
			if ( ! $refresh || $refresh['client_id'] !== $client['client_id'] ) {
				self::error( 'invalid_grant', 'The refresh token is invalid or expired.' );
			}
			// Rotate: the old refresh token keeps working for a minute in case of parallel requests.
			AISB_Store::expire_in( $refresh, self::REFRESH_GRACE );
			self::issue_tokens( $client, (int) $refresh['user_id'], isset( $refresh['data']['resource'] ) ? (string) $refresh['data']['resource'] : '' );
		}

		self::error( 'unsupported_grant_type', 'Supported grant types: authorization_code, refresh_token.' );
	}

	/**
	 * RFC 7009 token revocation.
	 */
	public static function revoke() {
		if ( 'POST' !== AISB_Router::method() ) {
			AISB_Router::json( array( 'error' => 'invalid_request' ), 405, array( 'Allow' => 'POST' ) );
		}
		$body   = (array) AISB_Router::body();
		$client = self::authenticate_client( $body );
		$value  = isset( $body['token'] ) ? (string) $body['token'] : '';
		foreach ( array( 'access', 'refresh' ) as $type ) {
			$row = AISB_Store::find( $value, $type );
			if ( $row && $row['client_id'] === $client['client_id'] ) {
				AISB_Store::delete( $row['id'] );
			}
		}
		AISB_Router::json( (object) array() );
	}

	/**
	 * Validate the Bearer token of an MCP request.
	 *
	 * @return array|WP_Error Token row (with `client`) or error code `invalid_token` / `no_token`.
	 */
	public static function authenticate_bearer() {
		$header = AISB_Router::authorization_header();
		if ( ! preg_match( '/^Bearer\s+(\S+)$/i', $header, $m ) ) {
			return new WP_Error( 'no_token' );
		}
		$token = AISB_Store::find( $m[1], 'access' );
		if ( ! $token ) {
			return new WP_Error( 'invalid_token', __( 'The access token is invalid or expired.', 'ai-site-bridge' ) );
		}
		$client = AISB_Store::get_client( $token['client_id'] );
		$user   = get_userdata( (int) $token['user_id'] );
		if ( ! $client || ! $user || ! user_can( $user, AISB_Settings::connect_capability() ) ) {
			return new WP_Error( 'invalid_token', __( 'This connection is no longer allowed. Connect again.', 'ai-site-bridge' ) );
		}
		AISB_Store::touch_client( $client );
		$token['client'] = $client;
		return $token;
	}

	/**
	 * WWW-Authenticate header value for 401 responses, pointing at the discovery document.
	 *
	 * @param string $error Optional RFC 6750 error code.
	 * @return string
	 */
	public static function www_authenticate( $error = '' ) {
		$value = sprintf(
			'Bearer realm="%s", resource_metadata="%s"',
			esc_attr( AISB_Router::issuer() ),
			esc_url_raw( home_url( '/.well-known/oauth-protected-resource/' . AISB_Router::PREFIX . '/mcp' ) )
		);
		if ( $error ) {
			$value .= sprintf( ', error="%s"', $error );
		}
		return $value;
	}

	/**
	 * Issue an access + refresh token pair and send the token response.
	 *
	 * @param array  $client   Client row.
	 * @param int    $user_id  User ID.
	 * @param string $resource Resource the tokens are for.
	 */
	private static function issue_tokens( $client, $user_id, $resource ) {
		$user = get_userdata( $user_id );
		if ( ! $user || ! user_can( $user, AISB_Settings::connect_capability() ) ) {
			self::error( 'invalid_grant', 'This user can no longer connect AI apps.' );
		}
		$data    = array( 'resource' => $resource );
		$access  = AISB_Store::issue( 'access', $client['client_id'], $user_id, self::ACCESS_TTL, $data );
		$refresh = AISB_Store::issue( 'refresh', $client['client_id'], $user_id, self::REFRESH_TTL, $data );
		AISB_Store::touch_client( $client );

		AISB_Router::json(
			array(
				'access_token'  => $access,
				'token_type'    => 'Bearer',
				'expires_in'    => self::ACCESS_TTL,
				'refresh_token' => $refresh,
				'scope'         => self::SCOPE,
			),
			200,
			array( 'Cache-Control' => 'no-store' )
		);
	}

	/**
	 * Identify (and for confidential apps authenticate) the calling app.
	 *
	 * @param array $body Request body.
	 * @return array Client row.
	 */
	private static function authenticate_client( $body ) {
		$id     = isset( $body['client_id'] ) ? (string) $body['client_id'] : '';
		$secret = isset( $body['client_secret'] ) ? (string) $body['client_secret'] : '';

		if ( preg_match( '/^Basic\s+(\S+)$/i', AISB_Router::authorization_header(), $m ) ) {
			$pair = explode( ':', (string) base64_decode( $m[1] ), 2 ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( 2 === count( $pair ) ) {
				$id     = urldecode( $pair[0] );
				$secret = urldecode( $pair[1] );
			}
		}

		$client = AISB_Store::get_client( $id );
		if ( ! $client ) {
			self::error( 'invalid_client', 'Unknown client.', 401 );
		}
		if ( 'none' !== $client['auth_method'] && ! hash_equals( $client['secret_hash'], AISB_Store::hash( $secret ) ) ) {
			self::error( 'invalid_client', 'Client authentication failed.', 401 );
		}
		return $client;
	}

	/**
	 * Whether a redirect URI is acceptable for registration.
	 *
	 * @param string $uri URI.
	 * @return bool
	 */
	private static function valid_redirect_uri( $uri ) {
		$parts = wp_parse_url( $uri );
		if ( ! $parts || empty( $parts['scheme'] ) || isset( $parts['fragment'] ) ) {
			return false;
		}
		$scheme = strtolower( $parts['scheme'] );
		$host   = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
		if ( 'https' === $scheme ) {
			return '' !== $host;
		}
		if ( 'http' === $scheme ) {
			return in_array( $host, array( 'localhost', '127.0.0.1', '[::1]' ), true );
		}
		// Private-use schemes of desktop apps (RFC 8252), but nothing a browser would run.
		return (bool) preg_match( '/^[a-z][a-z0-9+.-]*$/', $scheme ) && ! in_array( $scheme, array( 'javascript', 'data', 'file', 'vbscript', 'blob', 'about' ), true );
	}

	/**
	 * Whether the allowed-apps setting lets this host receive codes.
	 *
	 * @param string $host Redirect URI host.
	 * @return bool
	 */
	private static function host_allowed( $host ) {
		$allowed = AISB_Settings::allowed_hosts();
		if ( ! $allowed ) {
			return true;
		}
		$host = trim( $host, '[]' );
		foreach ( $allowed as $entry ) {
			if ( $host === $entry || substr( $host, -strlen( '.' . $entry ) ) === '.' . $entry ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * S256 PKCE challenge for a verifier.
	 *
	 * @param string $verifier Code verifier.
	 * @return string
	 */
	private static function pkce_challenge( $verifier ) {
		return rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' );
	}

	/**
	 * Send an OAuth error response.
	 *
	 * @param string $code        Error code.
	 * @param string $description Description.
	 * @param int    $status      HTTP status.
	 */
	private static function error( $code, $description, $status = 400 ) {
		$headers = array( 'Cache-Control' => 'no-store' );
		if ( 401 === $status ) {
			$headers['WWW-Authenticate'] = 'Basic realm="' . esc_attr( AISB_Router::issuer() ) . '"';
		}
		AISB_Router::json(
			array(
				'error'             => $code,
				'error_description' => $description,
			),
			$status,
			$headers
		);
	}

	/**
	 * Send the user back to the app with query parameters.
	 *
	 * @param string $uri    Registered redirect URI.
	 * @param array  $params Parameters.
	 */
	private static function redirect( $uri, $params ) {
		$params = array_filter( $params, 'strlen' );
		$url    = $uri . ( false === strpos( $uri, '?' ) ? '?' : '&' ) . http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );
		header( 'Location: ' . $url, true, 302 );
		exit;
	}

	/**
	 * Send the user back to the app with an OAuth error.
	 *
	 * @param array  $req         Authorization request.
	 * @param string $code        Error code.
	 * @param string $description Description.
	 */
	private static function redirect_error( $req, $code, $description ) {
		self::redirect(
			$req['redirect_uri'],
			array(
				'error'             => $code,
				'error_description' => $description,
				'state'             => $req['state'],
				'iss'               => AISB_Router::issuer(),
			)
		);
	}

	/**
	 * Approval page.
	 *
	 * @param array   $client Client row.
	 * @param array   $req    Authorization request.
	 * @param WP_User $user   Current user.
	 * @param string  $host   Host the user returns to.
	 */
	private static function consent_page( $client, $req, $user, $host ) {
		$groups = array();
		foreach ( AISB_Settings::groups() as $key => $group ) {
			if ( AISB_Settings::group_enabled( $key ) ) {
				$groups[] = $group;
			}
		}
		$action     = AISB_Router::url( 'oauth/authorize' );
		$switch_url = wp_logout_url( add_query_arg( array_map( 'rawurlencode', array_filter( $req, 'strlen' ) ), $action ) );
		$nonce      = wp_create_nonce( 'aisb_authorize_' . $client['client_id'] );

		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		include AISB_PATH . 'templates/consent.php';
		exit;
	}

	/**
	 * Error page shown in the browser.
	 *
	 * @param string $message    Message (may contain markup from this plugin).
	 * @param string $switch_url Optional "log in with another account" link.
	 */
	private static function page_error( $message, $switch_url = '' ) {
		status_header( 400 );
		header( 'Content-Type: text/html; charset=utf-8' );
		$error = $message;
		include AISB_PATH . 'templates/consent.php';
		exit;
	}
}
