<?php
/**
 * Storage for registered apps, authorization codes and tokens.
 *
 * Secrets are never stored: only their SHA-256 hashes.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * DB access for the clients and tokens tables.
 */
class AISB_Store {

	/**
	 * Apps that registered but never connected are removed after this long.
	 */
	const ABANDONED_CLIENT_TTL = WEEK_IN_SECONDS;

	/**
	 * Clients table name.
	 *
	 * @return string
	 */
	public static function clients_table() {
		global $wpdb;
		return $wpdb->prefix . 'aisb_clients';
	}

	/**
	 * Tokens table name.
	 *
	 * @return string
	 */
	public static function tokens_table() {
		global $wpdb;
		return $wpdb->prefix . 'aisb_tokens';
	}

	/**
	 * A new random secret.
	 *
	 * @param int $bytes Number of random bytes.
	 * @return string Hex string.
	 */
	public static function random( $bytes = 32 ) {
		return bin2hex( random_bytes( $bytes ) );
	}

	/**
	 * Hash used to store and look up secrets.
	 *
	 * @param string $secret Secret.
	 * @return string
	 */
	public static function hash( $secret ) {
		return hash( 'sha256', (string) $secret );
	}

	/**
	 * Register an app (OAuth client).
	 *
	 * @param string   $name          App name.
	 * @param string[] $redirect_uris Allowed redirect URIs.
	 * @param string   $auth_method   Token endpoint auth method.
	 * @return array Client row plus `client_secret` when one was issued.
	 */
	public static function create_client( $name, $redirect_uris, $auth_method ) {
		global $wpdb;

		$client_id = 'aisb_' . self::random( 16 );
		$secret    = 'none' === $auth_method ? '' : self::random( 32 );
		$row       = array(
			'client_id'     => $client_id,
			'secret_hash'   => '' === $secret ? '' : self::hash( $secret ),
			'auth_method'   => $auth_method,
			'client_name'   => $name,
			'redirect_uris' => wp_json_encode( array_values( $redirect_uris ) ),
			'created_at'    => time(),
			'last_used_at'  => 0,
		);
		$wpdb->insert( self::clients_table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$row['client_secret'] = $secret;
		return $row;
	}

	/**
	 * Look up an app.
	 *
	 * @param string $client_id Client ID.
	 * @return array|null Row with decoded `redirect_uris`.
	 */
	public static function get_client( $client_id ) {
		global $wpdb;

		if ( ! is_string( $client_id ) || '' === $client_id ) {
			return null;
		}
		$table = self::clients_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE client_id = %s", $client_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			return null;
		}
		$uris                 = json_decode( $row['redirect_uris'], true );
		$row['redirect_uris'] = is_array( $uris ) ? $uris : array();
		return $row;
	}

	/**
	 * Remember when an app was last used (at most every few minutes).
	 *
	 * @param array $client Client row.
	 */
	public static function touch_client( $client ) {
		global $wpdb;

		if ( (int) $client['last_used_at'] > time() - 5 * MINUTE_IN_SECONDS ) {
			return;
		}
		$wpdb->update( self::clients_table(), array( 'last_used_at' => time() ), array( 'client_id' => $client['client_id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Store a code or token and return the plain value.
	 *
	 * @param string $type      code, access or refresh.
	 * @param string $client_id Client ID.
	 * @param int    $user_id   User the token acts as.
	 * @param int    $ttl       Lifetime in seconds.
	 * @param array  $data      Extra data (redirect URI, PKCE challenge…).
	 * @return string
	 */
	public static function issue( $type, $client_id, $user_id, $ttl, $data = array() ) {
		global $wpdb;

		$value = self::random( 32 );
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::tokens_table(),
			array(
				'token_hash' => self::hash( $value ),
				'type'       => $type,
				'client_id'  => $client_id,
				'user_id'    => (int) $user_id,
				'data'       => wp_json_encode( $data ),
				'created_at' => time(),
				'expires_at' => time() + (int) $ttl,
			)
		);
		return $value;
	}

	/**
	 * Find a live code or token by its plain value.
	 *
	 * @param string $value Plain value.
	 * @param string $type  Expected type.
	 * @return array|null Row with decoded `data`.
	 */
	public static function find( $value, $type ) {
		global $wpdb;

		if ( ! is_string( $value ) || '' === $value ) {
			return null;
		}
		$table = self::tokens_table();
		$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE token_hash = %s AND type = %s AND expires_at > %d", self::hash( $value ), $type, time() ),
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		$data        = json_decode( (string) $row['data'], true );
		$row['data'] = is_array( $data ) ? $data : array();
		return $row;
	}

	/**
	 * Delete one code or token by row ID.
	 *
	 * @param int $id Row ID.
	 * @return bool Whether a row was deleted (false when another request used it first).
	 */
	public static function delete( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( self::tokens_table(), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Shorten the life of a token (used to give a rotated refresh token a short grace period).
	 *
	 * @param array $row     Token row.
	 * @param int   $seconds Seconds from now.
	 */
	public static function expire_in( $row, $seconds ) {
		global $wpdb;

		$expires = time() + (int) $seconds;
		if ( (int) $row['expires_at'] > $expires ) {
			$wpdb->update( self::tokens_table(), array( 'expires_at' => $expires ), array( 'id' => (int) $row['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		}
	}

	/**
	 * Revoke everything an app holds for a user (disconnect).
	 *
	 * @param string $client_id Client ID.
	 * @param int    $user_id   User ID, or 0 for every user.
	 */
	public static function revoke( $client_id, $user_id = 0 ) {
		global $wpdb;

		$where = array( 'client_id' => $client_id );
		if ( $user_id ) {
			$where['user_id'] = (int) $user_id;
		}
		$wpdb->delete( self::tokens_table(), $where ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Apps that currently hold a token, one row per app and user.
	 *
	 * @return array[]
	 */
	public static function connections() {
		global $wpdb;

		$tokens  = self::tokens_table();
		$clients = self::clients_table();
		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT t.client_id, t.user_id, MIN(t.created_at) AS connected_at, c.client_name, c.redirect_uris, c.last_used_at
				FROM {$tokens} t LEFT JOIN {$clients} c ON c.client_id = t.client_id
				WHERE t.type IN ('access','refresh') AND t.expires_at > %d
				GROUP BY t.client_id, t.user_id, c.client_name, c.redirect_uris, c.last_used_at
				ORDER BY connected_at DESC",
				time()
			),
			ARRAY_A
		);
	}

	/**
	 * Remove expired codes and tokens and apps that never finished connecting.
	 */
	public static function delete_expired() {
		global $wpdb;

		$tokens  = self::tokens_table();
		$clients = self::clients_table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$tokens} WHERE expires_at <= %d", time() ) ); // phpcs:ignore WordPress.DB
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"DELETE FROM {$clients} WHERE last_used_at = 0 AND created_at < %d AND client_id NOT IN (SELECT client_id FROM {$tokens})",
				time() - self::ABANDONED_CLIENT_TTL
			)
		);
	}
}
