<?php
/**
 * Plugin settings access.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads and normalises the single `aisb_settings` option.
 */
class AISB_Settings {

	const OPTION = 'aisb_settings';

	/**
	 * Default values for every setting.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'       => 1,
			'connect_role'  => 'administrator',
			'groups'        => array_values( array_diff( array_keys( self::groups() ), self::dangerous_groups() ) ),
			'allowed_hosts' => "claude.ai\nclaude.com\nlocalhost\n127.0.0.1",
		);
	}

	/**
	 * What the assistant may do, grouped so the site owner can switch each part off.
	 *
	 * @return array Group key => array( label, description ).
	 */
	public static function groups() {
		return array(
			'read'     => array(
				__( 'Read content', 'ai-site-bridge' ),
				__( 'List and read posts, pages, categories, tags, media, comments and site details.', 'ai-site-bridge' ),
			),
			'write'    => array(
				__( 'Create and edit content', 'ai-site-bridge' ),
				__( 'Create and edit posts and pages (drafts or published), categories and tags, and restore items from the trash.', 'ai-site-bridge' ),
			),
			'delete'   => array(
				__( 'Delete content', 'ai-site-bridge' ),
				__( 'Move posts and pages to the trash, or delete them permanently when asked.', 'ai-site-bridge' ),
			),
			'media'    => array(
				__( 'Media library', 'ai-site-bridge' ),
				__( 'Upload images from a link, set featured images and edit alt text and captions.', 'ai-site-bridge' ),
			),
			'comments' => array(
				__( 'Comments', 'ai-site-bridge' ),
				__( 'Approve, unapprove, spam or trash comments and reply to them.', 'ai-site-bridge' ),
			),
			'site'     => array(
				__( 'Site settings', 'ai-site-bridge' ),
				__( 'Change the site title, tagline and homepage settings.', 'ai-site-bridge' ),
			),
			'design'   => array(
				__( 'Design (CSS, menus, Elementor)', 'ai-site-bridge' ),
				__( 'Change custom CSS, navigation menus and the text of Elementor pages. Does not touch code files.', 'ai-site-bridge' ),
			),
			'code'     => array(
				__( 'Themes, plugins & code (advanced)', 'ai-site-bridge' ),
				__( 'Read and edit theme and plugin files, create new themes and plugins, and install, update, activate or delete plugins and themes. Administrators only. Changes are backed up and rolled back if they break the site. Leave off unless you want the assistant to build and change code.', 'ai-site-bridge' ),
			),
		);
	}

	/**
	 * Groups that are off unless the site owner turns them on.
	 *
	 * @return string[]
	 */
	public static function dangerous_groups() {
		return array( 'code' );
	}

	/**
	 * Roles that may connect an assistant, mapped to the capability that is checked.
	 *
	 * @return array Role key => array( label, capability ).
	 */
	public static function connect_roles() {
		return array(
			'administrator' => array( __( 'Administrators only', 'ai-site-bridge' ), 'manage_options' ),
			'editor'        => array( __( 'Editors and administrators', 'ai-site-bridge' ), 'edit_others_posts' ),
			'author'        => array( __( 'Authors, editors and administrators', 'ai-site-bridge' ), 'publish_posts' ),
		);
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * One setting.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Whether connections are switched on.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) self::get( 'enabled' );
	}

	/**
	 * Whether a tool group is switched on.
	 *
	 * @param string $group Group key.
	 * @return bool
	 */
	public static function group_enabled( $group ) {
		return in_array( $group, (array) self::get( 'groups' ), true );
	}

	/**
	 * Capability a user needs to connect an assistant and keep using it.
	 *
	 * @return string
	 */
	public static function connect_capability() {
		$roles = self::connect_roles();
		$role  = self::get( 'connect_role' );
		return isset( $roles[ $role ] ) ? $roles[ $role ][1] : 'manage_options';
	}

	/**
	 * Host names an assistant may send the user back to after approving. Empty means any.
	 *
	 * @return string[]
	 */
	public static function allowed_hosts() {
		$hosts = preg_split( '/[\s,]+/', strtolower( (string) self::get( 'allowed_hosts' ) ) );
		return array_values( array_filter( array_map( 'trim', $hosts ) ) );
	}

	/**
	 * Sanitize callback for the settings form.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$out   = array();

		$out['enabled'] = empty( $input['enabled'] ) ? 0 : 1;

		$role                = isset( $input['connect_role'] ) ? sanitize_key( $input['connect_role'] ) : '';
		$out['connect_role'] = array_key_exists( $role, self::connect_roles() ) ? $role : 'administrator';

		$groups        = isset( $input['groups'] ) ? array_map( 'sanitize_key', (array) $input['groups'] ) : array();
		$out['groups'] = array_values( array_intersect( array_keys( self::groups() ), $groups ) );

		$hosts = isset( $input['allowed_hosts'] ) ? preg_split( '/[\s,]+/', strtolower( (string) $input['allowed_hosts'] ) ) : array();
		$clean = array();
		foreach ( $hosts as $host ) {
			$host = preg_replace( '#^[a-z][a-z0-9+.-]*://#', '', trim( $host ) );
			$host = preg_replace( '#[/:].*$#', '', $host );
			if ( '' !== $host && preg_match( '/^[a-z0-9.-]+$/', $host ) ) {
				$clean[] = $host;
			}
		}
		$out['allowed_hosts'] = implode( "\n", array_unique( $clean ) );

		return $out;
	}
}
