<?php
/**
 * MCP server endpoint (Streamable HTTP transport, JSON responses, stateless).
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles JSON-RPC messages from the AI app.
 */
class AISB_MCP {

	/**
	 * Protocol versions this server speaks, newest first.
	 */
	const PROTOCOL_VERSIONS = array( '2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05' );

	/**
	 * Client ID of the app making the current request (for the activity log).
	 *
	 * @var string
	 */
	public static $client_id = '';

	/**
	 * Entry point for /ai-site-bridge/mcp.
	 */
	public static function handle() {
		$method = AISB_Router::method();
		if ( 'POST' !== $method ) {
			// No server-to-client stream and no sessions: everything is a plain POST.
			AISB_Router::json( array( 'error' => 'Method not allowed. Send JSON-RPC messages with POST.' ), 405, array( 'Allow' => 'POST' ) );
		}

		$token = AISB_OAuth::authenticate_bearer();
		if ( is_wp_error( $token ) ) {
			$code = $token->get_error_code();
			AISB_Router::json(
				array(
					'error'             => 'no_token' === $code ? 'unauthorized' : 'invalid_token',
					'error_description' => 'no_token' === $code ? 'Authorization required.' : $token->get_error_message(),
				),
				401,
				array( 'WWW-Authenticate' => AISB_OAuth::www_authenticate( 'no_token' === $code ? '' : 'invalid_token' ) )
			);
		}
		if ( ! AISB_Settings::enabled() ) {
			AISB_Router::json( self::error_response( null, -32000, __( 'Connections are turned off on this site.', 'ai-site-bridge' ) ), 403 );
		}

		wp_set_current_user( (int) $token['user_id'] );
		self::$client_id = $token['client_id'];

		$raw     = (string) file_get_contents( 'php://input' );
		$message = json_decode( $raw, true );
		if ( null === $message && 'null' !== trim( $raw ) ) {
			AISB_Router::json( self::error_response( null, -32700, 'Parse error' ), 400 );
		}

		if ( is_array( $message ) && array_keys( $message ) === range( 0, count( $message ) - 1 ) && $message ) {
			$responses = array();
			foreach ( $message as $item ) {
				$response = self::dispatch( $item );
				if ( null !== $response ) {
					$responses[] = $response;
				}
			}
			self::respond( $responses ? $responses : null );
		}

		self::respond( self::dispatch( $message ) );
	}

	/**
	 * Send the response, or 202 Accepted when the message needed none.
	 *
	 * @param array|null $response Response.
	 */
	private static function respond( $response ) {
		if ( null === $response ) {
			status_header( 202 );
			exit;
		}
		AISB_Router::json( $response );
	}

	/**
	 * Handle one JSON-RPC message.
	 *
	 * @param mixed $message Decoded message.
	 * @return array|null Response, or null for notifications and responses.
	 */
	private static function dispatch( $message ) {
		if ( ! is_array( $message ) || ! isset( $message['jsonrpc'] ) || '2.0' !== $message['jsonrpc'] ) {
			return self::error_response( null, -32600, 'Invalid Request' );
		}
		if ( ! isset( $message['method'] ) ) {
			return null; // A response to a server request; we never send any.
		}
		if ( ! array_key_exists( 'id', $message ) ) {
			return null; // Notification (initialized, cancelled…).
		}

		$id     = $message['id'];
		$params = isset( $message['params'] ) && is_array( $message['params'] ) ? $message['params'] : array();

		switch ( $message['method'] ) {
			case 'initialize':
				return self::result( $id, self::initialize( $params ) );
			case 'ping':
				return self::result( $id, (object) array() );
			case 'tools/list':
				return self::result( $id, array( 'tools' => AISB_Tools::definitions() ) );
			case 'tools/call':
				$name = isset( $params['name'] ) && is_string( $params['name'] ) ? $params['name'] : '';
				if ( ! AISB_Tools::exists( $name ) ) {
					return self::error_response( $id, -32602, 'Unknown tool: ' . $name );
				}
				$args = isset( $params['arguments'] ) && is_array( $params['arguments'] ) ? $params['arguments'] : array();
				return self::result( $id, AISB_Tools::call( $name, $args ) );
			case 'resources/list':
				return self::result( $id, array( 'resources' => array() ) );
			case 'resources/templates/list':
				return self::result( $id, array( 'resourceTemplates' => array() ) );
			case 'prompts/list':
				return self::result( $id, array( 'prompts' => array() ) );
			case 'logging/setLevel':
				return self::result( $id, (object) array() );
		}
		return self::error_response( $id, -32601, 'Method not found: ' . ( is_string( $message['method'] ) ? $message['method'] : '' ) );
	}

	/**
	 * Result of the initialize request.
	 *
	 * @param array $params Request params.
	 * @return array
	 */
	private static function initialize( $params ) {
		$requested = isset( $params['protocolVersion'] ) ? (string) $params['protocolVersion'] : '';
		$version   = in_array( $requested, self::PROTOCOL_VERSIONS, true ) ? $requested : self::PROTOCOL_VERSIONS[0];
		$site      = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		return array(
			'protocolVersion' => $version,
			'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
			'serverInfo'      => array(
				'name'    => 'ai-site-bridge',
				'title'   => 'AI Site Bridge',
				'version' => AISB_VERSION,
			),
			'instructions'    => sprintf(
				'These tools manage the live WordPress site "%1$s" (%2$s) as the user %3$s. Changes are visible to visitors once published. '
				. 'Start with get_site_info; it lists the content types, active theme and page builders, and which action groups are enabled. '
				. 'Content: create new posts and pages as drafts unless the user asks to publish; read an item with get_content before editing and keep its existing block markup. '
				. 'Page builders: for an Elementor page use get_elementor / update_elementor (text only); get_content and update_content will not change what Elementor, Divi or other builders show. '
				. 'Design: prefer update_custom_css for colours, spacing and fonts (it never breaks the site); use update_menu for navigation. '
				. 'Themes, plugins and code (only when get_site_info shows the "code" group is enabled, administrators only): read_file / write_file / edit_file change theme and plugin files; write_file also creates new themes and plugins (a child theme for theme changes). '
				. 'PHP is syntax-checked and, for active code, the site is loaded again after each change: if it breaks, the change is undone automatically. Every file, CSS and Elementor change is backed up — use list_backups and restore_backup to undo. '
				. 'manage_plugin and manage_theme install (from a WordPress.org slug or https .zip), activate, update and delete; activation rolls back if it breaks the site. '
				. 'Always ask before deleting anything, switching the theme, installing software or making large or site-wide changes, and share the link or edit link of what you changed.',
				$site,
				home_url( '/' ),
				wp_get_current_user()->display_name
			),
		);
	}

	/**
	 * JSON-RPC result.
	 *
	 * @param mixed $id     Request ID.
	 * @param mixed $result Result.
	 * @return array
	 */
	private static function result( $id, $result ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	/**
	 * JSON-RPC error.
	 *
	 * @param mixed  $id      Request ID.
	 * @param int    $code    Error code.
	 * @param string $message Message.
	 * @return array
	 */
	private static function error_response( $id, $code, $message ) {
		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => array(
				'code'    => $code,
				'message' => $message,
			),
		);
	}
}
