<?php
/**
 * Install, activate, update and remove themes and plugins.
 *
 * Installs come from the WordPress.org directory (by slug) or a direct .zip URL. Activating a
 * plugin loads it in a loopback request first and rolls back if it crashes the site.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Package (theme/plugin) tool handlers.
 */
class AISB_Packages {

	/**
	 * Tool definitions.
	 *
	 * @return array
	 */
	public static function tools() {
		return array(
			'manage_plugin' => array(
				'group'       => 'code',
				'title'       => 'Install or manage a plugin',
				'description' => 'Install a plugin from the WordPress.org directory (by slug, e.g. "contact-form-7") or a .zip URL, and activate, deactivate, update or delete plugins. Activation is rolled back if it breaks the site.',
				'properties'  => array(
					'action' => array(
						'type' => 'string',
						'enum' => array( 'install', 'activate', 'deactivate', 'update', 'delete' ),
					),
					'slug'   => array(
						'type'        => 'string',
						'description' => 'WordPress.org plugin slug (for install), or the plugin folder (for activate/update/delete), e.g. "akismet".',
					),
					'zip_url' => array(
						'type'        => 'string',
						'description' => 'Direct https URL of a plugin .zip, instead of a WordPress.org slug.',
					),
					'activate' => array(
						'type'        => 'boolean',
						'description' => 'Activate right after installing (default true).',
					),
				),
				'required'    => array( 'action' ),
				'destructive' => true,
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'manage_plugin' ),
			),
			'manage_theme'  => array(
				'group'       => 'code',
				'title'       => 'Install or manage a theme',
				'description' => 'Install a theme from the WordPress.org directory (by slug) or a .zip URL, switch the active theme, update or delete themes.',
				'properties'  => array(
					'action'  => array(
						'type' => 'string',
						'enum' => array( 'install', 'activate', 'update', 'delete' ),
					),
					'slug'    => array(
						'type'        => 'string',
						'description' => 'WordPress.org theme slug (for install), or the theme folder (for activate/update/delete), e.g. "astra".',
					),
					'zip_url' => array(
						'type'        => 'string',
						'description' => 'Direct https URL of a theme .zip, instead of a WordPress.org slug.',
					),
					'activate' => array(
						'type'        => 'boolean',
						'description' => 'Switch to the theme right after installing (default false).',
					),
				),
				'required'    => array( 'action' ),
				'destructive' => true,
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'manage_theme' ),
			),
			'search_directory' => array(
				'group'       => 'code',
				'read_only'   => true,
				'title'       => 'Search the WordPress.org directory',
				'description' => 'Search the free WordPress.org directory for plugins or themes to install. Returns slug, name, rating and short description.',
				'properties'  => array(
					'type'   => array(
						'type' => 'string',
						'enum' => array( 'plugin', 'theme' ),
					),
					'search' => array( 'type' => 'string' ),
				),
				'required'    => array( 'type', 'search' ),
				'open_world'  => true,
				'handler'     => array( __CLASS__, 'search_directory' ),
			),
		);
	}

	/**
	 * Manage plugins.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	public static function manage_plugin( $args ) {
		AISB_Files::require_file_changes();
		self::prepare();

		$action = AISB_Tools::str( $args, 'action' );
		switch ( $action ) {
			case 'install':
				return self::install( 'plugin', $args );
			case 'activate':
				return self::activate_plugin( self::plugin_file( AISB_Tools::str( $args, 'slug' ) ) );
			case 'deactivate':
				$file = self::plugin_file( AISB_Tools::str( $args, 'slug' ) );
				deactivate_plugins( $file );
				return array(
					'plugin' => $file,
					'status' => 'deactivated',
				);
			case 'update':
				return self::update( 'plugin', AISB_Tools::str( $args, 'slug' ) );
			case 'delete':
				return self::delete_plugin( self::plugin_file( AISB_Tools::str( $args, 'slug' ) ) );
		}
		throw new AISB_Tool_Error( 'Unknown action.' );
	}

	/**
	 * Manage themes.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	public static function manage_theme( $args ) {
		AISB_Files::require_file_changes();
		self::prepare();

		$action = AISB_Tools::str( $args, 'action' );
		switch ( $action ) {
			case 'install':
				return self::install( 'theme', $args );
			case 'activate':
				return self::activate_theme( AISB_Tools::str( $args, 'slug' ) );
			case 'update':
				return self::update( 'theme', AISB_Tools::str( $args, 'slug' ) );
			case 'delete':
				return self::delete_theme( AISB_Tools::str( $args, 'slug' ) );
		}
		throw new AISB_Tool_Error( 'Unknown action.' );
	}

	/**
	 * Search the WordPress.org directory.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	public static function search_directory( $args ) {
		AISB_Files::require_admin();
		$type   = AISB_Tools::str( $args, 'type' );
		$search = AISB_Tools::str( $args, 'search' );
		if ( '' === $search ) {
			throw new AISB_Tool_Error( 'Give something to search for.' );
		}

		$items = array();
		if ( 'theme' === $type ) {
			require_once ABSPATH . 'wp-admin/includes/theme.php';
			$res = themes_api( 'query_themes', array( 'search' => $search, 'per_page' => 10, 'fields' => array( 'description' => false ) ) );
			if ( is_wp_error( $res ) ) {
				throw new AISB_Tool_Error( $res->get_error_message() );
			}
			foreach ( $res->themes as $theme ) {
				$theme    = (array) $theme;
				$items[] = array(
					'slug'   => $theme['slug'],
					'name'   => $theme['name'],
					'rating' => round( ( isset( $theme['rating'] ) ? $theme['rating'] : 0 ) / 20, 1 ) . '/5',
					'author' => wp_strip_all_tags( is_array( $theme['author'] ) ? $theme['author']['display_name'] : $theme['author'] ),
				);
			}
		} else {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			$res = plugins_api( 'query_plugins', array( 'search' => $search, 'per_page' => 10, 'fields' => array( 'short_description' => true, 'icons' => false ) ) );
			if ( is_wp_error( $res ) ) {
				throw new AISB_Tool_Error( $res->get_error_message() );
			}
			foreach ( $res->plugins as $plugin ) {
				$plugin   = (array) $plugin;
				$items[] = array(
					'slug'        => $plugin['slug'],
					'name'        => wp_strip_all_tags( $plugin['name'] ),
					'rating'      => round( ( isset( $plugin['rating'] ) ? $plugin['rating'] : 0 ) / 20, 1 ) . '/5',
					'installs'    => isset( $plugin['active_installs'] ) ? $plugin['active_installs'] . '+' : '',
					'description' => wp_strip_all_tags( isset( $plugin['short_description'] ) ? $plugin['short_description'] : '' ),
				);
			}
		}
		return array( 'items' => $items );
	}

	/**
	 * Install a theme or plugin from the directory or a zip URL.
	 *
	 * @param string $type plugin or theme.
	 * @param array  $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function install( $type, $args ) {
		$slug    = AISB_Tools::str( $args, 'slug' );
		$zip_url = AISB_Tools::str( $args, 'zip_url' );
		$source  = '';

		if ( '' !== $zip_url ) {
			$host    = strtolower( (string) wp_parse_url( $zip_url, PHP_URL_HOST ) );
			$schemes = in_array( $host, array( 'localhost', '127.0.0.1', '[::1]' ), true ) ? array( 'http', 'https' ) : array( 'https' );
			$source  = esc_url_raw( $zip_url, $schemes );
			if ( '' === $source ) {
				throw new AISB_Tool_Error( 'zip_url must be an https URL (http is allowed only for localhost).' );
			}
		} elseif ( '' !== $slug ) {
			$source = self::directory_download_url( $type, $slug );
		} else {
			throw new AISB_Tool_Error( 'Give a WordPress.org slug or a zip_url.' );
		}

		if ( 'plugin' === $type ) {
			require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
			$upgrader = new Plugin_Upgrader( new WP_Ajax_Upgrader_Skin() );
		} else {
			require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
			$upgrader = new Theme_Upgrader( new WP_Ajax_Upgrader_Skin() );
		}

		$result = $upgrader->install( $source );
		self::check_upgrader( $upgrader, $result, 'Install failed' );

		$installed = $upgrader->result['destination_name'];
		if ( 'plugin' === $type ) {
			wp_clean_plugins_cache();
			$out = array(
				'installed' => $installed,
				'plugin'    => self::plugin_file( $installed ),
			);
			if ( ! isset( $args['activate'] ) || $args['activate'] ) {
				$out['activation'] = self::activate_plugin( $out['plugin'] );
			}
			return $out;
		}

		wp_clean_themes_cache();
		$out = array( 'installed' => $installed );
		if ( ! empty( $args['activate'] ) ) {
			$out['activation'] = self::activate_theme( $installed );
		}
		return $out;
	}

	/**
	 * Activate a plugin, rolling back if it crashes the site.
	 *
	 * @param string $file Plugin file (folder/main.php).
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function activate_plugin( $file ) {
		if ( is_plugin_active( $file ) ) {
			return array(
				'plugin' => $file,
				'status' => 'already active',
			);
		}
		// activate_plugin() loads the plugin in this request; a fatal there is caught and the
		// plugin is not activated. silent=false still fires activation hooks.
		$error = activate_plugin( $file );
		if ( is_wp_error( $error ) ) {
			throw new AISB_Tool_Error( 'Could not activate: ' . $error->get_error_message() );
		}

		$check = AISB_Health::check();
		if ( is_string( $check ) ) {
			deactivate_plugins( $file, true );
			throw new AISB_Tool_Error( 'The plugin was deactivated again because it broke the site: ' . $check );
		}
		return array(
			'plugin'     => $file,
			'status'     => 'activated',
			'site_check' => true === $check ? 'passed' : 'could not run; check the site',
		);
	}

	/**
	 * Delete a plugin.
	 *
	 * @param string $file Plugin file.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function delete_plugin( $file ) {
		if ( is_plugin_active( $file ) ) {
			deactivate_plugins( $file, true );
		}
		$result = delete_plugins( array( $file ) );
		if ( is_wp_error( $result ) ) {
			throw new AISB_Tool_Error( $result->get_error_message() );
		}
		if ( false === $result ) {
			throw new AISB_Tool_Error( 'Could not delete the plugin (check file permissions).' );
		}
		wp_clean_plugins_cache();
		return array(
			'plugin' => $file,
			'status' => 'deleted',
		);
	}

	/**
	 * Switch the active theme, rolling back if the new one errors.
	 *
	 * @param string $stylesheet Theme folder.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function activate_theme( $stylesheet ) {
		$theme = wp_get_theme( $stylesheet );
		if ( ! $theme->exists() ) {
			throw new AISB_Tool_Error( sprintf( 'No installed theme with the folder "%s".', $stylesheet ) );
		}
		if ( $theme->errors() ) {
			throw new AISB_Tool_Error( 'This theme has a problem: ' . $theme->errors()->get_error_message() );
		}
		$previous = get_stylesheet();
		if ( $previous === $stylesheet ) {
			return array(
				'theme'  => $stylesheet,
				'status' => 'already active',
			);
		}

		switch_theme( $stylesheet );
		$check = AISB_Health::check();
		if ( is_string( $check ) ) {
			switch_theme( $previous );
			throw new AISB_Tool_Error( 'Switched back to the previous theme because the new one broke the site: ' . $check );
		}
		return array(
			'theme'      => $stylesheet,
			'name'       => $theme->get( 'Name' ),
			'status'     => 'activated',
			'previous'   => $previous,
			'site_check' => true === $check ? 'passed' : 'could not run; check the site',
		);
	}

	/**
	 * Delete a theme.
	 *
	 * @param string $stylesheet Theme folder.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function delete_theme( $stylesheet ) {
		require_once ABSPATH . 'wp-admin/includes/theme.php';
		if ( in_array( $stylesheet, array( get_stylesheet(), get_template() ), true ) ) {
			throw new AISB_Tool_Error( 'This theme is in use. Activate another theme first.' );
		}
		$result = delete_theme( $stylesheet );
		if ( is_wp_error( $result ) ) {
			throw new AISB_Tool_Error( $result->get_error_message() );
		}
		if ( false === $result ) {
			throw new AISB_Tool_Error( 'Could not delete the theme (check file permissions).' );
		}
		wp_clean_themes_cache();
		return array(
			'theme'  => $stylesheet,
			'status' => 'deleted',
		);
	}

	/**
	 * Update a theme or plugin from WordPress.org.
	 *
	 * @param string $type plugin or theme.
	 * @param string $slug Plugin file / theme folder.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function update( $type, $slug ) {
		if ( '' === $slug ) {
			throw new AISB_Tool_Error( 'Give the plugin or theme to update.' );
		}
		if ( 'plugin' === $type ) {
			$file = self::plugin_file( $slug );
			wp_update_plugins();
			require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
			$upgrader = new Plugin_Upgrader( new WP_Ajax_Upgrader_Skin() );
			$active   = is_plugin_active( $file );
			$result   = $upgrader->upgrade( $file );
			self::check_upgrader( $upgrader, $result, 'Update failed', 'No update was available or the plugin is already up to date.' );
			if ( $active ) {
				$check = AISB_Health::check();
				if ( is_string( $check ) ) {
					$result = array(
						'plugin'  => $file,
						'status'  => 'updated',
						'warning' => 'The site shows an error after the update: ' . $check . ' You may need to restore a backup or roll the plugin back.',
					);
					return $result;
				}
			}
			wp_clean_plugins_cache();
			return array(
				'plugin' => $file,
				'status' => 'updated',
			);
		}

		wp_update_themes();
		require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
		$upgrader = new Theme_Upgrader( new WP_Ajax_Upgrader_Skin() );
		$result   = $upgrader->upgrade( $slug );
		self::check_upgrader( $upgrader, $result, 'Update failed', 'No update was available or the theme is already up to date.' );
		wp_clean_themes_cache();
		return array(
			'theme'  => $slug,
			'status' => 'updated',
		);
	}

	/**
	 * Resolve a plugin folder or file to its main file.
	 *
	 * @param string $slug Plugin folder or file.
	 * @return string
	 * @throws AISB_Tool_Error When not found.
	 */
	private static function plugin_file( $slug ) {
		if ( '' === $slug ) {
			throw new AISB_Tool_Error( 'Give the plugin folder, e.g. "akismet".' );
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugins = get_plugins();
		if ( isset( $plugins[ $slug ] ) ) {
			return $slug;
		}
		foreach ( array_keys( $plugins ) as $file ) {
			if ( 0 === strpos( $file, $slug . '/' ) || $file === $slug . '.php' ) {
				return $file;
			}
		}
		throw new AISB_Tool_Error( sprintf( 'No installed plugin "%s". get_site_info lists active plugins; use list_files on "plugins" for all folders.', $slug ) );
	}

	/**
	 * Download URL for a WordPress.org plugin or theme.
	 *
	 * @param string $type plugin or theme.
	 * @param string $slug Slug.
	 * @return string
	 * @throws AISB_Tool_Error When not found.
	 */
	private static function directory_download_url( $type, $slug ) {
		$slug = sanitize_key( $slug );
		if ( 'plugin' === $type ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			$res = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
		} else {
			require_once ABSPATH . 'wp-admin/includes/theme.php';
			$res = themes_api( 'theme_information', array( 'slug' => $slug ) );
		}
		if ( is_wp_error( $res ) ) {
			throw new AISB_Tool_Error( sprintf( 'Not found in the WordPress.org directory: "%s". Check the slug with search_directory.', $slug ) );
		}
		$res = (array) $res;
		if ( empty( $res['download_link'] ) ) {
			throw new AISB_Tool_Error( 'No download link for this item.' );
		}
		return $res['download_link'];
	}

	/**
	 * Load the upgrader classes and silence their screen output.
	 */
	private static function prepare() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
		}
	}

	/**
	 * Turn an upgrader result into an error when it failed.
	 *
	 * @param WP_Upgrader $upgrader  Upgrader.
	 * @param mixed       $result    Result of install()/upgrade().
	 * @param string      $context   Error prefix.
	 * @param string      $empty_msg Message when the result is empty (nothing to do).
	 * @throws AISB_Tool_Error On failure.
	 */
	private static function check_upgrader( $upgrader, $result, $context, $empty_msg = '' ) {
		if ( is_wp_error( $result ) ) {
			throw new AISB_Tool_Error( $context . ': ' . $result->get_error_message() );
		}
		$errors = $upgrader->skin->get_errors();
		if ( is_wp_error( $errors ) && $errors->has_errors() ) {
			throw new AISB_Tool_Error( $context . ': ' . $errors->get_error_message() );
		}
		if ( null === $result || false === $result ) {
			throw new AISB_Tool_Error( '' !== $empty_msg ? $empty_msg : ( $context . ': the operation did not complete.' ) );
		}
	}
}
