<?php
/**
 * Front controller for the connector URLs.
 *
 * The endpoints are served before WordPress builds the page (not through the REST API), so
 * plugins that disable or lock down the REST API, or that read every Bearer token as their own
 * JWT, don't break the connection.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Maps request paths to the OAuth and MCP handlers.
 */
class AISB_Router {

	/**
	 * First path segment of every connector URL.
	 */
	const PREFIX = 'ai-site-bridge';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'parse_request', array( __CLASS__, 'route' ), 0 );
	}

	/**
	 * Absolute URL of a connector endpoint, e.g. `mcp` or `oauth/token`.
	 *
	 * @param string $path Endpoint path.
	 * @return string
	 */
	public static function url( $path ) {
		return home_url( '/' . self::PREFIX . '/' . ltrim( $path, '/' ) );
	}

	/**
	 * The URL people paste into their AI app.
	 *
	 * @return string
	 */
	public static function mcp_url() {
		return self::url( 'mcp' );
	}

	/**
	 * OAuth issuer: the site's home URL.
	 *
	 * @return string
	 */
	public static function issuer() {
		return untrailingslashit( home_url() );
	}

	/**
	 * Serve the request when it is for one of the connector URLs.
	 */
	public static function route() {
		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$path = '/' . ltrim( $path, '/' );

		// Path relative to the WordPress home, so sites installed in a sub-folder work too.
		$home = '/' . trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$rel  = $path;
		if ( '/' !== $home && 0 === strpos( $path . '/', $home . '/' ) ) {
			$rel = '/' . ltrim( substr( $path, strlen( $home ) ), '/' );
		}

		// Discovery documents (RFC 9728, RFC 8414 and OpenID Connect discovery).
		$discovery = self::discovery_handler( untrailingslashit( $path ), untrailingslashit( $rel ), '/' === $home ? '' : $home );
		if ( $discovery ) {
			self::serve( $discovery, true );
		}

		$routes = array(
			'/' . self::PREFIX . '/mcp'             => array( array( 'AISB_MCP', 'handle' ), true ),
			'/' . self::PREFIX . '/oauth/register'  => array( array( 'AISB_OAuth', 'register' ), true ),
			'/' . self::PREFIX . '/oauth/token'     => array( array( 'AISB_OAuth', 'token' ), true ),
			'/' . self::PREFIX . '/oauth/revoke'    => array( array( 'AISB_OAuth', 'revoke' ), true ),
			'/' . self::PREFIX . '/oauth/jwks'      => array( array( 'AISB_OAuth', 'jwks' ), true ),
			'/' . self::PREFIX . '/oauth/authorize' => array( array( 'AISB_OAuth', 'authorize' ), false ),
		);
		$rel    = untrailingslashit( $rel );
		if ( isset( $routes[ $rel ] ) ) {
			self::serve( $routes[ $rel ][0], $routes[ $rel ][1] );
		}
	}

	/**
	 * Which discovery document a request asks for, if any.
	 *
	 * For a site in a sub-folder (home https://example.com/shop) clients look in two places:
	 * - below the home folder: /shop/.well-known/openid-configuration (what WordPress here can serve);
	 * - at the server root with the folder appended: /.well-known/oauth-authorization-server/shop
	 *   (only reaches this install when the root forwards it, e.g. multisite or a root rule).
	 * Only the documents for THIS site are answered. Another site's paths are left alone, so a
	 * WordPress at the domain root never answers for a sub-folder site with the wrong issuer.
	 *
	 * @param string $path Request path, no trailing slash.
	 * @param string $rel  Path relative to the home folder, no trailing slash.
	 * @param string $home Home folder ('' at the domain root), e.g. /shop.
	 * @return callable|null
	 */
	private static function discovery_handler( $path, $rel, $home ) {
		$resource = '/' . self::PREFIX . '/mcp';

		$prm = '/.well-known/oauth-protected-resource';
		if ( in_array( $rel, array( $prm, $prm . $resource ), true ) || in_array( $path, array( $prm . $home, $prm . $home . $resource ), true ) ) {
			return array( 'AISB_OAuth', 'protected_resource_metadata' );
		}

		$as = '/.well-known/oauth-authorization-server';
		if ( $as === $rel || $as . $home === $path ) {
			return array( 'AISB_OAuth', 'authorization_server_metadata' );
		}

		$oidc = '/.well-known/openid-configuration';
		if ( $oidc === $rel || $oidc . $home === $path ) {
			return array( 'AISB_OAuth', 'openid_configuration' );
		}

		return null;
	}

	/**
	 * Run a handler and stop WordPress from rendering a page.
	 *
	 * @param callable $handler Handler.
	 * @param bool     $api     Machine endpoint: allow cross-origin calls and answer preflights.
	 */
	private static function serve( $handler, $api ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();

		if ( $api ) {
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS' );
			header( 'Access-Control-Allow-Headers: Authorization, Content-Type, Accept, Mcp-Session-Id, Mcp-Protocol-Version, Last-Event-ID' );
			header( 'Access-Control-Expose-Headers: WWW-Authenticate, Mcp-Session-Id' );
			header( 'Access-Control-Max-Age: 86400' );
			if ( 'OPTIONS' === self::method() ) {
				status_header( 204 );
				exit;
			}
		}

		call_user_func( $handler );
		exit;
	}

	/**
	 * Request method.
	 *
	 * @return string
	 */
	public static function method() {
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
	}

	/**
	 * Send a JSON response and stop.
	 *
	 * @param mixed $data    Data.
	 * @param int   $status  HTTP status.
	 * @param array $headers Extra headers.
	 */
	public static function json( $data, $status = 200, $headers = array() ) {
		status_header( $status );
		header( 'Content-Type: application/json; charset=utf-8' );
		foreach ( $headers as $name => $value ) {
			header( $name . ': ' . $value );
		}
		echo wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/**
	 * Request body decoded from JSON, or form fields.
	 *
	 * @return array|null Null when a JSON body could not be parsed.
	 */
	public static function body() {
		$type = isset( $_SERVER['CONTENT_TYPE'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['CONTENT_TYPE'] ) ) ) : '';
		if ( false !== strpos( $type, 'application/x-www-form-urlencoded' ) || false !== strpos( $type, 'multipart/form-data' ) ) {
			return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		$raw = (string) file_get_contents( 'php://input' );
		if ( '' === trim( $raw ) ) {
			return array();
		}
		$data = json_decode( $raw, true );
		return is_array( $data ) ? $data : null;
	}

	/**
	 * Authorization request header (some servers only pass it through under other names).
	 *
	 * @return string
	 */
	public static function authorization_header() {
		foreach ( array( 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				return trim( wp_unslash( $_SERVER[ $key ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			}
		}
		if ( function_exists( 'getallheaders' ) ) {
			foreach ( (array) getallheaders() as $name => $value ) {
				if ( 'authorization' === strtolower( $name ) ) {
					return trim( $value );
				}
			}
		}
		return '';
	}
}
