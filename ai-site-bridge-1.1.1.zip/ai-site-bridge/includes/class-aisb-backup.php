<?php
/**
 * Backups of everything the assistant overwrites (files, Elementor layouts, custom CSS), so any
 * change can be undone with restore_backup.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Backups table and the list/restore tools.
 */
class AISB_Backup {

	/**
	 * Backups older than this are removed by the daily cleanup (about a week).
	 */
	const KEEP_DAYS = 7;

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'aisb_backups';
	}

	/**
	 * Save the previous version of something before it changes.
	 *
	 * @param string      $kind    file, elementor or css.
	 * @param string      $target  File path, post ID or theme.
	 * @param string|null $content Previous content, or null when it didn't exist yet.
	 * @param string      $label   What changed.
	 * @return int Backup ID.
	 */
	public static function save( $kind, $target, $content, $label ) {
		global $wpdb;

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::table(),
			array(
				'created_at' => time(),
				'user_id'    => get_current_user_id(),
				'client_id'  => AISB_MCP::$client_id,
				'kind'       => $kind,
				'target'     => (string) $target,
				'label'      => mb_substr( (string) $label, 0, 255 ),
				'existed'    => null === $content ? 0 : 1,
				'content'    => null === $content ? '' : $content,
			)
		);
		$id = (int) $wpdb->insert_id;

		// Keep only this newest backup of this file / page / CSS; drop the older ones.
		$table = self::table();
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "DELETE FROM {$table} WHERE kind = %s AND target = %s AND id < %d", $kind, (string) $target, $id )
		);
		return $id;
	}

	/**
	 * One backup.
	 *
	 * @param int $id Backup ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$table = self::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Delete one backup (when the change it was made for was undone).
	 *
	 * @param int $id Backup ID.
	 */
	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Remove old backups.
	 */
	public static function prune() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %d", time() - self::KEEP_DAYS * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Tool definitions.
	 *
	 * @return array
	 */
	public static function tools() {
		return array(
			'list_backups'   => array(
				'group'       => 'write',
				'read_only'   => true,
				'title'       => 'List backups',
				'description' => 'Earlier versions saved automatically before files, Elementor layouts or custom CSS were changed. Only the most recent backup of each file/page/CSS is kept, for up to ' . self::KEEP_DAYS . ' days. Use restore_backup to undo the last change.',
				'properties'  => array(
					'target' => array(
						'type'        => 'string',
						'description' => 'Only backups of this file path (e.g. themes/my-theme/style.css), post ID or theme.',
					),
					'kind'   => array(
						'type' => 'string',
						'enum' => array( 'file', 'elementor', 'css' ),
					),
					'limit'  => array(
						'type'        => 'integer',
						'minimum'     => 1,
						'maximum'     => 100,
						'description' => 'Max rows (default 20).',
					),
				),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_backups' ),
			),
			'restore_backup' => array(
				'group'       => 'write',
				'title'       => 'Restore a backup',
				'description' => 'Put back a version from list_backups (undo). A file that did not exist before is deleted. The current version is backed up first, so a restore can be undone too.',
				'properties'  => array(
					'backup_id' => array( 'type' => 'integer' ),
				),
				'required'    => array( 'backup_id' ),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'restore_backup' ),
			),
		);
	}

	/**
	 * List backups.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function list_backups( $args ) {
		global $wpdb;

		$table  = self::table();
		$where  = array( '1=1' );
		$values = array();
		if ( '' !== AISB_Tools::str( $args, 'target' ) ) {
			$where[]  = 'target = %s';
			$values[] = AISB_Tools::str( $args, 'target' );
		}
		if ( '' !== AISB_Tools::str( $args, 'kind' ) ) {
			$where[]  = 'kind = %s';
			$values[] = AISB_Tools::str( $args, 'kind' );
		}
		$values[] = isset( $args['limit'] ) ? max( 1, min( 100, (int) $args['limit'] ) ) : 20;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id, created_at, kind, target, label, existed, LENGTH(content) AS size FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d', $values ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'backup_id' => (int) $row['id'],
				'date'      => wp_date( 'Y-m-d H:i:s', (int) $row['created_at'] ),
				'kind'      => $row['kind'],
				'target'    => $row['target'],
				'change'    => $row['label'],
				'previous'  => $row['existed'] ? sprintf( '%d bytes', (int) $row['size'] ) : 'did not exist',
			);
		}
		return array( 'items' => $items );
	}

	/**
	 * Restore a backup.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error When the backup is missing or its kind is turned off.
	 */
	public static function restore_backup( $args ) {
		$backup = self::get( isset( $args['backup_id'] ) ? absint( $args['backup_id'] ) : 0 );
		if ( ! $backup ) {
			throw new AISB_Tool_Error( 'No backup with this ID (backups are kept ' . self::KEEP_DAYS . ' days).' );
		}
		$content = $backup['existed'] ? $backup['content'] : null;

		if ( 'file' === $backup['kind'] ) {
			self::require_group( 'code' );
			$result = AISB_Files::restore( $backup['target'], $content, $backup['id'] );
		} elseif ( 'elementor' === $backup['kind'] ) {
			self::require_group( 'design' );
			$result = AISB_Design::restore_elementor( (int) $backup['target'], $content, $backup['id'] );
		} elseif ( 'css' === $backup['kind'] ) {
			self::require_group( 'design' );
			$result = AISB_Design::restore_css( $backup['target'], (string) $content, $backup['id'] );
		} else {
			throw new AISB_Tool_Error( 'Unknown backup type.' );
		}

		$result['restored_backup'] = (int) $backup['id'];
		return $result;
	}

	/**
	 * Stop when the action group a backup belongs to is turned off.
	 *
	 * @param string $group Group key.
	 * @throws AISB_Tool_Error When off.
	 */
	private static function require_group( $group ) {
		if ( ! AISB_Settings::group_enabled( $group ) ) {
			throw new AISB_Tool_Error( 'The site owner has turned this kind of change off in AI Site Bridge settings.' );
		}
	}
}
