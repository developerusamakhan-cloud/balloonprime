<?php
/**
 * Checks that the site still works after a code change, by loading the homepage and the
 * dashboard as the current user (like WordPress' own theme and plugin editor does).
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loopback health check.
 */
class AISB_Health {

	const PARAM = 'aisb_health';
	const KEY   = 'aisb_health_key';

	/**
	 * On a health-check request, add the PHP error details to WordPress' "critical error" page.
	 * Runs as soon as this plugin file loads.
	 */
	public static function init() {
		if ( empty( $_GET[ self::PARAM ] ) || ! is_string( $_GET[ self::PARAM ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$key = get_transient( self::KEY );
		if ( is_string( $key ) && '' !== $key && hash_equals( $key, sanitize_text_field( wp_unslash( $_GET[ self::PARAM ] ) ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			add_filter( 'wp_php_error_message', array( __CLASS__, 'mark_error' ), 10, 2 );
		}
	}

	/**
	 * Hidden marker with the error, read back by check().
	 *
	 * @param string $message Error page message.
	 * @param array  $error   Error from error_get_last().
	 * @return string
	 */
	public static function mark_error( $message, $error ) {
		$details = array(
			'message' => isset( $error['message'] ) ? (string) $error['message'] : '',
			'file'    => isset( $error['file'] ) ? str_replace( wp_normalize_path( WP_CONTENT_DIR ) . '/', '', wp_normalize_path( (string) $error['file'] ) ) : '',
			'line'    => isset( $error['line'] ) ? (int) $error['line'] : 0,
		);
		return $message . '<!--AISB_ERROR ' . base64_encode( wp_json_encode( $details ) ) . ' -->'; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Load the homepage and the dashboard and look for PHP errors.
	 *
	 * @return true|string|null True when both load, the error when one fails, null when the
	 *                          site could not be reached at all (loopback requests blocked).
	 */
	public static function check() {
		$user_id = get_current_user_id();
		$key     = wp_generate_password( 32, false );
		$expires = time() + 5 * MINUTE_IN_SECONDS;
		set_transient( self::KEY, $key, 5 * MINUTE_IN_SECONDS );

		// A short-lived login session so the dashboard (and logged-in pages, past page caches) load.
		$manager = WP_Session_Tokens::get_instance( $user_id );
		$token   = $manager->create( $expires );
		$secure  = 'https' === wp_parse_url( admin_url(), PHP_URL_SCHEME );
		$cookies = array(
			( $secure ? SECURE_AUTH_COOKIE : AUTH_COOKIE ) => wp_generate_auth_cookie( $user_id, $expires, $secure ? 'secure_auth' : 'auth', $token ),
			LOGGED_IN_COOKIE                               => wp_generate_auth_cookie( $user_id, $expires, 'logged_in', $token ),
		);

		$error   = '';
		$reached = 0;
		foreach ( array( home_url( '/' ), admin_url( '/' ) ) as $url ) {
			$response = wp_remote_get(
				add_query_arg(
					array(
						self::PARAM    => $key,
						'aisb_nocache' => wp_rand(),
					),
					$url
				),
				array(
					'timeout'     => 20,
					'redirection' => 0,
					'cookies'     => $cookies,
					'headers'     => array( 'Cache-Control' => 'no-cache' ),
					'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core filter.
				)
			);
			if ( is_wp_error( $response ) ) {
				continue;
			}
			++$reached;
			$error = self::find_error( $response, $url );
			if ( $error ) {
				break;
			}
		}

		$manager->destroy( $token );
		delete_transient( self::KEY );

		if ( $error ) {
			return $error;
		}
		return $reached ? true : null;
	}

	/**
	 * PHP error in a loopback response, if any.
	 *
	 * @param array  $response HTTP response.
	 * @param string $url      URL that was loaded.
	 * @return string
	 */
	private static function find_error( $response, $url ) {
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		$page = 0 === strpos( $url, admin_url() ) ? 'the dashboard' : 'the homepage';

		if ( preg_match( '/<!--AISB_ERROR ([A-Za-z0-9+\/=]+) -->/', $body, $m ) ) {
			$details = json_decode( (string) base64_decode( $m[1] ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( is_array( $details ) ) {
				return sprintf( 'PHP error on %s: %s in %s on line %d', $page, $details['message'], $details['file'], $details['line'] );
			}
		}
		if ( preg_match( '/(?:Fatal|Parse) error<\/b>:\s*(.+?)<br/s', $body, $m ) || preg_match( '/PHP (?:Fatal|Parse) error:\s*([^\n<]+)/', $body, $m ) ) {
			return sprintf( 'PHP error on %s: %s', $page, trim( wp_strip_all_tags( $m[1] ) ) );
		}
		if ( $code >= 500 ) {
			$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $body ) ) );
			return sprintf( '%s returned HTTP %d: %s', ucfirst( $page ), $code, mb_substr( $text, 0, 300 ) );
		}
		return '';
	}
}
