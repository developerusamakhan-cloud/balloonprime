<?php
/**
 * Design tools: Additional CSS (Customizer), navigation menus and Elementor page content.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Design tool handlers.
 */
class AISB_Design {

	/**
	 * Tool definitions.
	 *
	 * @return array
	 */
	public static function tools() {
		return array(
			'get_custom_css'      => array(
				'group'       => 'design',
				'read_only'   => true,
				'title'       => 'Get custom CSS',
				'description' => 'Read the site\'s Additional CSS (Appearance → Customize → Additional CSS).',
				'properties'  => array(),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'get_custom_css' ),
			),
			'update_custom_css'   => array(
				'group'       => 'design',
				'title'       => 'Update custom CSS',
				'description' => 'Replace the site\'s Additional CSS. This is the safe way to change colours, spacing and fonts: it never breaks the site and a backup is kept. Pass the complete CSS (read it first with get_custom_css and keep what should stay).',
				'properties'  => array(
					'css' => array(
						'type'        => 'string',
						'description' => 'The complete Additional CSS.',
					),
				),
				'required'    => array( 'css' ),
				'destructive' => true,
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'update_custom_css' ),
			),
			'list_menus'          => array(
				'group'       => 'design',
				'read_only'   => true,
				'title'       => 'List navigation menus',
				'description' => 'List the navigation menus, their items and where each menu is shown (menu locations the theme offers).',
				'properties'  => array(),
				'required'    => array(),
				'handler'     => array( __CLASS__, 'list_menus' ),
			),
			'update_menu'         => array(
				'group'       => 'design',
				'title'       => 'Edit a navigation menu',
				'description' => 'Create a menu or change its items: add links to pages, posts, categories or custom URLs, reorder them, nest them and remove them. Optionally show the menu in a theme location.',
				'properties'  => array(
					'menu_id'   => array(
						'type'        => 'integer',
						'description' => 'Menu to edit. Leave empty and pass name to create a new menu.',
					),
					'name'      => array(
						'type'        => 'string',
						'description' => 'Name for a new menu, or a new name for an existing one.',
					),
					'location'  => array(
						'type'        => 'string',
						'description' => 'Theme menu location to show this menu in (from list_menus).',
					),
					'items'     => array(
						'type'        => 'array',
						'description' => 'The full list of menu items, in order; replaces the current items. Leave out to only rename or relocate.',
						'items'       => array(
							'type'       => 'object',
							'properties' => array(
								'label'    => array(
									'type'        => 'string',
									'description' => 'Text shown; defaults to the page or post title.',
								),
								'type'     => array(
									'type'        => 'string',
									'enum'        => array( 'page', 'post', 'category', 'custom' ),
									'description' => 'What the item links to (default page).',
								),
								'object_id' => array(
									'type'        => 'integer',
									'description' => 'Page, post or category ID for type page/post/category.',
								),
								'url'      => array(
									'type'        => 'string',
									'description' => 'URL for type custom.',
								),
								'parent'   => array(
									'type'        => 'integer',
									'description' => '1-based position of the parent item in this list, for a sub-menu item (0 for top level).',
								),
							),
						),
					),
				),
				'required'    => array(),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'update_menu' ),
			),
			'get_elementor'       => array(
				'group'       => 'design',
				'read_only'   => true,
				'title'       => 'Get Elementor content',
				'description' => 'Read the text and settings of an Elementor page or post as structured data (widgets with their IDs). Use this to edit Elementor pages, which get_content cannot change.',
				'properties'  => array(
					'id' => array(
						'type'        => 'integer',
						'description' => 'Page or post ID (must be built with Elementor).',
					),
				),
				'required'    => array( 'id' ),
				'handler'     => array( __CLASS__, 'get_elementor' ),
			),
			'update_elementor'    => array(
				'group'       => 'design',
				'title'       => 'Edit Elementor text',
				'description' => 'Change the text of Elementor widgets on a page. Pass the widget ID (from get_elementor) and the new text for each. A backup is kept. Adding or removing widgets, or changing layout, is not supported.',
				'properties'  => array(
					'id'      => array(
						'type'        => 'integer',
						'description' => 'Page or post ID.',
					),
					'changes' => array(
						'type'        => 'array',
						'description' => 'One entry per widget to change.',
						'items'       => array(
							'type'       => 'object',
							'properties' => array(
								'widget_id' => array(
									'type'        => 'string',
									'description' => 'Widget ID from get_elementor.',
								),
								'field'     => array(
									'type'        => 'string',
									'description' => 'Which text to change: title, editor, text or caption (default: the widget\'s main text).',
								),
								'text'      => array( 'type' => 'string' ),
							),
						),
					),
				),
				'required'    => array( 'id', 'changes' ),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'update_elementor' ),
			),
		);
	}

	/**
	 * Read Additional CSS.
	 *
	 * @return array
	 */
	public static function get_custom_css() {
		self::require_admin();
		return array(
			'theme' => get_stylesheet(),
			'css'   => wp_get_custom_css(),
		);
	}

	/**
	 * Replace Additional CSS.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error When saving fails.
	 */
	public static function update_custom_css( $args ) {
		self::require_admin();
		if ( ! isset( $args['css'] ) || ! is_string( $args['css'] ) ) {
			throw new AISB_Tool_Error( 'Give the CSS.' );
		}
		$old       = wp_get_custom_css();
		$backup_id = AISB_Backup::save( 'css', get_stylesheet(), $old, 'update_custom_css' );

		$post = wp_update_custom_css_post( $args['css'] );
		if ( is_wp_error( $post ) ) {
			AISB_Backup::delete( $backup_id );
			throw new AISB_Tool_Error( $post->get_error_message() );
		}
		return array(
			'theme'     => get_stylesheet(),
			'saved'     => true,
			'backup_id' => $backup_id,
		);
	}

	/**
	 * Put back a CSS backup (used by restore_backup).
	 *
	 * @param string $theme     Theme stylesheet.
	 * @param string $css       Previous CSS.
	 * @param int    $backup_id Backup being restored.
	 * @return array
	 */
	public static function restore_css( $theme, $css, $backup_id ) {
		self::require_admin();
		wp_update_custom_css_post( $css, array( 'stylesheet' => $theme ) );
		return array(
			'theme'   => $theme,
			'kind'    => 'css',
			'action'  => 'restored',
		);
	}

	/**
	 * List menus and locations.
	 *
	 * @return array
	 */
	public static function list_menus() {
		self::require_admin();

		$locations = get_nav_menu_locations();
		$menus     = array();
		foreach ( wp_get_nav_menus() as $menu ) {
			$items    = array();
			$position = array();
			foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
				$position[ $item->ID ] = count( $items ) + 1;
				$items[]               = array(
					'label'  => $item->title,
					'type'   => $item->type,
					'url'    => $item->url,
					'parent' => $item->menu_item_parent ? ( isset( $position[ (int) $item->menu_item_parent ] ) ? $position[ (int) $item->menu_item_parent ] : 0 ) : 0,
				);
			}
			$menus[] = array(
				'menu_id'   => $menu->term_id,
				'name'      => $menu->name,
				'locations' => array_keys( $locations, $menu->term_id, true ),
				'items'     => $items,
			);
		}

		$theme_locations = array();
		foreach ( get_registered_nav_menus() as $slug => $label ) {
			$theme_locations[] = array(
				'location'  => $slug,
				'label'     => $label,
				'menu_id'   => isset( $locations[ $slug ] ) ? $locations[ $slug ] : 0,
			);
		}
		return array(
			'menus'           => $menus,
			'theme_locations' => $theme_locations,
		);
	}

	/**
	 * Create or edit a menu.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	public static function update_menu( $args ) {
		self::require_admin();
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to edit menus.' );
		}

		$menu_id = isset( $args['menu_id'] ) ? absint( $args['menu_id'] ) : 0;
		$name    = AISB_Tools::str( $args, 'name' );

		if ( $menu_id ) {
			if ( ! wp_get_nav_menu_object( $menu_id ) ) {
				throw new AISB_Tool_Error( 'No menu with this ID.' );
			}
			if ( '' !== $name ) {
				wp_update_nav_menu_object( $menu_id, array( 'menu-name' => $name ) );
			}
		} else {
			if ( '' === $name ) {
				throw new AISB_Tool_Error( 'Give a name to create a new menu, or a menu_id to edit one.' );
			}
			$menu_id = wp_create_nav_menu( $name );
			if ( is_wp_error( $menu_id ) ) {
				throw new AISB_Tool_Error( $menu_id->get_error_message() );
			}
		}

		if ( isset( $args['items'] ) && is_array( $args['items'] ) ) {
			foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $existing ) {
				wp_delete_post( $existing->ID, true );
			}
			$db_ids = array();
			foreach ( $args['items'] as $index => $item ) {
				$db_ids[ $index + 1 ] = self::add_menu_item( $menu_id, (array) $item, $db_ids );
			}
		}

		if ( '' !== AISB_Tools::str( $args, 'location' ) ) {
			$location  = AISB_Tools::str( $args, 'location' );
			$available = get_registered_nav_menus();
			if ( ! isset( $available[ $location ] ) ) {
				throw new AISB_Tool_Error( sprintf( 'This theme has no menu location "%s". list_menus shows the available locations.', $location ) );
			}
			$locations              = get_nav_menu_locations();
			$locations[ $location ] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}

		return self::menu_summary( $menu_id );
	}

	/**
	 * Add one item to a menu.
	 *
	 * @param int   $menu_id Menu ID.
	 * @param array $item    Item data.
	 * @param array $db_ids  1-based index => created DB ID, for parents.
	 * @return int New item DB ID.
	 * @throws AISB_Tool_Error On errors.
	 */
	private static function add_menu_item( $menu_id, $item, $db_ids ) {
		$type   = isset( $item['type'] ) ? sanitize_key( $item['type'] ) : 'page';
		$parent = isset( $item['parent'] ) ? (int) $item['parent'] : 0;
		$data   = array(
			'menu-item-title'     => isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '',
			'menu-item-status'    => 'publish',
			'menu-item-parent-id' => $parent && isset( $db_ids[ $parent ] ) ? $db_ids[ $parent ] : 0,
		);

		if ( 'custom' === $type ) {
			$data['menu-item-type'] = 'custom';
			$data['menu-item-url']  = esc_url_raw( isset( $item['url'] ) ? $item['url'] : '' );
			if ( '' === $data['menu-item-url'] ) {
				throw new AISB_Tool_Error( 'A custom menu item needs a url.' );
			}
		} else {
			$object_id = isset( $item['object_id'] ) ? absint( $item['object_id'] ) : 0;
			if ( ! $object_id ) {
				throw new AISB_Tool_Error( sprintf( 'A %s menu item needs object_id.', $type ) );
			}
			if ( 'category' === $type ) {
				$data['menu-item-type']      = 'taxonomy';
				$data['menu-item-object']    = 'category';
				$data['menu-item-object-id'] = $object_id;
			} else {
				$data['menu-item-type']      = 'post_type';
				$data['menu-item-object']    = get_post_type( $object_id ) ? get_post_type( $object_id ) : $type;
				$data['menu-item-object-id'] = $object_id;
			}
		}

		$id = wp_update_nav_menu_item( $menu_id, 0, $data );
		if ( is_wp_error( $id ) ) {
			throw new AISB_Tool_Error( $id->get_error_message() );
		}
		return (int) $id;
	}

	/**
	 * Menu after editing.
	 *
	 * @param int $menu_id Menu ID.
	 * @return array
	 */
	private static function menu_summary( $menu_id ) {
		$menu = wp_get_nav_menu_object( $menu_id );
		return array(
			'menu_id'    => $menu_id,
			'name'       => $menu ? $menu->name : '',
			'item_count' => count( (array) wp_get_nav_menu_items( $menu_id ) ),
		);
	}

	/**
	 * Read Elementor data.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error When not an Elementor page.
	 */
	public static function get_elementor( $args ) {
		self::require_admin();
		$id   = absint( isset( $args['id'] ) ? $args['id'] : 0 );
		$data = self::elementor_data( $id );

		$widgets = array();
		self::collect_widgets( $data, $widgets );
		return array(
			'id'       => $id,
			'title'    => get_the_title( $id ),
			'widgets'  => $widgets,
			'note'     => 'Edit text with update_elementor using each widget_id. The "text" fields below are what visitors see.',
		);
	}

	/**
	 * Change Elementor text.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On errors.
	 */
	public static function update_elementor( $args ) {
		self::require_admin();
		$id = absint( isset( $args['id'] ) ? $args['id'] : 0 );
		if ( ! current_user_can( 'edit_post', $id ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to edit this page.' );
		}
		$data    = self::elementor_data( $id );
		$changes = isset( $args['changes'] ) && is_array( $args['changes'] ) ? $args['changes'] : array();
		if ( ! $changes ) {
			throw new AISB_Tool_Error( 'Give at least one change.' );
		}

		$wanted = array();
		foreach ( $changes as $change ) {
			if ( isset( $change['widget_id'] ) && isset( $change['text'] ) ) {
				$wanted[ (string) $change['widget_id'] ] = array(
					'field' => isset( $change['field'] ) ? (string) $change['field'] : '',
					'text'  => (string) $change['text'],
				);
			}
		}
		$applied = array();
		$data    = self::apply_widget_text( $data, $wanted, $applied );

		$missing = array_diff( array_keys( $wanted ), $applied );
		if ( $missing ) {
			throw new AISB_Tool_Error( 'These widget IDs were not found on the page: ' . implode( ', ', $missing ) . '. Use get_elementor for the current IDs.' );
		}

		$old_meta  = get_post_meta( $id, '_elementor_data', true );
		$backup_id = AISB_Backup::save( 'elementor', (string) $id, is_string( $old_meta ) ? $old_meta : wp_json_encode( $old_meta ), 'update_elementor' );

		// Elementor stores the data slash-escaped in post meta.
		update_metadata( 'post', $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
		self::clear_elementor_cache( $id );

		return array(
			'id'          => $id,
			'updated'     => array_values( $applied ),
			'backup_id'   => $backup_id,
		);
	}

	/**
	 * Put back an Elementor backup (used by restore_backup).
	 *
	 * @param int    $id        Post ID.
	 * @param string $json      Previous _elementor_data (JSON string).
	 * @param int    $backup_id Backup being restored.
	 * @return array
	 */
	public static function restore_elementor( $id, $json, $backup_id ) {
		self::require_admin();
		if ( ! current_user_can( 'edit_post', $id ) ) {
			throw new AISB_Tool_Error( 'You are not allowed to edit this page.' );
		}
		update_metadata( 'post', $id, '_elementor_data', wp_slash( (string) $json ) );
		self::clear_elementor_cache( $id );
		return array(
			'id'     => $id,
			'kind'   => 'elementor',
			'action' => 'restored',
		);
	}

	/**
	 * Elementor data array for a post.
	 *
	 * @param int $id Post ID.
	 * @return array
	 * @throws AISB_Tool_Error When not Elementor or unreadable.
	 */
	private static function elementor_data( $id ) {
		if ( ! get_post( $id ) ) {
			throw new AISB_Tool_Error( 'No post or page with this ID.' );
		}
		if ( 'builder' !== get_post_meta( $id, '_elementor_edit_mode', true ) ) {
			throw new AISB_Tool_Error( 'This page is not built with Elementor. Use get_content / update_content instead.' );
		}
		$raw  = get_post_meta( $id, '_elementor_data', true );
		$data = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		if ( ! is_array( $data ) ) {
			throw new AISB_Tool_Error( 'Could not read this page\'s Elementor data.' );
		}
		return $data;
	}

	/**
	 * Collect editable text from Elementor widgets.
	 *
	 * @param array $elements Elementor elements.
	 * @param array $widgets  Output.
	 */
	private static function collect_widgets( $elements, &$widgets ) {
		foreach ( (array) $elements as $element ) {
			if ( isset( $element['elType'] ) && 'widget' === $element['elType'] ) {
				$fields = array();
				foreach ( array( 'title', 'editor', 'text', 'caption', 'description_text', 'button_text' ) as $field ) {
					if ( isset( $element['settings'][ $field ] ) && is_string( $element['settings'][ $field ] ) && '' !== trim( wp_strip_all_tags( $element['settings'][ $field ] ) ) ) {
						$fields[ $field ] = $element['settings'][ $field ];
					}
				}
				if ( $fields ) {
					$widgets[] = array(
						'widget_id' => isset( $element['id'] ) ? $element['id'] : '',
						'type'      => isset( $element['widgetType'] ) ? $element['widgetType'] : '',
						'text'      => $fields,
					);
				}
			}
			if ( ! empty( $element['elements'] ) ) {
				self::collect_widgets( $element['elements'], $widgets );
			}
		}
	}

	/**
	 * Apply new text to widgets by ID.
	 *
	 * @param array $elements Elementor elements.
	 * @param array $wanted   widget_id => array( field, text ).
	 * @param array $applied  Output: widget IDs changed.
	 * @return array Updated elements.
	 */
	private static function apply_widget_text( $elements, $wanted, &$applied ) {
		foreach ( $elements as &$element ) {
			$wid = isset( $element['id'] ) ? (string) $element['id'] : '';
			if ( '' !== $wid && isset( $wanted[ $wid ], $element['settings'] ) && is_array( $element['settings'] ) ) {
				$field = $wanted[ $wid ]['field'];
				if ( '' === $field || ! isset( $element['settings'][ $field ] ) ) {
					foreach ( array( 'title', 'editor', 'text', 'caption', 'button_text' ) as $candidate ) {
						if ( isset( $element['settings'][ $candidate ] ) ) {
							$field = $candidate;
							break;
						}
					}
				}
				if ( $field && isset( $element['settings'][ $field ] ) ) {
					$element['settings'][ $field ] = wp_kses_post( $wanted[ $wid ]['text'] );
					$applied[ $wid ]               = $wid;
				}
			}
			if ( ! empty( $element['elements'] ) ) {
				$element['elements'] = self::apply_widget_text( $element['elements'], $wanted, $applied );
			}
		}
		unset( $element );
		return $elements;
	}

	/**
	 * Clear Elementor's cached CSS for a post.
	 *
	 * @param int $id Post ID.
	 */
	private static function clear_elementor_cache( $id ) {
		delete_post_meta( $id, '_elementor_css' );
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	/**
	 * Only administrators.
	 *
	 * @throws AISB_Tool_Error Otherwise.
	 */
	private static function require_admin() {
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			throw new AISB_Tool_Error( 'Only administrators can change the site design.' );
		}
	}
}
