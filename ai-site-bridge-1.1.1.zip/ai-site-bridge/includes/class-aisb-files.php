<?php
/**
 * Theme and plugin files: list, read, search, create, edit and delete.
 *
 * Safety: paths are limited to wp-content/themes and wp-content/plugins (never this plugin's own
 * files), PHP is syntax-checked before saving, the previous version is backed up, and when the
 * file belongs to the active theme or an active plugin the site is loaded again: if the change
 * broke it, the change is undone and the error is returned so it can be fixed.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * File tools.
 */
class AISB_Files {

	/**
	 * Extensions that may be written (text files only).
	 */
	const EDITABLE = array( 'php', 'css', 'scss', 'sass', 'less', 'js', 'mjs', 'json', 'html', 'htm', 'twig', 'txt', 'md', 'svg', 'xml', 'yml', 'yaml', 'pot', 'po' );

	/**
	 * Folders skipped when listing and searching.
	 */
	const SKIP_DIRS = array( '.git', 'node_modules', '.svn' );

	/**
	 * Largest file read in one go without a line range.
	 */
	const MAX_READ = 400000;

	/**
	 * Tool definitions.
	 *
	 * @return array
	 */
	public static function tools() {
		$path = array(
			'type'        => 'string',
			'description' => 'Path inside wp-content, e.g. themes/my-theme/functions.php or plugins/my-plugin/my-plugin.php.',
		);
		return array(
			'list_files'   => array(
				'group'       => 'code',
				'read_only'   => true,
				'title'       => 'List theme or plugin files',
				'description' => 'List the files of a theme or plugin folder (e.g. themes/my-theme). Use "themes" or "plugins" alone to list the installed folders.',
				'properties'  => array( 'path' => $path ),
				'required'    => array( 'path' ),
				'handler'     => array( __CLASS__, 'list_files' ),
			),
			'read_file'    => array(
				'group'       => 'code',
				'read_only'   => true,
				'title'       => 'Read a theme or plugin file',
				'description' => 'Read a text file of a theme or plugin. For long files pass start_line and end_line.',
				'properties'  => array(
					'path'       => $path,
					'start_line' => array( 'type' => 'integer' ),
					'end_line'   => array( 'type' => 'integer' ),
				),
				'required'    => array( 'path' ),
				'handler'     => array( __CLASS__, 'read_file' ),
			),
			'search_files' => array(
				'group'       => 'code',
				'read_only'   => true,
				'title'       => 'Search theme or plugin files',
				'description' => 'Find text in the files of a theme or plugin (case-insensitive). Returns file, line number and the matching line.',
				'properties'  => array(
					'path' => array(
						'type'        => 'string',
						'description' => 'Folder to search, e.g. themes/my-theme.',
					),
					'text' => array( 'type' => 'string' ),
				),
				'required'    => array( 'path', 'text' ),
				'handler'     => array( __CLASS__, 'search_files' ),
			),
			'write_file'   => array(
				'group'       => 'code',
				'title'       => 'Create or replace a file',
				'description' => 'Create a file, or replace a whole file, in a theme or plugin folder (folders are created as needed, so this also creates new themes and plugins). PHP is checked before saving; if the change breaks the live site it is undone and the error is returned. For small changes to an existing file use edit_file.',
				'properties'  => array(
					'path'    => $path,
					'content' => array(
						'type'        => 'string',
						'description' => 'Complete file content.',
					),
				),
				'required'    => array( 'path', 'content' ),
				'destructive' => true,
				'idempotent'  => true,
				'handler'     => array( __CLASS__, 'write_file' ),
			),
			'edit_file'    => array(
				'group'       => 'code',
				'title'       => 'Edit part of a file',
				'description' => 'Replace an exact piece of text in a theme or plugin file. old_text must match exactly (spaces and line breaks too) and appear once, unless replace_all is set. Same safety checks as write_file.',
				'properties'  => array(
					'path'        => $path,
					'old_text'    => array( 'type' => 'string' ),
					'new_text'    => array( 'type' => 'string' ),
					'replace_all' => array( 'type' => 'boolean' ),
				),
				'required'    => array( 'path', 'old_text', 'new_text' ),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'edit_file' ),
			),
			'delete_file'  => array(
				'group'       => 'code',
				'title'       => 'Delete a file',
				'description' => 'Delete one file from a theme or plugin folder (a backup is kept). To remove a whole theme or plugin use manage_theme or manage_plugin.',
				'properties'  => array( 'path' => $path ),
				'required'    => array( 'path' ),
				'destructive' => true,
				'handler'     => array( __CLASS__, 'delete_file' ),
			),
		);
	}

	/**
	 * List files.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On bad paths.
	 */
	public static function list_files( $args ) {
		self::require_admin();
		$path = trim( str_replace( '\\', '/', AISB_Tools::str( $args, 'path' ) ), '/' );
		$path = preg_replace( '#^wp-content/#', '', $path );

		if ( 'themes' === $path || 'plugins' === $path ) {
			$root  = 'themes' === $path ? get_theme_root() : WP_PLUGIN_DIR;
			$items = array();
			foreach ( (array) scandir( $root ) as $name ) {
				if ( '.' !== $name[0] && 'index.php' !== $name ) {
					$items[] = $path . '/' . $name . ( is_dir( $root . '/' . $name ) ? '/' : '' );
				}
			}
			return array( 'items' => $items );
		}

		$info = self::resolve( $path );
		if ( ! is_dir( $info['abs'] ) ) {
			throw new AISB_Tool_Error( is_file( $info['abs'] ) ? 'This is a file: use read_file.' : 'No such folder.' );
		}

		$items = array();
		$total = 0;
		foreach ( self::walk( $info['abs'] ) as $file ) {
			++$total;
			if ( count( $items ) < 500 ) {
				$items[] = array(
					'path' => $info['rel'] . '/' . substr( $file, strlen( $info['abs'] ) + 1 ),
					'size' => filesize( $file ),
				);
			}
		}
		return array(
			'total' => $total,
			'items' => $items,
			'note'  => $total > 500 ? 'Only the first 500 files are listed; list a sub-folder to see more.' : null,
		);
	}

	/**
	 * Read a file.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On bad paths.
	 */
	public static function read_file( $args ) {
		self::require_admin();
		$info = self::resolve( AISB_Tools::str( $args, 'path' ) );
		if ( ! is_file( $info['abs'] ) ) {
			throw new AISB_Tool_Error( 'No such file.' );
		}
		$content = (string) file_get_contents( $info['abs'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false !== strpos( $content, "\0" ) ) {
			throw new AISB_Tool_Error( 'This is a binary file.' );
		}

		$lines = explode( "\n", $content );
		$start = isset( $args['start_line'] ) ? max( 1, (int) $args['start_line'] ) : 1;
		$end   = isset( $args['end_line'] ) ? min( count( $lines ), (int) $args['end_line'] ) : count( $lines );
		$part  = implode( "\n", array_slice( $lines, $start - 1, max( 0, $end - $start + 1 ) ) );
		if ( strlen( $part ) > self::MAX_READ ) {
			throw new AISB_Tool_Error( sprintf( 'The file is too long to read at once (%d lines); pass start_line and end_line.', count( $lines ) ) );
		}

		return array(
			'path'        => $info['rel'],
			'total_lines' => count( $lines ),
			'start_line'  => $start,
			'end_line'    => $end,
			'content'     => $part,
		);
	}

	/**
	 * Search files.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error On bad paths.
	 */
	public static function search_files( $args ) {
		self::require_admin();
		$info = self::resolve( AISB_Tools::str( $args, 'path' ) );
		$text = AISB_Tools::str( $args, 'text' );
		if ( '' === $text ) {
			throw new AISB_Tool_Error( 'Give the text to search for.' );
		}
		$files = is_dir( $info['abs'] ) ? self::walk( $info['abs'] ) : array( $info['abs'] );

		$matches = array();
		foreach ( $files as $file ) {
			if ( ! in_array( strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ), self::EDITABLE, true ) || filesize( $file ) > 2000000 ) {
				continue;
			}
			foreach ( (array) file( $file ) as $number => $line ) {
				if ( false !== stripos( $line, $text ) ) {
					$matches[] = sprintf( '%s:%d: %s', $info['rel'] . substr( $file, strlen( $info['abs'] ) ), $number + 1, mb_substr( trim( $line ), 0, 200 ) );
					if ( count( $matches ) >= 100 ) {
						break 2;
					}
				}
			}
		}
		return array(
			'matches' => $matches,
			'note'    => count( $matches ) >= 100 ? 'Stopped at 100 matches.' : null,
		);
	}

	/**
	 * Create or replace a file.
	 *
	 * @param array $args Arguments.
	 * @return array
	 */
	public static function write_file( $args ) {
		$info = self::resolve( AISB_Tools::str( $args, 'path' ), true );
		if ( ! isset( $args['content'] ) || ! is_string( $args['content'] ) ) {
			throw new AISB_Tool_Error( 'Give the file content.' );
		}
		return self::apply( $info, $args['content'], file_exists( $info['abs'] ) ? 'write_file (replace)' : 'write_file (new)' );
	}

	/**
	 * Replace text in a file.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error When the text isn't found exactly once.
	 */
	public static function edit_file( $args ) {
		$info = self::resolve( AISB_Tools::str( $args, 'path' ), true );
		if ( ! is_file( $info['abs'] ) ) {
			throw new AISB_Tool_Error( 'No such file. Use write_file to create it.' );
		}
		$old = isset( $args['old_text'] ) && is_string( $args['old_text'] ) ? $args['old_text'] : '';
		$new = isset( $args['new_text'] ) && is_string( $args['new_text'] ) ? $args['new_text'] : '';
		if ( '' === $old ) {
			throw new AISB_Tool_Error( 'old_text is empty.' );
		}

		$content = (string) file_get_contents( $info['abs'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$count   = substr_count( $content, $old );
		if ( 0 === $count ) {
			throw new AISB_Tool_Error( 'old_text was not found. It must match the file exactly, including spaces, tabs and line breaks; read_file shows the current text.' );
		}
		if ( $count > 1 && empty( $args['replace_all'] ) ) {
			throw new AISB_Tool_Error( sprintf( 'old_text appears %d times. Include more surrounding text so it is unique, or set replace_all.', $count ) );
		}
		$result             = self::apply( $info, str_replace( $old, $new, $content ), 'edit_file' );
		$result['replaced'] = empty( $args['replace_all'] ) ? 1 : $count;
		return $result;
	}

	/**
	 * Delete a file.
	 *
	 * @param array $args Arguments.
	 * @return array
	 * @throws AISB_Tool_Error When missing.
	 */
	public static function delete_file( $args ) {
		$info = self::resolve( AISB_Tools::str( $args, 'path' ), true );
		if ( ! is_file( $info['abs'] ) ) {
			throw new AISB_Tool_Error( 'No such file.' );
		}
		return self::apply( $info, null, 'delete_file' );
	}

	/**
	 * Put back a backed-up file (used by restore_backup).
	 *
	 * @param string      $path      File path.
	 * @param string|null $content   Content, or null to delete the file.
	 * @param int         $backup_id Backup being restored.
	 * @return array
	 */
	public static function restore( $path, $content, $backup_id ) {
		return self::apply( self::resolve( $path, true ), $content, 'restore_backup #' . $backup_id );
	}

	/**
	 * Save new content (null deletes), with syntax check, backup and site check.
	 *
	 * @param array       $info    Resolved path.
	 * @param string|null $content New content.
	 * @param string      $label   Backup label.
	 * @return array
	 * @throws AISB_Tool_Error When the change is refused or broke the site.
	 */
	private static function apply( $info, $content, $label ) {
		self::require_file_changes();

		$is_php = 'php' === strtolower( pathinfo( $info['abs'], PATHINFO_EXTENSION ) );
		if ( null !== $content && $is_php ) {
			self::lint( $content );
		}
		$old = is_file( $info['abs'] ) ? (string) file_get_contents( $info['abs'] ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( $old === $content ) {
			return array(
				'path'    => $info['rel'],
				'changed' => false,
			);
		}

		$backup_id = AISB_Backup::save( 'file', $info['rel'], $old, $label );
		self::put( $info['abs'], $content );

		$result = array(
			'path'      => $info['rel'],
			'action'    => null === $content ? 'deleted' : ( null === $old ? 'created' : 'updated' ),
			'backup_id' => $backup_id,
		);

		if ( $is_php && self::is_loaded( $info ) ) {
			$check = AISB_Health::check();
			if ( is_string( $check ) ) {
				self::put( $info['abs'], $old );
				$before = AISB_Health::check();
				if ( true === $before || null === $before ) {
					AISB_Backup::delete( $backup_id );
					throw new AISB_Tool_Error( 'This change broke the site, so it was undone automatically (nothing changed). ' . $check );
				}
				// The site fails without the change too: keep it, the error is elsewhere.
				self::put( $info['abs'], $content );
				$result['warning'] = 'The site shows an error that also happens without this change: ' . $check;
			}
			$result['site_check'] = true === $check ? 'passed: the homepage and dashboard still load' : ( null === $check ? 'could not run (the server blocks requests to itself); check the site' : 'site already had an error' );
		}

		if ( 'themes' === $info['area'] ) {
			wp_clean_themes_cache();
		} else {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
			wp_clean_plugins_cache( false );
		}
		return $result;
	}

	/**
	 * Write or delete a file and clear it from the PHP opcode cache.
	 *
	 * @param string      $abs     Absolute path.
	 * @param string|null $content Content, or null to delete.
	 * @throws AISB_Tool_Error When the file can't be written.
	 */
	private static function put( $abs, $content ) {
		if ( null === $content ) {
			if ( is_file( $abs ) && ! unlink( $abs ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				throw new AISB_Tool_Error( 'Could not delete the file (check file permissions).' );
			}
		} else {
			if ( ! wp_mkdir_p( dirname( $abs ) ) || false === file_put_contents( $abs, $content ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				throw new AISB_Tool_Error( 'Could not write the file (check file permissions).' );
			}
		}
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $abs, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- may be restricted by opcache.restrict_api.
		}
		clearstatcache( true, $abs );
	}

	/**
	 * Stop on PHP syntax errors.
	 *
	 * @param string $code PHP source.
	 * @throws AISB_Tool_Error On a syntax error.
	 */
	private static function lint( $code ) {
		try {
			token_get_all( $code, TOKEN_PARSE );
		} catch ( ParseError $e ) {
			throw new AISB_Tool_Error( sprintf( 'PHP syntax error on line %d: %s. Nothing was saved.', $e->getLine(), $e->getMessage() ) );
		}
	}

	/**
	 * Whether a file belongs to code the site runs (active theme or its parent, active plugin).
	 *
	 * @param array $info Resolved path.
	 * @return bool
	 */
	private static function is_loaded( $info ) {
		if ( 'themes' === $info['area'] ) {
			return in_array( $info['slug'], array( get_stylesheet(), get_template() ), true );
		}
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		foreach ( $active as $file ) {
			if ( $file === $info['slug'] || 0 === strpos( $file, $info['slug'] . '/' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Turn a wp-content relative path into a safe absolute path.
	 *
	 * @param string $path  Path such as themes/my-theme/style.css.
	 * @param bool   $write Whether the file will be changed.
	 * @return array abs, rel, area (themes|plugins) and slug (theme or plugin folder).
	 * @throws AISB_Tool_Error On paths outside themes/plugins, or this plugin's own files.
	 */
	private static function resolve( $path, $write = false ) {
		$path  = trim( str_replace( '\\', '/', (string) $path ), '/' );
		$path  = preg_replace( '#^wp-content/#', '', $path );
		$parts = explode( '/', $path );

		if ( count( $parts ) < 2 || ! in_array( $parts[0], array( 'themes', 'plugins' ), true ) ) {
			throw new AISB_Tool_Error( 'Paths start with themes/<theme-folder>/ or plugins/<plugin-folder>/, e.g. themes/my-theme/style.css.' );
		}
		foreach ( $parts as $part ) {
			if ( '' === $part || '.' === $part || '..' === $part || false !== strpos( $part, "\0" ) ) {
				throw new AISB_Tool_Error( 'Invalid path.' );
			}
		}
		if ( 'plugins' === $parts[0] && dirname( plugin_basename( AISB_FILE ) ) === $parts[1] && $write ) {
			throw new AISB_Tool_Error( 'AI Site Bridge cannot change its own files.' );
		}

		$root = wp_normalize_path( 'themes' === $parts[0] ? get_theme_root() : WP_PLUGIN_DIR );
		$abs  = $root . '/' . implode( '/', array_slice( $parts, 1 ) );

		// The closest existing folder must really be inside the themes or plugins folder (no symlink escapes).
		$existing = $abs;
		while ( ! file_exists( $existing ) && strlen( $existing ) > strlen( $root ) ) {
			$existing = dirname( $existing );
		}
		$real_root = realpath( $root );
		$real      = realpath( $existing );
		if ( ! $real_root || ! $real || 0 !== strpos( $real . '/', $real_root . '/' ) ) {
			throw new AISB_Tool_Error( 'This path is outside the themes or plugins folder.' );
		}

		if ( $write ) {
			if ( is_dir( $abs ) ) {
				throw new AISB_Tool_Error( 'This is a folder, not a file.' );
			}
			if ( ! in_array( strtolower( pathinfo( $abs, PATHINFO_EXTENSION ) ), self::EDITABLE, true ) ) {
				throw new AISB_Tool_Error( 'Only text files can be written: ' . implode( ', ', self::EDITABLE ) . '.' );
			}
		}

		return array(
			'abs'  => $abs,
			'rel'  => implode( '/', $parts ),
			'area' => $parts[0],
			'slug' => $parts[1],
		);
	}

	/**
	 * All files below a folder.
	 *
	 * @param string $dir Folder.
	 * @return string[]
	 */
	private static function walk( $dir ) {
		$files = array();
		$it    = new RecursiveIteratorIterator(
			new RecursiveCallbackFilterIterator(
				new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
				static function ( $current ) {
					return ! ( $current->isDir() && in_array( $current->getFilename(), self::SKIP_DIRS, true ) );
				}
			)
		);
		foreach ( $it as $file ) {
			if ( $file->isFile() ) {
				$files[] = wp_normalize_path( $file->getPathname() );
			}
		}
		sort( $files );
		return $files;
	}

	/**
	 * Only administrators may work with code.
	 *
	 * @throws AISB_Tool_Error Otherwise.
	 */
	public static function require_admin() {
		if ( ! current_user_can( 'manage_options' ) || ( is_multisite() && ! is_super_admin() ) ) {
			throw new AISB_Tool_Error( 'Only administrators can work with theme and plugin files.' );
		}
	}

	/**
	 * Stop when files can't be changed on this server.
	 *
	 * @throws AISB_Tool_Error When file changes are disabled or need FTP details.
	 */
	public static function require_file_changes() {
		self::require_admin();
		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			throw new AISB_Tool_Error( 'File changes are disabled on this site (DISALLOW_FILE_MODS in wp-config.php).' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( 'direct' !== get_filesystem_method() ) {
			throw new AISB_Tool_Error( 'This server only allows file changes with FTP details, which AI Site Bridge does not support. Ask the host to let WordPress write its files directly (FS_METHOD "direct").' );
		}
	}
}
