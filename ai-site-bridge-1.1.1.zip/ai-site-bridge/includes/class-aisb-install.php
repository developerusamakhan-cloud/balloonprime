<?php
/**
 * Activation, DB schema and daily cleanup.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Creates the tables and removes expired data.
 */
class AISB_Install {

	const CRON_HOOK = 'aisb_daily_cleanup';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'cleanup' ) );
	}

	/**
	 * Activation hook.
	 */
	public static function activate() {
		self::create_tables();
		if ( false === get_option( AISB_Settings::OPTION ) ) {
			add_option( AISB_Settings::OPTION, AISB_Settings::defaults() );
		}
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Deactivation hook.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * Re-run schema when the DB version changes (covers updates without re-activation).
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'aisb_db_version' ) !== AISB_DB_VERSION ) {
			self::create_tables();
		}
	}

	/**
	 * Create or update the tables.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}aisb_clients (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				client_id varchar(64) NOT NULL,
				secret_hash varchar(64) NOT NULL DEFAULT '',
				auth_method varchar(32) NOT NULL DEFAULT 'none',
				client_name varchar(191) NOT NULL DEFAULT '',
				redirect_uris text NOT NULL,
				created_at int(10) unsigned NOT NULL DEFAULT 0,
				last_used_at int(10) unsigned NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY client_id (client_id)
			) $charset;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}aisb_tokens (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				token_hash char(64) NOT NULL,
				type varchar(16) NOT NULL,
				client_id varchar(64) NOT NULL,
				user_id bigint(20) unsigned NOT NULL,
				data text NULL,
				created_at int(10) unsigned NOT NULL DEFAULT 0,
				expires_at int(10) unsigned NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY client_user (client_id,user_id),
				KEY expires_at (expires_at)
			) $charset;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}aisb_log (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created_at int(10) unsigned NOT NULL DEFAULT 0,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				client_id varchar(64) NOT NULL DEFAULT '',
				tool varchar(64) NOT NULL DEFAULT '',
				object_id bigint(20) unsigned NOT NULL DEFAULT 0,
				summary varchar(255) NOT NULL DEFAULT '',
				status varchar(16) NOT NULL DEFAULT 'ok',
				PRIMARY KEY  (id),
				KEY created_at (created_at)
			) $charset;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}aisb_backups (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created_at int(10) unsigned NOT NULL DEFAULT 0,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				client_id varchar(64) NOT NULL DEFAULT '',
				kind varchar(16) NOT NULL DEFAULT '',
				target varchar(255) NOT NULL DEFAULT '',
				label varchar(255) NOT NULL DEFAULT '',
				existed tinyint(1) NOT NULL DEFAULT 1,
				content longtext NULL,
				PRIMARY KEY  (id),
				KEY created_at (created_at),
				KEY target (target)
			) $charset;"
		);

		update_option( 'aisb_db_version', AISB_DB_VERSION );
	}

	/**
	 * Daily: drop expired codes and tokens, old log rows and abandoned app registrations.
	 */
	public static function cleanup() {
		AISB_Store::delete_expired();
		AISB_Log::prune();
		AISB_Backup::prune();
	}
}
