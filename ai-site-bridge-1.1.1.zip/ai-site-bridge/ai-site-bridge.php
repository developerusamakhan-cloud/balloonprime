<?php
/**
 * Plugin Name:       AI Site Bridge
 * Plugin URI:        https://github.com/khalidupwork/Plugins
 * Description:       Connect this site to an AI chat assistant (Claude or any MCP client) so it can manage posts, pages, media, comments and site settings from the chat. Secure WordPress login, per-feature permissions and an activity log.
 * Version:           1.1.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-site-bridge
 * Domain Path:       /languages
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

define( 'AISB_VERSION', '1.1.1' );
define( 'AISB_DB_VERSION', '1.1.0' );
define( 'AISB_FILE', __FILE__ );
define( 'AISB_PATH', plugin_dir_path( __FILE__ ) );
define( 'AISB_URL', plugin_dir_url( __FILE__ ) );

require_once AISB_PATH . 'includes/class-aisb-settings.php';
require_once AISB_PATH . 'includes/class-aisb-install.php';
require_once AISB_PATH . 'includes/class-aisb-store.php';
require_once AISB_PATH . 'includes/class-aisb-log.php';
require_once AISB_PATH . 'includes/class-aisb-backup.php';
require_once AISB_PATH . 'includes/class-aisb-health.php';
require_once AISB_PATH . 'includes/class-aisb-router.php';
require_once AISB_PATH . 'includes/class-aisb-oauth.php';
require_once AISB_PATH . 'includes/class-aisb-files.php';
require_once AISB_PATH . 'includes/class-aisb-design.php';
require_once AISB_PATH . 'includes/class-aisb-packages.php';
require_once AISB_PATH . 'includes/class-aisb-tools.php';
require_once AISB_PATH . 'includes/class-aisb-mcp.php';
require_once AISB_PATH . 'includes/class-aisb-admin.php';

// The health check marks fatal errors on its own loopback requests; must run as the file loads.
AISB_Health::init();

register_activation_hook( __FILE__, array( 'AISB_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AISB_Install', 'deactivate' ) );

add_action(
	'init',
	static function () {
		load_plugin_textdomain( 'ai-site-bridge', false, dirname( plugin_basename( AISB_FILE ) ) . '/languages' );
	}
);

add_action(
	'plugins_loaded',
	static function () {
		AISB_Install::maybe_upgrade();
		AISB_Install::init();
		AISB_Router::init();

		if ( is_admin() ) {
			AISB_Admin::init();
		}
	}
);
