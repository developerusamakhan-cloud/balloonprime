<?php
/**
 * Connection approval page (and its error state).
 *
 * Variables: $error (string, error state) or $client, $req, $user, $host, $groups, $action,
 * $nonce; optional $switch_url.
 *
 * @package AISiteBridge
 */

defined( 'ABSPATH' ) || exit;

$aisb_site  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
$aisb_icon  = get_site_icon_url( 96 );
$aisb_roles = array();
if ( isset( $user ) ) {
	$aisb_names = wp_roles()->role_names;
	foreach ( $user->roles as $aisb_role ) {
		$aisb_roles[] = isset( $aisb_names[ $aisb_role ] ) ? translate_user_role( $aisb_names[ $aisb_role ] ) : $aisb_role;
	}
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Connect an AI app to %s', 'ai-site-bridge' ), $aisb_site ) ); ?></title>
<style>
	:root { --bg: #f0f2f5; --card: #fff; --text: #1d2327; --muted: #50575e; --line: #dcdcde; --accent: #2271b1; --accent-text: #fff; --warn: #fcf9e8; --warn-line: #dba617; --err: #fcf0f1; --err-line: #d63638; }
	@media (prefers-color-scheme: dark) {
		:root { --bg: #101517; --card: #1d2327; --text: #f0f0f1; --muted: #a7aaad; --line: #3c434a; --accent: #72aee6; --accent-text: #101517; --warn: #2b2610; --warn-line: #dba617; --err: #2c1416; --err-line: #f86368; }
	}
	* { box-sizing: border-box; }
	body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px 16px; background: var(--bg); color: var(--text); font: 15px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
	.card { width: 100%; max-width: 440px; background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 28px; }
	.site { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
	.site img { width: 40px; height: 40px; border-radius: 8px; }
	.site strong { font-size: 16px; }
	.site span { display: block; color: var(--muted); font-size: 13px; }
	h1 { font-size: 20px; line-height: 1.3; margin: 0 0 12px; }
	p { margin: 0 0 14px; }
	ul { margin: 0 0 16px; padding: 0; list-style: none; }
	li { padding: 8px 0 8px 26px; border-top: 1px solid var(--line); position: relative; }
	li::before { content: "✓"; position: absolute; left: 4px; color: var(--accent); font-weight: 700; }
	li small { display: block; color: var(--muted); }
	.note { background: var(--warn); border-left: 4px solid var(--warn-line); padding: 10px 12px; border-radius: 4px; font-size: 14px; margin-bottom: 18px; }
	.error { background: var(--err); border-left: 4px solid var(--err-line); padding: 12px; border-radius: 4px; }
	.actions { display: flex; gap: 10px; }
	button { flex: 1; font: inherit; font-weight: 600; padding: 11px 14px; border-radius: 8px; cursor: pointer; border: 1px solid var(--line); background: transparent; color: var(--text); }
	button.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-text); }
	.muted { color: var(--muted); font-size: 13px; margin-top: 16px; }
	a { color: var(--accent); }
</style>
</head>
<body>
<main class="card">
	<div class="site">
		<?php if ( $aisb_icon ) : ?>
			<img src="<?php echo esc_url( $aisb_icon ); ?>" alt="">
		<?php endif; ?>
		<div>
			<strong><?php echo esc_html( $aisb_site ); ?></strong>
			<span><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?></span>
		</div>
	</div>

	<?php if ( isset( $error ) ) : ?>
		<h1><?php esc_html_e( 'Can’t connect', 'ai-site-bridge' ); ?></h1>
		<p class="error"><?php echo wp_kses( $error, array( 'strong' => array() ) ); ?></p>
		<?php if ( ! empty( $switch_url ) ) : ?>
			<p class="muted"><a href="<?php echo esc_url( $switch_url ); ?>"><?php esc_html_e( 'Log in with another account', 'ai-site-bridge' ); ?></a></p>
		<?php endif; ?>
	<?php else : ?>
		<h1>
			<?php
			/* translators: %s: app name */
			echo esc_html( sprintf( __( '%s wants to manage this site', 'ai-site-bridge' ), $client['client_name'] ) );
			?>
		</h1>
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: user display name, 2: role names */
					__( 'It will act as you (%1$s, %2$s) and can only do what your account is allowed to do:', 'ai-site-bridge' ),
					$user->display_name,
					implode( ', ', $aisb_roles )
				)
			);
			?>
		</p>
		<ul>
			<?php foreach ( $groups as $aisb_group ) : ?>
				<li><?php echo esc_html( $aisb_group[0] ); ?><small><?php echo esc_html( $aisb_group[1] ); ?></small></li>
			<?php endforeach; ?>
		</ul>
		<p class="note">
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: host name */
					__( 'After approving you will return to %s. Only approve if you started this connection there yourself.', 'ai-site-bridge' ),
					'<strong>' . esc_html( $host ) . '</strong>'
				),
				array( 'strong' => array() )
			);
			?>
		</p>
		<form method="post" action="<?php echo esc_url( $action ); ?>">
			<?php foreach ( $req as $aisb_key => $aisb_value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $aisb_key ); ?>" value="<?php echo esc_attr( $aisb_value ); ?>">
			<?php endforeach; ?>
			<input type="hidden" name="_aisb_nonce" value="<?php echo esc_attr( $nonce ); ?>">
			<div class="actions">
				<button type="submit" name="deny" value="1"><?php esc_html_e( 'Cancel', 'ai-site-bridge' ); ?></button>
				<button type="submit" name="approve" value="1" class="primary"><?php esc_html_e( 'Approve', 'ai-site-bridge' ); ?></button>
			</div>
		</form>
		<p class="muted">
			<?php esc_html_e( 'You can disconnect at any time under AI Site Bridge in the dashboard.', 'ai-site-bridge' ); ?>
			<a href="<?php echo esc_url( $switch_url ); ?>"><?php esc_html_e( 'Not you?', 'ai-site-bridge' ); ?></a>
		</p>
	<?php endif; ?>
</main>
</body>
</html>
