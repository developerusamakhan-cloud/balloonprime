<?php
/**
 * Uninstall: removes the tables (apps, tokens, log) and settings, which also disconnects every app.
 *
 * @package AISiteBridge
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

foreach ( array( 'aisb_clients', 'aisb_tokens', 'aisb_log', 'aisb_backups' ) as $aisb_table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$aisb_table}" ); // phpcs:ignore WordPress.DB
}
delete_option( 'aisb_settings' );
delete_option( 'aisb_db_version' );
delete_transient( 'aisb_discovery_check' );
wp_clear_scheduled_hook( 'aisb_daily_cleanup' );
