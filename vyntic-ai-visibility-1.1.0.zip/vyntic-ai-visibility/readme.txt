=== Vyntic AI Visibility ===
Contributors: vyntic
Author: Vyntic Studio
Author URI: https://vyntic.studio/
Plugin URI: https://vyntic.studio/plugins/vyntic-ai-visibility/
Tags: ai visibility, chatgpt, generative engine optimization, llms.txt, brand monitoring
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

See how often ChatGPT, Claude, Gemini and Perplexity mention and cite your business, which competitors they recommend instead, and what to do about it.

== Description ==

AI assistants now answer questions like "who is the best dentist in Austin?" directly. This plugin tracks whether those answers include you.

How it works:

1. You add the questions ("prompts") your customers ask AI, or let AI suggest them.
2. On a schedule (or when you click "Run check now") the plugin sends every prompt to every enabled AI engine through its official API, with web search turned on so the answers match what the consumer apps show.
3. Each answer is analysed:
   * **Mention**: is your brand name (or an alias / your domain) in the answer?
   * **Position**: are you named first, second, third… compared with your competitors?
   * **Citation**: does the answer link to your website?
   * **Sentiment**: are the sentences about you positive, neutral or negative?
   * **Competitors**: which competitors are named or cited?
   * **Sources**: which websites the AI used.
4. The dashboard shows AI Visibility %, Citation %, average position, net sentiment, a trend chart, results per engine, share of voice vs. competitors, the sources AI cites most, and a prioritised list of **opportunities**:
   * prompts where competitors are recommended but you are not,
   * prompts where AI describes you negatively,
   * prompts where you are mentioned but another site is linked,
   * third-party sites AI keeps citing (outreach / listing targets),
   * AI crawlers blocked in robots.txt, missing llms.txt.

Extras:

* **AI Crawlers check**: shows whether robots.txt blocks GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-SearchBot, PerplexityBot, Google-Extended, Bingbot and more, and explains which ones matter for AI answers.
* **llms.txt generator**: serves `/llms.txt` built from your pages, products and posts.
* **Responses log**: read every AI answer with its sources, filter by prompt, engine and mentioned / not mentioned.

The plugin is free. You bring your own API keys and pay the AI providers directly (usually a fraction of a cent to a few cents per check). Nothing is sent to any other server.

== Installation ==

1. In WordPress go to Plugins, Add New, Upload Plugin, choose `vyntic-ai-visibility.zip` and activate.
2. Open **Vyntic, AI Visibility, Settings** (or **AI Visibility** when it is your only Vyntic plugin): enter your brand name, other spellings, domain, a short description and your competitors (`Name | domain.com`, one per line).
3. Enable at least one engine and paste its API key:
   * ChatGPT: https://platform.openai.com/api-keys
   * Claude: https://platform.claude.com/settings/keys
   * Gemini: https://aistudio.google.com/app/apikey
   * Perplexity: https://www.perplexity.ai/account/api/keys
4. Open the **Prompts** tab, add 10 to 20 questions (or click "Suggest prompts with AI") and click "Run all prompts now".
5. Open the **Dashboard** tab. Checks repeat weekly by default (Settings, Automatic checks).

Updates arrive automatically from vyntic.studio, like every Vyntic plugin.

== Frequently Asked Questions ==

= Why do results differ from what I see in ChatGPT? =

AI answers vary between runs, locations and accounts. Track the trend over several checks rather than one answer, and use enough prompts (10+) for meaningful percentages.

= How much does it cost? =

Checks per run = active prompts × enabled engines. 20 prompts × 4 engines weekly is 80 API calls per week. Pick cheaper models in Settings to lower cost.

= Can I change the models? =

Yes, each engine has a model field. The engine must support web search through its API (e.g. OpenAI models that support the `web_search` tool, Perplexity `sonar` / `sonar-pro`).

= Does WP-Cron need to run? =

Scheduled checks use WP-Cron, which runs when your site gets visits. On low-traffic sites set up a real cron job that calls `wp-cron.php`. Manual checks from the admin always work.

= I used "AI Visibility Tracker" before. Do I lose my data? =

No. Vyntic AI Visibility uses the same prompts, results and settings. Deactivate and delete the old plugin, then activate this one; everything is still there.

= Is my API key sent anywhere else? =

No. Keys are stored in your WordPress database and sent only to the AI provider you enabled. Nothing goes to Vyntic Studio.

== Changelog ==

= 1.1.0 (2026-10-13) =
* Now part of the Vyntic plugin family: one "AI Visibility" item in the shared Vyntic menu, with Dashboard, Prompts, Responses, AI Crawlers and Settings as tabs.
* New look in Vyntic Studio colours.
* Automatic updates from vyntic.studio, with an Updates tab.
* Data from "AI Visibility Tracker" carries over unchanged. Running both at once is blocked with a clear notice instead of an error.

= 1.0.0 (2026-09-22) =
* First release: AI visibility, citation and sentiment tracking across ChatGPT, Claude, Gemini and Perplexity, competitor share of voice, opportunities, AI crawler check and llms.txt generator.
