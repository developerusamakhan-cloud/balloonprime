<?php
/**
 * Checks whether robots.txt lets AI crawlers in.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * AI crawler access checker.
 */
class AIVT_Crawlers {

	const CACHE = 'aivt_robots_txt';

	/**
	 * Known AI user agents.
	 *
	 * "search" bots fetch pages when a user asks a question; blocking them removes you from answers.
	 * The others collect training data; blocking them is a business choice.
	 *
	 * @return array[] Each: agent, owner, purpose, search.
	 */
	public static function bots() {
		return array(
			array( 'agent' => 'OAI-SearchBot', 'owner' => 'OpenAI', 'purpose' => __( 'ChatGPT search results', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'ChatGPT-User', 'owner' => 'OpenAI', 'purpose' => __( 'Pages opened by ChatGPT for a user', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'GPTBot', 'owner' => 'OpenAI', 'purpose' => __( 'Model training', 'vyntic-ai-visibility' ), 'search' => false ),
			array( 'agent' => 'Claude-SearchBot', 'owner' => 'Anthropic', 'purpose' => __( 'Claude search results', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'Claude-User', 'owner' => 'Anthropic', 'purpose' => __( 'Pages opened by Claude for a user', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'ClaudeBot', 'owner' => 'Anthropic', 'purpose' => __( 'Model training', 'vyntic-ai-visibility' ), 'search' => false ),
			array( 'agent' => 'PerplexityBot', 'owner' => 'Perplexity', 'purpose' => __( 'Perplexity search index', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'Perplexity-User', 'owner' => 'Perplexity', 'purpose' => __( 'Pages opened by Perplexity for a user', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'Googlebot', 'owner' => 'Google', 'purpose' => __( 'Google Search & AI Overviews', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'Google-Extended', 'owner' => 'Google', 'purpose' => __( 'Gemini training & grounding', 'vyntic-ai-visibility' ), 'search' => false ),
			array( 'agent' => 'Bingbot', 'owner' => 'Microsoft', 'purpose' => __( 'Bing & Copilot answers', 'vyntic-ai-visibility' ), 'search' => true ),
			array( 'agent' => 'Applebot-Extended', 'owner' => 'Apple', 'purpose' => __( 'Apple Intelligence training', 'vyntic-ai-visibility' ), 'search' => false ),
			array( 'agent' => 'meta-externalagent', 'owner' => 'Meta', 'purpose' => __( 'Meta AI training', 'vyntic-ai-visibility' ), 'search' => false ),
			array( 'agent' => 'CCBot', 'owner' => 'Common Crawl', 'purpose' => __( 'Open dataset used by many AI models', 'vyntic-ai-visibility' ), 'search' => false ),
		);
	}

	/**
	 * Current robots.txt contents (cached for 12 hours).
	 *
	 * @param bool $refresh Ignore the cache.
	 * @return string
	 */
	public static function robots_txt( $refresh = false ) {
		$cached = get_transient( self::CACHE );
		if ( ! $refresh && false !== $cached ) {
			return $cached;
		}

		$body = '';
		if ( file_exists( ABSPATH . 'robots.txt' ) ) {
			$body = (string) file_get_contents( ABSPATH . 'robots.txt' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} else {
			$response = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 10 ) );
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$body = wp_remote_retrieve_body( $response );
			} else {
				// Loopback failed: rebuild WordPress' virtual robots.txt.
				$public = (string) get_option( 'blog_public' );
				$body   = "User-agent: *\n" . ( '0' === $public ? "Disallow: /\n" : "Disallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n" );
				$body   = (string) apply_filters( 'robots_txt', $body, $public ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
			}
		}

		set_transient( self::CACHE, $body, 12 * HOUR_IN_SECONDS );
		return $body;
	}

	/**
	 * Status of every known bot.
	 *
	 * @param bool $refresh Re-fetch robots.txt.
	 * @return array[] Bot rows plus "blocked" and "rule" (which group matched).
	 */
	public static function check( $refresh = false ) {
		$groups = self::parse( self::robots_txt( $refresh ) );
		$out    = array();
		foreach ( self::bots() as $bot ) {
			$agent = strtolower( $bot['agent'] );
			$group = null;
			$rule  = '';
			if ( isset( $groups[ $agent ] ) ) {
				$group = $groups[ $agent ];
				$rule  = $bot['agent'];
			} elseif ( isset( $groups['*'] ) ) {
				$group = $groups['*'];
				$rule  = '*';
			}
			$bot['blocked'] = $group ? self::blocks_root( $group ) : false;
			$bot['rule']    = $rule;
			$out[]          = $bot;
		}
		return $out;
	}

	/**
	 * Names of blocked answer/search bots (the ones that hurt AI visibility).
	 *
	 * @return string[]
	 */
	public static function blocked_bots() {
		$out = array();
		foreach ( self::check() as $bot ) {
			if ( $bot['search'] && $bot['blocked'] ) {
				$out[] = $bot['agent'];
			}
		}
		return $out;
	}

	/**
	 * Parse robots.txt into user-agent => rules.
	 *
	 * @param string $robots File contents.
	 * @return array lower-case agent => array of [directive, path].
	 */
	private static function parse( $robots ) {
		$groups  = array();
		$agents  = array();
		$in_rules = false;

		foreach ( preg_split( '/\r\n|\r|\n/', $robots ) as $line ) {
			$line = trim( preg_replace( '/#.*$/', '', $line ) );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $field, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$field                 = strtolower( $field );

			if ( 'user-agent' === $field ) {
				if ( $in_rules ) {
					$agents   = array();
					$in_rules = false;
				}
				$agents[] = strtolower( $value );
				if ( ! isset( $groups[ strtolower( $value ) ] ) ) {
					$groups[ strtolower( $value ) ] = array();
				}
			} elseif ( in_array( $field, array( 'allow', 'disallow' ), true ) ) {
				$in_rules = true;
				foreach ( $agents as $agent ) {
					$groups[ $agent ][] = array( $field, $value );
				}
			}
		}
		return $groups;
	}

	/**
	 * Whether a group blocks the homepage ("Disallow: /" without "Allow: /").
	 *
	 * @param array $rules Rules.
	 * @return bool
	 */
	private static function blocks_root( array $rules ) {
		$blocked = false;
		foreach ( $rules as $rule ) {
			if ( '/' === $rule[1] || '/*' === $rule[1] ) {
				if ( 'allow' === $rule[0] ) {
					return false;
				}
				$blocked = true;
			}
		}
		return $blocked;
	}
}
