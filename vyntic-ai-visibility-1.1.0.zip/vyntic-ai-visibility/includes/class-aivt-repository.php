<?php
/**
 * Database access for prompts and results.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

/**
 * CRUD helpers.
 */
class AIVT_Repository {

	/* ---------------------------------------------------------------------
	 * Prompts
	 * ------------------------------------------------------------------- */

	/**
	 * All prompts, newest first.
	 *
	 * @param bool $active_only Only active prompts.
	 * @return object[]
	 */
	public static function prompts( $active_only = false ) {
		global $wpdb;
		$table = AIVT_Install::prompts_table();
		$where = $active_only ? 'WHERE active = 1' : '';
		return $wpdb->get_results( "SELECT * FROM {$table} {$where} ORDER BY id DESC" );
	}

	/**
	 * One prompt.
	 *
	 * @param int $id Prompt ID.
	 * @return object|null
	 */
	public static function prompt( $id ) {
		global $wpdb;
		$table = AIVT_Install::prompts_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
	}

	/**
	 * Add a prompt unless the same text already exists.
	 *
	 * @param string $prompt Prompt text.
	 * @param string $tag    Optional tag / topic.
	 * @return int|false Insert ID, or false when skipped.
	 */
	public static function add_prompt( $prompt, $tag = '' ) {
		global $wpdb;
		$table  = AIVT_Install::prompts_table();
		$prompt = trim( $prompt );
		if ( '' === $prompt ) {
			return false;
		}
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE prompt = %s", $prompt ) );
		if ( $exists ) {
			return false;
		}
		$wpdb->insert(
			$table,
			array(
				'prompt'     => $prompt,
				'tag'        => $tag,
				'active'     => 1,
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Toggle a prompt's active flag.
	 *
	 * @param int  $id     Prompt ID.
	 * @param bool $active New state.
	 */
	public static function set_prompt_active( $id, $active ) {
		global $wpdb;
		$wpdb->update( AIVT_Install::prompts_table(), array( 'active' => $active ? 1 : 0 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
	}

	/**
	 * Delete a prompt and its results.
	 *
	 * @param int $id Prompt ID.
	 */
	public static function delete_prompt( $id ) {
		global $wpdb;
		$wpdb->delete( AIVT_Install::prompts_table(), array( 'id' => $id ), array( '%d' ) );
		$wpdb->delete( AIVT_Install::results_table(), array( 'prompt_id' => $id ), array( '%d' ) );
	}

	/* ---------------------------------------------------------------------
	 * Results
	 * ------------------------------------------------------------------- */

	/**
	 * Store one analysed answer.
	 *
	 * @param array $row Column => value.
	 * @return int Insert ID.
	 */
	public static function add_result( array $row ) {
		global $wpdb;
		$row = wp_parse_args(
			$row,
			array(
				'prompt_id'       => 0,
				'engine'          => '',
				'model'           => '',
				'status'          => 'ok',
				'response'        => '',
				'brand_mentioned' => 0,
				'brand_position'  => null,
				'brand_cited'     => 0,
				'sentiment'       => '',
				'sentiment_score' => null,
				'competitors'     => array(),
				'citations'       => array(),
				'error'           => '',
				'created_at'      => current_time( 'mysql', true ),
			)
		);

		$row['competitors'] = wp_json_encode( array_values( (array) $row['competitors'] ) );
		$row['citations']   = wp_json_encode( array_values( (array) $row['citations'] ) );

		// NULL columns are left out so MySQL stores NULL instead of 0.
		foreach ( array( 'brand_position', 'sentiment_score' ) as $nullable ) {
			if ( null === $row[ $nullable ] ) {
				unset( $row[ $nullable ] );
			}
		}

		$wpdb->insert( AIVT_Install::results_table(), $row );
		return (int) $wpdb->insert_id;
	}

	/**
	 * Successful results since a date, with JSON columns decoded.
	 *
	 * @param string $since GMT datetime.
	 * @return object[]
	 */
	public static function results_since( $since ) {
		global $wpdb;
		$table = AIVT_Install::results_table();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, prompt_id, engine, model, brand_mentioned, brand_position, brand_cited, sentiment, sentiment_score, competitors, citations, created_at
				FROM {$table} WHERE status = 'ok' AND created_at >= %s ORDER BY created_at ASC",
				$since
			)
		);
		return array_map( array( __CLASS__, 'decode' ), $rows );
	}

	/**
	 * Latest result for every prompt + engine pair.
	 *
	 * @return object[]
	 */
	public static function latest_results() {
		global $wpdb;
		$table = AIVT_Install::results_table();
		$rows  = $wpdb->get_results(
			"SELECT r.* FROM {$table} r
			INNER JOIN ( SELECT MAX(id) AS id FROM {$table} GROUP BY prompt_id, engine ) m ON m.id = r.id"
		);
		return array_map( array( __CLASS__, 'decode' ), $rows );
	}

	/**
	 * Paged results list for the Responses screen.
	 *
	 * @param array $args engine, prompt_id, mentioned ('' | '1' | '0'), page, per_page.
	 * @return array rows, total.
	 */
	public static function results_page( array $args ) {
		global $wpdb;
		$table   = AIVT_Install::results_table();
		$where   = array( '1=1' );
		$params  = array();

		if ( ! empty( $args['engine'] ) ) {
			$where[]  = 'engine = %s';
			$params[] = $args['engine'];
		}
		if ( ! empty( $args['prompt_id'] ) ) {
			$where[]  = 'prompt_id = %d';
			$params[] = (int) $args['prompt_id'];
		}
		if ( isset( $args['mentioned'] ) && '' !== $args['mentioned'] ) {
			$where[]  = "status = 'ok' AND brand_mentioned = %d";
			$params[] = (int) $args['mentioned'];
		}

		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( max( 1, (int) $args['page'] ) - 1 ) * $per_page;
		$sql_where = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$sql_where}";
		$list_sql  = "SELECT * FROM {$table} WHERE {$sql_where} ORDER BY id DESC LIMIT %d OFFSET %d";

		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $params, array( $per_page, $offset ) ) ) );

		return array(
			'rows'  => array_map( array( __CLASS__, 'decode' ), $rows ),
			'total' => $total,
		);
	}

	/**
	 * Delete results older than N days.
	 *
	 * @param int $days Days to keep.
	 */
	public static function purge( $days ) {
		global $wpdb;
		$table = AIVT_Install::results_table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * (int) $days ) ) );
	}

	/**
	 * Decode JSON columns.
	 *
	 * @param object $row Row.
	 * @return object
	 */
	private static function decode( $row ) {
		foreach ( array( 'competitors', 'citations' ) as $col ) {
			if ( property_exists( $row, $col ) ) {
				$decoded     = json_decode( (string) $row->$col, true );
				$row->$col   = is_array( $decoded ) ? $decoded : array();
			}
		}
		return $row;
	}
}
