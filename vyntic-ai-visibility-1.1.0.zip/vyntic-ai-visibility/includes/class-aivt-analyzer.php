<?php
/**
 * Turns an AI answer into visibility metrics.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Detects brand mentions, list position, citations, competitors and sentiment.
 */
class AIVT_Analyzer {

	/**
	 * Words that signal a positive opinion.
	 *
	 * @var string[]
	 */
	private static $positive = array(
		'best', 'top', 'leading', 'excellent', 'great', 'good', 'trusted', 'reliable', 'reputable', 'recommended', 'recommend',
		'popular', 'favorite', 'favourite', 'affordable', 'innovative', 'outstanding', 'strong', 'easy', 'helpful', 'fast',
		'quality', 'professional', 'experienced', 'expert', 'award', 'awarded', 'well-known', 'established', 'transparent',
		'secure', 'safe', 'friendly', 'responsive', 'efficient', 'effective', 'impressive', 'solid', 'loved', 'praised',
		'positive', 'value', 'standout', 'notable', 'premier', 'ideal', 'excellent', 'superior', 'satisfied', 'flexible',
	);

	/**
	 * Words that signal a negative opinion.
	 *
	 * @var string[]
	 */
	private static $negative = array(
		'bad', 'poor', 'worst', 'expensive', 'overpriced', 'scam', 'complaint', 'complaints', 'unreliable', 'slow', 'difficult',
		'hidden', 'lawsuit', 'controversy', 'controversial', 'negative', 'limited', 'lacks', 'lacking', 'issue', 'issues',
		'problem', 'problems', 'unresponsive', 'outdated', 'avoid', 'warning', 'risky', 'fraud', 'misleading', 'disappointing',
		'mixed', 'criticized', 'criticised', 'downside', 'downsides', 'drawback', 'drawbacks', 'concern', 'concerns', 'weak',
		'confusing', 'rude', 'delay', 'delays', 'unclear', 'costly', 'fees',
	);

	/**
	 * Words that flip the next opinion word.
	 *
	 * @var string[]
	 */
	private static $negations = array( 'not', 'no', 'never', 'without', "isn't", "aren't", "wasn't", "don't", "doesn't", 'hardly', 'lack' );

	/**
	 * Analyse one answer.
	 *
	 * @param string $text      Answer text.
	 * @param array  $citations Citations (url, title, domain).
	 * @return array Columns for AIVT_Repository::add_result().
	 */
	public static function analyze( $text, array $citations ) {
		$text        = (string) $text;
		$brand_terms = AIVT_Settings::brand_terms();
		$domain      = AIVT_Settings::get( 'brand_domain' );
		if ( $domain ) {
			$brand_terms[] = $domain;
		}

		$brand_offset = self::first_offset( $text, $brand_terms );

		// Position among all brands named in the answer (1 = named first).
		$offsets     = array();
		$competitors = array();
		foreach ( AIVT_Settings::competitors() as $competitor ) {
			$terms = array( $competitor['name'] );
			if ( $competitor['domain'] ) {
				$terms[] = $competitor['domain'];
			}
			$offset = self::first_offset( $text, $terms );
			if ( null === $offset && $competitor['domain'] && self::cites_domain( $citations, $competitor['domain'] ) ) {
				$competitors[] = $competitor['name'];
				continue;
			}
			if ( null !== $offset ) {
				$competitors[] = $competitor['name'];
				$offsets[]     = $offset;
			}
		}

		$position = null;
		if ( null !== $brand_offset ) {
			$position = 1;
			foreach ( $offsets as $offset ) {
				if ( $offset < $brand_offset ) {
					++$position;
				}
			}
		}

		$cited = $domain && self::cites_domain( $citations, $domain );

		$sentiment = array(
			'label' => '',
			'score' => null,
		);
		if ( null !== $brand_offset ) {
			$sentiment = self::sentiment( $text, $brand_terms );
		}

		return array(
			'brand_mentioned' => null !== $brand_offset ? 1 : 0,
			'brand_position'  => $position,
			'brand_cited'     => $cited ? 1 : 0,
			'sentiment'       => $sentiment['label'],
			'sentiment_score' => $sentiment['score'],
			'competitors'     => $competitors,
		);
	}

	/**
	 * Does any citation point at a domain (or its subdomains)?
	 *
	 * @param array  $citations Citations.
	 * @param string $domain    Domain without www.
	 * @return bool
	 */
	public static function cites_domain( array $citations, $domain ) {
		$domain = strtolower( $domain );
		foreach ( $citations as $c ) {
			$host = isset( $c['domain'] ) ? strtolower( $c['domain'] ) : '';
			if ( $host === $domain || substr( $host, -strlen( '.' . $domain ) ) === '.' . $domain ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Earliest whole-word match of any term.
	 *
	 * @param string   $text  Text.
	 * @param string[] $terms Terms.
	 * @return int|null Byte offset.
	 */
	private static function first_offset( $text, array $terms ) {
		$best = null;
		foreach ( $terms as $term ) {
			if ( preg_match( self::pattern( $term ), $text, $m, PREG_OFFSET_CAPTURE ) ) {
				$best = null === $best ? $m[0][1] : min( $best, $m[0][1] );
			}
		}
		return $best;
	}

	/**
	 * Case-insensitive whole-word regex for a term.
	 *
	 * @param string $term Term.
	 * @return string
	 */
	private static function pattern( $term ) {
		return '/(?<![\p{L}\p{N}])' . preg_quote( trim( $term ), '/' ) . '(?![\p{L}\p{N}])/iu';
	}

	/**
	 * Lexicon sentiment of the sentences that mention the brand.
	 *
	 * @param string   $text  Answer.
	 * @param string[] $terms Brand terms.
	 * @return array label (positive|neutral|negative), score (-1..1).
	 */
	private static function sentiment( $text, array $terms ) {
		$sentences = preg_split( '/(?<=[.!?])\s+|\n+/u', $text );
		$pos       = 0;
		$neg       = 0;

		foreach ( $sentences as $sentence ) {
			$about_brand = false;
			foreach ( $terms as $term ) {
				if ( preg_match( self::pattern( $term ), $sentence ) ) {
					$about_brand = true;
					break;
				}
			}
			if ( ! $about_brand ) {
				continue;
			}

			$words = preg_split( '/[^\p{L}\p{N}\'-]+/u', strtolower( $sentence ), -1, PREG_SPLIT_NO_EMPTY );
			foreach ( $words as $i => $word ) {
				$value = 0;
				if ( in_array( $word, self::$positive, true ) ) {
					$value = 1;
				} elseif ( in_array( $word, self::$negative, true ) ) {
					$value = -1;
				}
				if ( 0 === $value ) {
					continue;
				}
				// A negation within the previous three words flips the meaning.
				for ( $j = max( 0, $i - 3 ); $j < $i; $j++ ) {
					if ( in_array( $words[ $j ], self::$negations, true ) ) {
						$value = -$value;
						break;
					}
				}
				if ( $value > 0 ) {
					++$pos;
				} else {
					++$neg;
				}
			}
		}

		$score = ( $pos + $neg ) > 0 ? round( ( $pos - $neg ) / ( $pos + $neg ), 2 ) : 0.0;
		$label = 'neutral';
		if ( $score > 0.2 ) {
			$label = 'positive';
		} elseif ( $score < -0.2 ) {
			$label = 'negative';
		}

		return array(
			'label' => $label,
			'score' => $score,
		);
	}
}
