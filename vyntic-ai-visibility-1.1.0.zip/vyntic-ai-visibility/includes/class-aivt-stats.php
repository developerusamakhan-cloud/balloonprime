<?php
/**
 * Dashboard aggregates and opportunities.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Turns stored results into KPIs, trends, share of voice and recommendations.
 */
class AIVT_Stats {

	/**
	 * Everything the dashboard shows for a period.
	 *
	 * @param int $days Period length in days.
	 * @return array
	 */
	public static function dashboard( $days ) {
		$days     = max( 1, (int) $days );
		$now      = time();
		$start    = $now - DAY_IN_SECONDS * $days;
		$rows     = AIVT_Repository::results_since( gmdate( 'Y-m-d H:i:s', $now - DAY_IN_SECONDS * $days * 2 ) );
		$current  = array();
		$previous = array();

		foreach ( $rows as $row ) {
			if ( strtotime( $row->created_at . ' UTC' ) >= $start ) {
				$current[] = $row;
			} else {
				$previous[] = $row;
			}
		}

		$kpis      = self::kpis( $current );
		$prev_kpis = self::kpis( $previous );
		$latest    = AIVT_Repository::latest_results();

		return array(
			'kpis'          => $kpis,
			'prev'          => $previous ? $prev_kpis : null,
			'by_engine'     => self::by_engine( $current ),
			'share'         => self::share_of_voice( $current ),
			'trend'         => self::trend( $current ),
			'domains'       => self::top_domains( $current ),
			'opportunities' => self::opportunities( $latest, $current ),
		);
	}

	/**
	 * Headline numbers.
	 *
	 * @param object[] $rows Results.
	 * @return array
	 */
	public static function kpis( array $rows ) {
		$total     = count( $rows );
		$mentioned = 0;
		$cited     = 0;
		$positions = array();
		$sentiment = array(
			'positive' => 0,
			'neutral'  => 0,
			'negative' => 0,
		);

		foreach ( $rows as $row ) {
			if ( $row->brand_mentioned ) {
				++$mentioned;
				if ( $row->brand_position ) {
					$positions[] = (int) $row->brand_position;
				}
				if ( isset( $sentiment[ $row->sentiment ] ) ) {
					++$sentiment[ $row->sentiment ];
				}
			}
			if ( $row->brand_cited ) {
				++$cited;
			}
		}

		return array(
			'total'        => $total,
			'mentioned'    => $mentioned,
			'cited'        => $cited,
			'visibility'   => $total ? round( 100 * $mentioned / $total, 1 ) : 0,
			'citation'     => $total ? round( 100 * $cited / $total, 1 ) : 0,
			'avg_position' => $positions ? round( array_sum( $positions ) / count( $positions ), 1 ) : null,
			'sentiment'    => $sentiment,
			'net_sentiment' => $mentioned ? round( 100 * ( $sentiment['positive'] - $sentiment['negative'] ) / $mentioned ) : 0,
		);
	}

	/**
	 * Visibility per engine.
	 *
	 * @param object[] $rows Results.
	 * @return array engine => total, mentioned, cited, visibility, citation.
	 */
	private static function by_engine( array $rows ) {
		$groups = array();
		foreach ( $rows as $row ) {
			$groups[ $row->engine ][] = $row;
		}
		$out = array();
		foreach ( $groups as $engine => $group ) {
			$out[ $engine ] = self::kpis( $group );
		}
		return $out;
	}

	/**
	 * Mentions of the brand vs. each competitor.
	 *
	 * @param object[] $rows Results.
	 * @return array[] Each: name, count, share, is_brand. Sorted by count.
	 */
	private static function share_of_voice( array $rows ) {
		$brand  = AIVT_Settings::get( 'brand_name' );
		$counts = array( $brand => 0 );
		foreach ( AIVT_Settings::competitors() as $competitor ) {
			$counts[ $competitor['name'] ] = 0;
		}

		foreach ( $rows as $row ) {
			if ( $row->brand_mentioned ) {
				++$counts[ $brand ];
			}
			foreach ( $row->competitors as $name ) {
				if ( isset( $counts[ $name ] ) ) {
					++$counts[ $name ];
				}
			}
		}

		$sum = array_sum( $counts );
		$out = array();
		foreach ( $counts as $name => $count ) {
			$out[] = array(
				'name'     => $name,
				'count'    => $count,
				'share'    => $sum ? round( 100 * $count / $sum, 1 ) : 0,
				'is_brand' => $name === $brand,
			);
		}
		usort(
			$out,
			static function ( $a, $b ) {
				return $b['count'] - $a['count'];
			}
		);
		return $out;
	}

	/**
	 * Daily visibility and citation rate.
	 *
	 * @param object[] $rows Results.
	 * @return array date => visibility, citation, total.
	 */
	private static function trend( array $rows ) {
		$days = array();
		foreach ( $rows as $row ) {
			$day = get_date_from_gmt( $row->created_at, 'Y-m-d' );
			if ( ! isset( $days[ $day ] ) ) {
				$days[ $day ] = array();
			}
			$days[ $day ][] = $row;
		}
		ksort( $days );

		$out = array();
		foreach ( $days as $day => $group ) {
			$kpis        = self::kpis( $group );
			$out[ $day ] = array(
				'visibility' => $kpis['visibility'],
				'citation'   => $kpis['citation'],
				'total'      => $kpis['total'],
			);
		}
		return $out;
	}

	/**
	 * Domains AI engines cite most (your site flagged).
	 *
	 * @param object[] $rows  Results.
	 * @param int      $limit Max domains.
	 * @return array[] Each: domain, count, is_brand, competitor.
	 */
	private static function top_domains( array $rows, $limit = 15 ) {
		$own   = AIVT_Settings::get( 'brand_domain' );
		$comps = array();
		foreach ( AIVT_Settings::competitors() as $competitor ) {
			if ( $competitor['domain'] ) {
				$comps[ $competitor['domain'] ] = $competitor['name'];
			}
		}

		$counts = array();
		foreach ( $rows as $row ) {
			$seen = array();
			foreach ( $row->citations as $c ) {
				$domain = isset( $c['domain'] ) ? $c['domain'] : '';
				if ( '' === $domain || isset( $seen[ $domain ] ) || false !== strpos( $domain, 'vertexaisearch' ) ) {
					continue;
				}
				$seen[ $domain ]   = true;
				$counts[ $domain ] = isset( $counts[ $domain ] ) ? $counts[ $domain ] + 1 : 1;
			}
		}
		arsort( $counts );

		$out = array();
		foreach ( array_slice( $counts, 0, $limit, true ) as $domain => $count ) {
			$out[] = array(
				'domain'     => $domain,
				'count'      => $count,
				'is_brand'   => $own && AIVT_Analyzer::cites_domain( array( array( 'domain' => $domain ) ), $own ),
				'competitor' => isset( $comps[ $domain ] ) ? $comps[ $domain ] : '',
			);
		}
		return $out;
	}

	/**
	 * Actionable recommendations, most important first.
	 *
	 * @param object[] $latest  Latest result per prompt + engine.
	 * @param object[] $current Results in the period.
	 * @return array[] Each: type, priority (high|medium|low), title, detail.
	 */
	public static function opportunities( array $latest, array $current ) {
		$out     = array();
		$prompts = array();
		foreach ( AIVT_Repository::prompts() as $p ) {
			$prompts[ $p->id ] = $p->prompt;
		}

		// Group latest answers by prompt.
		$by_prompt = array();
		foreach ( $latest as $row ) {
			if ( 'ok' === $row->status && isset( $prompts[ $row->prompt_id ] ) ) {
				$by_prompt[ $row->prompt_id ][] = $row;
			}
		}

		foreach ( $by_prompt as $prompt_id => $rows ) {
			$missing     = array();
			$competitors = array();
			$negative    = array();
			$uncited     = array();
			foreach ( $rows as $row ) {
				$label = AIVT_Engine::label_for( $row->engine );
				if ( ! $row->brand_mentioned ) {
					$missing[]   = $label;
					$competitors = array_merge( $competitors, $row->competitors );
				} else {
					if ( 'negative' === $row->sentiment ) {
						$negative[] = $label;
					}
					if ( ! $row->brand_cited ) {
						$uncited[] = $label;
					}
				}
			}
			$competitors = array_unique( $competitors );
			$question    = $prompts[ $prompt_id ];

			if ( $missing && $competitors ) {
				$out[] = array(
					'type'     => 'gap',
					'priority' => 'high',
					/* translators: %s: prompt */
					'title'    => sprintf( __( 'Competitors win "%s"', 'vyntic-ai-visibility' ), $question ),
					/* translators: 1: engines, 2: competitors */
					'detail'   => sprintf( __( '%2$s are recommended by %1$s instead of you. Publish a page that directly answers this question (comparison, "best of" list, FAQ) and get mentioned on the sites these engines cite.', 'vyntic-ai-visibility' ), implode( ', ', $missing ), implode( ', ', $competitors ) ),
				);
			} elseif ( count( $missing ) === count( $rows ) ) {
				$out[] = array(
					'type'     => 'missing',
					'priority' => 'medium',
					/* translators: %s: prompt */
					'title'    => sprintf( __( 'Not visible for "%s"', 'vyntic-ai-visibility' ), $question ),
					'detail'   => __( 'No AI engine mentions your brand for this question yet. Create a clear, well-structured page answering it (short direct answer first, then details, FAQ schema).', 'vyntic-ai-visibility' ),
				);
			}

			if ( $negative ) {
				$out[] = array(
					'type'     => 'sentiment',
					'priority' => 'high',
					/* translators: %s: prompt */
					'title'    => sprintf( __( 'Negative tone in answers to "%s"', 'vyntic-ai-visibility' ), $question ),
					/* translators: %s: engines */
					'detail'   => sprintf( __( 'Answers from %s describe your brand negatively. Read the responses, fix the underlying issue and publish up-to-date information, reviews and case studies.', 'vyntic-ai-visibility' ), implode( ', ', $negative ) ),
				);
			}

			if ( $uncited && count( $uncited ) === count( $rows ) - count( $missing ) && count( $uncited ) > 0 ) {
				$out[] = array(
					'type'     => 'citation',
					'priority' => 'low',
					/* translators: %s: prompt */
					'title'    => sprintf( __( 'Mentioned but not linked for "%s"', 'vyntic-ai-visibility' ), $question ),
					/* translators: %s: engines */
					'detail'   => sprintf( __( 'Answers from %s name your brand but link to other websites. Add citable facts, statistics and original data to your own pages so AI links to you.', 'vyntic-ai-visibility' ), implode( ', ', $uncited ) ),
				);
			}
		}

		// Third-party sites AI trusts in your niche → outreach / listing targets.
		$targets = array();
		foreach ( self::top_domains( $current, 30 ) as $domain ) {
			if ( ! $domain['is_brand'] && ! $domain['competitor'] && $domain['count'] >= 2 ) {
				$targets[] = $domain['domain'];
			}
			if ( count( $targets ) >= 5 ) {
				break;
			}
		}
		if ( $targets ) {
			$out[] = array(
				'type'     => 'outreach',
				'priority' => 'medium',
				'title'    => __( 'Get featured on the sites AI cites', 'vyntic-ai-visibility' ),
				/* translators: %s: domains */
				'detail'   => sprintf( __( 'AI engines repeatedly use these sources for your questions: %s. Get listed, reviewed or quoted there (directories, guest posts, PR, review profiles).', 'vyntic-ai-visibility' ), implode( ', ', $targets ) ),
			);
		}

		// Technical blockers.
		$blocked = AIVT_Crawlers::blocked_bots();
		if ( $blocked ) {
			$out[] = array(
				'type'     => 'crawler',
				'priority' => 'high',
				'title'    => __( 'AI crawlers are blocked', 'vyntic-ai-visibility' ),
				/* translators: %s: bot names */
				'detail'   => sprintf( __( 'Your robots.txt blocks %s. These assistants cannot read or cite your site. See AI Visibility → AI Crawlers.', 'vyntic-ai-visibility' ), implode( ', ', $blocked ) ),
			);
		}
		if ( ! AIVT_Settings::get( 'llms_txt_enabled' ) && ! file_exists( ABSPATH . 'llms.txt' ) ) {
			$out[] = array(
				'type'     => 'llms',
				'priority' => 'low',
				'title'    => __( 'Add an llms.txt file', 'vyntic-ai-visibility' ),
				'detail'   => __( 'An llms.txt file gives AI tools a clean summary of your most important pages. Enable it in one click under AI Visibility → AI Crawlers.', 'vyntic-ai-visibility' ),
			);
		}

		$order = array(
			'high'   => 0,
			'medium' => 1,
			'low'    => 2,
		);
		usort(
			$out,
			static function ( $a, $b ) use ( $order ) {
				return $order[ $a['priority'] ] - $order[ $b['priority'] ];
			}
		);
		return $out;
	}
}
