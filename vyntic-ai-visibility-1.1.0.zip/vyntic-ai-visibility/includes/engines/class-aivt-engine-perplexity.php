<?php
/**
 * Perplexity Sonar (always searches the web).
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Perplexity engine.
 */
class AIVT_Engine_Perplexity extends AIVT_Engine {

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'perplexity';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'Perplexity';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://www.perplexity.ai/account/api/keys';
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$body = array(
			'model'    => $this->model(),
			'messages' => array(
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
		);
		if ( ! $web_search ) {
			$body['disable_search'] = true;
		}

		$data = $this->post_json( 'https://api.perplexity.ai/chat/completions', $body, array( 'Authorization' => 'Bearer ' . $this->api_key() ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$text      = isset( $data['choices'][0]['message']['content'] ) ? (string) $data['choices'][0]['message']['content'] : '';
		$citations = array();

		if ( ! empty( $data['search_results'] ) ) {
			foreach ( (array) $data['search_results'] as $result ) {
				if ( ! empty( $result['url'] ) ) {
					$citations[] = $this->citation( $result['url'], isset( $result['title'] ) ? $result['title'] : '' );
				}
			}
		} elseif ( ! empty( $data['citations'] ) ) {
			foreach ( (array) $data['citations'] as $url ) {
				$citations[] = $this->citation( $url );
			}
		}

		// Strip [1] style markers so they don't pollute sentiment / mention matching.
		$text = preg_replace( '/\[\d+\]/', '', $text );

		return array(
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ),
			'model'     => isset( $data['model'] ) ? $data['model'] : $this->model(),
		);
	}
}
