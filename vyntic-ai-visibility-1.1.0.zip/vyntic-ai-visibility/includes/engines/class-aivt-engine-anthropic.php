<?php
/**
 * Claude via the Anthropic Messages API.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * Anthropic engine.
 */
class AIVT_Engine_Anthropic extends AIVT_Engine {

	/**
	 * Models that support the dynamic-filtering web search tool and the effort setting.
	 */
	const MODERN_MODELS = '/(opus-5|opus-4-[678]|sonnet-5|sonnet-4-6|fable|mythos)/';

	/**
	 * Models that accept server-side refusal fallbacks ("default" routing).
	 */
	const FALLBACK_MODELS = '/^claude-(opus-5|opus-5-5|fable-5-1|sonnet-5-5)$/';

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'anthropic';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'Claude';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://platform.claude.com/settings/keys';
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$model   = $this->model();
		$modern  = (bool) preg_match( self::MODERN_MODELS, $model );
		$headers = array(
			'x-api-key'         => $this->api_key(),
			'anthropic-version' => '2023-06-01',
		);

		$body = array(
			'model'      => $model,
			'max_tokens' => 8000,
			'messages'   => array(
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
		);

		if ( $modern ) {
			// Everyday questions don't need deep reasoning; keeps cost per check low.
			$body['output_config'] = array( 'effort' => 'low' );
		}
		if ( preg_match( self::FALLBACK_MODELS, $model ) ) {
			$headers['anthropic-beta'] = 'server-side-fallback-2026-07-01';
			$body['fallbacks']         = 'default';
		}
		if ( $web_search ) {
			$body['tools'] = array(
				array(
					'type'     => $modern ? 'web_search_20260209' : 'web_search_20250305',
					'name'     => 'web_search',
					'max_uses' => 5,
				),
			);
		}

		$content = array();
		$data    = array();

		// Long web-search turns can pause; continue them a couple of times.
		for ( $i = 0; $i < 3; $i++ ) {
			$data = $this->post_json( 'https://api.anthropic.com/v1/messages', $body, $headers );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$content = array_merge( $content, isset( $data['content'] ) ? (array) $data['content'] : array() );

			if ( ! isset( $data['stop_reason'] ) || 'pause_turn' !== $data['stop_reason'] ) {
				break;
			}
			$body['messages'][] = array(
				'role'    => 'assistant',
				'content' => $data['content'],
			);
		}

		if ( isset( $data['stop_reason'] ) && 'refusal' === $data['stop_reason'] ) {
			return new WP_Error( 'aivt_refusal', __( 'Claude declined to answer this prompt.', 'vyntic-ai-visibility' ) );
		}

		$text      = '';
		$citations = array();
		$sources   = array();
		foreach ( $content as $block ) {
			$type = isset( $block['type'] ) ? $block['type'] : '';
			if ( 'text' === $type ) {
				$text .= $block['text'];
				foreach ( isset( $block['citations'] ) ? (array) $block['citations'] : array() as $cite ) {
					if ( ! empty( $cite['url'] ) ) {
						$citations[] = $this->citation( $cite['url'], isset( $cite['title'] ) ? $cite['title'] : '' );
					}
				}
			} elseif ( 'web_search_tool_result' === $type && isset( $block['content'] ) && is_array( $block['content'] ) && isset( $block['content'][0] ) ) {
				// A list means success; an error comes back as a single object.
				foreach ( $block['content'] as $result ) {
					if ( ! empty( $result['url'] ) ) {
						$sources[] = $this->citation( $result['url'], isset( $result['title'] ) ? $result['title'] : '' );
					}
				}
			}
		}

		return array(
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ? $citations : $sources ),
			'model'     => isset( $data['model'] ) ? $data['model'] : $model,
		);
	}
}
