<?php
/**
 * ChatGPT via the OpenAI Responses API.
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * OpenAI engine.
 */
class AIVT_Engine_OpenAI extends AIVT_Engine {

	/**
	 * {@inheritDoc}
	 */
	public function id() {
		return 'openai';
	}

	/**
	 * {@inheritDoc}
	 */
	public function label() {
		return 'ChatGPT';
	}

	/**
	 * {@inheritDoc}
	 */
	public function key_url() {
		return 'https://platform.openai.com/api-keys';
	}

	/**
	 * {@inheritDoc}
	 */
	public function ask( $prompt, $web_search = true ) {
		$body = array(
			'model' => $this->model(),
			'input' => $prompt,
		);
		if ( $web_search ) {
			$body['tools'] = array( array( 'type' => 'web_search' ) );
		}

		$data = $this->post_json( 'https://api.openai.com/v1/responses', $body, array( 'Authorization' => 'Bearer ' . $this->api_key() ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$text      = '';
		$citations = array();
		foreach ( isset( $data['output'] ) ? (array) $data['output'] : array() as $item ) {
			if ( ! isset( $item['type'] ) || 'message' !== $item['type'] || empty( $item['content'] ) ) {
				continue;
			}
			foreach ( $item['content'] as $part ) {
				if ( ! isset( $part['type'] ) || 'output_text' !== $part['type'] ) {
					continue;
				}
				$text .= $part['text'];
				foreach ( isset( $part['annotations'] ) ? (array) $part['annotations'] : array() as $note ) {
					if ( isset( $note['type'], $note['url'] ) && 'url_citation' === $note['type'] ) {
						$citations[] = $this->citation( $note['url'], isset( $note['title'] ) ? $note['title'] : '' );
					}
				}
			}
		}

		return array(
			'text'      => $text,
			'citations' => $this->unique_citations( $citations ),
			'model'     => isset( $data['model'] ) ? $data['model'] : $this->model(),
		);
	}
}
