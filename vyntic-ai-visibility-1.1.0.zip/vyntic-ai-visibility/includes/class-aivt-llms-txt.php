<?php
/**
 * Serves /llms.txt: a Markdown summary of the site for AI tools (llmstxt.org).
 *
 * @package AIVisibilityTracker
 */

defined( 'ABSPATH' ) || exit;

/**
 * llms.txt generator.
 */
class AIVT_Llms_Txt {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'parse_request', array( __CLASS__, 'maybe_serve' ), 0 );
	}

	/**
	 * Output llms.txt when that path is requested.
	 */
	public static function maybe_serve() {
		if ( ! AIVT_Settings::get( 'llms_txt_enabled' ) ) {
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
		$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( untrailingslashit( (string) $home ) . '/llms.txt' !== $path ) {
			return;
		}

		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo self::content(); // phpcs:ignore WordPress.Security.EscapeOutput -- plain text.
		exit;
	}

	/**
	 * Build the file.
	 *
	 * @return string
	 */
	public static function content() {
		$name  = AIVT_Settings::get( 'brand_name' );
		$desc  = AIVT_Settings::get( 'brand_description' );
		$intro = AIVT_Settings::get( 'llms_txt_intro' );

		$lines   = array( '# ' . self::clean( $name ? $name : get_bloginfo( 'name' ) ), '' );
		if ( $desc ) {
			$lines[] = '> ' . self::clean( $desc );
			$lines[] = '';
		}
		if ( $intro ) {
			$lines[] = trim( $intro );
			$lines[] = '';
		}

		$pages = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => 30,
				'orderby'     => 'menu_order title',
				'order'       => 'ASC',
				'has_password' => false,
			)
		);
		self::section( $lines, __( 'Pages', 'vyntic-ai-visibility' ), $pages );

		if ( post_type_exists( 'product' ) ) {
			$products = get_posts(
				array(
					'post_type'   => 'product',
					'post_status' => 'publish',
					'numberposts' => 30,
				)
			);
			self::section( $lines, __( 'Products', 'vyntic-ai-visibility' ), $products );
		}

		$posts = get_posts(
			array(
				'post_type'    => 'post',
				'post_status'  => 'publish',
				'numberposts'  => 30,
				'has_password' => false,
			)
		);
		self::section( $lines, __( 'Articles', 'vyntic-ai-visibility' ), $posts );

		$lines[] = '## ' . __( 'Optional', 'vyntic-ai-visibility' );
		$lines[] = '';
		$lines[] = '- [' . __( 'XML sitemap', 'vyntic-ai-visibility' ) . '](' . home_url( '/wp-sitemap.xml' ) . ')';
		$lines[] = '';

		return (string) apply_filters( 'aivt_llms_txt', implode( "\n", $lines ) );
	}

	/**
	 * Append a "## Heading" list of links.
	 *
	 * @param array     $lines Lines (by reference).
	 * @param string    $title Section title.
	 * @param WP_Post[] $posts Posts.
	 */
	private static function section( array &$lines, $title, array $posts ) {
		if ( ! $posts ) {
			return;
		}
		$lines[] = '## ' . $title;
		$lines[] = '';
		foreach ( $posts as $post ) {
			$summary = has_excerpt( $post ) ? $post->post_excerpt : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 20, '…' );
			$line    = '- [' . self::clean( get_the_title( $post ) ) . '](' . get_permalink( $post ) . ')';
			if ( $summary ) {
				$line .= ': ' . self::clean( $summary );
			}
			$lines[] = $line;
		}
		$lines[] = '';
	}

	/**
	 * Single-line plain text.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function clean( $text ) {
		return trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) );
	}
}
