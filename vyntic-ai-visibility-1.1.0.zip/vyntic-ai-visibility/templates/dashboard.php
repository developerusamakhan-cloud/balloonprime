<?php
/**
 * Dashboard view.
 *
 * @package AIVisibilityTracker
 *
 * @var int   $days Period.
 * @var array $data AIVT_Stats::dashboard().
 */

defined( 'ABSPATH' ) || exit;

$aivt_kpis     = $data['kpis'];
$aivt_prev     = $data['prev'];
$aivt_engines  = AIVT_Engine::active();
$aivt_prompts  = AIVT_Repository::prompts( true );
$aivt_last_run = (int) get_option( 'aivt_last_run' );
$aivt_queued   = AIVT_Runner::queued();
$aivt_next     = wp_next_scheduled( AIVT_Runner::CRON_HOOK );
?>
<div class="wrap aivt-wrap">
	<div class="aivt-header">
		<div>
			<h1><span class="dashicons dashicons-visibility"></span> <?php esc_html_e( 'AI Visibility', 'vyntic-ai-visibility' ); ?></h1>
			<p class="aivt-muted">
				<?php
				printf(
					/* translators: 1: brand name, 2: domain */
					esc_html__( 'How often AI assistants mention and cite %1$s (%2$s).', 'vyntic-ai-visibility' ),
					'<strong>' . esc_html( AIVT_Settings::get( 'brand_name' ) ) . '</strong>',
					esc_html( AIVT_Settings::get( 'brand_domain' ) )
				);
				?>
			</p>
		</div>
		<div class="aivt-header-actions">
			<nav class="aivt-tabs">
				<?php foreach ( array( 7, 30, 90 ) as $aivt_d ) : ?>
					<a class="<?php echo $aivt_d === $days ? 'is-active' : ''; ?>" href="<?php echo esc_url( AIVT_Admin::url( 'dashboard', array( 'days' => $aivt_d ) ) ); ?>">
						<?php
						/* translators: %d: days */
						printf( esc_html__( '%d days', 'vyntic-ai-visibility' ), (int) $aivt_d );
						?>
					</a>
				<?php endforeach; ?>
			</nav>
			<button type="button" class="button button-primary aivt-run" <?php disabled( ! $aivt_engines || ! $aivt_prompts ); ?>><?php esc_html_e( 'Run check now', 'vyntic-ai-visibility' ); ?></button>
		</div>
	</div>

	<div class="aivt-progress" hidden><div class="aivt-progress-bar"><span></span></div><p class="aivt-progress-text"></p></div>

	<?php if ( ! $aivt_engines || ! $aivt_prompts ) : ?>
		<div class="aivt-card aivt-setup">
			<h2><?php esc_html_e( 'Get started in 3 steps', 'vyntic-ai-visibility' ); ?></h2>
			<ol>
				<li class="<?php echo AIVT_Settings::get( 'brand_name' ) ? 'is-done' : ''; ?>">
					<a href="<?php echo esc_url( AIVT_Admin::url( 'settings' ) ); ?>"><?php esc_html_e( 'Enter your brand name, domain and competitors', 'vyntic-ai-visibility' ); ?></a>
				</li>
				<li class="<?php echo $aivt_engines ? 'is-done' : ''; ?>">
					<a href="<?php echo esc_url( AIVT_Admin::url( 'settings' ) . '#aivt-engines' ); ?>"><?php esc_html_e( 'Add at least one API key (ChatGPT, Claude, Gemini or Perplexity)', 'vyntic-ai-visibility' ); ?></a>
				</li>
				<li class="<?php echo $aivt_prompts ? 'is-done' : ''; ?>">
					<a href="<?php echo esc_url( AIVT_Admin::url( 'prompts' ) ); ?>"><?php esc_html_e( 'Add the questions your customers ask AI (or let AI suggest them)', 'vyntic-ai-visibility' ); ?></a>
				</li>
			</ol>
		</div>
	<?php endif; ?>

	<div class="aivt-kpis">
		<div class="aivt-card aivt-kpi">
			<span class="aivt-kpi-label"><?php esc_html_e( 'AI Visibility', 'vyntic-ai-visibility' ); ?></span>
			<span class="aivt-kpi-value"><?php echo esc_html( $aivt_kpis['visibility'] ); ?>%</span>
			<?php echo wp_kses_post( self::delta( $aivt_kpis['visibility'], $aivt_prev ? $aivt_prev['visibility'] : null ) ); ?>
			<span class="aivt-kpi-help">
				<?php
				/* translators: 1: answers mentioning the brand, 2: total answers */
				printf( esc_html__( 'Mentioned in %1$d of %2$d AI answers', 'vyntic-ai-visibility' ), (int) $aivt_kpis['mentioned'], (int) $aivt_kpis['total'] );
				?>
			</span>
		</div>
		<div class="aivt-card aivt-kpi">
			<span class="aivt-kpi-label"><?php esc_html_e( 'Citations', 'vyntic-ai-visibility' ); ?></span>
			<span class="aivt-kpi-value"><?php echo esc_html( $aivt_kpis['citation'] ); ?>%</span>
			<?php echo wp_kses_post( self::delta( $aivt_kpis['citation'], $aivt_prev ? $aivt_prev['citation'] : null ) ); ?>
			<span class="aivt-kpi-help">
				<?php
				/* translators: %d: answers linking to the site */
				printf( esc_html__( '%d answers linked to your website', 'vyntic-ai-visibility' ), (int) $aivt_kpis['cited'] );
				?>
			</span>
		</div>
		<div class="aivt-card aivt-kpi">
			<span class="aivt-kpi-label"><?php esc_html_e( 'Avg. position', 'vyntic-ai-visibility' ); ?></span>
			<span class="aivt-kpi-value"><?php echo null === $aivt_kpis['avg_position'] ? '-' : '#' . esc_html( $aivt_kpis['avg_position'] ); ?></span>
			<?php echo wp_kses_post( self::delta( $aivt_kpis['avg_position'], $aivt_prev ? $aivt_prev['avg_position'] : null, true ) ); ?>
			<span class="aivt-kpi-help"><?php esc_html_e( 'Order you are named in vs. competitors', 'vyntic-ai-visibility' ); ?></span>
		</div>
		<div class="aivt-card aivt-kpi">
			<span class="aivt-kpi-label"><?php esc_html_e( 'Sentiment', 'vyntic-ai-visibility' ); ?></span>
			<span class="aivt-kpi-value"><?php echo esc_html( ( $aivt_kpis['net_sentiment'] > 0 ? '+' : '' ) . $aivt_kpis['net_sentiment'] ); ?></span>
			<?php echo wp_kses_post( self::delta( $aivt_kpis['net_sentiment'], $aivt_prev ? $aivt_prev['net_sentiment'] : null ) ); ?>
			<span class="aivt-kpi-help aivt-sentiment-split">
				<span class="aivt-pill is-positive"><?php echo (int) $aivt_kpis['sentiment']['positive']; ?></span>
				<span class="aivt-pill is-neutral"><?php echo (int) $aivt_kpis['sentiment']['neutral']; ?></span>
				<span class="aivt-pill is-negative"><?php echo (int) $aivt_kpis['sentiment']['negative']; ?></span>
			</span>
		</div>
	</div>

	<div class="aivt-grid-2">
		<div class="aivt-card">
			<h2><?php esc_html_e( 'Trend', 'vyntic-ai-visibility' ); ?></h2>
			<div class="aivt-legend"><span class="is-visibility"><?php esc_html_e( 'Visibility', 'vyntic-ai-visibility' ); ?></span><span class="is-citation"><?php esc_html_e( 'Citations', 'vyntic-ai-visibility' ); ?></span></div>
			<?php echo self::trend_svg( $data['trend'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped while building. ?>
		</div>

		<div class="aivt-card">
			<h2><?php esc_html_e( 'By AI engine', 'vyntic-ai-visibility' ); ?></h2>
			<?php if ( ! $data['by_engine'] ) : ?>
				<p class="aivt-muted"><?php esc_html_e( 'No answers in this period yet.', 'vyntic-ai-visibility' ); ?></p>
			<?php else : ?>
				<table class="aivt-table">
					<thead><tr><th><?php esc_html_e( 'Engine', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Visibility', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Citations', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Avg. pos.', 'vyntic-ai-visibility' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $data['by_engine'] as $aivt_engine => $aivt_e ) : ?>
						<tr>
							<td><span class="aivt-engine is-<?php echo esc_attr( $aivt_engine ); ?>"><?php echo esc_html( AIVT_Engine::label_for( $aivt_engine ) ); ?></span></td>
							<td><div class="aivt-bar"><span style="width:<?php echo esc_attr( $aivt_e['visibility'] ); ?>%"></span></div><?php echo esc_html( $aivt_e['visibility'] ); ?>%</td>
							<td><?php echo esc_html( $aivt_e['citation'] ); ?>%</td>
							<td><?php echo null === $aivt_e['avg_position'] ? '-' : '#' . esc_html( $aivt_e['avg_position'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</div>

	<div class="aivt-grid-2">
		<div class="aivt-card">
			<h2><?php esc_html_e( 'Opportunities', 'vyntic-ai-visibility' ); ?></h2>
			<?php if ( ! $data['opportunities'] ) : ?>
				<p class="aivt-muted"><?php esc_html_e( 'No opportunities yet. Run a check to find gaps where competitors are recommended instead of you.', 'vyntic-ai-visibility' ); ?></p>
			<?php else : ?>
				<ul class="aivt-opps">
					<?php foreach ( array_slice( $data['opportunities'], 0, 12 ) as $aivt_opp ) : ?>
						<li class="is-<?php echo esc_attr( $aivt_opp['priority'] ); ?>">
							<span class="aivt-priority"><?php echo esc_html( ucfirst( $aivt_opp['priority'] ) ); ?></span>
							<strong><?php echo esc_html( $aivt_opp['title'] ); ?></strong>
							<p><?php echo esc_html( $aivt_opp['detail'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div>
			<div class="aivt-card">
				<h2><?php esc_html_e( 'Share of voice', 'vyntic-ai-visibility' ); ?></h2>
				<?php if ( count( $data['share'] ) < 2 ) : ?>
					<p class="aivt-muted">
						<?php esc_html_e( 'Add competitors in Settings to compare how often AI recommends them vs. you.', 'vyntic-ai-visibility' ); ?>
					</p>
				<?php else : ?>
					<ul class="aivt-share">
						<?php foreach ( $data['share'] as $aivt_s ) : ?>
							<li class="<?php echo $aivt_s['is_brand'] ? 'is-brand' : ''; ?>">
								<span class="aivt-share-name"><?php echo esc_html( $aivt_s['name'] ); ?></span>
								<div class="aivt-bar"><span style="width:<?php echo esc_attr( $aivt_s['share'] ); ?>%"></span></div>
								<span class="aivt-share-val"><?php echo esc_html( $aivt_s['share'] ); ?>%</span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>

			<div class="aivt-card">
				<h2><?php esc_html_e( 'Sources AI cites most', 'vyntic-ai-visibility' ); ?></h2>
				<?php if ( ! $data['domains'] ) : ?>
					<p class="aivt-muted"><?php esc_html_e( 'No citations yet.', 'vyntic-ai-visibility' ); ?></p>
				<?php else : ?>
					<table class="aivt-table">
						<tbody>
						<?php foreach ( $data['domains'] as $aivt_dom ) : ?>
							<tr>
								<td>
									<?php echo esc_html( $aivt_dom['domain'] ); ?>
									<?php if ( $aivt_dom['is_brand'] ) : ?>
										<span class="aivt-pill is-positive"><?php esc_html_e( 'You', 'vyntic-ai-visibility' ); ?></span>
									<?php elseif ( $aivt_dom['competitor'] ) : ?>
										<span class="aivt-pill is-negative"><?php echo esc_html( $aivt_dom['competitor'] ); ?></span>
									<?php endif; ?>
								</td>
								<td class="aivt-num"><?php echo (int) $aivt_dom['count']; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<p class="aivt-muted aivt-footnote">
		<?php
		if ( $aivt_last_run ) {
			/* translators: %s: time ago */
			printf( esc_html__( 'Last check: %s ago.', 'vyntic-ai-visibility' ), esc_html( human_time_diff( $aivt_last_run ) ) );
			echo ' ';
		}
		if ( $aivt_queued ) {
			/* translators: %d: queued checks */
			printf( esc_html__( '%d scheduled checks are running in the background.', 'vyntic-ai-visibility' ), (int) $aivt_queued );
			echo ' ';
		}
		if ( $aivt_next ) {
			/* translators: %s: date */
			printf( esc_html__( 'Next automatic check: %s.', 'vyntic-ai-visibility' ), esc_html( get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $aivt_next ), get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ) );
		}
		?>
	</p>
</div>
