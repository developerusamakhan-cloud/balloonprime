<?php
/**
 * AI crawler access + llms.txt view.
 *
 * @package AIVisibilityTracker
 *
 * @var array[] $bots AIVT_Crawlers::check().
 */

defined( 'ABSPATH' ) || exit;

$aivt_llms_url = home_url( '/llms.txt' );
?>
<div class="wrap aivt-wrap">
	<h1><?php esc_html_e( 'AI Crawlers & llms.txt', 'vyntic-ai-visibility' ); ?></h1>
	<p class="aivt-muted"><?php esc_html_e( 'AI assistants can only recommend and cite pages they are allowed to read.', 'vyntic-ai-visibility' ); ?></p>

	<?php if ( '0' === (string) get_option( 'blog_public' ) ) : ?>
		<div class="notice notice-error"><p>
			<?php
			printf(
				/* translators: %s: link to Reading settings */
				esc_html__( '"Discourage search engines from indexing this site" is turned on. AI search engines will ignore your site. Change it in %s.', 'vyntic-ai-visibility' ),
				'<a href="' . esc_url( admin_url( 'options-reading.php' ) ) . '">' . esc_html__( 'Settings → Reading', 'vyntic-ai-visibility' ) . '</a>'
			);
			?>
		</p></div>
	<?php endif; ?>

	<div class="aivt-card">
		<div class="aivt-card-head">
			<h2><?php esc_html_e( 'robots.txt check', 'vyntic-ai-visibility' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'aivt_refresh_robots' ); ?>
				<input type="hidden" name="action" value="aivt_refresh_robots">
				<button class="button"><?php esc_html_e( 'Re-check', 'vyntic-ai-visibility' ); ?></button>
				<a class="button" href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View robots.txt', 'vyntic-ai-visibility' ); ?></a>
			</form>
		</div>
		<table class="aivt-table">
			<thead><tr><th><?php esc_html_e( 'Crawler', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Company', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Used for', 'vyntic-ai-visibility' ); ?></th><th><?php esc_html_e( 'Status', 'vyntic-ai-visibility' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $bots as $aivt_bot ) : ?>
				<tr>
					<td><code><?php echo esc_html( $aivt_bot['agent'] ); ?></code></td>
					<td><?php echo esc_html( $aivt_bot['owner'] ); ?></td>
					<td><?php echo esc_html( $aivt_bot['purpose'] ); ?></td>
					<td>
						<?php if ( ! $aivt_bot['blocked'] ) : ?>
							<span class="aivt-pill is-positive"><?php esc_html_e( 'Allowed', 'vyntic-ai-visibility' ); ?></span>
						<?php elseif ( $aivt_bot['search'] ) : ?>
							<span class="aivt-pill is-negative"><?php esc_html_e( 'Blocked, hurts AI visibility', 'vyntic-ai-visibility' ); ?></span>
						<?php else : ?>
							<span class="aivt-pill is-neutral"><?php esc_html_e( 'Blocked (training only)', 'vyntic-ai-visibility' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Search / user bots fetch your pages when someone asks a question, so keep them allowed. Training bots only collect data for future models; blocking them is your choice. Edit robots.txt with your SEO plugin (e.g. Rank Math → General Settings → Edit robots.txt).', 'vyntic-ai-visibility' ); ?></p>
	</div>

	<div class="aivt-card">
		<h2>llms.txt</h2>
		<p><?php esc_html_e( 'llms.txt is a proposed standard: a short Markdown file at the root of your site that lists your most important pages for AI tools.', 'vyntic-ai-visibility' ); ?></p>
		<?php if ( file_exists( ABSPATH . 'llms.txt' ) ) : ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( 'A physical llms.txt file already exists in your site root, so the generated version is not used.', 'vyntic-ai-visibility' ); ?></p></div>
		<?php elseif ( AIVT_Settings::get( 'llms_txt_enabled' ) ) : ?>
			<p><span class="aivt-pill is-positive"><?php esc_html_e( 'Enabled', 'vyntic-ai-visibility' ); ?></span> <a href="<?php echo esc_url( $aivt_llms_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $aivt_llms_url ); ?></a></p>
		<?php else : ?>
			<p>
				<span class="aivt-pill is-neutral"><?php esc_html_e( 'Disabled', 'vyntic-ai-visibility' ); ?></span>
				<a href="<?php echo esc_url( AIVT_Admin::url( 'settings' ) . '#aivt-llms' ); ?>"><?php esc_html_e( 'Enable it in Settings', 'vyntic-ai-visibility' ); ?></a>
			</p>
		<?php endif; ?>
		<details>
			<summary><?php esc_html_e( 'Preview', 'vyntic-ai-visibility' ); ?></summary>
			<pre class="aivt-pre"><?php echo esc_html( AIVT_Llms_Txt::content() ); ?></pre>
		</details>
	</div>
</div>
