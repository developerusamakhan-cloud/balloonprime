<?php
/**
 * Prompts view.
 *
 * @package AIVisibilityTracker
 *
 * @var object[] $prompts Prompts.
 * @var array    $latest  prompt_id => engine => latest result.
 * @var array    $engines Ready engines.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap aivt-wrap">
	<div class="aivt-header">
		<div>
			<h1><?php esc_html_e( 'Tracked Prompts', 'vyntic-ai-visibility' ); ?></h1>
			<p class="aivt-muted"><?php esc_html_e( 'The questions your potential customers ask AI assistants. Each prompt is asked to every enabled AI engine on every check.', 'vyntic-ai-visibility' ); ?></p>
		</div>
		<div class="aivt-header-actions">
			<button type="button" class="button button-primary aivt-run" <?php disabled( ! $engines || ! $prompts ); ?>><?php esc_html_e( 'Run all prompts now', 'vyntic-ai-visibility' ); ?></button>
		</div>
	</div>

	<div class="aivt-progress" hidden><div class="aivt-progress-bar"><span></span></div><p class="aivt-progress-text"></p></div>

	<?php // phpcs:disable WordPress.Security.NonceVerification ?>
	<?php if ( isset( $_GET['added'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p>
			<?php
			/* translators: %d: prompts added */
			printf( esc_html__( '%d prompts added.', 'vyntic-ai-visibility' ), absint( $_GET['added'] ) );
			?>
		</p></div>
	<?php endif; ?>
	<?php // phpcs:enable ?>

	<?php if ( ! $engines ) : ?>
		<div class="notice notice-warning"><p>
			<?php
			printf(
				/* translators: %s: settings link */
				esc_html__( 'No AI engine is enabled yet. Add an API key in %s.', 'vyntic-ai-visibility' ),
				'<a href="' . esc_url( AIVT_Admin::url( 'settings' ) . '#aivt-engines' ) . '">' . esc_html__( 'Settings', 'vyntic-ai-visibility' ) . '</a>'
			);
			?>
		</p></div>
	<?php endif; ?>

	<div class="aivt-card">
		<h2><?php esc_html_e( 'Add prompts', 'vyntic-ai-visibility' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'aivt_add_prompts' ); ?>
			<input type="hidden" name="action" value="aivt_add_prompts">
			<textarea name="prompts" id="aivt-prompts-input" rows="6" class="large-text" placeholder="<?php esc_attr_e( "One question per line, e.g.\nWhat is the best SEO agency in Lahore?\nWhich credit repair company is most trusted?", 'vyntic-ai-visibility' ); ?>"></textarea>
			<p>
				<input type="text" name="tag" class="regular-text" placeholder="<?php esc_attr_e( 'Topic / tag (optional)', 'vyntic-ai-visibility' ); ?>">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Add prompts', 'vyntic-ai-visibility' ); ?></button>
				<button type="button" class="button aivt-suggest" <?php disabled( ! $engines ); ?>><span class="dashicons dashicons-lightbulb"></span> <?php esc_html_e( 'Suggest prompts with AI', 'vyntic-ai-visibility' ); ?></button>
				<span class="aivt-suggest-status aivt-muted"></span>
			</p>
			<p class="description"><?php esc_html_e( 'Tip: write prompts the way a customer would, without your brand name, e.g. "best", "top", "vs", "alternatives to", "near me" questions. Start with 10 to 20 prompts.', 'vyntic-ai-visibility' ); ?></p>
		</form>
	</div>

	<div class="aivt-card">
		<table class="aivt-table aivt-prompts">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Prompt', 'vyntic-ai-visibility' ); ?></th>
					<?php foreach ( AIVT_Engine::ids() as $aivt_id ) : ?>
						<th class="aivt-center"><?php echo esc_html( AIVT_Engine::label_for( $aivt_id ) ); ?></th>
					<?php endforeach; ?>
					<th class="aivt-right"><?php esc_html_e( 'Actions', 'vyntic-ai-visibility' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( ! $prompts ) : ?>
				<tr><td colspan="<?php echo count( AIVT_Engine::ids() ) + 2; ?>" class="aivt-muted"><?php esc_html_e( 'No prompts yet.', 'vyntic-ai-visibility' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $prompts as $aivt_p ) : ?>
				<tr class="<?php echo $aivt_p->active ? '' : 'is-paused'; ?>">
					<td>
						<a href="<?php echo esc_url( AIVT_Admin::url( 'responses', array( 'prompt_id' => (int) $aivt_p->id ) ) ); ?>"><?php echo esc_html( $aivt_p->prompt ); ?></a>
						<?php if ( $aivt_p->tag ) : ?>
							<span class="aivt-tag"><?php echo esc_html( $aivt_p->tag ); ?></span>
						<?php endif; ?>
						<?php if ( ! $aivt_p->active ) : ?>
							<span class="aivt-tag"><?php esc_html_e( 'Paused', 'vyntic-ai-visibility' ); ?></span>
						<?php endif; ?>
					</td>
					<?php foreach ( AIVT_Engine::ids() as $aivt_id ) : ?>
						<td class="aivt-center">
							<?php
							$aivt_r = isset( $latest[ $aivt_p->id ][ $aivt_id ] ) ? $latest[ $aivt_p->id ][ $aivt_id ] : null;
							if ( ! $aivt_r ) {
								echo '<span class="aivt-muted">-</span>';
							} elseif ( 'ok' !== $aivt_r->status ) {
								echo '<span class="aivt-status is-error" title="' . esc_attr( $aivt_r->error ) . '">!</span>';
							} elseif ( $aivt_r->brand_mentioned ) {
								$aivt_title = $aivt_r->brand_position ? sprintf( /* translators: %d: position */ __( 'Mentioned at position #%d', 'vyntic-ai-visibility' ), $aivt_r->brand_position ) : __( 'Mentioned', 'vyntic-ai-visibility' );
								echo '<span class="aivt-status is-yes" title="' . esc_attr( $aivt_title ) . '">' . ( $aivt_r->brand_position ? '#' . (int) $aivt_r->brand_position : '✓' ) . '</span>';
								if ( $aivt_r->brand_cited ) {
									echo ' <span class="dashicons dashicons-admin-links aivt-cited" title="' . esc_attr__( 'Your site was cited', 'vyntic-ai-visibility' ) . '"></span>';
								}
							} else {
								echo '<span class="aivt-status is-no" title="' . esc_attr( $aivt_r->competitors ? implode( ', ', $aivt_r->competitors ) : __( 'Not mentioned', 'vyntic-ai-visibility' ) ) . '">✕</span>';
							}
							?>
						</td>
					<?php endforeach; ?>
					<td class="aivt-right aivt-actions">
						<button type="button" class="button button-small aivt-run" data-prompt="<?php echo (int) $aivt_p->id; ?>" <?php disabled( ! $engines ); ?>><?php esc_html_e( 'Run', 'vyntic-ai-visibility' ); ?></button>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<?php wp_nonce_field( 'aivt_prompt_action' ); ?>
							<input type="hidden" name="action" value="aivt_prompt_action">
							<input type="hidden" name="prompt_id" value="<?php echo (int) $aivt_p->id; ?>">
							<button type="submit" name="do" value="<?php echo $aivt_p->active ? 'pause' : 'resume'; ?>" class="button button-small"><?php echo $aivt_p->active ? esc_html__( 'Pause', 'vyntic-ai-visibility' ) : esc_html__( 'Resume', 'vyntic-ai-visibility' ); ?></button>
							<button type="submit" name="do" value="delete" class="button button-small button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this prompt and all its results?', 'vyntic-ai-visibility' ) ); ?>');"><?php esc_html_e( 'Delete', 'vyntic-ai-visibility' ); ?></button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="aivt-muted aivt-legend-text">
			<?php esc_html_e( '#N = mentioned at that position · ✓ = mentioned · ✕ = not mentioned (hover to see which competitors were) · link icon = your site was cited · ! = error (hover for details)', 'vyntic-ai-visibility' ); ?>
		</p>
	</div>
</div>
