<?php
/**
 * Responses log view.
 *
 * @package AIVisibilityTracker
 *
 * @var array $filters Active filters.
 * @var array $result  rows, total.
 * @var array $prompts id => text.
 */

defined( 'ABSPATH' ) || exit;

$aivt_pages = (int) ceil( $result['total'] / $filters['per_page'] );
?>
<div class="wrap aivt-wrap">
	<h1><?php esc_html_e( 'AI Responses', 'vyntic-ai-visibility' ); ?></h1>
	<p class="aivt-muted"><?php esc_html_e( 'Every answer the AI engines gave, with what was detected in it.', 'vyntic-ai-visibility' ); ?></p>

	<form method="get" class="aivt-filters">
		<input type="hidden" name="page" value="vyntic-ai-visibility">
		<input type="hidden" name="tab" value="responses">
		<select name="prompt_id">
			<option value=""><?php esc_html_e( 'All prompts', 'vyntic-ai-visibility' ); ?></option>
			<?php foreach ( $prompts as $aivt_id => $aivt_text ) : ?>
				<option value="<?php echo (int) $aivt_id; ?>" <?php selected( $filters['prompt_id'], $aivt_id ); ?>><?php echo esc_html( wp_trim_words( $aivt_text, 12 ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="engine">
			<option value=""><?php esc_html_e( 'All engines', 'vyntic-ai-visibility' ); ?></option>
			<?php foreach ( AIVT_Engine::ids() as $aivt_e ) : ?>
				<option value="<?php echo esc_attr( $aivt_e ); ?>" <?php selected( $filters['engine'], $aivt_e ); ?>><?php echo esc_html( AIVT_Engine::label_for( $aivt_e ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="mentioned">
			<option value=""><?php esc_html_e( 'Mentioned or not', 'vyntic-ai-visibility' ); ?></option>
			<option value="1" <?php selected( $filters['mentioned'], '1' ); ?>><?php esc_html_e( 'Mentioned', 'vyntic-ai-visibility' ); ?></option>
			<option value="0" <?php selected( $filters['mentioned'], '0' ); ?>><?php esc_html_e( 'Not mentioned', 'vyntic-ai-visibility' ); ?></option>
		</select>
		<button class="button"><?php esc_html_e( 'Filter', 'vyntic-ai-visibility' ); ?></button>
	</form>

	<div class="aivt-card">
		<?php if ( ! $result['rows'] ) : ?>
			<p class="aivt-muted"><?php esc_html_e( 'No responses yet. Run a check from the Dashboard or Prompts screen.', 'vyntic-ai-visibility' ); ?></p>
		<?php endif; ?>

		<?php foreach ( $result['rows'] as $aivt_r ) : ?>
			<details class="aivt-response">
				<summary>
					<span class="aivt-engine is-<?php echo esc_attr( $aivt_r->engine ); ?>"><?php echo esc_html( AIVT_Engine::label_for( $aivt_r->engine ) ); ?></span>
					<span class="aivt-response-prompt"><?php echo esc_html( isset( $prompts[ $aivt_r->prompt_id ] ) ? $prompts[ $aivt_r->prompt_id ] : '#' . $aivt_r->prompt_id ); ?></span>
					<span class="aivt-response-meta">
						<?php if ( 'ok' !== $aivt_r->status ) : ?>
							<span class="aivt-pill is-negative"><?php esc_html_e( 'Error', 'vyntic-ai-visibility' ); ?></span>
						<?php elseif ( $aivt_r->brand_mentioned ) : ?>
							<span class="aivt-pill is-positive">
								<?php
								echo $aivt_r->brand_position
									/* translators: %d: position */
									? esc_html( sprintf( __( 'Mentioned #%d', 'vyntic-ai-visibility' ), $aivt_r->brand_position ) )
									: esc_html__( 'Mentioned', 'vyntic-ai-visibility' );
								?>
							</span>
							<?php if ( $aivt_r->brand_cited ) : ?>
								<span class="aivt-pill is-positive"><?php esc_html_e( 'Cited', 'vyntic-ai-visibility' ); ?></span>
							<?php endif; ?>
							<?php echo wp_kses_post( self::sentiment_pill( $aivt_r->sentiment ) ); ?>
						<?php else : ?>
							<span class="aivt-pill is-neutral"><?php esc_html_e( 'Not mentioned', 'vyntic-ai-visibility' ); ?></span>
						<?php endif; ?>
						<span class="aivt-muted"><?php echo esc_html( get_date_from_gmt( $aivt_r->created_at, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ); ?></span>
					</span>
				</summary>
				<div class="aivt-response-body">
					<?php if ( 'ok' !== $aivt_r->status ) : ?>
						<p class="aivt-error"><?php echo esc_html( $aivt_r->error ); ?></p>
					<?php else : ?>
						<?php if ( $aivt_r->competitors ) : ?>
							<p><strong><?php esc_html_e( 'Competitors mentioned:', 'vyntic-ai-visibility' ); ?></strong> <?php echo esc_html( implode( ', ', $aivt_r->competitors ) ); ?></p>
						<?php endif; ?>
						<div class="aivt-answer"><?php echo nl2br( esc_html( $aivt_r->response ) ); ?></div>
						<?php if ( $aivt_r->citations ) : ?>
							<p><strong><?php esc_html_e( 'Sources cited:', 'vyntic-ai-visibility' ); ?></strong></p>
							<ol class="aivt-citations">
								<?php foreach ( $aivt_r->citations as $aivt_c ) : ?>
									<li><a href="<?php echo esc_url( $aivt_c['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $aivt_c['title'] ? $aivt_c['title'] : $aivt_c['domain'] ); ?></a> <span class="aivt-muted"><?php echo esc_html( $aivt_c['domain'] ); ?></span></li>
								<?php endforeach; ?>
							</ol>
						<?php endif; ?>
						<p class="aivt-muted"><?php echo esc_html( $aivt_r->model ); ?></p>
					<?php endif; ?>
				</div>
			</details>
		<?php endforeach; ?>

		<?php if ( $aivt_pages > 1 ) : ?>
			<div class="tablenav"><div class="tablenav-pages">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'    => add_query_arg( 'paged', '%#%' ),
							'format'  => '',
							'current' => $filters['page'],
							'total'   => $aivt_pages,
						)
					)
				);
				?>
			</div></div>
		<?php endif; ?>
	</div>
</div>
