<?php
/**
 * AI website planner. Needs WordPress 7.0+ with an AI provider in Settings → Connectors.
 * Visitors describe their business and get a homepage plan in seconds.
 *
 * @package Vyntic
 */

/* Prefer the Vyntic AI Planner plugin (free Gemini API, lead capture). */
$vyntic_plugin_html = shortcode_exists( 'vyntic_planner' ) ? do_shortcode( '[vyntic_planner theme="dark"]' ) : '';
if ( $vyntic_plugin_html ) :
	?>
	<section class="ai" id="ai-planner" aria-labelledby="ai-title">
		<div class="ai__bg" aria-hidden="true"></div>
		<div class="wrap ai__inner">
			<div class="ai__copy">
				<p class="ai__badge"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Try our AI website planner', 'vyntic' ); ?></p>
				<h2 class="ai__title" id="ai-title"><?php esc_html_e( 'Describe your business. Get your homepage plan in seconds.', 'vyntic' ); ?></h2>
				<p class="ai__text"><?php esc_html_e( 'Tell us what you do, and our planner suggests a headline, the sections your homepage needs and one quick win for speed or SEO. We will also email you a copy to keep.', 'vyntic' ); ?></p>
				<ul class="ai__points">
					<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Free, takes about 30 seconds', 'vyntic' ); ?></li>
					<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Tailored to your industry and goal', 'vyntic' ); ?></li>
					<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'A copy sent straight to your inbox', 'vyntic' ); ?></li>
				</ul>
			</div>
			<div class="ai__plugin"><?php echo $vyntic_plugin_html; // phpcs:ignore WordPress.Security.EscapeOutput -- plugin output is escaped. ?></div>
		</div>
	</section>
	<?php
	return;
endif;

if ( ! vyntic_ai_available() ) {
	if ( current_user_can( 'manage_options' ) ) {
		echo '<div class="wrap"><p class="notice notice--error" style="margin-block:2rem">' . esc_html__( 'Editor note: install and set up the Vyntic AI Planner plugin to show the AI planner here. Visitors do not see this message.', 'vyntic' ) . '</p></div>';
	}
	return;
}
$vyntic_goals = array(
	__( 'More enquiries', 'vyntic' ),
	__( 'Online bookings', 'vyntic' ),
	__( 'Sell products online', 'vyntic' ),
	__( 'Look more trustworthy', 'vyntic' ),
);
$vyntic_contact = vyntic_template_url( 'page-templates/contact.php' );
?>
<section class="ai" id="ai-planner" aria-labelledby="ai-title">
	<div class="ai__bg" aria-hidden="true"></div>
	<div class="wrap ai__inner">
		<div class="ai__copy">
			<p class="ai__badge"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Try our AI website planner', 'vyntic' ); ?></p>
			<h2 class="ai__title" id="ai-title"><?php esc_html_e( 'Describe your business. Get your homepage plan in seconds.', 'vyntic' ); ?></h2>
			<p class="ai__text"><?php esc_html_e( 'Our planner suggests a headline, the sections your homepage needs and one quick win for speed or SEO. It is a starting point: our team turns it into the real thing.', 'vyntic' ); ?></p>
		</div>

		<div class="ai__app" data-ai data-endpoint="<?php echo esc_url( rest_url( 'vyntic/v1/plan' ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'vyntic_ai' ) ); ?>" data-contact="<?php echo esc_url( $vyntic_contact ); ?>">
			<form class="ai__form" data-ai-form>
				<label class="ai__label" for="ai-business"><?php esc_html_e( 'What does your business do, and where?', 'vyntic' ); ?></label>
				<textarea id="ai-business" name="business" rows="3" maxlength="400" required placeholder="<?php esc_attr_e( 'e.g. Family dental clinic in Leeds with two dentists and a hygienist', 'vyntic' ); ?>"></textarea>
				<fieldset class="ai__goals">
					<legend class="ai__label"><?php esc_html_e( 'Main goal', 'vyntic' ); ?></legend>
					<?php foreach ( $vyntic_goals as $vyntic_i => $vyntic_goal ) : ?>
						<label class="goal"><input type="radio" name="goal" value="<?php echo esc_attr( $vyntic_goal ); ?>" <?php checked( 0, $vyntic_i ); ?>><span><?php echo esc_html( $vyntic_goal ); ?></span></label>
					<?php endforeach; ?>
				</fieldset>
				<input type="text" name="hp" class="form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">
				<button class="btn btn--primary btn--lg ai__submit" type="submit"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Plan my homepage', 'vyntic' ); ?></span></button>
				<p class="ai__fine"><?php esc_html_e( 'Free. Nothing is saved. Written by AI, so check the details.', 'vyntic' ); ?></p>
			</form>

			<div class="ai__thinking" data-ai-loading hidden>
				<span class="ai__orb" aria-hidden="true"></span>
				<p data-ai-status><?php esc_html_e( 'Reading about your business…', 'vyntic' ); ?></p>
				<div class="skeleton"><i></i><i></i><i></i><i></i></div>
			</div>

			<div class="ai__result" data-ai-result hidden aria-live="polite">
				<div class="plan-preview">
					<div class="plan-preview__bar"><i></i><i></i><i></i><span><?php esc_html_e( 'Your homepage, planned', 'vyntic' ); ?></span></div>
					<div class="plan-preview__body">
						<h3 class="plan-preview__headline" data-ai-headline></h3>
						<p class="plan-preview__sub" data-ai-sub></p>
						<ol class="plan-preview__sections" data-ai-sections></ol>
						<div class="plan-preview__features">
							<p class="ai__label"><?php esc_html_e( 'Must-have features', 'vyntic' ); ?></p>
							<ul data-ai-features></ul>
						</div>
						<p class="plan-preview__tip"><strong><?php esc_html_e( 'Quick win:', 'vyntic' ); ?></strong> <span data-ai-tip></span></p>
					</div>
				</div>
				<div class="ai__actions">
					<a class="btn btn--primary btn--lg" href="<?php echo esc_url( $vyntic_contact ? $vyntic_contact : vyntic_cta_url() ); ?>" data-ai-build><?php esc_html_e( 'Build this with Vyntic', 'vyntic' ); ?></a>
					<button class="btn btn--ghost-light btn--lg" type="button" data-ai-reset><?php esc_html_e( 'Plan another', 'vyntic' ); ?></button>
				</div>
			</div>

			<p class="notice notice--error" data-ai-error hidden role="alert"></p>
		</div>
	</div>
</section>
