<?php
/**
 * Project inquiry form: services and budget as tap-friendly chips.
 *
 * @package Vyntic
 */

$vyntic_notice   = vyntic_form_notice();
$vyntic_back     = get_permalink() ? get_permalink() : home_url( '/' );
$vyntic_budgets  = array( __( 'Under $3k', 'vyntic' ), __( '$3k to $7.5k', 'vyntic' ), __( '$7.5k to $15k', 'vyntic' ), __( '$15k+', 'vyntic' ), __( 'Not sure yet', 'vyntic' ) );
$vyntic_timeline = array( __( 'As soon as possible', 'vyntic' ), __( 'In 1 to 3 months', 'vyntic' ), __( 'In 3 to 6 months', 'vyntic' ), __( 'Just exploring', 'vyntic' ) );
$vyntic_uid      = wp_unique_id( 'cf-' );
?>
<form class="form cform" id="contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<?php if ( $vyntic_notice ) : ?>
		<p class="notice notice--<?php echo esc_attr( $vyntic_notice['type'] ); ?>" role="<?php echo 'error' === $vyntic_notice['type'] ? 'alert' : 'status'; ?>"><?php echo esc_html( $vyntic_notice['text'] ); ?></p>
	<?php endif; ?>

	<input type="hidden" name="action" value="vyntic_contact">
	<input type="hidden" name="_back" value="<?php echo esc_url( $vyntic_back ); ?>">
	<?php wp_nonce_field( 'vyntic_contact', 'vyntic_contact_nonce' ); ?>
	<div class="form__hp" aria-hidden="true"><label for="<?php echo esc_attr( $vyntic_uid ); ?>-hp">Leave this empty</label><input type="text" id="<?php echo esc_attr( $vyntic_uid ); ?>-hp" name="company_website" tabindex="-1" autocomplete="off"></div>

	<fieldset class="cform__group">
		<legend><?php esc_html_e( 'What can we help with?', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'pick any', 'vyntic' ); ?></span></legend>
		<div class="chips">
			<?php foreach ( vyntic_services() as $vyntic_service ) : ?>
				<label class="pick"><input type="checkbox" name="services[]" value="<?php echo esc_attr( $vyntic_service['title'] ); ?>"><span><?php echo esc_html( $vyntic_service['title'] ); ?></span></label>
			<?php endforeach; ?>
		</div>
	</fieldset>

	<div class="form__row">
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-name"><?php esc_html_e( 'Your name', 'vyntic' ); ?></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-name" name="name" type="text" autocomplete="name" required>
		</div>
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-email"><?php esc_html_e( 'Work email', 'vyntic' ); ?></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-email" name="email" type="email" autocomplete="email" required>
		</div>
	</div>

	<div class="form__row">
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-phone"><?php esc_html_e( 'Phone or WhatsApp', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'optional', 'vyntic' ); ?></span></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-phone" name="phone" type="tel" autocomplete="tel">
		</div>
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-site"><?php esc_html_e( 'Current website', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'optional', 'vyntic' ); ?></span></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-site" name="website" type="text" inputmode="url" placeholder="yourbusiness.com">
		</div>
	</div>

	<fieldset class="cform__group">
		<legend><?php esc_html_e( 'Budget', 'vyntic' ); ?></legend>
		<div class="chips">
			<?php foreach ( $vyntic_budgets as $vyntic_i => $vyntic_budget ) : ?>
				<label class="pick"><input type="radio" name="budget" value="<?php echo esc_attr( $vyntic_budget ); ?>" <?php checked( 4, $vyntic_i ); ?>><span><?php echo esc_html( $vyntic_budget ); ?></span></label>
			<?php endforeach; ?>
		</div>
	</fieldset>

	<div class="field">
		<label for="<?php echo esc_attr( $vyntic_uid ); ?>-time"><?php esc_html_e( 'When do you want to launch?', 'vyntic' ); ?></label>
		<select id="<?php echo esc_attr( $vyntic_uid ); ?>-time" name="timeline">
			<?php foreach ( $vyntic_timeline as $vyntic_t ) : ?>
				<option><?php echo esc_html( $vyntic_t ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>

	<div class="field">
		<label for="f-message"><?php esc_html_e( 'Tell us about the project', 'vyntic' ); ?></label>
		<textarea id="f-message" name="message" rows="5" required placeholder="<?php esc_attr_e( 'What you sell, what is not working today, and anything you already know you need.', 'vyntic' ); ?>"></textarea>
	</div>

	<label class="cform__consent"><input type="checkbox" name="consent" value="1" required><span><?php esc_html_e( 'I agree that Vyntic Studio can use these details to reply to my inquiry.', 'vyntic' ); ?></span></label>

	<div class="cform__submit">
		<button class="btn btn--primary btn--lg" type="submit"><?php esc_html_e( 'Send inquiry', 'vyntic' ); ?></button>
		<p class="form__note"><?php esc_html_e( 'We reply within 24 hours on business days.', 'vyntic' ); ?></p>
	</div>
</form>
