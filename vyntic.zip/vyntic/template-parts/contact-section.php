<?php
/**
 * "Start a project" section with the full inquiry form (Home and Location pages).
 *
 * @package Vyntic
 */

$vyntic_email = vyntic_mod( 'email' );
$vyntic_phone = vyntic_mod( 'phone' );
$vyntic_wa    = preg_replace( '/\D+/', '', (string) vyntic_mod( 'whatsapp' ) );
?>
<section class="section contact-block" id="contact" aria-labelledby="contact-title">
	<div class="wrap contact-block__inner">
		<div class="contact-block__info">
			<h2 class="section__title" id="contact-title"><?php esc_html_e( 'Start a project', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Tell us a little about your business. You will hear from a real person within 24 hours with next steps and a rough budget range.', 'vyntic' ); ?></p>
			<ol class="next-steps">
				<li><?php esc_html_e( 'We read your message and look at your current site.', 'vyntic' ); ?></li>
				<li><?php esc_html_e( 'A 30-minute call at a time that suits your time zone.', 'vyntic' ); ?></li>
				<li><?php esc_html_e( 'A written scope with a fixed price within two business days.', 'vyntic' ); ?></li>
			</ol>
			<ul class="contact-block__direct">
				<?php if ( $vyntic_email ) : ?>
					<li><a href="mailto:<?php echo esc_attr( antispambot( $vyntic_email ) ); ?>"><?php echo vyntic_icon( 'chat' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><small><?php esc_html_e( 'Email us', 'vyntic' ); ?></small><?php echo esc_html( antispambot( $vyntic_email ) ); ?></span></a></li>
				<?php endif; ?>
				<?php if ( $vyntic_phone ) : ?>
					<li><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $vyntic_phone ) ); ?>"><?php echo vyntic_icon( 'target' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><small><?php esc_html_e( 'Call us', 'vyntic' ); ?></small><?php echo esc_html( $vyntic_phone ); ?></span></a></li>
				<?php endif; ?>
				<?php if ( $vyntic_wa ) : ?>
					<li><a href="<?php echo esc_url( 'https://wa.me/' . $vyntic_wa ); ?>"><?php echo vyntic_icon( 'chat' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><small><?php esc_html_e( 'WhatsApp', 'vyntic' ); ?></small><?php esc_html_e( 'Message us', 'vyntic' ); ?></span></a></li>
				<?php endif; ?>
			</ul>
		</div>
		<div class="contact-block__form">
			<?php get_template_part( 'template-parts/contact-form' ); ?>
		</div>
	</div>
</section>
