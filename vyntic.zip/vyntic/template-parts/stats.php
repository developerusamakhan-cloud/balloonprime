<?php
/**
 * Proof strip. Edit numbers in inc/content.php → vyntic_stats().
 *
 * @package Vyntic
 */
?>
<section class="proof" aria-label="<?php esc_attr_e( 'Studio in numbers', 'vyntic' ); ?>">
	<div class="wrap">
		<ul class="proof__grid">
			<?php foreach ( vyntic_stats() as $vyntic_stat ) : ?>
				<li class="proof__item">
					<span class="proof__icon"><?php echo vyntic_icon( isset( $vyntic_stat['icon'] ) ? $vyntic_stat['icon'] : 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<p class="proof__num"><span data-count="<?php echo esc_attr( $vyntic_stat['count'] ); ?>"><?php echo esc_html( $vyntic_stat['count'] ); ?></span><em><?php echo esc_html( $vyntic_stat['suffix'] ); ?></em></p>
					<p class="proof__label"><?php echo esc_html( $vyntic_stat['label'] ); ?></p>
					<?php if ( ! empty( $vyntic_stat['note'] ) ) : ?>
						<p class="proof__note"><?php echo esc_html( $vyntic_stat['note'] ); ?></p>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
