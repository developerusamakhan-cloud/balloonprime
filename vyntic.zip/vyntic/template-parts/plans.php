<?php
/**
 * Care plans.
 *
 * @package Vyntic
 */
?>
<section class="section" aria-label="<?php esc_attr_e( 'Care plans', 'vyntic' ); ?>">
	<div class="wrap">
		<div class="plans">
			<?php foreach ( vyntic_plans() as $vyntic_plan ) : ?>
				<article class="plan<?php echo $vyntic_plan['featured'] ? ' plan--featured' : ''; ?>">
					<?php if ( $vyntic_plan['featured'] ) : ?>
						<p class="plan__flag"><?php esc_html_e( 'Most chosen', 'vyntic' ); ?></p>
					<?php endif; ?>
					<h2 class="plan__name"><?php echo esc_html( $vyntic_plan['name'] ); ?></h2>
					<p class="plan__for"><?php echo esc_html( $vyntic_plan['for'] ); ?></p>
					<p class="plan__price"><span><?php echo esc_html( $vyntic_plan['price'] ); ?></span> <?php echo esc_html( $vyntic_plan['period'] ); ?></p>
					<ul class="plan__features">
						<?php foreach ( $vyntic_plan['features'] as $vyntic_feature ) : ?>
							<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $vyntic_feature ); ?></li>
						<?php endforeach; ?>
					</ul>
					<a class="btn <?php echo $vyntic_plan['featured'] ? 'btn--primary' : 'btn--ghost'; ?> plan__cta" href="<?php echo esc_url( vyntic_cta_url() ); ?>">
						<?php
						/* translators: %s plan name */
						echo esc_html( sprintf( __( 'Start %s', 'vyntic' ), $vyntic_plan['name'] ) );
						?>
					</a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
