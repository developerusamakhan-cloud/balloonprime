<?php
/**
 * Latest articles on Home: one row of three cards and a button to the blog.
 *
 * @package Vyntic
 */

$vyntic_posts = new WP_Query(
	array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);
if ( ! $vyntic_posts->have_posts() ) {
	return;
}
$vyntic_blog = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
?>
<section class="section journal" aria-labelledby="latest-title">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="latest-title"><?php esc_html_e( 'From the studio journal', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Practical notes on speed, SEO and AI search, written for business owners, not developers.', 'vyntic' ); ?></p>
		</div>
		<div class="post-grid journal__row">
			<?php
			while ( $vyntic_posts->have_posts() ) :
				$vyntic_posts->the_post();
				get_template_part( 'template-parts/post-card' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
		<div class="journal__more">
			<a class="btn btn--primary btn--lg" href="<?php echo esc_url( $vyntic_blog ); ?>"><?php esc_html_e( 'Read all articles', 'vyntic' ); ?></a>
		</div>
	</div>
</section>
