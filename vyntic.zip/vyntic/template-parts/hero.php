<?php
/**
 * Home hero: rotating headline, service pills and a visual that shows
 * the three things we deliver: a fast site, Google rankings and AI answers.
 * Per-page overrides: hero_title, hero_words, hero_text, hero_score.
 *
 * @package Vyntic
 */

$vyntic_lead  = vyntic_field( 'hero_title', vyntic_mod( 'hero_title' ) );
$vyntic_words = array_values( array_filter( array_map( 'trim', explode( '|', (string) vyntic_field( 'hero_words', vyntic_mod( 'hero_words' ) ) ) ) ) );
$vyntic_text  = vyntic_field( 'hero_text', vyntic_mod( 'hero_text' ) );
$vyntic_score = (int) vyntic_field( 'hero_score', vyntic_mod( 'hero_score' ) );
$vyntic_work  = vyntic_template_url( 'page-templates/work.php' );
$vyntic_label = trim( $vyntic_lead . ' ' . implode( ', ', $vyntic_words ) );
$vyntic_pills = array(
	array( 'code', __( 'Web design and development', 'vyntic' ) ),
	array( 'pin', __( 'SEO and local SEO', 'vyntic' ) ),
	array( 'spark', __( 'AI search visibility', 'vyntic' ) ),
	array( 'cart', __( 'Online stores', 'vyntic' ) ),
);
?>
<section class="hero">
	<div class="wrap hero__inner">
		<div class="hero__copy">
			<h1 class="hero__title" aria-label="<?php echo esc_attr( $vyntic_label ); ?>">
				<span class="hero__lead" aria-hidden="true"><?php echo esc_html( $vyntic_lead ); ?></span>
				<?php if ( $vyntic_words ) : ?>
					<span class="rotator" aria-hidden="true" data-rotator>
						<?php foreach ( $vyntic_words as $vyntic_i => $vyntic_word ) : ?>
							<span class="rotator__item<?php echo 0 === $vyntic_i ? ' is-active' : ''; ?>"><?php echo esc_html( $vyntic_word ); ?></span>
						<?php endforeach; ?>
					</span>
				<?php endif; ?>
			</h1>
			<p class="hero__text"><?php echo esc_html( $vyntic_text ); ?></p>
			<ul class="hero__pills">
				<?php foreach ( $vyntic_pills as $vyntic_pill ) : ?>
					<li><?php echo vyntic_icon( $vyntic_pill[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $vyntic_pill[1] ); ?></li>
				<?php endforeach; ?>
			</ul>
			<div class="hero__actions">
				<a class="btn btn--primary btn--lg" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
				<?php if ( $vyntic_work ) : ?>
					<a class="btn btn--ghost btn--lg" href="<?php echo esc_url( $vyntic_work ); ?>"><?php esc_html_e( 'See our work', 'vyntic' ); ?></a>
				<?php endif; ?>
			</div>
			<p class="hero__trust"><?php echo esc_html( vyntic_mod( 'trust_line' ) ); ?></p>
		</div>

		<div class="hero__visual">
			<a class="badge" href="#services" aria-label="<?php esc_attr_e( 'Scroll to services', 'vyntic' ); ?>">
				<svg class="badge__ring" viewBox="0 0 120 120" aria-hidden="true">
					<defs><path id="badge-circle" d="M60,60 m-45,0 a45,45 0 1,1 90,0 a45,45 0 1,1 -90,0"/></defs>
					<text textLength="282" lengthAdjust="spacing"><textPath href="#badge-circle" textLength="282" lengthAdjust="spacing"><?php esc_html_e( 'WEBSITES • SEO • AI SEARCH • CARE •', 'vyntic' ); ?></textPath></text>
				</svg>
				<span class="badge__arrow"><?php echo vyntic_icon( 'down' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			</a>
			<img class="hero__site" src="<?php echo esc_url( vyntic_img( 'hero-site.svg' ) ); ?>" alt="" width="640" height="480" fetchpriority="high">

			<div class="hcard hcard--ai" aria-hidden="true">
				<p class="hcard__q"><?php esc_html_e( 'Who builds fast websites near me?', 'vyntic' ); ?></p>
				<div class="hcard__a">
					<span class="hcard__spark"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<span><strong><?php esc_html_e( 'Recommended in AI answers', 'vyntic' ); ?></strong><?php esc_html_e( 'Cited as a source', 'vyntic' ); ?></span>
				</div>
			</div>

			<div class="hcard hcard--rank" aria-hidden="true">
				<span class="hcard__big">#1</span>
				<span><strong><?php esc_html_e( 'Top of Google', 'vyntic' ); ?></strong><?php esc_html_e( 'and the local map pack', 'vyntic' ); ?></span>
			</div>

			<figure class="report" aria-labelledby="report-caption">
				<div class="report__head">
					<?php vyntic_score_ring( $vyntic_score, 'lg' ); ?>
					<div>
						<p class="report__title"><?php esc_html_e( 'Mobile speed', 'vyntic' ); ?></p>
						<p class="report__verdict"><?php esc_html_e( 'Core Web Vitals passed', 'vyntic' ); ?></p>
					</div>
				</div>
				<dl class="report__vitals">
					<div class="vital"><dt><abbr title="<?php esc_attr_e( 'Largest content loads', 'vyntic' ); ?>">LCP</abbr></dt><dd><?php echo esc_html( vyntic_mod( 'hero_lcp' ) ); ?></dd></div>
					<div class="vital"><dt><abbr title="<?php esc_attr_e( 'Layout stays still', 'vyntic' ); ?>">CLS</abbr></dt><dd><?php echo esc_html( vyntic_mod( 'hero_cls' ) ); ?></dd></div>
					<div class="vital"><dt><abbr title="<?php esc_attr_e( 'Responds to taps', 'vyntic' ); ?>">INP</abbr></dt><dd><?php echo esc_html( vyntic_mod( 'hero_inp' ) ); ?></dd></div>
				</dl>
				<figcaption id="report-caption" class="screen-reader-text"><?php esc_html_e( 'A typical Vyntic launch, measured with Google PageSpeed Insights.', 'vyntic' ); ?></figcaption>
			</figure>
		</div>
	</div>
</section>
