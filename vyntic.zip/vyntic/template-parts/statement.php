<?php
/**
 * Studio statement with a highlighter effect on key phrases and a visual on the right.
 * Wrap phrases in [[double brackets]] to highlight them.
 * Per-page override: statement_text. Own photo: Customize → Vyntic options → Home hero → Statement image URL.
 *
 * @package Vyntic
 */

$vyntic_text  = vyntic_field(
	'statement_text',
	__( 'We are a small studio with high standards. We build [[fast websites]], get them [[found on Google]] and [[recommended by AI]], then keep them running long after launch. Clinics, stores, law firms and startups come to us when their old site stopped working for them.', 'vyntic' )
);
$vyntic_image = vyntic_mod( 'statement_image' );
$vyntic_html  = preg_replace( '/\[\[(.+?)\]\]/', '<mark class="hl">$1</mark>', esc_html( $vyntic_text ) );
?>
<section class="section statement" aria-label="<?php esc_attr_e( 'About the studio', 'vyntic' ); ?>">
	<div class="wrap statement__inner">
		<div class="statement__copy">
			<p class="statement__text"><?php echo wp_kses( $vyntic_html, array( 'mark' => array( 'class' => true ) ) ); ?></p>
		</div>
		<div class="statement__art" aria-hidden="true">
			<?php if ( $vyntic_image ) : ?>
				<img class="statement__photo" src="<?php echo esc_url( $vyntic_image ); ?>" alt="" loading="lazy">
			<?php else : ?>
				<img class="stack-img stack-img--1" src="<?php echo esc_url( vyntic_img( 'services/spark.svg' ) ); ?>" alt="" width="360" height="240" loading="lazy" data-speed="0.08">
				<img class="stack-img stack-img--2" src="<?php echo esc_url( vyntic_img( 'services/pin.svg' ) ); ?>" alt="" width="360" height="240" loading="lazy" data-speed="-0.05">
				<img class="stack-img stack-img--3" src="<?php echo esc_url( vyntic_img( 'services/code.svg' ) ); ?>" alt="" width="360" height="240" loading="lazy" data-speed="0.12">
			<?php endif; ?>
		</div>
	</div>
</section>
