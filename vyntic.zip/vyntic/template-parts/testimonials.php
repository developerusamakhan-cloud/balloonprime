<?php
/**
 * Client quotes, pulled from case studies that have a quote filled in.
 * Hidden until at least one project has a quote, so nothing is ever made up.
 *
 * @package Vyntic
 */

$vyntic_quotes = get_posts(
	array(
		'post_type'      => 'work',
		'posts_per_page' => 6,
		'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'key'     => 'project_quote',
				'value'   => '',
				'compare' => '!=',
			),
		),
	)
);
if ( ! $vyntic_quotes ) {
	return;
}
?>
<section class="section section--mist testimonials" aria-labelledby="quotes-title">
	<div class="wrap">
		<div class="section__head section__head--row">
			<div><h2 class="section__title" id="quotes-title"><?php esc_html_e( 'What clients say', 'vyntic' ); ?></h2></div>
			<?php if ( count( $vyntic_quotes ) > 1 ) : ?>
				<div class="slider-nav">
					<button type="button" class="slider-nav__btn" data-slide="-1" aria-label="<?php esc_attr_e( 'Previous quote', 'vyntic' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
					<button type="button" class="slider-nav__btn" data-slide="1" aria-label="<?php esc_attr_e( 'Next quote', 'vyntic' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
				</div>
			<?php endif; ?>
		</div>
		<div class="quotes" data-slider tabindex="0">
			<?php foreach ( $vyntic_quotes as $vyntic_q ) : ?>
				<figure class="quote-card">
					<blockquote><p><?php echo esc_html( vyntic_work_meta( 'project_quote', $vyntic_q->ID ) ); ?></p></blockquote>
					<figcaption>
						<strong><?php echo esc_html( vyntic_work_meta( 'project_quote_name', $vyntic_q->ID ) ); ?></strong>
						<span><?php echo esc_html( vyntic_work_meta( 'project_quote_role', $vyntic_q->ID ) ); ?></span>
						<a href="<?php echo esc_url( get_permalink( $vyntic_q ) ); ?>"><?php esc_html_e( 'Read the case study', 'vyntic' ); ?></a>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
