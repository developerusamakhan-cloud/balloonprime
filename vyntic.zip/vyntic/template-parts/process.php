<?php
/**
 * Four-step process on a dark band.
 *
 * @package Vyntic
 */
?>
<section class="section section--night" aria-labelledby="process-title">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="process-title"><?php esc_html_e( 'From first call to launch', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Fixed scope, fixed price, and you see the site at every stage.', 'vyntic' ); ?></p>
		</div>
		<ol class="process">
			<?php foreach ( vyntic_process() as $vyntic_i => $vyntic_step ) : ?>
				<li class="process__step">
					<span class="process__num" aria-hidden="true"><?php echo esc_html( $vyntic_i + 1 ); ?></span>
					<h3 class="process__title"><?php echo esc_html( $vyntic_step['title'] ); ?></h3>
					<p><?php echo esc_html( $vyntic_step['text'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
