<?php
/**
 * One project in the work grid. Used inside a loop of 'project' posts.
 *
 * @package Vyntic
 */

$vyntic_id       = get_the_ID();
$vyntic_before   = vyntic_work_meta( 'project_score_before', $vyntic_id );
$vyntic_after    = vyntic_work_meta( 'project_score_after', $vyntic_id );
$vyntic_industry = vyntic_work_meta( 'project_industry', $vyntic_id );
$vyntic_location = vyntic_work_meta( 'project_location', $vyntic_id );
$vyntic_result   = vyntic_work_meta( 'project_result', $vyntic_id );
?>
<article class="project">
	<a class="project__media browser" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<span class="browser__bar"><i></i><i></i><i></i></span>
		<span class="project__frame"><?php vyntic_thumb( 'vyntic-project', 'project-fallback.svg' ); ?></span>
		<span class="project__view"><?php esc_html_e( 'View case study', 'vyntic' ); ?></span>
	</a>
	<div class="project__body">
		<div class="project__meta">
			<?php if ( $vyntic_industry ) : ?>
				<span><?php echo esc_html( $vyntic_industry ); ?></span>
			<?php endif; ?>
			<?php if ( $vyntic_location ) : ?>
				<span><?php echo esc_html( $vyntic_location ); ?></span>
			<?php endif; ?>
		</div>
		<h3 class="project__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<?php if ( $vyntic_result ) : ?>
			<p class="project__result"><?php echo esc_html( $vyntic_result ); ?></p>
		<?php elseif ( has_excerpt() ) : ?>
			<p class="project__result"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>
		<?php if ( '' !== $vyntic_after ) : ?>
			<div class="project__scores">
				<?php if ( '' !== $vyntic_before ) : ?>
					<span class="score-chip score-chip--<?php echo esc_attr( vyntic_score_band( $vyntic_before ) ); ?>">
						<span class="screen-reader-text"><?php esc_html_e( 'PageSpeed before:', 'vyntic' ); ?></span><?php echo esc_html( $vyntic_before ); ?>
					</span>
					<span class="project__to" aria-hidden="true"></span>
				<?php endif; ?>
				<span class="score-chip score-chip--<?php echo esc_attr( vyntic_score_band( $vyntic_after ) ); ?>">
					<span class="screen-reader-text"><?php esc_html_e( 'PageSpeed after:', 'vyntic' ); ?></span><?php echo esc_html( $vyntic_after ); ?>
				</span>
				<span class="project__scores-label"><?php esc_html_e( 'PageSpeed, mobile', 'vyntic' ); ?></span>
			</div>
		<?php endif; ?>
	</div>
</article>
