<?php
/**
 * Platforms we build on. Edit in inc/content.php → vyntic_platforms().
 *
 * @package Vyntic
 */
?>
<section class="section platforms" aria-labelledby="platforms-title">
	<div class="wrap">
		<div class="section__head section__head--row">
			<div>
				<h2 class="section__title" id="platforms-title"><?php esc_html_e( 'One standard, whatever your platform', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'We build, fix and grow sites on the platforms businesses actually use. We recommend the right one for you, then hold it to the same bar: fast, easy to edit, found on Google and in AI answers.', 'vyntic' ); ?></p>
			</div>
		</div>
		<ul class="platforms__grid">
			<?php foreach ( vyntic_platforms() as $vyntic_p ) : ?>
				<?php
				$vyntic_pkey = array( 'WordPress' => 'wordpress-development', 'Webflow' => 'webflow-development', 'Shopify' => 'shopify-development', 'WooCommerce' => 'woocommerce-development', 'GoHighLevel' => 'gohighlevel', 'Wix' => 'wix', 'Squarespace' => 'squarespace' );
				$vyntic_purl = isset( $vyntic_pkey[ $vyntic_p[0] ] ) && function_exists( 'vyntic_landing_url' ) ? vyntic_template_url( vyntic_landing_template( $vyntic_pkey[ $vyntic_p[0] ] ) ) : '';
				?>
				<li class="platform" style="--brand: <?php echo esc_attr( $vyntic_p[3] ); ?>">
					<span class="platform__mark" aria-hidden="true"><?php echo esc_html( $vyntic_p[2] ); ?></span>
					<h3 class="platform__name"><?php if ( $vyntic_purl ) : ?><a class="platform__link" href="<?php echo esc_url( $vyntic_purl ); ?>"><?php echo esc_html( $vyntic_p[0] ); ?></a><?php else : ?><?php echo esc_html( $vyntic_p[0] ); ?><?php endif; ?></h3>
					<p class="platform__best"><span><?php esc_html_e( 'Best for', 'vyntic' ); ?></span><?php echo esc_html( $vyntic_p[1] ); ?></p>
				</li>
			<?php endforeach; ?>
			<li class="platform platform--help">
				<p class="platform__name"><?php esc_html_e( 'Not sure which one fits?', 'vyntic' ); ?></p>
				<p><?php esc_html_e( 'Tell us about your business and we will recommend a platform, with the reasons, in your first call.', 'vyntic' ); ?></p>
				<a class="btn btn--light" href="#contact"><?php esc_html_e( 'Ask us', 'vyntic' ); ?></a>
			</li>
		</ul>
	</div>
</section>
