<?php
/**
 * Outputs the page's own editor content, if any, inside a readable column.
 * This lets you add extra text or blocks to any template from the editor.
 *
 * @package Vyntic
 */

$vyntic_class = isset( $args['class'] ) ? $args['class'] : '';
if ( '' === trim( (string) get_post_field( 'post_content', get_the_ID() ) ) ) {
	return;
}
?>
<section class="section section--content <?php echo esc_attr( $vyntic_class ); ?>">
	<div class="wrap">
		<div class="prose">
			<?php the_content(); ?>
		</div>
	</div>
</section>
