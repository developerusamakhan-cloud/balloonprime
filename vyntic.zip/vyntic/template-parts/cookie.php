<?php
/**
 * Cookie consent banner. Choice is stored in the browser for 12 months.
 * Fires a "vyntic:consent" event and updates Google Consent Mode when gtag is present.
 *
 * @package Vyntic
 */

$vyntic_policy = vyntic_page_url( 'cookie-policy' );
$vyntic_policy = $vyntic_policy ? $vyntic_policy : get_privacy_policy_url();
?>
<div class="cookie" data-cookie hidden role="dialog" aria-live="polite" aria-labelledby="cookie-title" aria-describedby="cookie-text">
	<div class="cookie__icon" aria-hidden="true">
		<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="19" fill="#e9b949"/><path d="M24 5a19 19 0 1 0 19 19 6 6 0 0 1-7-6 6 6 0 0 1-6-7 6 6 0 0 1-6-6z" fill="#d49a2e"/><circle cx="17" cy="19" r="2.6" fill="#6b3e1f"/><circle cx="27" cy="30" r="3" fill="#6b3e1f"/><circle cx="16" cy="31" r="2" fill="#6b3e1f"/><circle cx="31" cy="21" r="1.8" fill="#6b3e1f"/></svg>
	</div>
	<div class="cookie__body">
		<p class="cookie__title" id="cookie-title"><?php esc_html_e( 'Cookies, but only the useful kind', 'vyntic' ); ?></p>
		<p class="cookie__text" id="cookie-text">
			<?php esc_html_e( 'We use essential cookies to run the site and, with your OK, analytics cookies to see what helps visitors.', 'vyntic' ); ?>
			<?php if ( $vyntic_policy ) : ?>
				<a href="<?php echo esc_url( $vyntic_policy ); ?>"><?php esc_html_e( 'Read our cookie policy', 'vyntic' ); ?></a>
			<?php endif; ?>
		</p>
		<div class="cookie__actions">
			<button type="button" class="btn btn--primary" data-cookie-choice="all"><?php esc_html_e( 'Accept all', 'vyntic' ); ?></button>
			<button type="button" class="btn btn--ghost" data-cookie-choice="essential"><?php esc_html_e( 'Essential only', 'vyntic' ); ?></button>
		</div>
	</div>
</div>
<button type="button" class="cookie-reopen" data-cookie-reopen hidden aria-label="<?php esc_attr_e( 'Cookie settings', 'vyntic' ); ?>">
	<svg viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="19" fill="#e9b949"/><circle cx="17" cy="19" r="2.6" fill="#6b3e1f"/><circle cx="27" cy="30" r="3" fill="#6b3e1f"/><circle cx="31" cy="21" r="1.8" fill="#6b3e1f"/></svg>
</button>
