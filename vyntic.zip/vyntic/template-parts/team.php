<?php
/**
 * Team grid built from WordPress users (Users → Profile: name, job title, bio, photo).
 *
 * @package Vyntic
 */

$vyntic_team = vyntic_team();
if ( ! $vyntic_team ) {
	return;
}
?>
<section class="section section--mist team" aria-labelledby="team-title">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="team-title"><?php esc_html_e( 'The people behind your project', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'A small team, so you always work with the people doing the work.', 'vyntic' ); ?></p>
		</div>
		<ul class="team__grid">
			<?php foreach ( $vyntic_team as $vyntic_u ) : ?>
				<?php
				$vyntic_job   = get_user_meta( $vyntic_u->ID, 'vyntic_job', true );
				$vyntic_bio   = get_user_meta( $vyntic_u->ID, 'description', true );
				$vyntic_count = count_user_posts( $vyntic_u->ID, 'post', true );
				?>
				<li class="member">
					<?php echo vyntic_avatar( $vyntic_u->ID, 88, 'member__avatar' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<h3 class="member__name"><?php echo esc_html( $vyntic_u->display_name ); ?></h3>
					<?php if ( $vyntic_job ) : ?><p class="member__job"><?php echo esc_html( $vyntic_job ); ?></p><?php endif; ?>
					<?php if ( $vyntic_bio ) : ?><p class="member__bio"><?php echo esc_html( wp_trim_words( $vyntic_bio, 30 ) ); ?></p><?php endif; ?>
					<?php if ( $vyntic_count ) : ?>
						<a class="member__link" href="<?php echo esc_url( get_author_posts_url( $vyntic_u->ID ) ); ?>">
							<?php
							/* translators: %d number of articles */
							echo esc_html( sprintf( _n( '%d article', '%d articles', $vyntic_count, 'vyntic' ), $vyntic_count ) );
							?>
						</a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
