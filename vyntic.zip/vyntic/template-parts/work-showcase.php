<?php
/**
 * Selected work on a dark band. On desktop the row moves sideways as you scroll down;
 * on phones it is a swipeable row.
 *
 * @package Vyntic
 */

$vyntic_items = new WP_Query(
	array(
		'post_type'      => 'work',
		'posts_per_page' => 6,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		'no_found_rows'  => true,
	)
);
if ( ! $vyntic_items->have_posts() ) {
	if ( current_user_can( 'edit_posts' ) ) {
		get_template_part( 'template-parts/work-grid', null, array( 'count' => 4 ) );
	}
	return;
}
$vyntic_work_url = vyntic_template_url( 'page-templates/work.php' );
?>
<section class="reel" aria-labelledby="reel-title" data-reel>
	<div class="reel__sticky">
		<div class="wrap reel__head">
			<h2 class="section__title" id="reel-title"><?php esc_html_e( 'Work we are proud of', 'vyntic' ); ?></h2>
			<?php if ( $vyntic_work_url ) : ?>
				<a class="btn btn--light" href="<?php echo esc_url( $vyntic_work_url ); ?>"><?php esc_html_e( 'All case studies', 'vyntic' ); ?></a>
			<?php endif; ?>
		</div>
		<div class="reel__track" data-reel-track>
			<?php
			while ( $vyntic_items->have_posts() ) :
				$vyntic_items->the_post();
				$vyntic_after  = vyntic_work_meta( 'project_score_after' );
				$vyntic_result = vyntic_work_meta( 'project_result' );
				?>
				<article class="reel-card">
					<a class="reel-card__link" href="<?php the_permalink(); ?>" data-cursor="<?php esc_attr_e( 'View', 'vyntic' ); ?>">
						<span class="reel-card__media"><?php vyntic_thumb( 'large', 'project-fallback.svg' ); ?></span>
						<?php if ( '' !== $vyntic_after ) : ?>
							<span class="reel-card__score score-chip score-chip--<?php echo esc_attr( vyntic_score_band( $vyntic_after ) ); ?>"><?php echo esc_html( $vyntic_after ); ?></span>
						<?php endif; ?>
					</a>
					<div class="reel-card__meta">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p><?php echo esc_html( $vyntic_result ? $vyntic_result : get_the_excerpt() ); ?></p>
					</div>
				</article>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		</div>
		<div class="wrap"><div class="reel__progress" aria-hidden="true"><span data-reel-progress></span></div></div>
	</div>
</section>
