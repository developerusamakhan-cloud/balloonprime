<?php
/**
 * Grid of projects.
 * Args: count (int, -1 for all), heading, lead, more (bool), heading_level.
 *
 * @package Vyntic
 */

$vyntic_count   = isset( $args['count'] ) ? (int) $args['count'] : 4;
$vyntic_heading = isset( $args['heading'] ) ? $args['heading'] : __( 'Recent work', 'vyntic' );
$vyntic_lead    = isset( $args['lead'] ) ? $args['lead'] : __( 'Real sites, with the PageSpeed score before and after we rebuilt them.', 'vyntic' );
$vyntic_more    = ! empty( $args['more'] );
$vyntic_type    = isset( $_GET['type'] ) ? sanitize_title( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$vyntic_filter  = ! empty( $args['filter'] );

$vyntic_query_args = array(
	'post_type'      => 'work',
	'posts_per_page' => $vyntic_count,
	'orderby'        => array(
		'menu_order' => 'ASC',
		'date'       => 'DESC',
	),
	'no_found_rows'  => true,
);
if ( ! empty( $args['exclude'] ) ) {
	$vyntic_query_args['post__not_in'] = array( (int) $args['exclude'] );
}
if ( $vyntic_filter && $vyntic_type ) {
	$vyntic_query_args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
		array(
			'taxonomy' => 'project_type',
			'field'    => 'slug',
			'terms'    => $vyntic_type,
		),
	);
}
$vyntic_projects = new WP_Query( $vyntic_query_args );

if ( ! $vyntic_projects->have_posts() && ! current_user_can( 'edit_posts' ) ) {
	return;
}
$vyntic_work_url = vyntic_template_url( 'page-templates/work.php' );
?>
<section class="section section--mist" id="work" aria-labelledby="work-title">
	<div class="wrap">
		<div class="section__head section__head--row">
			<div>
				<h2 class="section__title" id="work-title"><?php echo esc_html( $vyntic_heading ); ?></h2>
				<?php if ( $vyntic_lead ) : ?>
					<p class="section__lead"><?php echo esc_html( $vyntic_lead ); ?></p>
				<?php endif; ?>
			</div>
			<?php if ( $vyntic_more && $vyntic_work_url ) : ?>
				<a class="btn btn--ghost" href="<?php echo esc_url( $vyntic_work_url ); ?>"><?php esc_html_e( 'View all projects', 'vyntic' ); ?></a>
			<?php endif; ?>
		</div>

		<?php if ( $vyntic_filter ) : ?>
			<?php $vyntic_terms = get_terms( array( 'taxonomy' => 'project_type', 'hide_empty' => true ) ); ?>
			<?php if ( ! is_wp_error( $vyntic_terms ) && $vyntic_terms ) : ?>
				<nav class="filters" aria-label="<?php esc_attr_e( 'Filter projects', 'vyntic' ); ?>">
					<a class="filter" href="<?php echo esc_url( remove_query_arg( 'type' ) ); ?>" <?php echo $vyntic_type ? '' : 'aria-current="page"'; ?>><?php esc_html_e( 'All', 'vyntic' ); ?></a>
					<?php foreach ( $vyntic_terms as $vyntic_term ) : ?>
						<a class="filter" href="<?php echo esc_url( add_query_arg( 'type', $vyntic_term->slug ) ); ?>" <?php echo $vyntic_type === $vyntic_term->slug ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $vyntic_term->name ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( $vyntic_projects->have_posts() ) : ?>
			<div class="work-grid">
				<?php
				while ( $vyntic_projects->have_posts() ) :
					$vyntic_projects->the_post();
					get_template_part( 'template-parts/project-card' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		<?php else : ?>
			<div class="empty">
				<p><strong><?php esc_html_e( 'No projects yet.', 'vyntic' ); ?></strong> <?php esc_html_e( 'Only logged-in editors see this message. Add your first case study under Projects in the dashboard and it will appear here.', 'vyntic' ); ?></p>
				<a class="btn btn--primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=work' ) ); ?>"><?php esc_html_e( 'Add a project', 'vyntic' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</section>
