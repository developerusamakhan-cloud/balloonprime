<?php
/**
 * Services as rows. On desktop a preview card follows the cursor over each row.
 * Args: heading, intro, id.
 *
 * @package Vyntic
 */

$vyntic_heading = isset( $args['heading'] ) ? $args['heading'] : __( 'Everything you need to win online', 'vyntic' );
$vyntic_intro   = isset( $args['intro'] ) ? $args['intro'] : __( 'Websites, stores and the AI tools around them. One team, one standard: fast, easy to edit and built to rank.', 'vyntic' );
$vyntic_id      = isset( $args['id'] ) ? $args['id'] : 'services';
$vyntic_tones   = array( 'ink', 'coral', 'mint', 'sand' );
?>
<section class="section" id="<?php echo esc_attr( $vyntic_id ); ?>" aria-labelledby="<?php echo esc_attr( $vyntic_id ); ?>-title" data-preview-zone>
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="<?php echo esc_attr( $vyntic_id ); ?>-title"><?php echo esc_html( $vyntic_heading ); ?></h2>
			<?php if ( $vyntic_intro ) : ?>
				<p class="section__lead"><?php echo esc_html( $vyntic_intro ); ?></p>
			<?php endif; ?>
		</div>
		<ul class="services">
			<?php foreach ( vyntic_services() as $vyntic_i => $vyntic_service ) : ?>
				<link rel="prefetch" as="image" href="<?php echo esc_url( vyntic_img( 'services/' . ( isset( $vyntic_service['icon'] ) ? $vyntic_service['icon'] : 'code' ) . '.svg' ) ); ?>">
				<?php
				$vyntic_url  = ( ! empty( $vyntic_service['url'] ) ? $vyntic_service['url'] : vyntic_page_url( $vyntic_service['page'] ) );
				$vyntic_icon = isset( $vyntic_service['icon'] ) ? $vyntic_service['icon'] : 'code';
				$vyntic_tone = $vyntic_tones[ $vyntic_i % count( $vyntic_tones ) ];
				?>
				<li class="service<?php echo $vyntic_url ? ' service--link' : ''; ?>" data-preview-img="<?php echo esc_url( ! empty( $vyntic_service['image'] ) ? $vyntic_service['image'] : vyntic_img( 'services/' . $vyntic_icon . '.svg' ) ); ?>" data-preview-tone="<?php echo esc_attr( $vyntic_tone ); ?>" data-preview-label="<?php echo esc_attr( $vyntic_service['title'] ); ?>">
					<div class="service__main">
						<h3 class="service__title">
							<?php if ( $vyntic_url ) : ?>
								<a href="<?php echo esc_url( $vyntic_url ); ?>"><?php echo esc_html( $vyntic_service['title'] ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $vyntic_service['title'] ); ?>
							<?php endif; ?>
						</h3>
						<?php if ( ! empty( $vyntic_service['tags'] ) ) : ?>
							<ul class="service__tags">
								<?php foreach ( $vyntic_service['tags'] as $vyntic_tag ) : ?>
									<li><?php echo esc_html( $vyntic_tag ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
					<p class="service__text"><?php echo esc_html( $vyntic_service['text'] ); ?></p>
					<span class="service__more" aria-hidden="true"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="preview" aria-hidden="true" data-preview>
		<div class="preview__card">
			<div class="preview__inner"><img class="preview__img" src="" alt="" width="360" height="240"></div>
			<span class="preview__label"></span>
		</div>
	</div>
</section>
