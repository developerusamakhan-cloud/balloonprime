<?php
/**
 * Scrolling strip of the tools we build with. Pauses on hover; static with reduced motion.
 *
 * @package Vyntic
 */

$vyntic_items = array_merge( vyntic_stack(), array( __( 'Core Web Vitals', 'vyntic' ), __( 'Schema markup', 'vyntic' ), __( 'Technical SEO', 'vyntic' ) ) );
?>
<section class="marquee" aria-label="<?php esc_attr_e( 'Tools and skills', 'vyntic' ); ?>">
	<div class="marquee__track">
		<?php for ( $vyntic_copy = 0; $vyntic_copy < 2; $vyntic_copy++ ) : ?>
			<ul class="marquee__list" <?php echo $vyntic_copy ? 'aria-hidden="true"' : ''; ?>>
				<?php foreach ( $vyntic_items as $vyntic_item ) : ?>
					<li><?php echo esc_html( $vyntic_item ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endfor; ?>
	</div>
</section>
