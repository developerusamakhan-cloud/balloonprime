<?php
/**
 * Blog post card.
 * Args: variant = card (default) | feature (large, stacked) | wide (large, image left) | row (compact, horizontal).
 *
 * @package Vyntic
 */

$vyntic_variant = isset( $args['variant'] ) ? $args['variant'] : 'card';
$vyntic_minutes = vyntic_reading_time();
$vyntic_cats    = get_the_category();
$vyntic_cat     = $vyntic_cats ? $vyntic_cats[0]->name : '';
$vyntic_author  = (int) get_the_author_meta( 'ID' );
?>
<article <?php post_class( 'pcard pcard--' . $vyntic_variant ); ?>>
	<a class="pcard__link" href="<?php the_permalink(); ?>" data-cursor="<?php esc_attr_e( 'Read', 'vyntic' ); ?>">
		<span class="pcard__media">
			<?php vyntic_thumb( in_array( $vyntic_variant, array( 'feature', 'wide' ), true ) ? 'large' : 'vyntic-card', 'post-fallback.svg', array( 'loading' => 'wide' === $vyntic_variant ? 'eager' : 'lazy' ) ); ?>
			<?php if ( $vyntic_cat ) : ?>
				<span class="pcard__cat"><?php echo esc_html( $vyntic_cat ); ?></span>
			<?php endif; ?>
		</span>

		<span class="pcard__body">
			<span class="pcard__meta">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time>
				<span class="pcard__read">
					<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M8 4.5V8l2.5 1.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
					<?php
					/* translators: %d minutes */
					echo esc_html( sprintf( __( '%d min read', 'vyntic' ), $vyntic_minutes ) );
					?>
				</span>
			</span>
			<span class="pcard__title"><?php the_title(); ?></span>
			<?php if ( 'row' !== $vyntic_variant ) : ?>
				<span class="pcard__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></span>
			<?php endif; ?>
			<span class="pcard__foot">
				<span class="pcard__author">
					<?php echo vyntic_avatar( $vyntic_author, 28, 'pcard__avatar' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php echo esc_html( vyntic_author_name( $vyntic_author ) ); ?>
				</span>
				<span class="pcard__go" aria-hidden="true"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			</span>
		</span>
		<span class="pcard__bar" aria-hidden="true"></span>
	</a>
</article>
