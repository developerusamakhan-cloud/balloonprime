<?php
/**
 * Process as stacked cards: each step pins and the next one slides over it.
 *
 * @package Vyntic
 */

$vyntic_details = apply_filters(
	'vyntic_process_tags',
	array(
		array( __( '30-min call', 'vyntic' ), __( 'Written scope', 'vyntic' ), __( 'Fixed price', 'vyntic' ) ),
		array( __( 'Wireframes', 'vyntic' ), __( 'Figma designs', 'vyntic' ), __( 'Mobile first', 'vyntic' ) ),
		array( __( 'Platform setup', 'vyntic' ), __( 'Easy editing', 'vyntic' ), __( 'Speed testing', 'vyntic' ) ),
		array( __( 'Cloudflare', 'vyntic' ), __( 'Training video', 'vyntic' ), __( 'Care plan', 'vyntic' ) ),
	)
);
?>
<section class="section process-stack" aria-labelledby="stack-title">
	<div class="wrap">
		<div class="section__head">
			<h2 class="section__title" id="stack-title"><?php esc_html_e( 'How we work, step by step', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Fixed scope, fixed price, and you see the site at every stage.', 'vyntic' ); ?></p>
		</div>
		<ol class="stack-cards">
			<?php foreach ( vyntic_process() as $vyntic_i => $vyntic_step ) : ?>
				<li class="stack-card" style="--n: <?php echo esc_attr( $vyntic_i ); ?>">
					<div class="stack-card__body">
						<p class="stack-card__step"><?php /* translators: %d step number */ echo esc_html( sprintf( __( 'Step %d', 'vyntic' ), $vyntic_i + 1 ) ); ?></p>
						<h3 class="stack-card__title"><?php echo esc_html( $vyntic_step['title'] ); ?></h3>
						<p class="stack-card__text"><?php echo esc_html( $vyntic_step['text'] ); ?></p>
						<?php if ( isset( $vyntic_details[ $vyntic_i ] ) ) : ?>
							<ul class="stack-card__tags">
								<?php foreach ( $vyntic_details[ $vyntic_i ] as $vyntic_tag ) : ?>
									<li><?php echo esc_html( $vyntic_tag ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
					<span class="stack-card__num" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $vyntic_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
