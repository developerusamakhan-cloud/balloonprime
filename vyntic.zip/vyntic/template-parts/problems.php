<?php
/**
 * "Is your website costing you money?" section.
 *
 * @package Vyntic
 */

$vyntic_audit_url = vyntic_template_url( 'page-templates/free-audit.php' );
$vyntic_audit_url = $vyntic_audit_url ? $vyntic_audit_url : '#free-audit';
?>
<section class="section problems" aria-labelledby="problems-title">
	<div class="wrap problems__inner">
		<div class="problems__head">
			<h2 class="section__title" id="problems-title"><?php esc_html_e( 'Is your website costing you money?', 'vyntic' ); ?></h2>
			<p class="section__lead"><?php esc_html_e( 'Most sites we are asked to fix show at least two of these signs. Each one is fixable, and most are fixed by the same rebuild.', 'vyntic' ); ?></p>
			<a class="btn btn--primary" href="<?php echo esc_url( $vyntic_audit_url ); ?>"><?php esc_html_e( 'Check my site for free', 'vyntic' ); ?></a>
		</div>
		<ul class="problems__list">
			<?php foreach ( vyntic_problems() as $vyntic_problem ) : ?>
				<li class="problem">
					<span class="problem__dot" aria-hidden="true"></span>
					<h3 class="problem__title"><?php echo esc_html( $vyntic_problem['title'] ); ?></h3>
					<p><?php echo esc_html( $vyntic_problem['text'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
