<?php
/**
 * Reviews wall. Reviews are managed in the dashboard under Reviews.
 * With 4 or more reviews the two columns scroll gently in opposite directions.
 *
 * @package Vyntic
 */

$vyntic_reviews = vyntic_reviews( 24 );
if ( ! $vyntic_reviews ) {
	if ( current_user_can( 'edit_posts' ) ) {
		echo '<div class="wrap"><p class="notice notice--error" style="margin-block:2rem">' . esc_html__( 'Editor note: add client reviews under Reviews in the dashboard and they will appear here. Visitors do not see this message.', 'vyntic' ) . '</p></div>';
	}
	get_template_part( 'template-parts/testimonials' );
	return;
}

$vyntic_total = 0;
foreach ( $vyntic_reviews as $vyntic_r ) {
	$vyntic_total += (int) ( get_post_meta( $vyntic_r->ID, 'review_rating', true ) ? get_post_meta( $vyntic_r->ID, 'review_rating', true ) : 5 );
}
$vyntic_avg     = round( $vyntic_total / count( $vyntic_reviews ), 1 );
$vyntic_moving  = count( $vyntic_reviews ) >= 4;
$vyntic_columns = array( array(), array() );
foreach ( $vyntic_reviews as $vyntic_i => $vyntic_r ) {
	$vyntic_columns[ $vyntic_i % 2 ][] = $vyntic_r;
}

$vyntic_card = function ( $review ) {
	$rating = (int) get_post_meta( $review->ID, 'review_rating', true );
	$rating = $rating ? $rating : 5;
	$role   = get_post_meta( $review->ID, 'review_role', true );
	$source = get_post_meta( $review->ID, 'review_source', true );
	$link   = get_post_meta( $review->ID, 'review_link', true );
	$big    = get_post_meta( $review->ID, 'review_featured', true );
	$text   = wp_strip_all_tags( $review->post_content );
	$name   = get_the_title( $review );
	?>
	<figure class="rcard<?php echo $big ? ' rcard--big' : ''; ?>">
		<div class="rcard__top">
			<?php echo vyntic_stars( $rating ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php if ( $source ) : ?>
				<?php if ( $link ) : ?>
					<a class="rcard__source" href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $source ); ?></a>
				<?php else : ?>
					<span class="rcard__source"><?php echo esc_html( $source ); ?></span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<blockquote class="rcard__text"><p><?php echo esc_html( $text ); ?></p></blockquote>
		<figcaption class="rcard__who">
			<?php if ( has_post_thumbnail( $review ) ) : ?>
				<?php echo get_the_post_thumbnail( $review, 'thumbnail', array( 'class' => 'rcard__photo', 'alt' => '', 'loading' => 'lazy' ) ); ?>
			<?php else : ?>
				<span class="rcard__initials" aria-hidden="true"><?php echo esc_html( mb_strtoupper( mb_substr( $name, 0, 1 ) ) ); ?></span>
			<?php endif; ?>
			<span><strong><?php echo esc_html( $name ); ?></strong><?php if ( $role ) : ?><span><?php echo esc_html( $role ); ?></span><?php endif; ?></span>
		</figcaption>
	</figure>
	<?php
};
?>
<section class="section reviews" aria-labelledby="reviews-title">
	<div class="wrap reviews__inner">
		<div class="reviews__summary">
			<h2 class="section__title" id="reviews-title"><?php esc_html_e( 'What our clients say', 'vyntic' ); ?></h2>
			<div class="reviews__score">
				<span class="reviews__avg"><?php echo esc_html( number_format_i18n( $vyntic_avg, 1 ) ); ?></span>
				<div>
					<?php echo vyntic_stars( $vyntic_avg ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<p>
						<?php
						/* translators: %d number of reviews */
						echo esc_html( sprintf( _n( 'Based on %d review', 'Based on %d reviews', count( $vyntic_reviews ), 'vyntic' ), count( $vyntic_reviews ) ) );
						?>
					</p>
				</div>
			</div>
			<p class="section__lead"><?php esc_html_e( 'Real words from the people we build for, in their own words.', 'vyntic' ); ?></p>
			<a class="btn btn--primary btn--lg" href="#contact"><?php esc_html_e( 'Start your project', 'vyntic' ); ?></a>
		</div>

		<div class="reviews__wall<?php echo $vyntic_moving ? ' is-moving' : ''; ?>">
			<?php foreach ( $vyntic_columns as $vyntic_c => $vyntic_col ) : ?>
				<?php if ( ! $vyntic_col ) { continue; } ?>
				<div class="reviews__col reviews__col--<?php echo esc_attr( $vyntic_c ); ?>">
					<div class="reviews__track">
						<?php
						foreach ( $vyntic_col as $vyntic_review ) {
							$vyntic_card( $vyntic_review );
						}
						if ( $vyntic_moving ) {
							echo '<div class="reviews__dupe" aria-hidden="true">';
							foreach ( $vyntic_col as $vyntic_review ) {
								$vyntic_card( $vyntic_review );
							}
							echo '</div>';
						}
						?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
