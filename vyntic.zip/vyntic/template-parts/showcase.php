<?php
/**
 * Scroll showcase: a wide panel that grows to full size as you scroll,
 * with floating result chips moving at different speeds.
 *
 * @package Vyntic
 */
?>
<section class="showcase" aria-label="<?php esc_attr_e( 'What a Vyntic site feels like', 'vyntic' ); ?>" data-showcase>
	<div class="wrap">
		<div class="showcase__panel" data-showcase-panel>
			<div class="showcase__glow" aria-hidden="true"></div>
			<p class="showcase__word" aria-hidden="true">fast.</p>
			<div class="showcase__stage">
				<img class="showcase__site" src="<?php echo esc_url( vyntic_img( 'hero-site.svg' ) ); ?>" alt="" width="640" height="480" loading="lazy" data-speed="-0.04">
				<div class="chip chip--score" data-speed="0.12">
					<?php vyntic_score_ring( vyntic_mod( 'hero_score' ), 'sm' ); ?>
					<span><strong><?php esc_html_e( 'Mobile score', 'vyntic' ); ?></strong><?php esc_html_e( 'Google PageSpeed', 'vyntic' ); ?></span>
				</div>
				<div class="chip chip--lead" data-speed="-0.1">
					<span class="chip__dot"></span>
					<span><strong><?php esc_html_e( 'New enquiry', 'vyntic' ); ?></strong><?php esc_html_e( 'from the contact form', 'vyntic' ); ?></span>
				</div>
				<div class="chip chip--rank" data-speed="0.07">
					<span class="chip__big">#1</span>
					<span><strong><?php esc_html_e( 'On page one', 'vyntic' ); ?></strong><?php esc_html_e( 'for your main keyword', 'vyntic' ); ?></span>
				</div>
			</div>
			<p class="showcase__caption"><?php esc_html_e( 'Fast pages, found on Google, turning visits into enquiries.', 'vyntic' ); ?></p>
		</div>
	</div>
</section>
