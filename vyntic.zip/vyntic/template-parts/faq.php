<?php
/**
 * FAQ using native details/summary, so it works without JavaScript.
 *
 * @package Vyntic
 */
?>
<section class="section" aria-labelledby="faq-title">
	<div class="wrap faq">
		<h2 class="section__title" id="faq-title"><?php esc_html_e( 'Questions clients ask first', 'vyntic' ); ?></h2>
		<div class="faq__list">
			<?php foreach ( vyntic_faq() as $vyntic_item ) : ?>
				<details class="faq__item">
					<summary><?php echo esc_html( $vyntic_item['q'] ); ?><span class="faq__icon"><?php echo vyntic_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></summary>
					<p><?php echo esc_html( $vyntic_item['a'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>
