<?php
/**
 * How we build.
 *
 * @package Vyntic
 */
?>
<section class="section" aria-labelledby="principles-title">
	<div class="wrap principles">
		<div class="principles__head">
			<h2 class="section__title" id="principles-title"><?php esc_html_e( 'How every site is built', 'vyntic' ); ?></h2>
			<ul class="stack" aria-label="<?php esc_attr_e( 'Tools we use', 'vyntic' ); ?>">
				<?php foreach ( vyntic_stack() as $vyntic_tool ) : ?>
					<li><?php echo esc_html( $vyntic_tool ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<ul class="principles__list">
			<?php foreach ( vyntic_principles() as $vyntic_item ) : ?>
				<li class="principle">
					<span class="principle__icon"><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<h3 class="principle__title"><?php echo esc_html( $vyntic_item['title'] ); ?></h3>
					<p><?php echo esc_html( $vyntic_item['text'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
