<?php
/**
 * Industries chip cloud: only industries that have their own page, all linked.
 *
 * @package Vyntic
 */

if ( ! function_exists( 'vyntic_industry_links' ) || ! vyntic_industry_links() ) {
	return;
}
?>
<section class="section section--tight" aria-labelledby="industries-title">
	<div class="wrap">
		<div class="industries">
			<div class="industries__copy">
				<h2 class="section__title section__title--md" id="industries-title"><?php esc_html_e( 'Built for businesses people actually visit', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'Bookings, quotes, reviews and WhatsApp in one fast site that your team can update themselves.', 'vyntic' ); ?></p>
			</div>
			<ul class="industries__list">
				<?php $vyntic_linked = function_exists( 'vyntic_industry_links' ) ? vyntic_industry_links() : array(); ?>
				<?php foreach ( $vyntic_linked as $vyntic_ind ) : ?>
					<li class="industries__linked"><a href="<?php echo esc_url( $vyntic_ind[1] ); ?>"><?php echo esc_html( $vyntic_ind[0] ); ?></a></li>
				<?php endforeach; ?>
				<?php $vyntic_hub = vyntic_template_url( 'page-templates/industries.php' ); ?>
				<li class="industries__cta"><a href="<?php echo esc_url( $vyntic_hub ? $vyntic_hub : vyntic_cta_url() ); ?>"><?php echo esc_html( $vyntic_hub ? __( 'See all industries', 'vyntic' ) : __( 'Yours not listed? Ask us', 'vyntic' ) ); ?></a></li>
			</ul>
		</div>
	</div>
</section>
