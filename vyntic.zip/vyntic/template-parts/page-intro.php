<?php
/**
 * Inner page intro. Uses page title and excerpt unless values are passed in.
 *
 * @package Vyntic
 */

$vyntic_title = ! empty( $args['title'] ) ? $args['title'] : get_the_title();
$vyntic_lead  = ! empty( $args['lead'] ) ? $args['lead'] : ( ( is_singular() && has_excerpt() ) ? get_the_excerpt() : '' );
?>
<section class="intro">
	<div class="wrap intro__inner">
		<?php vyntic_breadcrumbs(); ?>
		<h1 class="intro__title"><?php echo esc_html( $vyntic_title ); ?></h1>
		<?php if ( $vyntic_lead ) : ?>
			<p class="intro__lead"><?php echo esc_html( $vyntic_lead ); ?></p>
		<?php endif; ?>
	</div>
</section>
