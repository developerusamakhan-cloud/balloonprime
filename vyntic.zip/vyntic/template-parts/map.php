<?php
/**
 * World map with a pin for every published Location page.
 * Args: heading_level (h1|h2), compact (bool).
 *
 * @package Vyntic
 */

$vyntic_pins = vyntic_map_pins();
if ( ! $vyntic_pins ) {
	if ( current_user_can( 'edit_pages' ) ) {
		echo '<div class="wrap"><p class="notice notice--error" style="margin-block:2rem">' . esc_html__( 'Editor note: publish Location pages (Tools, Vyntic setup) and they will appear as pins on this map. Visitors do not see this message.', 'vyntic' ) . '</p></div>';
	}
	return;
}
$vyntic_hub  = vyntic_template_url( 'page-templates/locations.php' );
$vyntic_dots = file_get_contents( VYNTIC_DIR . '/assets/img/world-dots.svg' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
?>
<section class="worldmap" aria-labelledby="map-title">
	<div class="wrap">
		<div class="worldmap__head">
			<div>
				<h2 class="section__title" id="map-title"><?php esc_html_e( 'Where we work', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'A remote studio working with businesses across four continents. Pick a pin to see how we help businesses there.', 'vyntic' ); ?></p>
			</div>
			<?php if ( $vyntic_hub ) : ?>
				<a class="btn btn--light" href="<?php echo esc_url( $vyntic_hub ); ?>"><?php esc_html_e( 'All locations', 'vyntic' ); ?></a>
			<?php endif; ?>
		</div>

		<div class="worldmap__stage" data-worldmap>
			<div class="worldmap__dots"><?php echo $vyntic_dots; // phpcs:ignore WordPress.Security.EscapeOutput -- static theme SVG. ?></div>
			<svg class="worldmap__arcs" viewBox="0 0 100 50" preserveAspectRatio="none" aria-hidden="true">
				<?php
				$vyntic_route = $vyntic_pins;
				usort( $vyntic_route, function ( $a, $b ) { return $a['x'] <=> $b['x']; } );
				for ( $vyntic_i = 0; $vyntic_i < count( $vyntic_route ) - 1; $vyntic_i++ ) :
					$vyntic_a = $vyntic_route[ $vyntic_i ];
					$vyntic_b = $vyntic_route[ $vyntic_i + 1 ];
					if ( abs( $vyntic_b['x'] - $vyntic_a['x'] ) > 45 || ( abs( $vyntic_b['x'] - $vyntic_a['x'] ) < 1.5 && abs( $vyntic_b['y'] - $vyntic_a['y'] ) < 3 ) ) {
						continue;
					}
					$vyntic_mx = ( $vyntic_a['x'] + $vyntic_b['x'] ) / 2;
					$vyntic_my = min( $vyntic_a['y'], $vyntic_b['y'] ) / 2 - 6;
					?>
					<path d="M<?php echo esc_attr( $vyntic_a['x'] ); ?> <?php echo esc_attr( $vyntic_a['y'] / 2 ); ?> Q<?php echo esc_attr( $vyntic_mx ); ?> <?php echo esc_attr( max( 1, $vyntic_my ) ); ?> <?php echo esc_attr( $vyntic_b['x'] ); ?> <?php echo esc_attr( $vyntic_b['y'] / 2 ); ?>" style="--d: <?php echo esc_attr( $vyntic_i ); ?>"/>
				<?php endfor; ?>
			</svg>
			<ul class="worldmap__pins">
				<?php foreach ( $vyntic_pins as $vyntic_i => $vyntic_p ) : ?>
					<li class="pin pin--<?php echo esc_attr( $vyntic_p['type'] ); ?>" style="left: <?php echo esc_attr( $vyntic_p['x'] ); ?>%; top: <?php echo esc_attr( $vyntic_p['y'] ); ?>%; --i: <?php echo esc_attr( $vyntic_i ); ?>">
						<a href="<?php echo esc_url( $vyntic_p['url'] ); ?>" class="pin__link">
							<span class="pin__dot" aria-hidden="true"></span>
							<span class="pin__card">
								<strong><?php echo esc_html( $vyntic_p['label'] ); ?></strong>
								<span><?php esc_html_e( 'View page', 'vyntic' ); ?> <?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>

		<ul class="worldmap__list">
			<?php foreach ( $vyntic_pins as $vyntic_p ) : ?>
				<li><a href="<?php echo esc_url( $vyntic_p['url'] ); ?>"><?php echo vyntic_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $vyntic_p['label'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
