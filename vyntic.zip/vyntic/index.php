<?php
/**
 * Blog index, category/tag archives and search results.
 *
 * @package Vyntic
 */

get_header();

$vyntic_title = __( 'Blog', 'vyntic' );
$vyntic_lead  = __( 'Practical notes on website speed, SEO and AI search for business owners.', 'vyntic' );
if ( is_home() && get_option( 'page_for_posts' ) ) {
	$vyntic_title = get_the_title( get_option( 'page_for_posts' ) );
	$vyntic_page  = get_post( get_option( 'page_for_posts' ) );
	if ( $vyntic_page && $vyntic_page->post_excerpt ) {
		$vyntic_lead = $vyntic_page->post_excerpt;
	}
} elseif ( is_category() || is_tag() || is_tax() ) {
	$vyntic_title = single_term_title( '', false );
	$vyntic_lead  = wp_strip_all_tags( term_description() );
} elseif ( is_author() ) {
	$vyntic_title = get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) );
	$vyntic_lead  = get_the_author_meta( 'description', (int) get_query_var( 'author' ) );
} elseif ( is_archive() ) {
	$vyntic_title = wp_strip_all_tags( get_the_archive_title() );
	$vyntic_lead  = '';
} elseif ( is_search() ) {
	/* translators: %s search query */
	$vyntic_title = sprintf( __( 'Results for "%s"', 'vyntic' ), get_search_query() );
	$vyntic_lead  = '';
}

$vyntic_blog_url = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
$vyntic_cats     = get_categories( array( 'hide_empty' => true, 'parent' => 0, 'exclude' => get_option( 'default_category' ) ) );
$vyntic_featured = is_home() && ! is_paged();
?>
<section class="intro intro--blog">
	<div class="wrap intro__inner">
		<h1 class="intro__title"><?php echo esc_html( $vyntic_title ); ?></h1>
		<?php if ( $vyntic_lead ) : ?>
			<p class="intro__lead"><?php echo esc_html( $vyntic_lead ); ?></p>
		<?php endif; ?>
		<div class="blog-tools">
			<?php if ( $vyntic_cats ) : ?>
				<nav class="filters" aria-label="<?php esc_attr_e( 'Categories', 'vyntic' ); ?>">
					<a class="filter" href="<?php echo esc_url( $vyntic_blog_url ); ?>" <?php echo is_home() ? 'aria-current="page"' : ''; ?>><?php esc_html_e( 'All articles', 'vyntic' ); ?></a>
					<?php foreach ( $vyntic_cats as $vyntic_cat ) : ?>
						<a class="filter" href="<?php echo esc_url( get_category_link( $vyntic_cat ) ); ?>" <?php echo is_category( $vyntic_cat->term_id ) ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $vyntic_cat->name ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="section section--tight">
	<div class="wrap">
		<?php if ( have_posts() ) : ?>

			<?php if ( $vyntic_featured ) : ?>
				<?php the_post(); ?>
				<div class="blog-feature">
					<?php get_template_part( 'template-parts/post-card', null, array( 'variant' => 'wide' ) ); ?>
				</div>
			<?php endif; ?>

			<?php if ( have_posts() ) : ?>
				<div class="post-grid">
					<?php
					$vyntic_n = 0;
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post-card' );
						$vyntic_n++;
						if ( 3 === $vyntic_n && ! is_search() ) :
							?>
							<aside class="promo-card">
								<p class="promo-card__kicker"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Free for your business', 'vyntic' ); ?></p>
								<p class="promo-card__title"><?php esc_html_e( 'How fast is your website, really?', 'vyntic' ); ?></p>
								<p class="promo-card__text"><?php esc_html_e( 'Get a plain-English audit of your speed, SEO and AI search visibility.', 'vyntic' ); ?></p>
								<?php
								$vyntic_audit = vyntic_template_url( 'page-templates/free-audit.php' );
								?>
								<a class="btn btn--light" href="<?php echo esc_url( $vyntic_audit ? $vyntic_audit : '#free-audit' ); ?>"><?php esc_html_e( 'Get my free audit', 'vyntic' ); ?></a>
								<span class="promo-card__ring" aria-hidden="true"></span>
							</aside>
							<?php
						endif;
					endwhile;
					?>
				</div>
			<?php endif; ?>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => __( 'Newer', 'vyntic' ),
					'next_text' => __( 'Older', 'vyntic' ),
				)
			);
			?>
		<?php else : ?>
			<div class="empty">
				<p><?php esc_html_e( 'No articles match that. Try another search or browse all articles.', 'vyntic' ); ?></p>
				<a class="btn btn--primary" href="<?php echo esc_url( $vyntic_blog_url ); ?>"><?php esc_html_e( 'Browse all articles', 'vyntic' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</section>
<?php
get_template_part( 'template-parts/audit' );
get_footer();
