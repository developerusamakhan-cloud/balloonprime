<?php
/**
 * Single blog post: reading time, contents list, share links, author box, related posts.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	$vyntic_author_id = (int) get_the_author_meta( 'ID' );
	$vyntic_bio       = get_the_author_meta( 'description' );
	$vyntic_link      = rawurlencode( get_permalink() );
	$vyntic_text      = rawurlencode( get_the_title() );
	?>
	<div class="read-progress" aria-hidden="true"><span data-read-progress></span></div>
	<article <?php post_class( 'article' ); ?>>
		<header class="article__head">
			<div class="wrap"><div class="article__head-inner">
				<?php vyntic_breadcrumbs(); ?>
				<p class="card-post__meta">
					<?php echo vyntic_primary_category(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span>
						<?php
						/* translators: %d minutes */
						echo esc_html( sprintf( __( '%d min read', 'vyntic' ), vyntic_reading_time() ) );
						?>
					</span>
				</p>
				<h1 class="article__title"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="article__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
				<div class="byline">
					<?php echo vyntic_avatar( $vyntic_author_id, 44, 'byline__avatar' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<div>
						<p class="byline__name"><?php echo esc_html( vyntic_author_name( $vyntic_author_id ) ); ?><?php $vyntic_job = get_user_meta( $vyntic_author_id, 'vyntic_job', true ); if ( $vyntic_job ) : ?><span class="byline__job"><?php echo esc_html( $vyntic_job ); ?></span><?php endif; ?></p>
						<p class="byline__date">
							<?php esc_html_e( 'Published', 'vyntic' ); ?> <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
							<?php if ( get_the_modified_date( 'Ymd' ) > get_the_date( 'Ymd' ) ) : ?>
								<?php esc_html_e( ', updated', 'vyntic' ); ?> <time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>"><?php echo esc_html( get_the_modified_date() ); ?></time>
							<?php endif; ?>
						</p>
					</div>
				</div>
			</div></div>
		</header>

		<div class="wrap"><figure class="article__hero"><?php vyntic_thumb( 'full', 'post-fallback.svg', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></figure></div>

		<div class="wrap article__layout">
			<aside class="article__aside">
				<nav class="toc" aria-label="<?php esc_attr_e( 'In this article', 'vyntic' ); ?>" data-toc hidden>
					<p class="toc__title"><?php esc_html_e( 'In this article', 'vyntic' ); ?></p>
					<ol class="toc__list"></ol>
				</nav>
				<div class="share">
					<p class="toc__title"><?php esc_html_e( 'Share', 'vyntic' ); ?></p>
					<a href="<?php echo esc_url( 'https://www.linkedin.com/sharing/share-offsite/?url=' . $vyntic_link ); ?>" target="_blank" rel="noopener">LinkedIn</a>
					<a href="<?php echo esc_url( 'https://twitter.com/intent/tweet?url=' . $vyntic_link . '&text=' . $vyntic_text ); ?>" target="_blank" rel="noopener">X</a>
					<button type="button" class="share__copy" data-copy="<?php echo esc_url( get_permalink() ); ?>" data-done="<?php esc_attr_e( 'Link copied', 'vyntic' ); ?>"><?php esc_html_e( 'Copy link', 'vyntic' ); ?></button>
				</div>
			</aside>

			<div class="article__main">
				<div class="prose" data-article><?php the_content(); ?></div>
				<?php wp_link_pages(); ?>


				<?php $vyntic_tags = get_the_tag_list( '', '' ); ?>
				<?php if ( $vyntic_tags ) : ?>
					<p class="article__tags"><?php echo wp_kses_post( $vyntic_tags ); ?></p>
				<?php endif; ?>

				<div class="author-box">
					<?php echo vyntic_avatar( $vyntic_author_id, 72, 'author-box__avatar' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<div>
						<p class="author-box__label"><?php esc_html_e( 'Written by', 'vyntic' ); ?></p>
						<p class="author-box__name"><a href="<?php echo esc_url( get_author_posts_url( $vyntic_author_id ) ); ?>"><?php echo esc_html( vyntic_author_name( $vyntic_author_id ) ); ?></a></p>
						<?php if ( $vyntic_bio ) : ?>
							<p><?php echo esc_html( $vyntic_bio ); ?></p>
						<?php endif; ?>
					</div>
				</div>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>
		</div>
	</article>

	<?php
	vyntic_landing_cards( vyntic_post_services(), __( 'Services related to this article', 'vyntic' ) );
	get_template_part( 'template-parts/audit' );

	$vyntic_cats    = wp_get_post_categories( get_the_ID() );
	$vyntic_related = get_posts( array( 'numberposts' => 3, 'post__not_in' => array( get_the_ID() ), 'category__in' => $vyntic_cats ) );
	if ( count( $vyntic_related ) < 3 ) {
		$vyntic_related = array_merge( $vyntic_related, get_posts( array( 'numberposts' => 3 - count( $vyntic_related ), 'post__not_in' => array_merge( array( get_the_ID() ), wp_list_pluck( $vyntic_related, 'ID' ) ) ) ) );
	}
	vyntic_post_cards( $vyntic_related, __( 'Keep reading', 'vyntic' ) );
endwhile;
get_footer();
