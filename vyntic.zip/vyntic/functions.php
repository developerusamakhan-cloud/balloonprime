<?php
/**
 * Vyntic theme bootstrap.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VYNTIC_VERSION', '2.5.0' );
define( 'VYNTIC_DIR', get_template_directory() );
define( 'VYNTIC_URI', get_template_directory_uri() );

require VYNTIC_DIR . '/inc/content.php';
require VYNTIC_DIR . '/inc/helpers.php';
require VYNTIC_DIR . '/inc/setup.php';
require VYNTIC_DIR . '/inc/post-types.php';
require VYNTIC_DIR . '/inc/customizer.php';
require VYNTIC_DIR . '/inc/forms.php';
require VYNTIC_DIR . '/inc/ai.php';
require VYNTIC_DIR . '/inc/reviews.php';
require VYNTIC_DIR . '/inc/landing.php';
require VYNTIC_DIR . '/inc/setup-tool.php';
require VYNTIC_DIR . '/inc/people.php';
require VYNTIC_DIR . '/inc/links.php';
require VYNTIC_DIR . '/inc/rankmath.php';
