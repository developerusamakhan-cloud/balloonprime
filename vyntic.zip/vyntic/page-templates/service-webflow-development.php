<?php
/**
 * Template Name: Service: Webflow development
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "webflow-development".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'webflow-development' ) );
endwhile;
get_footer();
