<?php
/**
 * Template Name: Industries (hub)
 *
 * Lists the industry pages. Cards link to pages that use an "Industry: ..." template.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Every industry has its own customers, questions and search habits. We build websites and SEO around yours, so your site speaks the language your clients use.', 'vyntic' ) );
	$vyntic_items = array_filter(
		vyntic_landing(),
		function ( $d ) {
			return 'industry' === $d['kind'];
		}
	);
	?>
	<section class="section">
		<div class="wrap">
			<ul class="ind-grid">
				<?php foreach ( $vyntic_items as $vyntic_key => $vyntic_d ) : ?>
					<?php $vyntic_url = vyntic_landing_url( $vyntic_key ); ?>
					<li>
						<?php if ( $vyntic_url ) : ?><a class="ind-card" href="<?php echo esc_url( $vyntic_url ); ?>"><?php else : ?><div class="ind-card"><?php endif; ?>
							<span class="ind-card__art"><img src="<?php echo esc_url( vyntic_img( 'services/' . $vyntic_d['art'] . '.svg' ) ); ?>" alt="" width="360" height="240" loading="lazy"></span>
							<span class="ind-card__body">
								<span class="ind-card__name"><?php echo esc_html( $vyntic_d['label'] ); ?></span>
								<span class="ind-card__text"><?php echo esc_html( $vyntic_d['lead'] ); ?></span>
								<span class="ind-card__proof">
									<?php foreach ( $vyntic_d['proof'] as $vyntic_p ) : ?>
										<span><?php echo esc_html( $vyntic_p ); ?></span>
									<?php endforeach; ?>
								</span>
							</span>
							<span class="ind-card__go" aria-hidden="true"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php if ( $vyntic_url ) : ?></a><?php else : ?></div><?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php
	get_template_part( 'template-parts/industries' );
	vyntic_render_article( vyntic_current_article_key(), __( 'Industries', 'vyntic' ) );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
