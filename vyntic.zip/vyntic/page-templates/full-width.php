<?php
/**
 * Template Name: Full width
 *
 * Title plus editor content at full width. Use this to build any page
 * yourself with blocks (Gutenberg). Wide and full alignments are supported.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro();
	?>
	<div class="entry entry--wide">
		<?php the_content(); ?>
	</div>
	<?php
endwhile;
get_footer();
