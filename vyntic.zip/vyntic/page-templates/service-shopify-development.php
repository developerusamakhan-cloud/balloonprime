<?php
/**
 * Template Name: Service: Shopify development
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "shopify-development".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'shopify-development' ) );
endwhile;
get_footer();
