<?php
/**
 * Template Name: Locations (all areas)
 *
 * Lists every page that uses the Location template. Link to it from the footer and menu.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'We build websites and run SEO for businesses in these countries, and work remotely with clients everywhere else.', 'vyntic' ) );
	$vyntic_locations = vyntic_location_countries( 200 );
	?>
	<section class="section section--tight">
		<div class="wrap">
			<?php if ( $vyntic_locations ) : ?>
				<ul class="loc-grid">
					<?php foreach ( $vyntic_locations as $vyntic_loc ) : ?>
						<?php $vyntic_region = vyntic_field( 'location_region', '', $vyntic_loc->ID ); ?>
						<li>
							<a class="loc-card" href="<?php echo esc_url( get_permalink( $vyntic_loc ) ); ?>">
								<span class="loc-card__icon"><?php echo vyntic_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
								<span class="loc-card__city"><?php echo esc_html( vyntic_location_label( $vyntic_loc->ID ) ); ?></span>
								<?php if ( $vyntic_region ) : ?><span class="loc-card__region"><?php echo esc_html( $vyntic_region ); ?></span><?php endif; ?>
								<span class="loc-card__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php elseif ( current_user_can( 'edit_pages' ) ) : ?>
				<div class="empty"><p><?php esc_html_e( 'No location pages yet. Create a page, choose the "Location (local SEO)" template and it will appear here and in the footer. Only editors see this message.', 'vyntic' ); ?></p></div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	get_template_part( 'template-parts/map' );
	vyntic_render_article( vyntic_current_article_key(), __( 'Where we work', 'vyntic' ) );
	get_template_part( 'template-parts/services-list', null, array( 'heading' => __( 'What we do in every market', 'vyntic' ), 'intro' => __( 'The same services and the same standard, wherever your business is based.', 'vyntic' ) ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
