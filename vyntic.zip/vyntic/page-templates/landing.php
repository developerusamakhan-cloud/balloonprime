<?php
/**
 * Template Name: Landing page
 *
 * For ad campaigns: no main menu, no footer links, one goal.
 * Hero, your editor content, process, work and the inquiry form.
 * Per-page overrides: hero_title, hero_text, hero_score.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/hero' );
	get_template_part( 'template-parts/page-content' );
	get_template_part( 'template-parts/work-grid', null, array( 'count' => 2 ) );
	get_template_part( 'template-parts/process' );
	?>
	<section class="section" aria-labelledby="landing-form-title">
		<div class="wrap contact__inner">
			<div class="contact__info">
				<h2 class="section__title" id="landing-form-title"><?php echo esc_html( vyntic_field( 'cta_title', vyntic_mod( 'cta_title' ) ) ); ?></h2>
				<p class="section__lead"><?php echo esc_html( vyntic_field( 'cta_text', vyntic_mod( 'cta_text' ) ) ); ?></p>
			</div>
			<div class="contact__form"><?php get_template_part( 'template-parts/contact-form' ); ?></div>
		</div>
	</section>
	<?php
endwhile;
get_footer();
