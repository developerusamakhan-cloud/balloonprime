<?php
/**
 * Template Name: Service detail
 *
 * For a single service page (e.g. "WordPress development").
 * Title and excerpt make the intro, the editor content fills the middle,
 * featured image shows beside the intro. Process, work and CTA follow.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<section class="intro intro--split">
		<div class="wrap intro__inner">
			<div>
				<?php
				$vyntic_services_url = vyntic_template_url( 'page-templates/services.php' );
				if ( $vyntic_services_url ) :
					?>
					<a class="intro__back" href="<?php echo esc_url( $vyntic_services_url ); ?>"><?php esc_html_e( 'All services', 'vyntic' ); ?></a>
				<?php endif; ?>
				<h1 class="intro__title"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="intro__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
				<a class="btn btn--primary btn--lg" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
			</div>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="intro__media"><?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high' ) ); ?></div>
			<?php else : ?>
				<div class="intro__media intro__media--ring"><?php vyntic_score_ring( vyntic_field( 'hero_score', vyntic_mod( 'hero_score' ) ), 'lg' ); ?></div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	get_template_part( 'template-parts/page-content' );
	get_template_part( 'template-parts/process' );
	get_template_part( 'template-parts/work-grid', null, array( 'count' => 2, 'more' => true, 'heading' => __( 'Related work', 'vyntic' ) ) );
	get_template_part( 'template-parts/faq' );
endwhile;
get_footer();
