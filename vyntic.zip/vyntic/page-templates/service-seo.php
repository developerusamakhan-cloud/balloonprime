<?php
/**
 * Template Name: Service: SEO services
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "seo".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'seo' ) );
endwhile;
get_footer();
