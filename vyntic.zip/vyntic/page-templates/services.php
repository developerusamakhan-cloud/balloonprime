<?php
/**
 * Template Name: Services
 *
 * Overview of all services. Each row links to a page whose slug matches
 * the 'page' value in inc/content.php (use the Service detail template for those).
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Websites, online stores, SEO, local SEO, AI search visibility and automations. One studio, one standard: fast, easy to edit and built to bring customers.', 'vyntic' ) );
	get_template_part( 'template-parts/services-list', null, array( 'heading' => __( 'Pick what you need', 'vyntic' ), 'intro' => __( 'Hover over a service to preview it, or open the page for the full details, pricing approach and FAQs.', 'vyntic' ) ) );
	vyntic_render_article( vyntic_current_article_key(), __( 'Our services', 'vyntic' ) );
	get_template_part( 'template-parts/process' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
endwhile;
get_footer();
