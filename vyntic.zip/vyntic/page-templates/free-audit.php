<?php
/**
 * Template Name: Free audit
 *
 * Landing page for the free audit tool. The tool itself is set in
 * Customize → Vyntic options → Free audit (shortcode or embed code).
 * Editor content appears below the tool, e.g. to explain the report.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/audit', null, array( 'heading_level' => 'h1' ) );
	?>
	<section class="section" aria-labelledby="audit-sample-title">
		<div class="wrap audit-sample">
			<div class="audit-sample__art">
				<img src="<?php echo esc_url( vyntic_img( 'audit-report.svg' ) ); ?>" alt="" width="520" height="400" loading="lazy">
			</div>
			<div class="audit-sample__copy">
				<h2 class="section__title" id="audit-sample-title"><?php esc_html_e( 'What your report looks like', 'vyntic' ); ?></h2>
				<p class="section__lead"><?php esc_html_e( 'Scores first, then a short list of issues ranked by impact. Red items cost you visitors today, amber items are worth fixing soon, green items are already in good shape.', 'vyntic' ); ?></p>
				<p><?php esc_html_e( 'Each issue comes with a one-line explanation of why it matters and what the fix involves, so you can hand it to any developer, not just us.', 'vyntic' ); ?></p>
			</div>
		</div>
	</section>
	<?php
	vyntic_render_article( vyntic_current_article_key(), __( 'About the audit', 'vyntic' ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
endwhile;
get_footer();
