<?php
/**
 * Template Name: Reviews
 *
 * All client reviews (managed under Reviews in the dashboard) plus the inquiry form.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Real words from clinics, stores, law firms and startups we have worked with.', 'vyntic' ) );
	get_template_part( 'template-parts/reviews' );
	vyntic_render_article( vyntic_current_article_key(), __( 'About our reviews', 'vyntic' ) );
	get_template_part( 'template-parts/services-list', null, array( 'heading' => __( 'Services our clients review', 'vyntic' ), 'intro' => '' ) );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/work-grid', null, array( 'count' => 2, 'more' => true ) );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
