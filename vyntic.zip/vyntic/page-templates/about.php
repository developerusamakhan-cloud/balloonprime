<?php
/**
 * Template Name: About
 *
 * Intro, facts, your story (editor content, or the built-in story if the editor is empty),
 * team (from Users: authors, editors and named admins), principles, process, reviews, map and form.
 *
 * @package Vyntic
 */

$vyntic_facts = apply_filters(
	'vyntic_about_facts',
	array(
		array( '50+', __( 'brands we have built for', 'vyntic' ) ),
		array( '5', __( 'regions: USA, UK, Australia, Canada and Europe', 'vyntic' ) ),
		array( '90+', __( 'PageSpeed score we aim for at launch', 'vyntic' ) ),
		array( '24 h', __( 'maximum time to reply to a new inquiry', 'vyntic' ) ),
	)
);

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'A small web studio that treats speed, search and clean code as the job, not the extras.', 'vyntic' ) );
	?>
	<section class="section section--tight" aria-label="<?php esc_attr_e( 'Studio facts', 'vyntic' ); ?>">
		<div class="wrap">
			<dl class="facts">
				<?php foreach ( $vyntic_facts as $vyntic_fact ) : ?>
					<div class="fact">
						<dt><?php echo esc_html( $vyntic_fact[1] ); ?></dt>
						<dd><?php echo esc_html( $vyntic_fact[0] ); ?></dd>
					</div>
				<?php endforeach; ?>
			</dl>
		</div>
	</section>
	<?php
	if ( '' !== trim( (string) get_post_field( 'post_content', get_the_ID() ) ) ) {
		get_template_part( 'template-parts/page-content', null, array( 'class' => 'about-story' ) );
	} else {
		vyntic_render_article( 'about-page', __( 'Our story', 'vyntic' ) );
	}
	get_template_part( 'template-parts/team' );
	get_template_part( 'template-parts/principles' );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/map' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
