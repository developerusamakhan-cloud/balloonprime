<?php
/**
 * Template Name: Industry: Ecommerce and DTC brands
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "ecommerce-brands".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'ecommerce-brands' ) );
endwhile;
get_footer();
