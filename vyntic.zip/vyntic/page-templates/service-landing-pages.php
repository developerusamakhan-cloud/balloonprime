<?php
/**
 * Template Name: Service: Landing pages
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "landing-pages".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'landing-pages' ) );
endwhile;
get_footer();
