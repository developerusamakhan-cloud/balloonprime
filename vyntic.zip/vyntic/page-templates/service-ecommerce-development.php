<?php
/**
 * Template Name: Service: Online stores
 *
 * Ready-made page. Copy lives in inc/data/landing.json under "ecommerce-development".
 * Optional: Excerpt replaces the intro text, Featured image replaces the artwork,
 * editor content appears after the "What you get" section.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'ecommerce-development' ) );
endwhile;
get_footer();
