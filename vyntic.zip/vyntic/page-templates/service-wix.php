<?php
/**
 * Template Name: Service: Wix website design
 *
 * Ready-made page. Copy lives in inc/data/landing.json and inc/data/articles.json under "wix".
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'wix' ) );
endwhile;
get_footer();
