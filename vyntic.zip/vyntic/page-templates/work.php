<?php
/**
 * Template Name: Work
 *
 * All projects, with filters by Project type.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Sites we have designed, built or rebuilt, with the mobile PageSpeed score before and after.', 'vyntic' ) );
	get_template_part(
		'template-parts/work-grid',
		null,
		array(
			'count'   => -1,
			'heading' => __( 'All projects', 'vyntic' ),
			'lead'    => '',
			'filter'  => true,
		)
	);
	vyntic_render_article( vyntic_current_article_key(), __( 'About our work', 'vyntic' ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
