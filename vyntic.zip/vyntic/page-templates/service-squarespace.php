<?php
/**
 * Template Name: Service: Squarespace website design
 *
 * Ready-made page. Copy lives in inc/data/landing.json and inc/data/articles.json under "squarespace".
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/landing', null, array( 'key' => 'squarespace' ) );
endwhile;
get_footer();
