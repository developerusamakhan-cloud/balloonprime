<?php
/**
 * Default page template: title plus editor content in a readable column.
 * Choose a different template under Page → Template in the editor sidebar.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro();
	?>
	<section class="section section--tight">
		<div class="wrap">
			<div class="prose"><?php the_content(); ?></div>
			<?php wp_link_pages(); ?>
		</div>
	</section>
	<?php
endwhile;
get_footer();
