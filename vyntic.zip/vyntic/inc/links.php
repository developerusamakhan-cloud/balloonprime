<?php
/**
 * Internal linking map between blog posts and service or industry pages.
 * Keys on the left are post slugs, values are landing page keys.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function vyntic_link_map() {
	return apply_filters(
		'vyntic_link_map',
		array(
			'local-seo-guide'                 => array( 'local-seo', 'seo', 'dental' ),
			'get-recommended-by-chatgpt'      => array( 'ai-search-visibility', 'seo', 'law-firms' ),
			'google-business-profile-guide'   => array( 'local-seo', 'gohighlevel', 'plumbers' ),
			'website-cost'                    => array( 'web-design', 'ecommerce-development', 'wordpress-development' ),
			'core-web-vitals-explained'       => array( 'speed-optimization', 'wordpress-development', 'seo' ),
			'website-redesign-checklist'      => array( 'website-redesign', 'website-migration', 'web-design' ),
			'website-migration-seo-checklist' => array( 'website-migration', 'wix', 'squarespace' ),
			'local-seo-for-dentists'          => array( 'dental', 'local-seo', 'gohighlevel' ),
			'seo-for-law-firms'               => array( 'law-firms', 'seo', 'ai-search-visibility' ),
			'seo-for-roofers'                 => array( 'roofing', 'hvac', 'local-seo' ),
			'wordpress-vs-webflow'            => array( 'wordpress-development', 'webflow-development', 'website-migration' ),
			'wix-vs-wordpress'                => array( 'wix', 'wordpress-development', 'website-migration' ),
			'gohighlevel-vs-hubspot'          => array( 'gohighlevel', 'landing-pages', 'real-estate' ),
			'seo-cost'                        => array( 'seo', 'local-seo', 'ecommerce-brands' ),
			'dental-website-cost'             => array( 'dental', 'med-spa', 'web-design' ),
		)
	);
}

/** Landing keys related to a post. */
function vyntic_post_services( $post_id = null ) {
	$slug = get_post_field( 'post_name', $post_id ? $post_id : get_the_ID() );
	$map  = vyntic_link_map();
	return isset( $map[ $slug ] ) ? $map[ $slug ] : array( 'web-design', 'seo', 'local-seo' );
}

/** Published posts related to a landing key (most relevant first). */
function vyntic_landing_posts( $key, $limit = 3 ) {
	$slugs = array();
	foreach ( vyntic_link_map() as $slug => $keys ) {
		$pos = array_search( $key, $keys, true );
		if ( false !== $pos ) {
			$slugs[ $slug ] = $pos;
		}
	}
	asort( $slugs );
	$posts = array();
	foreach ( array_keys( $slugs ) as $slug ) {
		$found = get_posts( array( 'name' => $slug, 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1 ) );
		if ( $found ) {
			$posts[] = $found[0];
		}
		if ( count( $posts ) >= $limit ) {
			break;
		}
	}
	if ( count( $posts ) < $limit ) {
		$exclude = wp_list_pluck( $posts, 'ID' );
		$posts   = array_merge( $posts, get_posts( array( 'numberposts' => $limit - count( $posts ), 'post__not_in' => $exclude, 'post_status' => 'publish' ) ) );
	}
	return $posts;
}

/** Card list of landing pages (used on posts and case studies). */
function vyntic_landing_cards( $keys, $heading ) {
	$items = array();
	foreach ( $keys as $key ) {
		$d   = vyntic_landing( $key );
		$url = $d ? vyntic_landing_url( $key ) : '';
		if ( $d && $url ) {
			$items[] = array( $d, $url );
		}
	}
	if ( ! $items ) {
		return;
	}
	?>
	<section class="section section--tight" aria-label="<?php echo esc_attr( $heading ); ?>">
		<div class="wrap">
			<h2 class="section__title section__title--sm"><?php echo esc_html( $heading ); ?></h2>
			<ul class="lp-related">
				<?php foreach ( $items as $item ) : ?>
					<li>
						<a class="lp-rel" href="<?php echo esc_url( $item[1] ); ?>">
							<span class="lp-rel__icon"><?php echo vyntic_icon( $item[0]['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							<span class="lp-rel__name"><?php echo esc_html( $item[0]['label'] ); ?></span>
							<span class="lp-rel__text"><?php echo esc_html( $item[0]['h1'] ); ?></span>
							<span class="lp-rel__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php
}

/** Blog cards for a list of posts. */
function vyntic_post_cards( $posts, $heading ) {
	if ( ! $posts ) {
		return;
	}
	global $post;
	?>
	<section class="section section--mist" aria-label="<?php echo esc_attr( $heading ); ?>">
		<div class="wrap">
			<h2 class="section__title section__title--sm"><?php echo esc_html( $heading ); ?></h2>
			<div class="post-grid">
				<?php
				foreach ( $posts as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
					setup_postdata( $post );
					get_template_part( 'template-parts/post-card' );
				endforeach;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
	<?php
}

/** Published URL for a sitemap key (pages and posts), or ''. */
function vyntic_key_url( $key ) {
	if ( ! function_exists( 'vyntic_setup_find' ) ) {
		return '';
	}
	$p = vyntic_setup_find( $key );
	return ( $p && 'publish' === $p->post_status ) ? get_permalink( $p ) : '';
}

/**
 * Footer link columns built from the sitemap. Only published pages are shown.
 *
 * @return array title => array( label => url )
 */
function vyntic_footer_columns() {
	$cols  = array();
	$group = function ( $keys ) {
		$out = array();
		foreach ( $keys as $key => $label ) {
			$url = vyntic_key_url( $key );
			if ( $url ) {
				$out[ $label ] = $url;
			}
		}
		return $out;
	};
	$cols[ __( 'Services', 'vyntic' ) ] = $group(
		array(
			'web-design'           => __( 'Website design', 'vyntic' ),
			'ecommerce-development' => __( 'Online stores', 'vyntic' ),
			'local-seo'            => __( 'Local SEO', 'vyntic' ),
			'seo'                  => __( 'SEO services', 'vyntic' ),
			'ai-search-visibility' => __( 'AI search visibility', 'vyntic' ),
			'landing-pages'        => __( 'Landing pages', 'vyntic' ),
			'website-redesign'     => __( 'Website redesign', 'vyntic' ),
			'website-migration'    => __( 'Website migration', 'vyntic' ),
			'speed-optimization'   => __( 'Speed optimization', 'vyntic' ),
		)
	);
	$cols[ __( 'Platforms', 'vyntic' ) ] = $group(
		array(
			'wordpress-development'   => 'WordPress',
			'webflow-development'     => 'Webflow',
			'shopify-development'     => 'Shopify',
			'woocommerce-development' => 'WooCommerce',
			'wix'                     => 'Wix',
			'squarespace'             => 'Squarespace',
			'gohighlevel'             => 'GoHighLevel',
		)
	);
	$ind = array();
	foreach ( vyntic_industry_links() as $l ) {
		$ind[ $l[0] ] = $l[1];
	}
	$cols[ __( 'Industries', 'vyntic' ) ] = $ind;
	$cols[ __( 'Locations', 'vyntic' ) ]  = $group(
		array(
			'locations'       => __( 'All locations', 'vyntic' ),
			'loc-usa'         => __( 'USA', 'vyntic' ),
			'loc-uk'          => __( 'United Kingdom', 'vyntic' ),
			'loc-canada'      => __( 'Canada', 'vyntic' ),
			'loc-australia'   => __( 'Australia', 'vyntic' ),
			'loc-germany'     => __( 'Germany', 'vyntic' ),
			'loc-france'      => __( 'France', 'vyntic' ),
			'loc-netherlands' => __( 'Netherlands', 'vyntic' ),
			'loc-singapore'   => __( 'Singapore', 'vyntic' ),
			'loc-uae'         => __( 'United Arab Emirates', 'vyntic' ),
			'loc-new-zealand' => __( 'New Zealand', 'vyntic' ),
		)
	);
	$cols[ __( 'Resources', 'vyntic' ) ] = $group(
		array(
			'blog'                              => __( 'Blog', 'vyntic' ),
			'post-local-seo-guide'              => __( 'Local SEO guide', 'vyntic' ),
			'post-get-recommended-by-chatgpt'   => __( 'Get recommended by ChatGPT', 'vyntic' ),
			'post-google-business-profile-guide' => __( 'Google Business Profile guide', 'vyntic' ),
			'post-website-cost'                 => __( 'Website cost guide', 'vyntic' ),
			'post-seo-cost'                     => __( 'SEO cost guide', 'vyntic' ),
			'post-wordpress-vs-webflow'         => __( 'WordPress vs Webflow', 'vyntic' ),
		)
	);
	$cols[ __( 'Company', 'vyntic' ) ] = $group(
		array(
			'about'      => __( 'About', 'vyntic' ),
			'work'       => __( 'Case studies', 'vyntic' ),
			'reviews'    => __( 'Reviews', 'vyntic' ),
			'services'   => __( 'All services', 'vyntic' ),
			'industries' => __( 'All industries', 'vyntic' ),
			'care-plans' => __( 'Care plans', 'vyntic' ),
			'free-audit' => __( 'Free website audit', 'vyntic' ),
			'contact'    => __( 'Contact', 'vyntic' ),
		)
	);
	return apply_filters( 'vyntic_footer_columns', array_filter( $cols ) );
}

/**
 * Landing keys that match a case study: project types, industry and platform text.
 *
 * @param int $post_id Work post ID.
 * @return array
 */
function vyntic_work_services( $post_id ) {
	$terms    = get_the_terms( $post_id, 'project_type' );
	$terms    = is_array( $terms ) ? $terms : array();
	$haystack = strtolower(
		implode(
			' ',
			array_merge(
				wp_list_pluck( $terms, 'name' ),
				array(
					vyntic_work_meta( 'project_industry', $post_id ),
					vyntic_work_meta( 'project_stack', $post_id ),
					get_the_title( $post_id ),
					wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ),
				)
			)
		)
	);
	$rules = array(
		'shopify-development'     => array( 'shopify' ),
		'woocommerce-development' => array( 'woocommerce' ),
		'wordpress-development'   => array( 'wordpress' ),
		'webflow-development'     => array( 'webflow' ),
		'wix'                     => array( 'wix' ),
		'squarespace'             => array( 'squarespace' ),
		'gohighlevel'             => array( 'gohighlevel', 'highlevel', 'ghl' ),
		'local-seo'               => array( 'local seo', 'google business', 'maps' ),
		'seo'                     => array( 'seo', 'ranking', 'organic' ),
		'ecommerce-development'   => array( 'store', 'ecommerce', 'e-commerce', 'shop' ),
		'website-redesign'        => array( 'redesign', 'rebuild' ),
		'website-migration'       => array( 'migration', 'migrate', 'moved' ),
		'speed-optimization'      => array( 'speed', 'pagespeed', 'core web vitals' ),
		'dental'                  => array( 'dental', 'dentist' ),
		'law-firms'               => array( 'law', 'legal', 'attorney', 'solicitor' ),
		'roofing'                 => array( 'roof' ),
		'hvac'                    => array( 'hvac', 'heating', 'cooling' ),
		'plumbers'                => array( 'plumb' ),
		'real-estate'             => array( 'real estate', 'property', 'realtor', 'airbnb' ),
		'med-spa'                 => array( 'med spa', 'aesthetic', 'skin' ),
		'ecommerce-brands'        => array( 'brand' ),
	);
	$found = array();
	foreach ( $rules as $key => $words ) {
		foreach ( $words as $w ) {
			if ( false !== strpos( $haystack, $w ) ) {
				$found[] = $key;
				break;
			}
		}
	}
	$found = array_values( array_unique( array_merge( $found, array( 'web-design', 'seo', 'local-seo' ) ) ) );
	return array_slice( $found, 0, 6 );
}
