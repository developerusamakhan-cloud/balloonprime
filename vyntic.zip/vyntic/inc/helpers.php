<?php
/**
 * Helper functions.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defaults for every Customizer option.
 */
function vyntic_defaults() {
	return array(
		'hero_title'    => __( 'Websites that', 'vyntic' ),
		'hero_words'    => __( 'rank on Google|get cited by AI|win customers', 'vyntic' ),
		'hero_text'     => __( 'We design and build fast websites, then make sure the right people find them: on Google, on the map and in AI answers like ChatGPT. One studio for your site, your SEO and your AI search visibility.', 'vyntic' ),
		'hero_score'    => 97,
		'hero_lcp'      => '0.9 s',
		'hero_cls'      => '0.01',
		'hero_inp'      => '68 ms',
		'trust_line'    => __( 'Trusted by 50+ brands in the USA, UK, Canada, Australia and Europe.', 'vyntic' ),
		'address'       => '',
		'hours'         => __( 'Mon to Fri, 9:00 to 18:00', 'vyntic' ),
		'statement_image' => '',
		'cta_title'     => __( 'Let\'s build the site your business deserves.', 'vyntic' ),
		'cta_text'      => __( 'We reply to every inquiry within 24 hours with next steps and a rough budget range.', 'vyntic' ),
		'cta_label'     => __( 'Book a free project call', 'vyntic' ),
		'cta_url'       => '',
		'email'         => 'hello@vyntic.studio',
		'phone'         => '',
		'whatsapp'      => '',
		'linkedin'      => '',
		'instagram'     => '',
		'footer_text'   => __( 'A web studio for websites that load fast, rank on Google and get recommended by AI. Design, development, SEO and care under one roof.', 'vyntic' ),
		'form_to'       => '',
		'audit_title'   => __( 'Get a free audit of your website.', 'vyntic' ),
		'audit_text'    => __( 'Enter your address and we will check it the way Google does. You get a plain-English report of what is slowing the site down, what is hurting your rankings and what to fix first.', 'vyntic' ),
		'audit_points'  => "Mobile and desktop PageSpeed scores\nCore Web Vitals: LCP, CLS and INP\nOn-page SEO: titles, headings, schema\nThe three fixes that will make the biggest difference",
		'audit_embed'   => '',
		'audit_note'    => __( 'Free, with no sales call required.', 'vyntic' ),
	);
}

/**
 * Read a Customizer option with its default.
 *
 * @param string $key Option key.
 * @return mixed
 */
function vyntic_mod( $key ) {
	$defaults = vyntic_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	$value    = get_theme_mod( 'vyntic_' . $key, $default );
	return ( '' === $value || null === $value ) ? $default : $value;
}

/**
 * Read a per-page field. Uses ACF when installed, then post meta, then a default.
 * Lets you override template copy per page without touching code.
 *
 * @param string   $name    Field name.
 * @param mixed    $default Fallback value.
 * @param int|null $post_id Post ID.
 * @return mixed
 */
function vyntic_field( $name, $default = '', $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( function_exists( 'get_field' ) ) {
		$value = get_field( $name, $post_id );
		if ( ! empty( $value ) ) {
			return $value;
		}
	}
	$value = get_post_meta( $post_id, $name, true );
	return ( '' === $value || false === $value ) ? $default : $value;
}

/**
 * URL of a page by slug, or empty string if the page does not exist.
 *
 * @param string $slug Page slug.
 * @return string
 */
function vyntic_page_url( $slug ) {
	if ( empty( $slug ) ) {
		return '';
	}
	foreach ( array( $slug, 'services/' . $slug, 'industries/' . $slug ) as $path ) {
		$page = get_page_by_path( $path );
		if ( $page && 'publish' === $page->post_status ) {
			return get_permalink( $page );
		}
	}
	return '';
}

/**
 * URL of the first page that uses a given template, e.g. 'page-templates/contact.php'.
 *
 * @param string $template Template path.
 * @return string
 */
function vyntic_template_url( $template ) {
	static $cache = array();
	if ( isset( $cache[ $template ] ) ) {
		return $cache[ $template ];
	}
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $template,           // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'         => 'ids',
		)
	);
	$cache[ $template ] = $pages ? get_permalink( $pages[0] ) : '';
	return $cache[ $template ];
}

/** Where the main call-to-action button points. */
function vyntic_cta_url() {
	$url = vyntic_mod( 'cta_url' );
	if ( $url ) {
		return $url;
	}
	$contact = vyntic_template_url( 'page-templates/contact.php' );
	return $contact ? $contact : 'mailto:' . antispambot( vyntic_mod( 'email' ) );
}

/**
 * Colour band for a performance score, matching how Lighthouse reports it.
 *
 * @param int $score 0-100.
 * @return string good|average|poor
 */
function vyntic_score_band( $score ) {
	$score = (int) $score;
	if ( $score >= 90 ) {
		return 'good';
	}
	if ( $score >= 50 ) {
		return 'average';
	}
	return 'poor';
}

/**
 * Print the score ring.
 *
 * @param int    $score Score 0-100.
 * @param string $size  lg|sm.
 * @param string $label Accessible label.
 */
function vyntic_score_ring( $score, $size = 'lg', $label = '' ) {
	$score = max( 0, min( 100, (int) $score ) );
	$band  = vyntic_score_band( $score );
	$label = $label ? $label : sprintf( /* translators: %d score */ __( 'Performance score %d out of 100', 'vyntic' ), $score );
	?>
	<div class="ring ring--<?php echo esc_attr( $size ); ?> ring--<?php echo esc_attr( $band ); ?>" data-score="<?php echo esc_attr( $score ); ?>" role="img" aria-label="<?php echo esc_attr( $label ); ?>">
		<svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
			<circle class="ring__track" cx="60" cy="60" r="52" />
			<circle class="ring__bar" cx="60" cy="60" r="52" pathLength="100" style="--value: <?php echo esc_attr( $score ); ?>" />
		</svg>
		<span class="ring__value" aria-hidden="true"><?php echo esc_html( $score ); ?></span>
	</div>
	<?php
}

/**
 * Page intro block used by inner templates.
 *
 * @param string $title Heading.
 * @param string $lead  Intro text.
 */
function vyntic_page_intro( $title = '', $lead = '' ) {
	get_template_part(
		'template-parts/page-intro',
		null,
		array(
			'title' => $title,
			'lead'  => $lead,
		)
	);
}

/** Small inline icons. */
function vyntic_icon( $name ) {
	$icons = array(
		'check' => '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M4 10.5l4 4 8-9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'plus'  => '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M10 4v12M4 10h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
		'menu'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 7h18M3 12h18M3 17h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
		'code'    => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M17 14L7 24l10 10M31 14l10 10-10 10M27 10l-6 28" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'cart'    => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M6 8h6l5 22h20l4-15H14" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="19" cy="38" r="3" fill="currentColor"/><circle cx="35" cy="38" r="3" fill="currentColor"/></svg>',
		'target'  => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><circle cx="24" cy="24" r="17" fill="none" stroke="currentColor" stroke-width="3.5"/><circle cx="24" cy="24" r="9" fill="none" stroke="currentColor" stroke-width="3.5"/><circle cx="24" cy="24" r="2.5" fill="currentColor"/></svg>',
		'refresh' => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M39 20A15 15 0 0 0 11 15M9 28a15 15 0 0 0 28 5M11 7v8h8M37 41v-8h-8" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'move'    => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><rect x="5" y="12" width="15" height="24" rx="3" fill="none" stroke="currentColor" stroke-width="3.5"/><rect x="28" y="12" width="15" height="24" rx="3" fill="currentColor" opacity=".35"/><path d="M16 24h18M29 19l5 5-5 5" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'spark'   => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 5c1.8 9.5 6.5 14.2 16 16-9.5 1.8-14.2 6.5-16 16-1.8-9.5-6.5-14.2-16-16 9.5-1.8 14.2-6.5 16-16z" fill="currentColor"/><path d="M38 30c.8 3.6 2.4 5.2 6 6-3.6.8-5.2 2.4-6 6-.8-3.6-2.4-5.2-6-6 3.6-.8 5.2-2.4 6-6z" fill="currentColor" opacity=".55"/></svg>',
		'chat'    => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M8 11h32v21H22l-9 7v-7H8z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><circle cx="17" cy="21.5" r="2.5" fill="currentColor"/><circle cx="24" cy="21.5" r="2.5" fill="currentColor"/><circle cx="31" cy="21.5" r="2.5" fill="currentColor"/></svg>',
		'shield'  => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 5l15 6v11c0 10-6.5 17-15 21-8.5-4-15-11-15-21V11z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><path d="M17 24l5 5 9-10" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'arrow'   => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 17L17 7M9 7h8v8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'down'    => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M6 13l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'chart'   => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M8 40V8M8 40h32" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M15 31l8-9 6 5 11-13" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="40" cy="14" r="3" fill="currentColor"/></svg>',
		'pin'     => '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 43s-13-12.5-13-23a13 13 0 0 1 26 0c0 10.5-13 23-13 23z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><circle cx="24" cy="20" r="5" fill="currentColor"/></svg>',
		'close' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
	);
	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/** Fallback for menus that have not been assigned yet. */
function vyntic_menu_fallback( $args = array() ) {
	$class = ( is_array( $args ) && ! empty( $args['menu_class'] ) ) ? $args['menu_class'] : '';
	echo '<ul class="' . esc_attr( $class ) . '">';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 6,
		)
	);
	echo '</ul>';
}

/** URL of a theme image in assets/img. */
function vyntic_img( $file ) {
	return VYNTIC_URI . '/assets/img/' . ltrim( $file, '/' );
}

/**
 * Estimated reading time in minutes.
 *
 * @param int|null $post_id Post ID.
 * @return int
 */
function vyntic_reading_time( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() );
	$words   = str_word_count( wp_strip_all_tags( strip_shortcodes( (string) $content ) ) );
	return max( 1, (int) ceil( $words / 220 ) );
}

/**
 * Featured image, or the theme's fallback artwork when a post has none.
 *
 * @param string $size     Image size.
 * @param string $fallback Fallback file in assets/img.
 * @param array  $attr     Extra attributes.
 */
function vyntic_thumb( $size = 'vyntic-card', $fallback = 'post-fallback.svg', $attr = array() ) {
	$attr = wp_parse_args( $attr, array( 'loading' => 'lazy', 'alt' => '' ) );
	if ( has_post_thumbnail() ) {
		the_post_thumbnail( $size, $attr );
		return;
	}
	if ( 'post-fallback.svg' === $fallback ) {
		$variants = array( 'post-fallback.svg', 'post-fallback-2.svg', 'post-fallback-3.svg' );
		$fallback = $variants[ get_the_ID() % 3 ];
	}
	printf(
		'<img src="%s" alt="" loading="%s" width="960" height="640">',
		esc_url( vyntic_img( $fallback ) ),
		esc_attr( $attr['loading'] )
	);
}

/** First category of the current post, as a link. */
function vyntic_primary_category() {
	$cats = get_the_category();
	if ( empty( $cats ) ) {
		return '';
	}
	return sprintf( '<a class="tag" href="%s">%s</a>', esc_url( get_category_link( $cats[0] ) ), esc_html( $cats[0]->name ) );
}

/** Free audit text lines from the Customizer, one per line. */
function vyntic_audit_points() {
	$lines = preg_split( '/\r\n|\r|\n/', (string) vyntic_mod( 'audit_points' ) );
	return array_values( array_filter( array_map( 'trim', $lines ) ) );
}

/**
 * Pages that use the Location template (for local SEO), sorted by title.
 *
 * @param int $limit Max pages.
 * @return WP_Post[]
 */
function vyntic_location_pages( $limit = 50 ) {
	return get_posts(
		array(
			'post_type'      => 'page',
			'posts_per_page' => $limit,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => 'page-templates/location.php', // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
}

/**
 * Country-level location pages: Location pages whose parent is not another Location page.
 * Old city pages (children of a country page) are left out of the map and the locations hub.
 *
 * @param int $limit Max pages.
 * @return WP_Post[]
 */
function vyntic_location_countries( $limit = 50 ) {
	$pages = array_values(
		array_filter(
			vyntic_location_pages( $limit ),
			function ( $page ) {
				return ! $page->post_parent || 'page-templates/location.php' !== get_page_template_slug( $page->post_parent );
			}
		)
	);
	// Main markets first, in this order; any other country follows by title.
	$order = array( 'USA', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'France', 'Netherlands', 'Singapore', 'United Arab Emirates', 'New Zealand' );
	$rank  = function ( $page ) use ( $order ) {
		$i = array_search( vyntic_location_label( $page->ID ), $order, true );
		return false === $i ? count( $order ) : $i;
	};
	usort(
		$pages,
		function ( $a, $b ) use ( $rank ) {
			return $rank( $a ) <=> $rank( $b );
		}
	);
	return $pages;
}

/** City name for a location page: the location_city field, or the page title. */
function vyntic_location_city( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$city    = vyntic_field( 'location_city', '', $post_id );
	return $city ? $city : get_the_title( $post_id );
}

/** Display name for a location page on the map and location cards, e.g. "United Kingdom". */
function vyntic_location_label( $post_id = null ) {
	$city  = vyntic_location_city( $post_id );
	$names = array(
		'usa'                      => 'USA',
		'the usa'                  => 'USA',
		'uk'                       => __( 'United Kingdom', 'vyntic' ),
		'the uk'                   => __( 'United Kingdom', 'vyntic' ),
		'uae'                      => __( 'United Arab Emirates', 'vyntic' ),
		'the uae'                  => __( 'United Arab Emirates', 'vyntic' ),
	);
	$key = strtolower( trim( $city ) );
	return isset( $names[ $key ] ) ? $names[ $key ] : preg_replace( '/^the\s+/i', '', $city );
}
