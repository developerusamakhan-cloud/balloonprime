<?php
/**
 * Projects post type (portfolio) with simple built-in fields.
 * Works without ACF. If ACF is installed you can still use these meta keys.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Case studies use the existing "work" post type (the data already on the site).
 * If a plugin already registers "work", we leave it alone and only add our fields.
 */
add_action( 'init', 'vyntic_register_project', 5 );
function vyntic_register_project() {
	if ( post_type_exists( 'work' ) ) {
		if ( ! taxonomy_exists( 'project_type' ) ) {
			vyntic_register_project_type();
		}
		return;
	}
	register_post_type(
		'work',
		array(
			'labels'        => array(
				'name'          => __( 'Work', 'vyntic' ),
				'singular_name' => __( 'Case study', 'vyntic' ),
				'add_new_item'  => __( 'Add new case study', 'vyntic' ),
				'edit_item'     => __( 'Edit case study', 'vyntic' ),
				'all_items'     => __( 'All case studies', 'vyntic' ),
			),
			'public'        => true,
			'has_archive'   => false,
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 21,
			'show_in_rest'  => true,
			'rewrite'       => array( 'slug' => 'work' ),
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
		)
	);

	vyntic_register_project_type();
}

function vyntic_register_project_type() {
	register_taxonomy(
		'project_type',
		'work',
		array(
			'labels'            => array(
				'name'          => __( 'Project types', 'vyntic' ),
				'singular_name' => __( 'Project type', 'vyntic' ),
			),
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'work-type' ),
		)
	);
}

/**
 * Field definitions for the case study meta box: key => array( label, type, group ).
 */
function vyntic_project_fields() {
	return array(
		'project_client'        => array( __( 'Client name', 'vyntic' ), 'text', 'overview' ),
		'project_industry'      => array( __( 'Industry', 'vyntic' ), 'text', 'overview' ),
		'project_location'      => array( __( 'Client location (e.g. London, UK)', 'vyntic' ), 'text', 'overview' ),
		'project_timeline'      => array( __( 'Timeline (e.g. 6 weeks)', 'vyntic' ), 'text', 'overview' ),
		'project_stack'         => array( __( 'Built with (e.g. WordPress, ACF Pro, WooCommerce)', 'vyntic' ), 'text', 'overview' ),
		'project_url'           => array( __( 'Live site URL', 'vyntic' ), 'url', 'overview' ),
		'project_result'        => array( __( 'Headline result (e.g. "Booked appointments up 41% in three months")', 'vyntic' ), 'text', 'overview' ),
		'project_score_before'  => array( __( 'Mobile PageSpeed before (0-100, optional)', 'vyntic' ), 'number', 'scores' ),
		'project_score_after'   => array( __( 'Mobile PageSpeed after (0-100)', 'vyntic' ), 'number', 'scores' ),
		'project_challenge'     => array( __( 'The challenge: what was wrong before', 'vyntic' ), 'textarea', 'story' ),
		'project_solution'      => array( __( 'What we did', 'vyntic' ), 'textarea', 'story' ),
		'project_metric_1_value' => array( __( 'Result 1 number (e.g. +41%)', 'vyntic' ), 'text', 'results' ),
		'project_metric_1_label' => array( __( 'Result 1 label (e.g. more booked appointments)', 'vyntic' ), 'text', 'results' ),
		'project_metric_2_value' => array( __( 'Result 2 number', 'vyntic' ), 'text', 'results' ),
		'project_metric_2_label' => array( __( 'Result 2 label', 'vyntic' ), 'text', 'results' ),
		'project_metric_3_value' => array( __( 'Result 3 number', 'vyntic' ), 'text', 'results' ),
		'project_metric_3_label' => array( __( 'Result 3 label', 'vyntic' ), 'text', 'results' ),
		'project_quote'         => array( __( 'Client quote (their exact words)', 'vyntic' ), 'textarea', 'quote' ),
		'project_quote_name'    => array( __( 'Quote: person name', 'vyntic' ), 'text', 'quote' ),
		'project_quote_role'    => array( __( 'Quote: role and company', 'vyntic' ), 'text', 'quote' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'vyntic_project', __( 'Case study details', 'vyntic' ), 'vyntic_project_box', 'work', 'normal', 'high' );
} );

function vyntic_project_box( $post ) {
	wp_nonce_field( 'vyntic_project_save', 'vyntic_project_nonce' );
	$groups = array(
		'overview' => __( 'Overview', 'vyntic' ),
		'scores'   => __( 'Speed scores', 'vyntic' ),
		'story'    => __( 'The story', 'vyntic' ),
		'results'  => __( 'Results (shown as big numbers)', 'vyntic' ),
		'quote'    => __( 'Client quote', 'vyntic' ),
	);
	foreach ( $groups as $group => $title ) {
		echo '<h3 style="margin:1.5em 0 .25em">' . esc_html( $title ) . '</h3><table class="form-table" role="presentation"><tbody>';
		foreach ( vyntic_project_fields() as $key => $field ) {
			if ( $field[2] !== $group ) {
				continue;
			}
			$value = get_post_meta( $post->ID, $key, true );
			echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field[0] ) . '</label></th><td>';
			if ( 'textarea' === $field[1] ) {
				printf( '<textarea class="large-text" rows="4" id="%1$s" name="%1$s">%2$s</textarea>', esc_attr( $key ), esc_textarea( $value ) );
			} else {
				printf(
					'<input class="regular-text" type="%1$s" id="%2$s" name="%2$s" value="%3$s" %4$s>',
					esc_attr( $field[1] ),
					esc_attr( $key ),
					esc_attr( $value ),
					'number' === $field[1] ? 'min="0" max="100"' : ''
				);
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '<p class="description">' . esc_html__( 'Use the Excerpt for the one-line summary on cards, the Featured image for the main screenshot, and the editor for extra screenshots or detail.', 'vyntic' ) . '</p>';
}

add_action( 'save_post_work', function ( $post_id ) {
	if ( ! isset( $_POST['vyntic_project_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_project_nonce'] ) ), 'vyntic_project_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( vyntic_project_fields() as $key => $field ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		switch ( $field[1] ) {
			case 'url':
				$value = esc_url_raw( $raw );
				break;
			case 'number':
				$value = ( '' === trim( $raw ) ) ? '' : max( 0, min( 100, absint( $raw ) ) );
				break;
			case 'textarea':
				$value = sanitize_textarea_field( $raw );
				break;
			default:
				$value = sanitize_text_field( $raw );
		}
		update_post_meta( $post_id, $key, $value );
	}
} );

/** Flush rewrite rules once when the theme is activated so /work/ URLs work. */
add_action( 'after_switch_theme', function () {
	vyntic_register_project();
	flush_rewrite_rules();
} );

/**
 * Read a case study field. Checks the theme's own field first, then ACF fields
 * (so data saved by your previous setup still shows). Map old ACF names with the
 * 'vyntic_work_field_map' filter, e.g. array( 'project_result' => 'headline' ).
 *
 * @param string   $key     Theme field key.
 * @param int|null $post_id Post ID.
 * @return string
 */
function vyntic_work_meta( $key, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$value   = get_post_meta( $post_id, $key, true );
	if ( '' !== $value && false !== $value ) {
		return (string) $value;
	}
	$map = apply_filters( 'vyntic_work_field_map', array() );
	$alt = isset( $map[ $key ] ) ? $map[ $key ] : $key;
	if ( function_exists( 'get_field' ) ) {
		$acf = get_field( $alt, $post_id );
		if ( is_scalar( $acf ) && '' !== (string) $acf ) {
			return (string) $acf;
		}
	} elseif ( $alt !== $key ) {
		return (string) get_post_meta( $post_id, $alt, true );
	}
	return '';
}
