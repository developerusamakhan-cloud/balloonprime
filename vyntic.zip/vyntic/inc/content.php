<?php
/**
 * Default site content.
 *
 * Everything here is plain PHP arrays so you can edit copy in one place.
 * Each list also passes through a filter (e.g. 'vyntic_services'), so a
 * child theme or plugin can change it without touching this file.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Services shown on Home and the Services template.
 * 'page' is the slug of the page the row links to (leave empty for no link).
 */
function vyntic_services() {
	$services = array(
		array(
			'title' => __( 'Website design and development', 'vyntic' ),
			'text'  => __( 'Custom sites on WordPress, Webflow, Shopify or Wix, designed around your customers and built to load fast. Your team edits content in simple fields.', 'vyntic' ),
			'page'  => 'web-design',
			'icon'  => 'code',
			'tags'  => array( 'WordPress', 'Webflow', 'Wix' ),
		),
		array(
			'title' => __( 'Online stores', 'vyntic' ),
			'text'  => __( 'Shopify and WooCommerce stores with product pages, filters and checkout built for speed on mobile, where most of your buyers are.', 'vyntic' ),
			'page'  => 'ecommerce-development',
			'icon'  => 'cart',
			'tags'  => array( 'Shopify', 'WooCommerce', 'Checkout' ),
		),
		array(
			'title' => __( 'Local SEO', 'vyntic' ),
			'text'  => __( 'Google Maps, Google Business Profile, reviews and location pages that bring calls from people nearby.', 'vyntic' ),
			'page'  => 'local-seo',
			'icon'  => 'pin',
			'tags'  => array( 'Google Maps', 'Reviews', 'Citations' ),
		),
		array(
			'title' => __( 'SEO services', 'vyntic' ),
			'text'  => __( 'Technical fixes, content and authority that bring people who want to buy, not just traffic.', 'vyntic' ),
			'page'  => 'seo',
			'icon'  => 'chart',
			'tags'  => array( 'Technical SEO', 'Content', 'Schema' ),
		),
		array(
			'title' => __( 'AI search visibility', 'vyntic' ),
			'text'  => __( 'Get your business found and quoted in ChatGPT, Perplexity and Google AI answers, not just the blue links.', 'vyntic' ),
			'page'  => 'ai-search-visibility',
			'icon'  => 'spark',
			'tags'  => array( 'Schema', 'llms.txt', 'Content structure' ),
		),
		array(
			'title' => __( 'Landing pages', 'vyntic' ),
			'text'  => __( 'Single-purpose pages for ads and launches, built to load in under a second and convert the traffic you pay for.', 'vyntic' ),
			'page'  => 'landing-pages',
			'icon'  => 'target',
			'tags'  => array( 'Paid ads', 'A/B tests', 'Launches' ),
		),
		array(
			'title' => __( 'Website redesign', 'vyntic' ),
			'text'  => __( 'Keep your rankings, lose the slow design. We rebuild page by page and map every URL before launch.', 'vyntic' ),
			'page'  => 'website-redesign',
			'icon'  => 'refresh',
			'tags'  => array( 'UX', 'Redirects', 'Speed' ),
		),
		array(
			'title' => __( 'Platform migrations', 'vyntic' ),
			'text'  => __( 'Move between WordPress, Webflow, Shopify, Wix and Squarespace with your content, redirects and SEO intact.', 'vyntic' ),
			'page'  => 'website-migration',
			'icon'  => 'move',
			'tags'  => array( 'WordPress', 'Webflow', 'Shopify' ),
		),
		array(
			'title' => __( 'GoHighLevel and automations', 'vyntic' ),
			'text'  => __( 'Funnels, booking, missed call text back, review requests and an AI chat assistant, all set up so no lead slips away.', 'vyntic' ),
			'page'  => 'gohighlevel',
			'icon'  => 'chat',
			'tags'  => array( 'GoHighLevel', 'Automations', 'AI assistant' ),
		),
		array(
			'title' => __( 'Maintenance and care plans', 'vyntic' ),
			'text'  => __( 'Updates, backups, uptime checks and monthly speed reports, handled by the people who built the site.', 'vyntic' ),
			'page'  => 'care-plans',
			'icon'  => 'shield',
			'tags'  => array( 'Updates', 'Backups', 'Monitoring' ),
		),
	);
	return apply_filters( 'vyntic_services', $services );
}

/** The four-step process. This is a real sequence, so it is numbered. */
function vyntic_process() {
	$steps = array(
		array(
			'title' => __( 'Scope and fixed quote', 'vyntic' ),
			'text'  => __( 'A 30-minute call, then a written scope with a fixed price and timeline. No hourly surprises.', 'vyntic' ),
		),
		array(
			'title' => __( 'Design', 'vyntic' ),
			'text'  => __( 'Page designs in Figma for desktop and mobile. You review, comment and approve before any code is written.', 'vyntic' ),
		),
		array(
			'title' => __( 'Build and test', 'vyntic' ),
			'text'  => __( 'We build on the platform that suits you, set up easy editing for your content and test speed, SEO and every device.', 'vyntic' ),
		),
		array(
			'title' => __( 'Launch and care', 'vyntic' ),
			'text'  => __( 'We launch behind Cloudflare, hand over logins and training, and stay on for updates if you want us to.', 'vyntic' ),
		),
	);
	return apply_filters( 'vyntic_process', $steps );
}

/** How we build: the principles section. */
function vyntic_principles() {
	$items = array(
		array(
			'title' => __( 'Speed is the starting point', 'vyntic' ),
			'text'  => __( 'We aim for a 90+ PageSpeed score and passing Core Web Vitals on launch day, not as a later fix.', 'vyntic' ),
		),
		array(
			'title' => __( 'SEO is in the structure', 'vyntic' ),
			'text'  => __( 'Clean headings, schema, fast mobile pages and sensible URLs are built in from the first template.', 'vyntic' ),
		),
		array(
			'title' => __( 'The right platform for you', 'vyntic' ),
			'text'  => __( 'WordPress, Webflow, Shopify or Wix. We recommend what fits your team and budget, not what is easiest for us.', 'vyntic' ),
		),
		array(
			'title' => __( 'You own everything', 'vyntic' ),
			'text'  => __( 'Your code, your hosting, your logins. No lock-in, and no licence you have to keep paying us for.', 'vyntic' ),
		),
	);
	return apply_filters( 'vyntic_principles', $items );
}

/** Tools we build with. */
function vyntic_stack() {
	return apply_filters(
		'vyntic_stack',
		array( 'WordPress', 'Webflow', 'Shopify', 'Wix', 'WooCommerce', 'Squarespace', 'GoHighLevel', 'Figma', 'Cloudflare' )
	);
}

/**
 * Care plans for the Care plans template.
 * PRICES ARE PLACEHOLDERS. Edit them before going live.
 */
function vyntic_plans() {
	$plans = array(
		array(
			'name'     => __( 'Essential', 'vyntic' ),
			'price'    => '$99',
			'period'   => __( 'per month', 'vyntic' ),
			'for'      => __( 'Brochure sites that need to stay safe and up to date.', 'vyntic' ),
			'features' => array(
				__( 'Weekly core, theme and plugin updates', 'vyntic' ),
				__( 'Daily off-site backups', 'vyntic' ),
				__( 'Uptime monitoring', 'vyntic' ),
				__( 'Security scans', 'vyntic' ),
			),
			'featured' => false,
		),
		array(
			'name'     => __( 'Growth', 'vyntic' ),
			'price'    => '$249',
			'period'   => __( 'per month', 'vyntic' ),
			'for'      => __( 'Business sites that change often and need to stay fast.', 'vyntic' ),
			'features' => array(
				__( 'Everything in Essential', 'vyntic' ),
				__( '3 hours of content or design changes', 'vyntic' ),
				__( 'Monthly speed and Core Web Vitals report', 'vyntic' ),
				__( 'Priority support within one business day', 'vyntic' ),
			),
			'featured' => true,
		),
		array(
			'name'     => __( 'Commerce', 'vyntic' ),
			'price'    => '$449',
			'period'   => __( 'per month', 'vyntic' ),
			'for'      => __( 'WooCommerce stores where downtime costs sales.', 'vyntic' ),
			'features' => array(
				__( 'Everything in Growth', 'vyntic' ),
				__( 'Checkout and payment testing after every update', 'vyntic' ),
				__( 'Hourly database backups', 'vyntic' ),
				__( '6 hours of development time', 'vyntic' ),
			),
			'featured' => false,
		),
	);
	return apply_filters( 'vyntic_plans', $plans );
}

/** Questions for the FAQ block (Services and Care plans). */
function vyntic_faq() {
	$faq = array(
		array(
			'q' => __( 'Which platforms do you build on?', 'vyntic' ),
			'a' => __( 'WordPress, Webflow, Shopify, WooCommerce, Wix and GoHighLevel. We recommend the one that fits your content, your team and your budget, and explain why in the proposal.', 'vyntic' ),
		),
		array(
			'q' => __( 'How long does a website take?', 'vyntic' ),
			'a' => __( 'Most business sites take 4 to 6 weeks from signed scope to launch. Stores and larger builds take 6 to 10 weeks. Your scope document gives the exact dates.', 'vyntic' ),
		),
		array(
			'q' => __( 'How much does a website cost?', 'vyntic' ),
			'a' => __( 'It depends on pages, features and platform. After a short call you get a written scope with a fixed price, so the number never changes halfway through.', 'vyntic' ),
		),
		array(
			'q' => __( 'Can I edit the site myself?', 'vyntic' ),
			'a' => __( 'Yes. Every section has simple fields for text and images, and we record a short training video for your team at handover.', 'vyntic' ),
		),
		array(
			'q' => __( 'Will I lose my Google rankings in a redesign or migration?', 'vyntic' ),
			'a' => __( 'We map every existing URL, keep or redirect it, and carry over titles and meta. Most clients see rankings hold or improve after launch.', 'vyntic' ),
		),
		array(
			'q' => __( 'What is AI search visibility?', 'vyntic' ),
			'a' => __( 'More people now ask ChatGPT, Perplexity or Google AI for recommendations. We structure your content and data so these tools can understand your business and cite it as a source.', 'vyntic' ),
		),
		array(
			'q' => __( 'Do you only work on new websites?', 'vyntic' ),
			'a' => __( 'No. We also fix slow sites, run SEO for existing sites, and look after sites other agencies built.', 'vyntic' ),
		),
		array(
			'q' => __( 'Do you work with clients outside the US?', 'vyntic' ),
			'a' => __( 'Yes. We work with brands in the USA, UK, Australia, Canada and Europe, and schedule calls in your time zone.', 'vyntic' ),
		),
		array(
			'q' => __( 'What happens after launch?', 'vyntic' ),
			'a' => __( 'You own everything from day one. If you want, a care plan covers updates, backups, uptime checks and monthly speed reports.', 'vyntic' ),
		),
		array(
			'q' => __( 'Who owns the website and the content?', 'vyntic' ),
			'a' => __( 'You do. The code, the design files, the domain and every login are yours, with no lock-in or licence to keep paying us for.', 'vyntic' ),
		),
	);
	return apply_filters( 'vyntic_faq', $faq );
}

/** "Is your website costing you money?" warning signs. */
function vyntic_problems() {
	return apply_filters(
		'vyntic_problems',
		array(
			array(
				'title' => __( 'It takes more than three seconds to load on a phone', 'vyntic' ),
				'text'  => __( 'Most of your visitors are on mobile data. Every extra second is a chance for them to go back to Google and pick someone else.', 'vyntic' ),
			),
			array(
				'title' => __( 'Your contact form is quiet', 'vyntic' ),
				'text'  => __( 'Traffic arrives but nobody fills in the form. Usually the page is slow, the offer is buried, or the form asks for too much.', 'vyntic' ),
			),
			array(
				'title' => __( 'Rankings are slipping', 'vyntic' ),
				'text'  => __( 'Google measures real visitor experience. Failing Core Web Vitals and messy structure quietly push you down the results.', 'vyntic' ),
			),
			array(
				'title' => __( 'Every small change needs a developer', 'vyntic' ),
				'text'  => __( 'If updating a price or a photo breaks the layout, the site is working against your team instead of for it.', 'vyntic' ),
			),
		)
	);
}

/** Numbers band on the homepage. 'count' animates; 'prefix'/'suffix' wrap it. */
function vyntic_stats() {
	return apply_filters(
		'vyntic_stats',
		array(
			array( 'count' => 50, 'suffix' => '+', 'label' => __( 'Brands launched', 'vyntic' ), 'note' => __( 'Clinics, stores, law firms and startups', 'vyntic' ), 'icon' => 'code' ),
			array( 'count' => 5, 'suffix' => '', 'label' => __( 'Markets served', 'vyntic' ), 'note' => __( 'USA, UK, Canada, Australia and Europe', 'vyntic' ), 'icon' => 'pin' ),
			array( 'count' => 90, 'suffix' => '+', 'label' => __( 'PageSpeed at launch', 'vyntic' ), 'note' => __( 'Our target on mobile for every site', 'vyntic' ), 'icon' => 'spark' ),
			array( 'count' => 24, 'suffix' => 'h', 'label' => __( 'Reply time', 'vyntic' ), 'note' => __( 'The longest you wait to hear back', 'vyntic' ), 'icon' => 'chat' ),
		)
	);
}


/** Industries chip cloud on the homepage. */
function vyntic_industries() {
	return apply_filters(
		'vyntic_industries',
		array(
			__( 'Medical clinics', 'vyntic' ),
			__( 'HVAC and plumbing', 'vyntic' ),
			__( 'Beauty and wellness', 'vyntic' ),
			__( 'Restaurants and cafes', 'vyntic' ),
			__( 'Online stores', 'vyntic' ),
			__( 'Builders and trades', 'vyntic' ),
			__( 'Real estate', 'vyntic' ),
			__( 'Coaches and consultants', 'vyntic' ),
			__( 'SaaS and startups', 'vyntic' ),
			__( 'Accountants', 'vyntic' ),
			__( 'Fitness studios', 'vyntic' ),
			__( 'Agencies (white label)', 'vyntic' ),
		)
	);
}

/** Platforms we build on (replaces the page builder comparison). */
function vyntic_platforms() {
	return apply_filters(
		'vyntic_platforms',
		array(
			array( 'WordPress', __( 'Content-heavy sites, blogs and anything that needs to grow. Most flexible, huge plugin choice.', 'vyntic' ), 'W', '#21759b' ),
			array( 'Webflow', __( 'Design-led marketing sites with smooth animation and a visual editor your team will enjoy.', 'vyntic' ), 'Wf', '#146ef5' ),
			array( 'Shopify', __( 'Stores that want payments, shipping and apps sorted out of the box.', 'vyntic' ), 'S', '#5e8e3e' ),
			array( 'WooCommerce', __( 'Stores that need full control, custom logic or no monthly platform fees.', 'vyntic' ), 'Wc', '#7f54b3' ),
			array( 'Wix', __( 'Small business sites the owner wants to run alone, on a simple all-in-one plan.', 'vyntic' ), 'Wx', '#0c6efc' ),
			array( 'Squarespace', __( 'Portfolios and service sites where polished templates and simplicity matter most.', 'vyntic' ), 'Sq', '#111111' ),
			array( 'GoHighLevel', __( 'Funnels, booking and follow-ups for service businesses that want their site, CRM and automations in one place.', 'vyntic' ), 'GHL', '#188bf6' ),
		)
	);
}
