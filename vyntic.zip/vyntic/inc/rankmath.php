<?php
/**
 * Rank Math: include the content that the theme template shows on a page
 * in Rank Math's content analysis, so scores reflect what visitors really see.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ! defined( 'RANK_MATH_VERSION' ) ) {
		return;
	}
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $post_id || 'page' !== get_post_type( $post_id ) ) {
		return;
	}
	$key = vyntic_current_article_key( $post_id );
	if ( ! $key ) {
		return;
	}
	ob_start();
	vyntic_render_article( $key );
	$html = ob_get_clean();

	// Add the ready-made template text (hero, problems, features, FAQ) for service and industry pages.
	$landing = '';
	$tpl     = get_page_template_slug( $post_id );
	if ( preg_match( '#page-templates/(service|industry)-(.+)\.php$#', $tpl, $m ) && function_exists( 'vyntic_landing' ) ) {
		$d = vyntic_landing( $m[2] );
		if ( $d ) {
			$landing .= '<h1>' . esc_html( $d['h1'] ) . '</h1><p>' . esc_html( $d['lead'] ) . '</p>';
			foreach ( array( 'problems', 'included', 'steps', 'faq' ) as $group ) {
				foreach ( (array) $d[ $group ] as $item ) {
					$landing .= '<h3>' . esc_html( $item[0] ) . '</h3><p>' . esc_html( $item[1] ) . '</p>';
				}
			}
		}
	}

	wp_register_script( 'vyntic-rankmath', '', array( 'wp-hooks' ), VYNTIC_VERSION, true );
	wp_enqueue_script( 'vyntic-rankmath' );
	wp_add_inline_script(
		'vyntic-rankmath',
		'(function(){var extra=' . wp_json_encode( $landing . $html ) . ';wp.hooks.addFilter("rank_math_content","vyntic",function(c){return (c||"")+extra;});var r=function(){if(window.rankMathEditor&&rankMathEditor.refresh){rankMathEditor.refresh("content");}};setTimeout(r,1500);setTimeout(r,4000);})();'
	);
} );
