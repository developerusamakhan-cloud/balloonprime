<?php
/**
 * Theme setup, assets and performance tweaks.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', 'vyntic_setup' );
function vyntic_setup() {
	load_theme_textdomain( 'vyntic', VYNTIC_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 64,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_editor_style( 'assets/css/editor.css' );

	add_theme_support(
		'editor-color-palette',
		array(
			array( 'name' => __( 'Ink', 'vyntic' ), 'slug' => 'ink', 'color' => '#0F2B2E' ),
			array( 'name' => __( 'Coral', 'vyntic' ), 'slug' => 'coral', 'color' => '#C7431F' ),
			array( 'name' => __( 'Mist', 'vyntic' ), 'slug' => 'mist', 'color' => '#EEF3F1' ),
			array( 'name' => __( 'White', 'vyntic' ), 'slug' => 'white', 'color' => '#FFFFFF' ),
			array( 'name' => __( 'Pass', 'vyntic' ), 'slug' => 'pass', 'color' => '#0E9F6A' ),
		)
	);

	add_post_type_support( 'page', 'excerpt' );

	set_post_thumbnail_size( 1200, 750, true );
	add_image_size( 'vyntic-project', 960, 640, true );
	add_image_size( 'vyntic-card', 720, 480, true );

	register_nav_menus(
		array(
			'primary' => __( 'Main menu', 'vyntic' ),
			'footer'  => __( 'Footer menu', 'vyntic' ),
			'legal'   => __( 'Legal links', 'vyntic' ),
		)
	);
}

add_action( 'wp_enqueue_scripts', 'vyntic_assets' );
function vyntic_assets() {
	wp_enqueue_style(
		'vyntic-fonts',
		'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Figtree:wght@400;500;600&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'vyntic-main', VYNTIC_URI . '/assets/css/main.css', array(), VYNTIC_VERSION );
	wp_enqueue_script( 'lenis', VYNTIC_URI . '/assets/vendor/lenis.min.js', array(), '1.3.26', array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_enqueue_script( 'vyntic-main', VYNTIC_URI . '/assets/js/main.js', array( 'lenis' ), VYNTIC_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

/** Preconnect to the font host so text renders sooner. */
add_filter( 'wp_resource_hints', 'vyntic_resource_hints', 10, 2 );
function vyntic_resource_hints( $urls, $relation ) {
	if ( 'preconnect' === $relation ) {
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}

/** Remove front-end weight WordPress adds by default. */
add_action( 'init', 'vyntic_cleanup' );
function vyntic_cleanup() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
}

/** Body classes for template-specific styling. */
add_filter( 'body_class', 'vyntic_body_class' );
function vyntic_body_class( $classes ) {
	if ( is_page_template() ) {
		$template  = get_page_template_slug();
		$classes[] = 'tpl-' . sanitize_html_class( basename( $template, '.php' ) );
	}
	return $classes;
}

add_filter( 'excerpt_length', function () {
	return 26;
} );
add_filter( 'excerpt_more', function () {
	return '…';
} );

/** Add class to menu links so styles do not depend on WP's markup. */
add_filter( 'nav_menu_link_attributes', function ( $atts, $item, $args ) {
	if ( isset( $args->theme_location ) && 'primary' === $args->theme_location ) {
		$atts['class'] = 'nav__link';
		if ( in_array( 'current-menu-item', (array) $item->classes, true ) ) {
			$atts['aria-current'] = 'page';
		}
		if ( in_array( 'menu-item-has-children', (array) $item->classes, true ) ) {
			$atts['aria-haspopup'] = 'true';
		}
	}
	return $atts;
}, 10, 3 );

/** Down arrow after main menu items that have a submenu. */
add_filter( 'nav_menu_item_title', function ( $title, $item, $args, $depth ) {
	if ( isset( $args->theme_location ) && 'primary' === $args->theme_location && 0 === (int) $depth && in_array( 'menu-item-has-children', (array) $item->classes, true ) ) {
		$title .= '<span class="nav__caret" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
	}
	return $title;
}, 10, 4 );

/** Mark that JavaScript is running, so the score ring can start empty and animate. */
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
}, 0 );

/** Built-in favicon when no Site Icon is set in Customize → Site Identity. */
add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( vyntic_img( 'brand/mark-app.svg' ) ) . '">' . "\n";
	}
}, 5 );

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_setting( 'vyntic_use_custom_logo', array( 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ) );
	$wp_customize->add_control(
		'vyntic_use_custom_logo',
		array(
			'label'       => __( 'Use the uploaded logo instead of the built-in Vyntic logo', 'vyntic' ),
			'section'     => 'title_tagline',
			'type'        => 'checkbox',
			'priority'    => 9,
		)
	);
}, 30 );

/**
 * Google Consent Mode defaults (only when enabled in Customize → Vyntic options → Contact and social).
 * Analytics and ads storage start as denied until the visitor accepts the cookie banner.
 */
add_action( 'wp_head', function () {
	if ( ! get_theme_mod( 'vyntic_consent_mode', false ) ) {
		return;
	}
	echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('consent','default',{ad_storage:'denied',analytics_storage:'denied',ad_user_data:'denied',ad_personalization:'denied',wait_for_update:500});try{if(localStorage.getItem('vyntic_consent')==='all'){gtag('consent','update',{ad_storage:'granted',analytics_storage:'granted',ad_user_data:'granted',ad_personalization:'granted'});}}catch(e){}</script>\n";
}, 1 );

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_setting( 'vyntic_consent_mode', array( 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ) );
	$wp_customize->add_control(
		'vyntic_consent_mode',
		array(
			'label'       => __( 'Use Google Consent Mode with the cookie banner', 'vyntic' ),
			'description' => __( 'Analytics and ads cookies stay off until a visitor clicks Accept all.', 'vyntic' ),
			'section'     => 'vyntic_contact',
			'type'        => 'checkbox',
		)
	);
}, 30 );
