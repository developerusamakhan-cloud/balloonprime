<?php
/**
 * Client reviews, managed in the dashboard under Reviews.
 *
 * Title = reviewer name, editor/excerpt = the review text, featured image = photo.
 * Extra fields: rating (1 to 5), role and company, source (Google, Trustpilot, direct...),
 * source link. Drag to reorder with the Order field.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type(
		'review',
		array(
			'labels'              => array(
				'name'          => __( 'Reviews', 'vyntic' ),
				'singular_name' => __( 'Review', 'vyntic' ),
				'add_new_item'  => __( 'Add new review', 'vyntic' ),
				'edit_item'     => __( 'Edit review', 'vyntic' ),
				'all_items'     => __( 'All reviews', 'vyntic' ),
				'title_placeholder' => __( 'Reviewer name', 'vyntic' ),
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_rest'        => true,
			'exclude_from_search' => true,
			'menu_icon'           => 'dashicons-star-filled',
			'menu_position'       => 22,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);
} );

add_filter( 'enter_title_here', function ( $text, $post ) {
	return 'review' === $post->post_type ? __( 'Reviewer name', 'vyntic' ) : $text;
}, 10, 2 );

/** Review field definitions. */
function vyntic_review_fields() {
	return array(
		'review_rating' => array( __( 'Rating (1 to 5)', 'vyntic' ), 'number' ),
		'review_role'   => array( __( 'Role and company (e.g. Owner, Harbor Dental)', 'vyntic' ), 'text' ),
		'review_source' => array( __( 'Source (e.g. Google, Trustpilot, Direct)', 'vyntic' ), 'text' ),
		'review_link'   => array( __( 'Link to the original review (optional)', 'vyntic' ), 'url' ),
		'review_featured' => array( __( 'Show larger on the homepage', 'vyntic' ), 'checkbox' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'vyntic_review', __( 'Review details', 'vyntic' ), 'vyntic_review_box', 'review', 'normal', 'high' );
} );

function vyntic_review_box( $post ) {
	wp_nonce_field( 'vyntic_review_save', 'vyntic_review_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( vyntic_review_fields() as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		if ( 'review_rating' === $key && '' === $value ) {
			$value = 5;
		}
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field[0] ) . '</label></th><td>';
		if ( 'checkbox' === $field[1] ) {
			printf( '<input type="checkbox" id="%1$s" name="%1$s" value="1" %2$s>', esc_attr( $key ), checked( $value, '1', false ) );
		} else {
			printf(
				'<input class="regular-text" type="%1$s" id="%2$s" name="%2$s" value="%3$s" %4$s>',
				esc_attr( $field[1] ),
				esc_attr( $key ),
				esc_attr( $value ),
				'number' === $field[1] ? 'min="1" max="5" step="1"' : ''
			);
		}
		echo '</td></tr>';
	}
	echo '</tbody></table><p class="description">' . esc_html__( 'Write the review text in the editor above. Use the Featured image for the reviewer photo or company logo. Only publish real reviews from real clients.', 'vyntic' ) . '</p>';
}

add_action( 'save_post_review', function ( $post_id ) {
	if ( ! isset( $_POST['vyntic_review_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_review_nonce'] ) ), 'vyntic_review_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( vyntic_review_fields() as $key => $field ) {
		$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		switch ( $field[1] ) {
			case 'number':
				$value = max( 1, min( 5, absint( $raw ) ) );
				break;
			case 'url':
				$value = esc_url_raw( $raw );
				break;
			case 'checkbox':
				$value = $raw ? '1' : '';
				break;
			default:
				$value = sanitize_text_field( $raw );
		}
		update_post_meta( $post_id, $key, $value );
	}
} );

/* Admin list: show rating and source columns. */
add_filter( 'manage_review_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'title' === $k ) {
			$new['review_rating'] = __( 'Rating', 'vyntic' );
			$new['review_source'] = __( 'Source', 'vyntic' );
		}
	}
	return $new;
} );

add_action( 'manage_review_posts_custom_column', function ( $col, $post_id ) {
	if ( 'review_rating' === $col ) {
		echo esc_html( str_repeat( '★', (int) get_post_meta( $post_id, 'review_rating', true ) ) );
	} elseif ( 'review_source' === $col ) {
		echo esc_html( get_post_meta( $post_id, 'review_source', true ) );
	}
}, 10, 2 );

/**
 * Published reviews.
 *
 * @param int $limit Max reviews.
 * @return WP_Post[]
 */
function vyntic_reviews( $limit = 24 ) {
	return get_posts(
		array(
			'post_type'      => 'review',
			'posts_per_page' => $limit,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		)
	);
}

/** Stars as inline SVG. */
function vyntic_stars( $rating ) {
	$rating = max( 0, min( 5, (float) $rating ) );
	$out    = '<span class="stars" role="img" aria-label="' . esc_attr( sprintf( /* translators: %s rating */ __( 'Rated %s out of 5', 'vyntic' ), $rating ) ) . '">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$out .= '<svg viewBox="0 0 20 20" aria-hidden="true" class="' . ( $i <= round( $rating ) ? 'on' : '' ) . '"><path d="M10 1.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.5 7.7l5.9-.9z"/></svg>';
	}
	return $out . '</span>';
}
