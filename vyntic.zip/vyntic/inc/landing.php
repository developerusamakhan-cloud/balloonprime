<?php
/**
 * Ready-made service and industry pages.
 *
 * The copy lives in inc/data/landing.json (plain text, easy to edit).
 * Each page template in page-templates/ (e.g. "Service: Local SEO")
 * renders one entry. Text you add in the page editor appears after the
 * "What you get" section, so you can add extra detail without touching code.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All landing page data, or one entry by key.
 *
 * @param string|null $key Entry key, e.g. 'local-seo'.
 * @return array|null
 */
function vyntic_landing( $key = null ) {
	static $data = null;
	if ( null === $data ) {
		$file = VYNTIC_DIR . '/inc/data/landing.json';
		$raw  = file_exists( $file ) ? file_get_contents( $file ) : '{}'; // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = apply_filters( 'vyntic_landing_data', (array) json_decode( $raw, true ) );
	}
	if ( null === $key ) {
		return $data;
	}
	return isset( $data[ $key ] ) ? $data[ $key ] : null;
}

/** Template file for a landing key. */
function vyntic_landing_template( $key ) {
	$entry = vyntic_landing( $key );
	if ( ! $entry ) {
		return '';
	}
	return 'page-templates/' . ( 'industry' === $entry['kind'] ? 'industry-' : 'service-' ) . $key . '.php';
}

/** URL of the page using a landing key's template (or a page with that slug). */
function vyntic_landing_url( $key ) {
	$url = vyntic_template_url( vyntic_landing_template( $key ) );
	return $url ? $url : vyntic_page_url( $key );
}

/**
 * Service links: prefer a page that uses the matching ready-made template.
 */
add_filter( 'vyntic_services', function ( $services ) {
	foreach ( $services as &$service ) {
		if ( vyntic_landing( $service['page'] ) ) {
			$url = vyntic_template_url( vyntic_landing_template( $service['page'] ) );
			if ( $url ) {
				$service['url'] = $url;
			}
		}
	}
	return $services;
}, 20 );

/**
 * Industry pages that exist, as array( label, url ).
 *
 * @return array
 */
function vyntic_industry_links() {
	$out = array();
	foreach ( vyntic_landing() as $key => $d ) {
		if ( 'industry' !== $d['kind'] ) {
			continue;
		}
		$url = vyntic_template_url( vyntic_landing_template( $key ) );
		if ( $url ) {
			$out[] = array( $d['label'], $url );
		}
	}
	return $out;
}

/**
 * Render a long-form article from inc/data/articles.json straight into the template,
 * with anchored headings and a contents list. Links use the same {{key|text}} tokens.
 *
 * @param string $key   Article key.
 * @param string $title Optional section heading above the article.
 */
function vyntic_render_article( $key, $title = '' ) {
	if ( ! function_exists( 'vyntic_setup_articles' ) ) {
		return;
	}
	$articles = vyntic_setup_articles();
	if ( empty( $articles[ $key ]['body'] ) ) {
		return;
	}
	$body  = $articles[ $key ]['body'];
	$toc   = array();
	$html  = '';
	$first = true;
	foreach ( $body as $block ) {
		list( $type, $value ) = $block;
		if ( 'h2' === $type ) {
			$id    = sanitize_title( $value );
			$toc[] = array( $id, $value );
			$html .= '<h2 id="' . esc_attr( $id ) . '">' . esc_html( $value ) . '</h2>';
		} elseif ( 'h3' === $type ) {
			$html .= '<h3>' . esc_html( $value ) . '</h3>';
		} elseif ( 'ul' === $type ) {
			$html .= '<ul>';
			foreach ( $value as $li ) {
				$html .= '<li>' . vyntic_setup_inline( $li ) . '</li>';
			}
			$html .= '</ul>';
		} else {
			$html .= '<p' . ( $first ? ' class="guide__lead"' : '' ) . '>' . vyntic_setup_inline( $value ) . '</p>';
			$first = false;
		}
	}
	if ( ! empty( $articles[ $key ]['faq'] ) ) {
		$html .= '<h2 id="faq">' . esc_html__( 'Frequently asked questions', 'vyntic' ) . '</h2>';
		foreach ( $articles[ $key ]['faq'] as $q ) {
			$html .= '<h3>' . esc_html( $q[0] ) . '</h3><p>' . esc_html( $q[1] ) . '</p>';
		}
	}
	?>
	<section class="section guide" aria-label="<?php echo esc_attr( $title ? $title : __( 'Guide', 'vyntic' ) ); ?>">
		<div class="wrap guide__inner">
			<?php if ( count( $toc ) > 2 ) : ?>
				<aside class="guide__toc">
					<p class="toc__title"><?php esc_html_e( 'On this page', 'vyntic' ); ?></p>
					<ol class="toc__list">
						<?php foreach ( $toc as $t ) : ?>
							<li><a href="#<?php echo esc_attr( $t[0] ); ?>"><?php echo esc_html( $t[1] ); ?></a></li>
						<?php endforeach; ?>
					</ol>
				</aside>
			<?php endif; ?>
			<div class="guide__body prose">
				<?php if ( $title ) : ?><p class="guide__kicker"><?php echo esc_html( $title ); ?></p><?php endif; ?>
				<?php echo wp_kses_post( $html ); ?>
			</div>
		</div>
	</section>
	<?php
}

/** Setup key whose template (or location city) matches the current page. */
function vyntic_current_article_key( $post_id = null ) {
	if ( ! function_exists( 'vyntic_setup_pages' ) ) {
		return '';
	}
	$post_id  = $post_id ? $post_id : get_the_ID();
	$template = get_page_template_slug( $post_id );
	$city     = get_post_meta( $post_id, 'location_city', true );
	foreach ( vyntic_setup_pages() as $key => $p ) {
		if ( empty( $p[7] ) ) {
			continue;
		}
		if ( 'page-templates/location.php' === $template ) {
			if ( ! empty( $p[8]['meta']['location_city'] ) && $p[8]['meta']['location_city'] === $city ) {
				return $p[7];
			}
			continue;
		}
		if ( $template && $p[3] === $template ) {
			return $p[7];
		}
	}
	return '';
}

/**
 * Pins for the world map: every published Location page with known coordinates.
 * Add custom fields location_lat and location_lng on a Location page for any other city.
 *
 * @return array[] { label, url, x, y, type }
 */
function vyntic_map_pins() {
	$known = array(
		'usa' => array( -98.5, 39.5 ), 'the usa' => array( -98.5, 39.5 ), 'uk' => array( -1.5, 52.6 ), 'the uk' => array( -1.5, 52.6 ),
		'canada' => array( -100, 56 ), 'australia' => array( 134, -25 ), 'ireland' => array( -8, 53.3 ), 'uae' => array( 54.4, 24.4 ),
		'new york' => array( -74.0, 40.7 ), 'houston' => array( -95.4, 29.8 ), 'london' => array( -0.13, 51.5 ), 'toronto' => array( -79.4, 43.7 ),
		'sydney' => array( 151.2, -33.9 ), 'dubai' => array( 55.3, 25.2 ), 'los angeles' => array( -118.2, 34.05 ), 'chicago' => array( -87.6, 41.9 ),
		'miami' => array( -80.2, 25.8 ), 'dallas' => array( -96.8, 32.8 ), 'manchester' => array( -2.24, 53.48 ), 'vancouver' => array( -123.1, 49.3 ),
		'melbourne' => array( 144.96, -37.8 ), 'calgary' => array( -114.07, 51.05 ), 'brisbane' => array( 153.0, -27.5 ), 'dublin' => array( -6.26, 53.35 ),
	);
	$pins = array();
	foreach ( vyntic_location_pages( 60 ) as $page ) {
		if ( 'publish' !== $page->post_status ) {
			continue;
		}
		$city = vyntic_location_city( $page->ID );
		$lat  = get_post_meta( $page->ID, 'location_lat', true );
		$lng  = get_post_meta( $page->ID, 'location_lng', true );
		if ( '' === $lat || '' === $lng ) {
			$k = strtolower( trim( $city ) );
			if ( ! isset( $known[ $k ] ) ) {
				continue;
			}
			list( $lng, $lat ) = $known[ $k ];
		}
		$is_country = (bool) get_pages( array( 'child_of' => $page->ID, 'parent' => $page->ID, 'number' => 1 ) ) || in_array( strtolower( $city ), array( 'the usa', 'the uk', 'canada', 'australia', 'usa', 'uk' ), true );
		$pins[]     = array(
			'label' => preg_replace( '/^the\s+/i', '', $city ),
			'url'   => get_permalink( $page ),
			'x'     => round( ( (float) $lng + 180 ) / 360 * 100, 2 ),
			'y'     => round( ( 78 - (float) $lat ) / 136 * 100, 2 ),
			'type'  => $is_country ? 'country' : 'city',
		);
	}
	return apply_filters( 'vyntic_map_pins', $pins );
}
