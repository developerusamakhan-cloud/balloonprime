<?php
/**
 * Contact form handling. No plugin needed.
 * Tip: install an SMTP plugin (e.g. WP Mail SMTP) so emails reach your inbox reliably.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_post_nopriv_vyntic_contact', 'vyntic_handle_contact' );
add_action( 'admin_post_vyntic_contact', 'vyntic_handle_contact' );

function vyntic_handle_contact() {
	$back = isset( $_POST['_back'] ) ? esc_url_raw( wp_unslash( $_POST['_back'] ) ) : home_url( '/' );
	$back = wp_validate_redirect( $back, home_url( '/' ) );

	if ( ! isset( $_POST['vyntic_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_contact_nonce'] ) ), 'vyntic_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'form', 'expired', $back ) . '#contact-form' );
		exit;
	}

	// Honeypot: real people never fill this hidden field.
	if ( ! empty( $_POST['company_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'form', 'sent', $back ) . '#contact-form' );
		exit;
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$website = isset( $_POST['website'] ) ? sanitize_text_field( wp_unslash( $_POST['website'] ) ) : '';
	$services = isset( $_POST['services'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['services'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$service  = $services ? implode( ', ', $services ) : ( isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : '' );
	$phone    = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$timeline = isset( $_POST['timeline'] ) ? sanitize_text_field( wp_unslash( $_POST['timeline'] ) ) : '';
	$budget  = isset( $_POST['budget'] ) ? sanitize_text_field( wp_unslash( $_POST['budget'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		wp_safe_redirect( add_query_arg( 'form', 'missing', $back ) . '#contact-form' );
		exit;
	}

	$to = vyntic_mod( 'form_to' ) ? vyntic_mod( 'form_to' ) : vyntic_mod( 'email' );
	$to = is_email( $to ) ? $to : get_option( 'admin_email' );

	/* translators: %s: sender name */
	$subject = sprintf( __( 'New project inquiry from %s', 'vyntic' ), $name );
	$body    = implode(
		"\n",
		array(
			'Name: ' . $name,
			'Email: ' . $email,
			'Phone: ' . ( $phone ? $phone : '-' ),
			'Website: ' . ( $website ? $website : '-' ),
			'Service: ' . ( $service ? $service : '-' ),
			'Budget: ' . ( $budget ? $budget : '-' ),
			'Timeline: ' . ( $timeline ? $timeline : '-' ),
			'',
			$message,
			'',
			'Sent from ' . $back,
		)
	);
	$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

	$sent = wp_mail( $to, $subject, $body, $headers );

	wp_safe_redirect( add_query_arg( 'form', $sent ? 'sent' : 'failed', $back ) . '#contact-form' );
	exit;
}

/**
 * Message to show after a form submission, based on ?form= in the URL.
 *
 * @return array|null { type, text }
 */
function vyntic_form_notice() {
	if ( empty( $_GET['form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return null;
	}
	$state    = sanitize_key( wp_unslash( $_GET['form'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array(
		'sent'    => array( 'success', __( 'Message sent. We will reply within 24 hours.', 'vyntic' ) ),
		'missing' => array( 'error', __( 'Add your name, a valid email and a short message, then send again.', 'vyntic' ) ),
		'expired' => array( 'error', __( 'The form timed out. Refresh the page and send again.', 'vyntic' ) ),
		'failed'  => array( 'error', sprintf( /* translators: %s email */ __( 'The message could not be sent. Email us directly at %s.', 'vyntic' ), vyntic_mod( 'email' ) ) ),
	);
	if ( ! isset( $messages[ $state ] ) ) {
		return null;
	}
	return array(
		'type' => $messages[ $state ][0],
		'text' => $messages[ $state ][1],
	);
}

/*
 * Free audit request form (used until you paste your own tool in Customize → Free audit).
 */
add_action( 'admin_post_nopriv_vyntic_audit', 'vyntic_handle_audit' );
add_action( 'admin_post_vyntic_audit', 'vyntic_handle_audit' );

function vyntic_handle_audit() {
	$back = isset( $_POST['_back'] ) ? esc_url_raw( wp_unslash( $_POST['_back'] ) ) : home_url( '/' );
	$back = wp_validate_redirect( $back, home_url( '/' ) );

	if ( ! isset( $_POST['vyntic_audit_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vyntic_audit_nonce'] ) ), 'vyntic_audit' ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'expired', $back ) . '#free-audit' );
		exit;
	}
	if ( ! empty( $_POST['company_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'sent', $back ) . '#free-audit' );
		exit;
	}

	$site  = isset( $_POST['site'] ) ? esc_url_raw( wp_unslash( $_POST['site'] ) ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

	if ( '' === $site || ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'audit', 'missing', $back ) . '#free-audit' );
		exit;
	}

	$to   = vyntic_mod( 'form_to' ) ? vyntic_mod( 'form_to' ) : vyntic_mod( 'email' );
	$to   = is_email( $to ) ? $to : get_option( 'admin_email' );
	$sent = wp_mail(
		$to,
		/* translators: %s website */
		sprintf( __( 'Free audit request: %s', 'vyntic' ), $site ),
		"Website: {$site}\nEmail: {$email}\n\nSent from {$back}",
		array( 'Reply-To: ' . $email )
	);

	wp_safe_redirect( add_query_arg( 'audit', $sent ? 'sent' : 'failed', $back ) . '#free-audit' );
	exit;
}

/** Message after an audit request, based on ?audit= in the URL. */
function vyntic_audit_notice() {
	if ( empty( $_GET['audit'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return null;
	}
	$state    = sanitize_key( wp_unslash( $_GET['audit'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array(
		'sent'    => array( 'success', __( 'Request received. Your audit will arrive by email within two business days.', 'vyntic' ) ),
		'missing' => array( 'error', __( 'Add your website address and a valid email, then send again.', 'vyntic' ) ),
		'expired' => array( 'error', __( 'The form timed out. Refresh the page and send again.', 'vyntic' ) ),
		'failed'  => array( 'error', sprintf( /* translators: %s email */ __( 'The request could not be sent. Email us at %s.', 'vyntic' ), vyntic_mod( 'email' ) ) ),
	);
	return isset( $messages[ $state ] ) ? array( 'type' => $messages[ $state ][0], 'text' => $messages[ $state ][1] ) : null;
}
