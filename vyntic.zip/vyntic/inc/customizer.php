<?php
/**
 * Customizer options: Appearance → Customize → Vyntic options.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'customize_register', 'vyntic_customize_register' );
function vyntic_customize_register( $wp_customize ) {
	$wp_customize->add_panel(
		'vyntic',
		array(
			'title'    => __( 'Vyntic options', 'vyntic' ),
			'priority' => 30,
		)
	);

	$sections = array(
		'vyntic_hero'    => array(
			'title'  => __( 'Home hero', 'vyntic' ),
			'fields' => array(
				'hero_title' => array( __( 'Headline start (e.g. "Websites that")', 'vyntic' ), 'text' ),
				'hero_words' => array( __( 'Rotating endings, separated by | (e.g. rank on Google|get recommended by AI)', 'vyntic' ), 'text' ),
				'hero_text'  => array( __( 'Intro text', 'vyntic' ), 'textarea' ),
				'hero_score' => array( __( 'Score shown in the ring (0-100)', 'vyntic' ), 'number' ),
				'hero_lcp'   => array( __( 'LCP value (e.g. 0.9 s)', 'vyntic' ), 'text' ),
				'hero_cls'   => array( __( 'CLS value (e.g. 0.01)', 'vyntic' ), 'text' ),
				'hero_inp'   => array( __( 'INP value (e.g. 68 ms)', 'vyntic' ), 'text' ),
				'trust_line' => array( __( 'Trust line under buttons', 'vyntic' ), 'text' ),
				'statement_image' => array( __( 'Statement image URL (e.g. a team photo from the Media Library). Leave empty for the built-in artwork.', 'vyntic' ), 'url' ),
			),
		),
		'vyntic_cta'     => array(
			'title'  => __( 'Call to action', 'vyntic' ),
			'fields' => array(
				'cta_title' => array( __( 'Heading', 'vyntic' ), 'text' ),
				'cta_text'  => array( __( 'Text', 'vyntic' ), 'textarea' ),
				'cta_label' => array( __( 'Button label', 'vyntic' ), 'text' ),
				'cta_url'   => array( __( 'Button link (leave empty to use your Contact page)', 'vyntic' ), 'url' ),
			),
		),
		'vyntic_audit'   => array(
			'title'  => __( 'Free audit', 'vyntic' ),
			'fields' => array(
				'audit_title'  => array( __( 'Heading', 'vyntic' ), 'text' ),
				'audit_text'   => array( __( 'Intro text', 'vyntic' ), 'textarea' ),
				'audit_points' => array( __( 'What the audit checks (one per line)', 'vyntic' ), 'textarea' ),
				'audit_note'   => array( __( 'Small note under the tool', 'vyntic' ), 'text' ),
				'audit_embed'  => array( __( 'Your audit tool: paste its shortcode or embed code. Leave empty to use the built-in request form.', 'vyntic' ), 'code' ),
			),
		),
		'vyntic_contact' => array(
			'title'  => __( 'Contact and social', 'vyntic' ),
			'fields' => array(
				'email'       => array( __( 'Public email', 'vyntic' ), 'email' ),
				'form_to'     => array( __( 'Send contact form to (defaults to public email)', 'vyntic' ), 'email' ),
				'phone'       => array( __( 'Phone', 'vyntic' ), 'text' ),
				'address'     => array( __( 'Studio address (shown in the footer)', 'vyntic' ), 'textarea' ),
				'hours'       => array( __( 'Opening hours', 'vyntic' ), 'text' ),
				'whatsapp'    => array( __( 'WhatsApp number, digits only with country code', 'vyntic' ), 'text' ),
				'linkedin'    => array( __( 'LinkedIn URL', 'vyntic' ), 'url' ),
				'instagram'   => array( __( 'Instagram URL', 'vyntic' ), 'url' ),
				'footer_text' => array( __( 'Footer description', 'vyntic' ), 'textarea' ),
			),
		),
	);

	$defaults = vyntic_defaults();
	$priority = 10;

	foreach ( $sections as $section_id => $section ) {
		$wp_customize->add_section(
			$section_id,
			array(
				'title' => $section['title'],
				'panel' => 'vyntic',
			)
		);

		foreach ( $section['fields'] as $key => $field ) {
			list( $label, $type ) = $field;

			switch ( $type ) {
				case 'url':
					$sanitize = 'esc_url_raw';
					break;
				case 'email':
					$sanitize = 'sanitize_email';
					break;
				case 'number':
					$sanitize = 'absint';
					break;
				case 'textarea':
					$sanitize = 'sanitize_textarea_field';
					break;
				case 'code':
					$sanitize = 'vyntic_sanitize_embed';
					break;
				default:
					$sanitize = 'sanitize_text_field';
			}

			$wp_customize->add_setting(
				'vyntic_' . $key,
				array(
					'default'           => isset( $defaults[ $key ] ) ? $defaults[ $key ] : '',
					'sanitize_callback' => $sanitize,
					'transport'         => 'refresh',
				)
			);

			$args = array(
				'label'    => $label,
				'section'  => $section_id,
				'type'     => 'code' === $type ? 'textarea' : $type,
				'priority' => $priority++,
			);
			if ( 'number' === $type ) {
				$args['input_attrs'] = array(
					'min' => 0,
					'max' => 100,
				);
			}
			$wp_customize->add_control( 'vyntic_' . $key, $args );
		}
	}
}

/**
 * Embed code for the audit tool. Admins who may post unfiltered HTML can paste
 * scripts and iframes; everyone else is limited to safe HTML.
 *
 * @param string $value Raw value.
 * @return string
 */
function vyntic_sanitize_embed( $value ) {
	return current_user_can( 'unfiltered_html' ) ? (string) $value : wp_kses_post( $value );
}
