/**
 * Vyntic theme scripts. No dependencies.
 */
(function () {
	'use strict';

	var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* Smooth scroll (Lenis). Native scrolling is kept on touch devices and for reduced motion. */
	var lenis = null;
	if (window.Lenis && !reduceMotion) {
		lenis = new window.Lenis({
			lerp: 0.09,
			wheelMultiplier: 0.95,
			anchors: { offset: -90 },
			prevent: function (node) { return node.closest && node.closest('.quotes, .plan-preview__body, .reel:not(.is-pinned) .reel__track, [data-lenis-prevent]'); }
		});
		(function raf(time) {
			lenis.raf(time);
			requestAnimationFrame(raf);
		})(0);
		window.vynticLenis = lenis;
	}

	/* Mobile menu */
	var toggle = document.querySelector('[data-nav-toggle]');
	var nav = document.querySelector('[data-nav]');

	function setMenu(open) {
		if (!toggle || !nav) return;
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		nav.classList.toggle('is-open', open);
		document.body.classList.toggle('nav-open', open);
		if (lenis) { open ? lenis.stop() : lenis.start(); }
	}

	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			setMenu(toggle.getAttribute('aria-expanded') !== 'true');
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && nav.classList.contains('is-open')) {
				setMenu(false);
				toggle.focus();
			}
		});
		nav.addEventListener('click', function (e) {
			if (e.target.closest('a')) setMenu(false);
		});
		window.matchMedia('(min-width: 961px)').addEventListener('change', function (mq) {
			if (mq.matches) setMenu(false);
		});
	}

	/* Header border once the page scrolls */
	var header = document.querySelector('[data-header]');
	if (header) {
		var onScroll = function () {
			header.classList.toggle('is-scrolled', window.scrollY > 8);
		};
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
	}

	/* Score rings fill and count up the first time they are seen */
	var rings = document.querySelectorAll('.ring[data-score]');

	function countUp(ring) {
		var target = parseInt(ring.getAttribute('data-score'), 10) || 0;
		var out = ring.querySelector('.ring__value');
		ring.classList.add('is-in');
		if (!out || reduceMotion || target === 0) return;
		var start = null;
		var duration = 1600;
		function frame(t) {
			if (start === null) start = t;
			var p = Math.min((t - start) / duration, 1);
			var eased = 1 - Math.pow(1 - p, 4);
			out.textContent = Math.round(target * eased);
			if (p < 1) window.requestAnimationFrame(frame);
		}
		out.textContent = '0';
		window.requestAnimationFrame(frame);
	}

	if (rings.length) {
		if (!('IntersectionObserver' in window)) {
			rings.forEach(function (r) { r.classList.add('is-in'); });
		} else {
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						countUp(entry.target);
						io.unobserve(entry.target);
					}
				});
			}, { threshold: 0.4 });
			rings.forEach(function (r) { io.observe(r); });
		}
	}

	/* Article contents list, built from the H2s in the post */
	var toc = document.querySelector('[data-toc]');
	var article = document.querySelector('[data-article]');
	if (toc && article) {
		var heads = article.querySelectorAll('h2');
		if (heads.length >= 2) {
			var list = toc.querySelector('ol');
			var links = [];
			heads.forEach(function (h, i) {
				if (!h.id) {
					h.id = (h.textContent || 'section').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'section-' + (i + 1);
				}
				var li = document.createElement('li');
				var a = document.createElement('a');
				a.href = '#' + h.id;
				a.textContent = h.textContent;
				li.appendChild(a);
				list.appendChild(li);
				links.push(a);
			});
			toc.hidden = false;
			if ('IntersectionObserver' in window) {
				var tocIO = new IntersectionObserver(function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							links.forEach(function (l) {
								l.classList.toggle('is-active', l.getAttribute('href') === '#' + entry.target.id);
							});
						}
					});
				}, { rootMargin: '0px 0px -70% 0px' });
				heads.forEach(function (h) { tocIO.observe(h); });
			}
		}
	}

	/* Copy link button */
	document.querySelectorAll('[data-copy]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var label = btn.textContent;
			var done = function () {
				btn.textContent = btn.getAttribute('data-done') || 'Copied';
				setTimeout(function () { btn.textContent = label; }, 2000);
			};
			if (navigator.clipboard) {
				navigator.clipboard.writeText(btn.getAttribute('data-copy')).then(done);
			}
		});
	});

	/* Hero headline: rotate the endings */
	var rot = document.querySelector('[data-rotator]');
	if (rot) {
		var items = rot.querySelectorAll('.rotator__item');
		var ri = 0;
		var fit = function () {};
		fit();
		window.addEventListener('resize', fit);
		if (items.length > 1 && !reduceMotion) {
			setInterval(function () {
				items[ri].classList.remove('is-active');
				items[ri].classList.add('is-leaving');
				var old = items[ri];
				setTimeout(function () { old.classList.remove('is-leaving'); }, 700);
				ri = (ri + 1) % items.length;
				items[ri].classList.add('is-active');
				fit();
			}, 2800);
		}
	}

	/* Hero headline: wrap each word so it can rise in */
	var split = document.querySelector('[data-split]');
	if (split && !reduceMotion) {
		var words = split.textContent.trim().split(/\s+/);
		split.setAttribute('aria-label', split.textContent.trim());
		split.innerHTML = words.map(function (w, i) {
			var safe = w.replace(/&/g, '&amp;').replace(/</g, '&lt;');
			return '<span class="word" aria-hidden="true"><span style="--i:' + i + '">' + safe + '</span></span>';
		}).join(' ');
		split.classList.add('is-split');
	}

	/* Scroll reveal for content blocks, staggered within each group */
	var revealSelector = [
		'.section__head', '.problems__head', '.problem', '.service', '.project', '.card-post',
		'.process__step', '.principle', '.faq__item', '.stat', '.versus__row', '.plan',
		'.quote-card', '.fact', '.metric', '.audit__copy', '.audit__tool', '.cta__inner > *',
		'.feature-post', '.case-story > div', '.audit-sample > *', '.next-case', '.pcard', '.promo-card', '.journal__topics', '.statement__copy', '.loc-card', '.footer-col', '.footer-cta > *', '.proof__item', '.platform', '.lp-card', '.lp-rel', '.ind-card', '.reviews__summary', '.contact-block__info', '.contact-block__form'
	].join(',');
	var revealEls = document.querySelectorAll(revealSelector);
	if (!reduceMotion && 'IntersectionObserver' in window && revealEls.length) {
		revealEls.forEach(function (el) {
			var siblings = Array.prototype.filter.call(el.parentNode.children, function (c) { return c.matches(revealSelector); });
			el.style.setProperty('--d', Math.min(siblings.indexOf(el), 6));
			el.setAttribute('data-reveal', '');
		});
		var revealIO = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('is-visible');
					revealIO.unobserve(entry.target);
				}
			});
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
		revealEls.forEach(function (el) { revealIO.observe(el); });
	} else {
		document.querySelectorAll('.process__step').forEach(function (el) { el.classList.add('is-visible'); });
	}

	/* Count-up numbers */
	var counters = document.querySelectorAll('[data-count]');
	if (counters.length && !reduceMotion && 'IntersectionObserver' in window) {
		var countIO = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (!entry.isIntersecting) return;
				var el = entry.target;
				var target = parseInt(el.getAttribute('data-count'), 10) || 0;
				var start = null;
				el.textContent = '0';
				function tick(t) {
					if (start === null) start = t;
					var p = Math.min((t - start) / 1400, 1);
					el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
					if (p < 1) requestAnimationFrame(tick);
				}
				requestAnimationFrame(tick);
				countIO.unobserve(el);
			});
		}, { threshold: 0.6 });
		counters.forEach(function (c) { countIO.observe(c); });
	}

	/* FAQ: animate opening and closing */
	document.querySelectorAll('.faq__item').forEach(function (item) {
		var summary = item.querySelector('summary');
		var body = item.querySelector('p');
		if (!summary || !body || reduceMotion) return;
		summary.addEventListener('click', function (e) {
			e.preventDefault();
			if (item.open) {
				var h = body.offsetHeight;
				body.animate([{ height: h + 'px', opacity: 1 }, { height: '0px', opacity: 0 }], { duration: 280, easing: 'ease-in' })
					.onfinish = function () { item.open = false; };
			} else {
				item.open = true;
				var full = body.offsetHeight;
				body.animate([{ height: '0px', opacity: 0 }, { height: full + 'px', opacity: 1 }], { duration: 380, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' });
			}
		});
	});

	/* Testimonials slider buttons */
	var slider = document.querySelector('[data-slider]');
	if (slider) {
		document.querySelectorAll('[data-slide]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var card = slider.querySelector('.quote-card');
				var step = card ? card.getBoundingClientRect().width + 24 : slider.clientWidth;
				slider.scrollBy({ left: step * parseInt(btn.getAttribute('data-slide'), 10), behavior: reduceMotion ? 'auto' : 'smooth' });
			});
		});
	}

	var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
	var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

	/* ---------- Custom cursor: a lens that inverts what is under it ---------- */
	if (finePointer && !reduceMotion) {
		var lens = document.createElement('div');
		var lensLabel = document.createElement('span');
		lens.className = 'lens';
		lens.setAttribute('aria-hidden', 'true');
		lens.appendChild(lensLabel);
		document.body.appendChild(lens);
		var mx = -100, my = -100, lx = -100, ly = -100, lastT = null;
		document.addEventListener('mousemove', function (e) {
			mx = e.clientX; my = e.clientY;
			document.body.classList.add('has-cursor');
			var t = e.target;
			var labelled = t.closest && t.closest('[data-cursor]');
			var link = t.closest && t.closest('a, button, summary, label, select, [data-slide]');
			var field = t.closest && t.closest('input, textarea');
			lens.classList.toggle('is-label', !!labelled);
			lens.classList.toggle('is-link', !labelled && !!link);
			lens.classList.toggle('is-text', !!field);
			if (labelled && lastT !== labelled) { lensLabel.textContent = labelled.getAttribute('data-cursor'); }
			lastT = labelled;
		});
		document.addEventListener('mouseleave', function () { document.body.classList.remove('has-cursor'); });
		document.addEventListener('mousedown', function () { lens.classList.add('is-down'); });
		document.addEventListener('mouseup', function () { lens.classList.remove('is-down'); });
		(function follow() {
			var dx = mx - lx, dy = my - ly;
			lx += dx * 0.2; ly += dy * 0.2;
			var speed = Math.min(Math.sqrt(dx * dx + dy * dy) / 60, 0.45);
			var angle = Math.atan2(dy, dx) * 180 / Math.PI;
			lens.style.transform = 'translate(' + lx + 'px,' + ly + 'px) rotate(' + angle + 'deg) scale(' + (1 + speed) + ',' + (1 - speed * 0.6) + ')';
			lensLabel.style.transform = 'rotate(' + (-angle) + 'deg)';
			requestAnimationFrame(follow);
		})();

		/* Magnetic pull on big buttons and the hero badge */
		document.querySelectorAll('.btn--lg, .badge, .slider-nav__btn').forEach(function (el) {
			el.addEventListener('mousemove', function (e) {
				var r = el.getBoundingClientRect();
				var x = (e.clientX - r.left - r.width / 2) * 0.25;
				var y = (e.clientY - r.top - r.height / 2) * 0.35;
				el.style.translate = x + 'px ' + y + 'px';
			});
			el.addEventListener('mouseleave', function () { el.style.translate = ''; });
			el.style.transition = (getComputedStyle(el).transition ? getComputedStyle(el).transition + ', ' : '') + 'translate 0.35s cubic-bezier(0.22, 1, 0.36, 1)';
		});
	}

	/* ---------- Service preview: screen that follows the cursor ---------- */
	var zone = document.querySelector('[data-preview-zone]');
	var preview = document.querySelector('[data-preview]');
	if (zone && preview && finePointer) {
		var pImg = preview.querySelector('.preview__img');
		var pLabel = preview.querySelector('.preview__label');
		var px = 0, py = 0, tx = 0, ty = 0, vx = 0;
		zone.querySelectorAll('.service').forEach(function (row) {
			row.addEventListener('mouseenter', function (e) {
				var src = row.getAttribute('data-preview-img');
				if (pImg.getAttribute('src') !== src) {
					preview.classList.remove('is-swap');
					void preview.offsetWidth;
					preview.classList.add('is-swap');
					pImg.setAttribute('src', src);
				}
				pLabel.textContent = row.getAttribute('data-preview-label');
				if (!preview.classList.contains('is-on')) { px = e.clientX; py = e.clientY; }
				preview.classList.add('is-on');
			});
			row.addEventListener('mouseleave', function () { preview.classList.remove('is-on'); });
		});
		zone.addEventListener('mousemove', function (e) { tx = e.clientX; ty = e.clientY; });
		(function move() {
			var dx = (tx - px) * 0.12;
			px += dx; py += (ty - py) * 0.12;
			vx += (dx - vx) * 0.2;
			preview.style.left = px + 'px';
			preview.style.top = py + 'px';
			preview.style.setProperty('--tilt', clamp(vx * 0.6, -12, 12).toFixed(2) + 'deg');
			preview.style.setProperty('--shift', clamp(-vx * 1.5, -20, 20).toFixed(1) + 'px');
			requestAnimationFrame(move);
		})();
	}

	/* ---------- Statement: highlighter sweeps across key phrases ---------- */
	var marks = document.querySelectorAll('.statement .hl');
	var scrubWords = [];
	var scrub = null;
	if (marks.length) {
		if (reduceMotion || !('IntersectionObserver' in window)) {
			marks.forEach(function (m) { m.classList.add('is-on'); });
		} else {
			var markIO = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						marks.forEach(function (m, i) { setTimeout(function () { m.classList.add('is-on'); }, 250 + i * 450); });
						markIO.disconnect();
					}
				});
			}, { threshold: 0.6 });
			markIO.observe(document.querySelector('.statement__text'));
		}
	}

	/* ---------- Work reel: pin and move sideways on desktop ---------- */
	var reel = document.querySelector('[data-reel]');
	var reelTrack = reel ? reel.querySelector('[data-reel-track]') : null;
	var reelBar = reel ? reel.querySelector('[data-reel-progress]') : null;
	var reelDistance = 0;
	function setupReel() {
		if (!reel || !reelTrack) return;
		var wide = window.innerWidth > 960 && !reduceMotion;
		reel.classList.toggle('is-pinned', wide);
		reelTrack.style.transform = '';
		if (!wide) { reel.style.height = ''; return; }
		reelDistance = Math.max(0, reelTrack.scrollWidth - window.innerWidth);
		reel.style.height = (window.innerHeight + reelDistance) + 'px';
	}
	setupReel();
	window.addEventListener('resize', setupReel);
	window.addEventListener('load', setupReel);

	/* ---------- One scroll loop for all scroll-linked effects ---------- */
	var showcase = document.querySelector('[data-showcase]');
	var speedEls = document.querySelectorAll('[data-speed]');
	var stackCards = document.querySelectorAll('.stack-card');
	var readBar = document.querySelector('[data-read-progress]');
	var ticking = false;

	function onScrollFrame() {
		ticking = false;
		var vh = window.innerHeight;

		if (showcase && !reduceMotion) {
			var r = showcase.getBoundingClientRect();
			var p = clamp((vh - r.top) / (vh * 0.9), 0, 1);
			showcase.style.setProperty('--p', p.toFixed(3));
		}

		if (!reduceMotion) {
			speedEls.forEach(function (el) {
				var box = (el.closest('section') || el).getBoundingClientRect();
				var mid = box.top + box.height / 2 - vh / 2;
				el.style.translate = '0 ' + (mid * parseFloat(el.getAttribute('data-speed'))).toFixed(1) + 'px';
			});
		}

		if (scrubWords.length && !reduceMotion) {
			var sr = scrub.getBoundingClientRect();
			var sp = clamp((vh * 0.85 - sr.top) / (sr.height + vh * 0.35), 0, 1);
			var lit = Math.round(sp * scrubWords.length);
			scrubWords.forEach(function (w, i) { w.classList.toggle('on', i < lit); });
		}

		if (reel && reel.classList.contains('is-pinned')) {
			var rr = reel.getBoundingClientRect();
			var rp = clamp(-rr.top / Math.max(1, reelDistance), 0, 1);
			reelTrack.style.transform = 'translate3d(' + (-rp * reelDistance).toFixed(1) + 'px,0,0)';
			if (reelBar) reelBar.style.setProperty('--rp', rp.toFixed(3));
		}

		if (readBar) {
			var docH = document.documentElement.scrollHeight - vh;
			readBar.style.setProperty('--rp', clamp(window.scrollY / Math.max(1, docH), 0, 1).toFixed(4));
		}

		if (stackCards.length && !reduceMotion) {
			stackCards.forEach(function (card, i) {
				var next = stackCards[i + 1];
				if (!next) return;
				var cr = card.getBoundingClientRect();
				var nr = next.getBoundingClientRect();
				var cover = clamp((cr.bottom - nr.top) / cr.height, 0, 1);
				card.style.transform = 'scale(' + (1 - cover * 0.06).toFixed(3) + ')';
				card.style.filter = 'brightness(' + (1 - cover * 0.12).toFixed(3) + ')';
			});
		}
	}
	window.addEventListener('scroll', function () {
		if (!ticking) { ticking = true; requestAnimationFrame(onScrollFrame); }
	}, { passive: true });
	onScrollFrame();

	/* ---------- CTA glow follows the mouse ---------- */
	var glowBox = document.querySelector('[data-glow]');
	if (glowBox && finePointer && !reduceMotion) {
		glowBox.addEventListener('mousemove', function (e) {
			var r = glowBox.getBoundingClientRect();
			glowBox.style.setProperty('--gx', (e.clientX - r.left) + 'px');
			glowBox.style.setProperty('--gy', (e.clientY - r.top) + 'px');
		});
	}

	/* ---------- AI website planner ---------- */
	var ai = document.querySelector('[data-ai]');
	if (ai) {
		var aiForm = ai.querySelector('[data-ai-form]');
		var aiLoading = ai.querySelector('[data-ai-loading]');
		var aiStatus = ai.querySelector('[data-ai-status]');
		var aiResult = ai.querySelector('[data-ai-result]');
		var aiError = ai.querySelector('[data-ai-error]');
		var steps = ['Reading about your business…', 'Picking the sections that win enquiries…', 'Writing your headline…', 'Adding a quick speed tip…'];
		var stepTimer = null;

		var show = function (el, on) { el.hidden = !on; };
		var fill = function (sel, text) { var el = ai.querySelector(sel); el.textContent = text || ''; return el; };

		aiForm.addEventListener('submit', function (e) {
			e.preventDefault();
			var fd = new FormData(aiForm);
			show(aiError, false);
			show(aiForm, false);
			show(aiLoading, true);
			var k = 0;
			aiStatus.textContent = steps[0];
			stepTimer = setInterval(function () { k = (k + 1) % steps.length; aiStatus.textContent = steps[k]; }, 1600);

			fetch(ai.getAttribute('data-endpoint'), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					business: fd.get('business') || '',
					goal: fd.get('goal') || '',
					hp: fd.get('hp') || '',
					nonce: ai.getAttribute('data-nonce')
				})
			}).then(function (res) {
				return res.json().then(function (data) { return { ok: res.ok, data: data }; });
			}).then(function (out) {
				clearInterval(stepTimer);
				show(aiLoading, false);
				if (!out.ok) throw new Error(out.data && out.data.message ? out.data.message : 'The planner could not answer. Try again.');
				var d = out.data;
				var n = 0;
				fill('[data-ai-headline]', d.headline).setAttribute('data-reveal-item', '');
				fill('[data-ai-sub]', d.subheadline).setAttribute('data-reveal-item', '');
				var list = ai.querySelector('[data-ai-sections]');
				list.innerHTML = '';
				(d.sections || []).forEach(function (s) {
					var li = document.createElement('li');
					var wrap = document.createElement('div');
					var strong = document.createElement('strong');
					var span = document.createElement('span');
					strong.textContent = s.name;
					span.textContent = s.why;
					wrap.appendChild(strong); wrap.appendChild(span); li.appendChild(wrap);
					li.setAttribute('data-reveal-item', '');
					list.appendChild(li);
				});
				var feats = ai.querySelector('[data-ai-features]');
				feats.innerHTML = '';
				(d.features || []).forEach(function (f) {
					var li = document.createElement('li');
					li.textContent = f;
					feats.appendChild(li);
				});
				fill('[data-ai-tip]', d.quick_win);
				ai.querySelectorAll('[data-reveal-item]').forEach(function (el) { el.style.setProperty('--k', n++); });

				var summary = 'AI homepage plan for: ' + (fd.get('business') || '') + '\nHeadline: ' + d.headline + '\nSections: ' +
					(d.sections || []).map(function (s) { return s.name; }).join(', ') + '\n\n';
				try { sessionStorage.setItem('vyntic_plan', summary); } catch (err) {}
				show(aiResult, true);
			}).catch(function (err) {
				clearInterval(stepTimer);
				show(aiLoading, false);
				show(aiForm, true);
				aiError.textContent = err.message;
				show(aiError, true);
			});
		});

		ai.querySelector('[data-ai-reset]').addEventListener('click', function () {
			show(aiResult, false);
			show(aiForm, true);
			aiForm.querySelector('textarea').focus();
		});
	}

	/* Prefill the contact form with a plan made by the AI planner */
	var msg = document.querySelector('[data-cform] textarea[name="message"]');
	if (msg && !msg.value) {
		try {
			var plan = sessionStorage.getItem('vyntic_plan');
			if (plan) msg.value = plan + 'More about the project: ';
		} catch (err) {}
	}

	/* Contact form: send in the background, then show the thank-you card */
	document.querySelectorAll('[data-cform]').forEach(function (form) {
		var wrap = form.closest('.cform-wrap');
		var thanks = wrap ? wrap.querySelector('[data-form-thanks]') : null;
		var errorBox = form.querySelector('[data-form-error]');
		var button = form.querySelector('[data-form-submit]');
		if (!thanks || !window.fetch || !window.FormData) return;
		var label = button ? button.textContent : '';
		var swap = function (hide, show) {
			hide.classList.add('is-leaving');
			setTimeout(function () {
				hide.hidden = true;
				hide.classList.remove('is-leaving');
				show.hidden = false;
				show.classList.add('is-entering');
				requestAnimationFrame(function () { requestAnimationFrame(function () { show.classList.remove('is-entering'); }); });
				var top = wrap.getBoundingClientRect().top + window.pageYOffset - 120;
				if (wrap.getBoundingClientRect().top < 80) window.scrollTo({ top: top, behavior: reduceMotion ? 'auto' : 'smooth' });
				if (show === thanks) thanks.focus({ preventScroll: true });
			}, reduceMotion ? 0 : 250);
		};
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (errorBox) errorBox.hidden = true;
			if (button) { button.disabled = true; button.textContent = button.getAttribute('data-sending') || 'Sending…'; }
			var fd = new FormData(form);
			fd.append('_ajax', '1');
			fetch(form.getAttribute('action'), { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (!res || !res.success) throw new Error(res && res.data && res.data.message ? res.data.message : '');
					thanks.querySelector('[data-thanks-title]').textContent = res.data.title;
					thanks.querySelector('[data-thanks-text]').textContent = res.data.text;
					swap(form, thanks);
				})
				.catch(function (err) {
					if (errorBox) {
						errorBox.textContent = err.message || 'Something went wrong. Please try again, or email us directly.';
						errorBox.hidden = false;
					}
				})
				.then(function () {
					if (button) { button.disabled = false; button.textContent = label; }
				});
		});
		var again = thanks.querySelector('[data-form-again]');
		if (again) again.addEventListener('click', function () {
			form.reset();
			swap(thanks, form);
		});
	});

	/* Cookie banner: Essential always on, Analytics and Marketing by choice */
	var cookieBox = document.querySelector('[data-cookie]');
	var cookieReopen = document.querySelector('[data-cookie-reopen]');
	if (cookieBox) {
		var stored = null;
		var saved = { analytics: false, marketing: false };
		try {
			stored = localStorage.getItem('vyntic_consent');
			saved.analytics = stored === 'all' || localStorage.getItem('vyntic_consent_analytics') === '1';
			saved.marketing = stored === 'all' || localStorage.getItem('vyntic_consent_marketing') === '1';
		} catch (e) {}
		window.vynticConsent = saved;
		var switches = cookieBox.querySelectorAll('[data-cookie-cat]');
		var openBanner = function () {
			switches.forEach(function (s) { s.checked = !!saved[s.getAttribute('data-cookie-cat')]; });
			cookieBox.hidden = false;
			if (cookieReopen) cookieReopen.hidden = true;
			requestAnimationFrame(function () { cookieBox.classList.add('is-in'); });
		};
		var choose = function (choice) {
			switches.forEach(function (s) {
				var cat = s.getAttribute('data-cookie-cat');
				saved[cat] = choice === 'all' ? true : (choice === 'essential' ? false : s.checked);
			});
			if (choice === 'custom' && saved.analytics && saved.marketing) choice = 'all';
			if (choice === 'custom' && !saved.analytics && !saved.marketing) choice = 'essential';
			try {
				localStorage.setItem('vyntic_consent', choice);
				localStorage.setItem('vyntic_consent_analytics', saved.analytics ? '1' : '0');
				localStorage.setItem('vyntic_consent_marketing', saved.marketing ? '1' : '0');
				localStorage.setItem('vyntic_consent_date', String(Date.now()));
			} catch (e) {}
			window.vynticConsent = saved;
			if (typeof window.gtag === 'function') {
				var a = saved.analytics ? 'granted' : 'denied';
				var m = saved.marketing ? 'granted' : 'denied';
				window.gtag('consent', 'update', { analytics_storage: a, ad_storage: m, ad_user_data: m, ad_personalization: m });
			}
			document.dispatchEvent(new CustomEvent('vyntic:consent', { detail: choice }));
			cookieBox.classList.remove('is-in');
			setTimeout(function () { cookieBox.hidden = true; if (cookieReopen) cookieReopen.hidden = false; }, 350);
		};
		var expired = false;
		try { expired = Date.now() - parseInt(localStorage.getItem('vyntic_consent_date') || '0', 10) > 31536000000; } catch (e) {}
		if (!stored || expired) { setTimeout(openBanner, 1200); } else if (cookieReopen) { cookieReopen.hidden = false; }
		cookieBox.querySelectorAll('[data-cookie-choice]').forEach(function (b) {
			b.addEventListener('click', function () { choose(b.getAttribute('data-cookie-choice')); });
		});
		if (cookieReopen) cookieReopen.addEventListener('click', openBanner);
	}
})();
