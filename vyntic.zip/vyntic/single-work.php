<?php
/**
 * Single case study (post type: work).
 * Layout: header with scores → screenshot → facts → challenge / what we did →
 * results → editor content → client quote → next project → CTA.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	$vyntic_id  = get_the_ID();
	$vyntic_m   = function ( $key ) use ( $vyntic_id ) {
		return vyntic_work_meta( $key, $vyntic_id );
	};
	$vyntic_before = $vyntic_m( 'project_score_before' );
	$vyntic_after  = $vyntic_m( 'project_score_after' );
	$vyntic_url    = $vyntic_m( 'project_url' );
	$vyntic_result = $vyntic_m( 'project_result' );
	$vyntic_types  = wp_strip_all_tags( (string) get_the_term_list( $vyntic_id, 'project_type', '', ', ' ) );
	$vyntic_facts  = array_filter(
		array(
			__( 'Client', 'vyntic' )     => $vyntic_m( 'project_client' ),
			__( 'Industry', 'vyntic' )   => $vyntic_m( 'project_industry' ),
			__( 'Location', 'vyntic' )   => $vyntic_m( 'project_location' ),
			__( 'Services', 'vyntic' )   => $vyntic_types,
			__( 'Timeline', 'vyntic' )   => $vyntic_m( 'project_timeline' ),
			__( 'Built with', 'vyntic' ) => $vyntic_m( 'project_stack' ),
		)
	);
	$vyntic_metrics = array();
	for ( $vyntic_i = 1; $vyntic_i <= 3; $vyntic_i++ ) {
		$vyntic_val = $vyntic_m( "project_metric_{$vyntic_i}_value" );
		if ( '' !== $vyntic_val ) {
			$vyntic_metrics[] = array( $vyntic_val, $vyntic_m( "project_metric_{$vyntic_i}_label" ) );
		}
	}
	$vyntic_challenge = $vyntic_m( 'project_challenge' );
	$vyntic_solution  = $vyntic_m( 'project_solution' );
	$vyntic_quote     = $vyntic_m( 'project_quote' );
	$vyntic_work_url  = vyntic_template_url( 'page-templates/work.php' );
	?>
	<section class="intro intro--split intro--case">
		<div class="wrap intro__inner">
			<div>
				<?php if ( $vyntic_work_url ) : ?>
					<a class="intro__back" href="<?php echo esc_url( $vyntic_work_url ); ?>"><?php esc_html_e( 'All case studies', 'vyntic' ); ?></a>
				<?php endif; ?>
				<p class="project__meta">
					<?php if ( $vyntic_m( 'project_industry' ) ) : ?><span><?php echo esc_html( $vyntic_m( 'project_industry' ) ); ?></span><?php endif; ?>
					<?php if ( $vyntic_m( 'project_location' ) ) : ?><span><?php echo esc_html( $vyntic_m( 'project_location' ) ); ?></span><?php endif; ?>
				</p>
				<?php vyntic_breadcrumbs(); ?>
				<h1 class="intro__title"><?php the_title(); ?></h1>
				<?php if ( $vyntic_result ) : ?>
					<p class="intro__lead"><?php echo esc_html( $vyntic_result ); ?></p>
				<?php elseif ( has_excerpt() ) : ?>
					<p class="intro__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
				<?php if ( $vyntic_url ) : ?>
					<a class="btn btn--ghost" href="<?php echo esc_url( $vyntic_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Visit the live site', 'vyntic' ); ?></a>
				<?php endif; ?>
			</div>
			<?php if ( '' !== $vyntic_after ) : ?>
				<div class="compare">
					<?php if ( '' !== $vyntic_before ) : ?>
						<div class="compare__item">
							<?php vyntic_score_ring( $vyntic_before, 'sm', sprintf( /* translators: %s score */ __( 'Score before: %s', 'vyntic' ), $vyntic_before ) ); ?>
							<p><?php esc_html_e( 'Before', 'vyntic' ); ?></p>
						</div>
					<?php endif; ?>
					<div class="compare__item">
						<?php vyntic_score_ring( $vyntic_after, 'lg', sprintf( /* translators: %s score */ __( 'Score after: %s', 'vyntic' ), $vyntic_after ) ); ?>
						<p><?php esc_html_e( 'After', 'vyntic' ); ?></p>
					</div>
					<p class="compare__label"><?php esc_html_e( 'Mobile PageSpeed score', 'vyntic' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<div class="wrap">
		<figure class="case-shot browser">
			<span class="browser__bar"><i></i><i></i><i></i></span>
			<?php vyntic_thumb( 'full', 'project-fallback.svg', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?>
		</figure>
	</div>

	<?php if ( $vyntic_facts ) : ?>
		<div class="wrap">
			<dl class="case-facts">
				<?php foreach ( $vyntic_facts as $vyntic_label => $vyntic_value ) : ?>
					<div><dt><?php echo esc_html( $vyntic_label ); ?></dt><dd><?php echo esc_html( $vyntic_value ); ?></dd></div>
				<?php endforeach; ?>
			</dl>
		</div>
	<?php endif; ?>

	<?php if ( $vyntic_challenge || $vyntic_solution ) : ?>
		<section class="section section--tight">
			<div class="wrap case-story">
				<?php if ( $vyntic_challenge ) : ?>
					<div>
						<h2 class="case-story__title"><?php esc_html_e( 'The challenge', 'vyntic' ); ?></h2>
						<?php echo wp_kses_post( wpautop( $vyntic_challenge ) ); ?>
					</div>
				<?php endif; ?>
				<?php if ( $vyntic_solution ) : ?>
					<div>
						<h2 class="case-story__title"><?php esc_html_e( 'What we did', 'vyntic' ); ?></h2>
						<?php echo wp_kses_post( wpautop( $vyntic_solution ) ); ?>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $vyntic_metrics ) : ?>
		<section class="section section--night section--tight" aria-labelledby="results-title">
			<div class="wrap">
				<h2 class="section__title section__title--sm" id="results-title"><?php esc_html_e( 'The results', 'vyntic' ); ?></h2>
				<dl class="metrics">
					<?php foreach ( $vyntic_metrics as $vyntic_metric ) : ?>
						<div class="metric"><dt><?php echo esc_html( $vyntic_metric[1] ); ?></dt><dd><?php echo esc_html( $vyntic_metric[0] ); ?></dd></div>
					<?php endforeach; ?>
				</dl>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( '' !== trim( get_the_content() ) ) : ?>
		<section class="section section--tight">
			<div class="wrap"><div class="prose prose--wide"><?php the_content(); ?></div></div>
		</section>
	<?php endif; ?>

	<?php if ( $vyntic_quote ) : ?>
		<section class="section section--tight">
			<div class="wrap">
				<figure class="quote">
					<blockquote><p><?php echo esc_html( $vyntic_quote ); ?></p></blockquote>
					<?php if ( $vyntic_m( 'project_quote_name' ) ) : ?>
						<figcaption><strong><?php echo esc_html( $vyntic_m( 'project_quote_name' ) ); ?></strong><?php if ( $vyntic_m( 'project_quote_role' ) ) : ?><span><?php echo esc_html( $vyntic_m( 'project_quote_role' ) ); ?></span><?php endif; ?></figcaption>
					<?php endif; ?>
				</figure>
			</div>
		</section>
	<?php endif; ?>

	<?php
	$vyntic_next = get_adjacent_post( false, '', false );
	if ( ! $vyntic_next ) {
		$vyntic_first = get_posts( array( 'post_type' => 'work', 'posts_per_page' => 1, 'post__not_in' => array( $vyntic_id ), 'orderby' => 'date', 'order' => 'ASC' ) );
		$vyntic_next  = $vyntic_first ? $vyntic_first[0] : null;
	}
	if ( $vyntic_next ) :
		?>
		<div class="wrap">
			<a class="next-case" href="<?php echo esc_url( get_permalink( $vyntic_next ) ); ?>">
				<span><?php esc_html_e( 'Next case study', 'vyntic' ); ?></span>
				<strong><?php echo esc_html( get_the_title( $vyntic_next ) ); ?></strong>
			</a>
		</div>
		<?php
	endif;
	$vyntic_keys = vyntic_work_services( get_the_ID() );
	vyntic_landing_cards( $vyntic_keys, __( 'Services behind this project', 'vyntic' ) );
	get_template_part( 'template-parts/work-grid', null, array( 'count' => 2, 'more' => true, 'heading' => __( 'More case studies', 'vyntic' ), 'lead' => '', 'exclude' => get_the_ID() ) );
	vyntic_post_cards( vyntic_landing_posts( $vyntic_keys[0], 3 ), __( 'Guides related to this project', 'vyntic' ) );
	get_template_part( 'template-parts/audit' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
