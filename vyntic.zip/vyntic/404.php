<?php
/**
 * 404 page: friendly message, search and the most useful next steps.
 *
 * @package Vyntic
 */

get_header();
$vyntic_links = array_filter(
	array(
		array( 'code', __( 'Services', 'vyntic' ), __( 'Websites, SEO, AI search and more', 'vyntic' ), vyntic_template_url( 'page-templates/services.php' ) ),
		array( 'target', __( 'Case studies', 'vyntic' ), __( 'Real projects and results', 'vyntic' ), vyntic_template_url( 'page-templates/work.php' ) ),
		array( 'chart', __( 'Blog', 'vyntic' ), __( 'Guides for business owners', 'vyntic' ), get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : '' ),
		array( 'spark', __( 'Free website audit', 'vyntic' ), __( 'See what is holding your site back', 'vyntic' ), vyntic_template_url( 'page-templates/free-audit.php' ) ),
	),
	function ( $l ) {
		return ! empty( $l[3] );
	}
);
$vyntic_posts = get_posts( array( 'numberposts' => 3, 'post_status' => 'publish' ) );
?>
<section class="intro intro--404">
	<div class="wrap intro__inner">
		<div class="e404__rings" aria-hidden="true">
			<span>4</span><?php vyntic_score_ring( 0, 'lg', __( 'Page not found', 'vyntic' ) ); ?><span>4</span>
		</div>
		<h1 class="intro__title"><?php esc_html_e( 'This page took a wrong turn.', 'vyntic' ); ?></h1>
		<p class="intro__lead"><?php esc_html_e( 'The link might be old, or the page may have moved. Try a search, or pick one of the pages below.', 'vyntic' ); ?></p>
		<?php get_search_form(); ?>
		<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the homepage', 'vyntic' ); ?></a>
	</div>
</section>

<?php if ( $vyntic_links ) : ?>
	<section class="section section--tight">
		<div class="wrap">
			<ul class="e404__grid">
				<?php foreach ( $vyntic_links as $vyntic_l ) : ?>
					<li>
						<a class="lp-rel" href="<?php echo esc_url( $vyntic_l[3] ); ?>">
							<span class="lp-rel__icon"><?php echo vyntic_icon( $vyntic_l[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							<span class="lp-rel__name"><?php echo esc_html( $vyntic_l[1] ); ?></span>
							<span class="lp-rel__text"><?php echo esc_html( $vyntic_l[2] ); ?></span>
							<span class="lp-rel__go"><?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ( $vyntic_posts ) : ?>
	<section class="section section--mist">
		<div class="wrap">
			<h2 class="section__title section__title--sm"><?php esc_html_e( 'Popular reading', 'vyntic' ); ?></h2>
			<div class="post-grid">
				<?php
				global $post;
				foreach ( $vyntic_posts as $post ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride
					setup_postdata( $post );
					get_template_part( 'template-parts/post-card' );
				endforeach;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
<?php endif; ?>
<?php
get_footer();
