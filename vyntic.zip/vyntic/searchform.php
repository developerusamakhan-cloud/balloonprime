<?php
/**
 * Search form.
 *
 * @package Vyntic
 */

$vyntic_uid = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $vyntic_uid ); ?>"><?php esc_html_e( 'Search the site', 'vyntic' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $vyntic_uid ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search articles', 'vyntic' ); ?>">
	<button class="btn btn--primary" type="submit"><?php esc_html_e( 'Search', 'vyntic' ); ?></button>
</form>
