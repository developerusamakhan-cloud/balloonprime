<?php
/**
 * Project inquiry form: services and budget as tap-friendly chips.
 * Fields, options and the thank-you message come from Inquiries → Settings.
 * JavaScript sends the form in the background and shows the thank-you card; without
 * JavaScript the page reloads and shows the same card.
 *
 * @package Vyntic
 */

$vyntic_notice   = vyntic_form_notice();
$vyntic_sent     = $vyntic_notice && 'success' === $vyntic_notice['type'];
$vyntic_back     = get_permalink() ? get_permalink() : home_url( '/' );
$vyntic_budgets  = vyntic_form_lines( 'budgets' );
$vyntic_timeline = vyntic_form_lines( 'timelines' );
$vyntic_uid      = wp_unique_id( 'cf-' );
$vyntic_plan     = isset( $_GET['plan'] ) ? sanitize_text_field( wp_unslash( $_GET['plan'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
/* translators: %s package or plan name */
$vyntic_prefill  = $vyntic_plan ? sprintf( __( 'I am interested in the %s package.', 'vyntic' ), $vyntic_plan ) . "\n\n" : '';
$vyntic_show     = function ( $key ) {
	return (bool) vyntic_form_setting( 'show_' . $key );
};
?>
<div class="cform-wrap" id="contact-form">
<div class="cform-thanks" data-form-thanks tabindex="-1" <?php echo $vyntic_sent ? '' : 'hidden'; ?>>
	<div class="cform-thanks__badge" aria-hidden="true">
		<svg viewBox="0 0 52 52"><circle class="cform-thanks__circle" cx="26" cy="26" r="24"/><path class="cform-thanks__tick" d="M15 27l7 7 15-16"/></svg>
	</div>
	<h3 class="cform-thanks__title" data-thanks-title><?php echo esc_html( vyntic_form_personalise( vyntic_form_setting( 'thanks_title' ) ) ); ?></h3>
	<p class="cform-thanks__text" data-thanks-text><?php echo esc_html( vyntic_form_personalise( vyntic_form_setting( 'thanks_text' ) ) ); ?></p>
	<ol class="cform-thanks__steps">
		<li><span>1</span><?php esc_html_e( 'We read your message and look at your current site.', 'vyntic' ); ?></li>
		<li><span>2</span><?php esc_html_e( 'You get a reply within one business day, usually with a few first ideas.', 'vyntic' ); ?></li>
		<li><span>3</span><?php esc_html_e( 'If it is a good fit, we book a short call at a time that suits you.', 'vyntic' ); ?></li>
	</ol>
	<button type="button" class="btn btn--ghost" data-form-again><?php esc_html_e( 'Send another message', 'vyntic' ); ?></button>
</div>

<form class="form cform" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cform novalidate <?php echo $vyntic_sent ? 'hidden' : ''; ?>>
	<p class="notice notice--error" data-form-error role="alert" hidden></p>
	<?php if ( $vyntic_notice && ! $vyntic_sent ) : ?>
		<p class="notice notice--<?php echo esc_attr( $vyntic_notice['type'] ); ?>" role="<?php echo 'error' === $vyntic_notice['type'] ? 'alert' : 'status'; ?>"><?php echo esc_html( $vyntic_notice['text'] ); ?></p>
	<?php endif; ?>

	<input type="hidden" name="action" value="vyntic_contact">
	<input type="hidden" name="_back" value="<?php echo esc_url( $vyntic_back ); ?>">
	<?php wp_nonce_field( 'vyntic_contact', 'vyntic_contact_nonce' ); ?>
	<div class="form__hp" aria-hidden="true"><label for="<?php echo esc_attr( $vyntic_uid ); ?>-hp">Leave this empty</label><input type="text" id="<?php echo esc_attr( $vyntic_uid ); ?>-hp" name="vf_extra_note" tabindex="-1" autocomplete="off" data-lpignore="true" data-1p-ignore="true" data-bwignore="true" data-form-type="other"></div>

	<?php if ( $vyntic_show( 'services' ) ) : ?>
	<fieldset class="cform__group">
		<legend><?php esc_html_e( 'What can we help with?', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'pick any', 'vyntic' ); ?></span></legend>
		<div class="chips">
			<?php foreach ( vyntic_services() as $vyntic_service ) : ?>
				<label class="pick"><input type="checkbox" name="services[]" value="<?php echo esc_attr( $vyntic_service['title'] ); ?>"><span><?php echo esc_html( $vyntic_service['title'] ); ?></span></label>
			<?php endforeach; ?>
		</div>
	</fieldset>
	<?php endif; ?>

	<div class="form__row">
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-name"><?php esc_html_e( 'Your name', 'vyntic' ); ?></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-name" name="name" type="text" autocomplete="name" required>
		</div>
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-email"><?php esc_html_e( 'Work email', 'vyntic' ); ?></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-email" name="email" type="email" autocomplete="email" required>
		</div>
	</div>

	<?php if ( $vyntic_show( 'phone' ) || $vyntic_show( 'website' ) ) : ?>
	<div class="form__row">
		<?php if ( $vyntic_show( 'phone' ) ) : ?>
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-phone"><?php esc_html_e( 'Phone or WhatsApp', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'optional', 'vyntic' ); ?></span></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-phone" name="phone" type="tel" autocomplete="tel">
		</div>
		<?php endif; ?>
		<?php if ( $vyntic_show( 'website' ) ) : ?>
		<div class="field">
			<label for="<?php echo esc_attr( $vyntic_uid ); ?>-site"><?php esc_html_e( 'Current website', 'vyntic' ); ?> <span class="field__opt"><?php esc_html_e( 'optional', 'vyntic' ); ?></span></label>
			<input id="<?php echo esc_attr( $vyntic_uid ); ?>-site" name="website" type="text" inputmode="url" placeholder="yourbusiness.com">
		</div>
		<?php endif; ?>
	</div>
	<?php endif; ?>

	<?php if ( $vyntic_show( 'budget' ) && $vyntic_budgets ) : ?>
	<fieldset class="cform__group">
		<legend><?php esc_html_e( 'Budget', 'vyntic' ); ?></legend>
		<div class="chips">
			<?php foreach ( $vyntic_budgets as $vyntic_i => $vyntic_budget ) : ?>
				<label class="pick"><input type="radio" name="budget" value="<?php echo esc_attr( $vyntic_budget ); ?>" <?php checked( count( $vyntic_budgets ) - 1, $vyntic_i ); ?>><span><?php echo esc_html( $vyntic_budget ); ?></span></label>
			<?php endforeach; ?>
		</div>
	</fieldset>
	<?php endif; ?>

	<?php if ( $vyntic_show( 'timeline' ) && $vyntic_timeline ) : ?>
	<div class="field">
		<label for="<?php echo esc_attr( $vyntic_uid ); ?>-time"><?php esc_html_e( 'When do you want to launch?', 'vyntic' ); ?></label>
		<select id="<?php echo esc_attr( $vyntic_uid ); ?>-time" name="timeline">
			<?php foreach ( $vyntic_timeline as $vyntic_t ) : ?>
				<option><?php echo esc_html( $vyntic_t ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<?php endif; ?>

	<div class="field">
		<label for="<?php echo esc_attr( $vyntic_uid ); ?>-message"><?php esc_html_e( 'Tell us about the project', 'vyntic' ); ?></label>
		<textarea id="<?php echo esc_attr( $vyntic_uid ); ?>-message" name="message" rows="5" required placeholder="<?php esc_attr_e( 'What you sell, what is not working today, and anything you already know you need.', 'vyntic' ); ?>"><?php echo esc_textarea( $vyntic_prefill ); ?></textarea>
	</div>

	<label class="cform__consent"><input type="checkbox" name="consent" value="1" required><span><?php esc_html_e( 'I agree that Vyntic Studio can use these details to reply to my inquiry.', 'vyntic' ); ?></span></label>

	<div class="cform__submit">
		<button class="btn btn--primary btn--lg" type="submit" data-form-submit data-sending="<?php esc_attr_e( 'Sending…', 'vyntic' ); ?>"><?php echo esc_html( vyntic_form_setting( 'button_label' ) ? vyntic_form_setting( 'button_label' ) : __( 'Send inquiry', 'vyntic' ) ); ?></button>
		<p class="form__note"><?php esc_html_e( 'We reply within 24 hours on business days.', 'vyntic' ); ?></p>
	</div>
</form>
</div>
