<?php
/**
 * Template Name: Home
 *
 * The page's editor content is NOT shown on this template, so leftover
 * content from an old theme or page builder can't break the layout.
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/hero' );
	get_template_part( 'template-parts/showcase' );
	get_template_part( 'template-parts/marquee' );
	get_template_part( 'template-parts/statement' );
	get_template_part( 'template-parts/services-list' );
	get_template_part( 'template-parts/ai-planner' );
	get_template_part( 'template-parts/problems' );
	get_template_part( 'template-parts/stats' );
	get_template_part( 'template-parts/work-showcase' );
	get_template_part( 'template-parts/industries' );
	get_template_part( 'template-parts/audit' );
	get_template_part( 'template-parts/platforms' );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/blog-latest' );
	get_template_part( 'template-parts/pricing' );
	get_template_part( 'template-parts/faq' );
	get_template_part( 'template-parts/map' );
	get_template_part( 'template-parts/contact-section' );
endwhile;
get_footer();
