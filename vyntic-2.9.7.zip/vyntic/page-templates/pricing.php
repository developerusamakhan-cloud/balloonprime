<?php
/**
 * Template Name: Care plans
 *
 * Monthly maintenance plans. Edit plans and prices in inc/content.php → vyntic_plans().
 *
 * @package Vyntic
 */

get_header();
while ( have_posts() ) :
	the_post();
	vyntic_page_intro( '', has_excerpt() ? '' : __( 'Updates, backups, monitoring and speed checks, done by the team that built your site. Cancel any month.', 'vyntic' ) );
	get_template_part( 'template-parts/pricing', null, array( 'tab' => 'care', 'heading' => __( 'Plans and pricing', 'vyntic' ), 'lead' => __( 'Monthly care for your website, plus starting prices for new builds. Cancel any month.', 'vyntic' ) ) );
	vyntic_render_article( vyntic_current_article_key(), __( 'About care plans', 'vyntic' ) );
	get_template_part( 'template-parts/process-stack' );
	get_template_part( 'template-parts/reviews' );
	get_template_part( 'template-parts/faq' );
endwhile;
get_footer();
