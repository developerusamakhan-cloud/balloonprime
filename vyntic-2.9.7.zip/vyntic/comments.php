<?php
/**
 * Comments on blog posts: the list and the reply form.
 *
 * @package Vyntic
 */

if ( post_password_required() ) {
	return;
}
?>
<section class="comments" id="comments" aria-labelledby="comments-title">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments__title" id="comments-title">
			<?php
			$vyntic_count = get_comments_number();
			/* translators: %s number of comments */
			echo esc_html( sprintf( _n( '%s comment', '%s comments', $vyntic_count, 'vyntic' ), number_format_i18n( $vyntic_count ) ) );
			?>
		</h2>
		<ol class="comments__list">
			<?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 44 ) ); ?>
		</ol>
		<?php the_comments_navigation(); ?>
	<?php else : ?>
		<h2 class="screen-reader-text" id="comments-title"><?php esc_html_e( 'Comments', 'vyntic' ); ?></h2>
	<?php endif; ?>

	<?php if ( comments_open() ) : ?>
		<?php comment_form( array( 'class_submit' => 'btn btn--primary', 'title_reply_before' => '<h2 class="comments__title">', 'title_reply_after' => '</h2>' ) ); ?>
	<?php else : ?>
		<p class="comments__closed"><?php esc_html_e( 'Comments are closed.', 'vyntic' ); ?></p>
	<?php endif; ?>
</section>
