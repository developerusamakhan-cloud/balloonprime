<?php
/**
 * Site footer: CTA with free audit, brand row, six link columns in one row
 * (Services, Platforms, Industries, Locations, Resources, Company),
 * giant wordmark and bottom bar with copyright and legal links.
 *
 * @package Vyntic
 */

$vyntic_minimal = is_page_template( 'page-templates/landing.php' );
$vyntic_email   = vyntic_mod( 'email' );
$vyntic_audit   = vyntic_template_url( 'page-templates/free-audit.php' );
$vyntic_audit   = $vyntic_audit ? $vyntic_audit : home_url( '/#free-audit' );
$vyntic_social  = array_filter(
	array(
		'LinkedIn'  => vyntic_mod( 'linkedin' ),
		'Instagram' => vyntic_mod( 'instagram' ),
	)
);

/* Quick links: the Footer menu if set, otherwise the main pages. */
$vyntic_quick = array_filter(
	array(
		__( 'About', 'vyntic' )        => vyntic_template_url( 'page-templates/about.php' ),
		__( 'Services', 'vyntic' )     => vyntic_template_url( 'page-templates/services.php' ),
		__( 'Case studies', 'vyntic' ) => vyntic_template_url( 'page-templates/work.php' ),
		__( 'Care plans', 'vyntic' )   => vyntic_template_url( 'page-templates/pricing.php' ),
		__( 'Blog', 'vyntic' )         => get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : '',
		__( 'Free audit', 'vyntic' )   => $vyntic_audit,
		__( 'Contact', 'vyntic' )      => vyntic_template_url( 'page-templates/contact.php' ),
	)
);

/* Legal: privacy policy plus pages with these slugs, if they exist, and the XML sitemap. */
$vyntic_legal = array_filter(
	array(
		__( 'Privacy policy', 'vyntic' )   => vyntic_privacy_url(),
		__( 'Cookie policy', 'vyntic' )    => vyntic_page_url( 'cookie-policy' ),
		__( 'Terms of service', 'vyntic' ) => vyntic_page_url( 'terms' ) ? vyntic_page_url( 'terms' ) : vyntic_page_url( 'terms-of-service' ),
		__( 'Refund policy', 'vyntic' )    => vyntic_page_url( 'refund-policy' ),
		__( 'Sitemap', 'vyntic' )          => vyntic_sitemap_url(),
	)
);

$vyntic_locations = $vyntic_minimal ? array() : vyntic_location_pages( 8 );
$vyntic_loc_index = vyntic_template_url( 'page-templates/locations.php' );
?>
</main>

<footer class="site-footer">
	<?php if ( ! $vyntic_minimal ) : ?>
		<div class="wrap footer-cta">
			<div>
				<p class="footer-cta__title"><?php esc_html_e( 'Have a project in mind?', 'vyntic' ); ?></p>
				<?php if ( $vyntic_email ) : ?>
					<a class="footer-cta__mail" href="mailto:<?php echo esc_attr( antispambot( $vyntic_email ) ); ?>" data-cursor="<?php esc_attr_e( 'Email', 'vyntic' ); ?>"><?php echo esc_html( antispambot( $vyntic_email ) ); ?></a>
				<?php endif; ?>
			</div>
			<div class="footer-cta__actions">
				<a class="btn btn--primary btn--lg" href="<?php echo esc_url( vyntic_cta_url() ); ?>"><?php echo esc_html( vyntic_mod( 'cta_label' ) ); ?></a>
				<a class="btn btn--ghost-light btn--lg" href="<?php echo esc_url( $vyntic_audit ); ?>"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Get a free audit', 'vyntic' ); ?></a>
			</div>
		</div>

		<div class="wrap footer-brand">
			<a class="footer-brand__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php bloginfo( 'name' ); ?>">
				<img src="<?php echo esc_url( vyntic_img( 'brand/logo-light.svg' ) ); ?>" alt="<?php bloginfo( 'name' ); ?>" width="339" height="124" loading="lazy">
			</a>
			<p><?php echo esc_html( vyntic_mod( 'footer_text' ) ); ?></p>
			<?php if ( $vyntic_social ) : ?>
				<ul class="footer-social">
					<?php foreach ( $vyntic_social as $vyntic_label => $vyntic_link ) : ?>
						<li><a href="<?php echo esc_url( $vyntic_link ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $vyntic_label ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div class="wrap footer-grid">
			<?php foreach ( vyntic_footer_columns() as $vyntic_title => $vyntic_links ) : ?>
				<div class="footer-col">
					<h2 class="footer-col__title"><?php echo esc_html( $vyntic_title ); ?></h2>
					<ul>
						<?php foreach ( $vyntic_links as $vyntic_label => $vyntic_link ) : ?>
							<li><a href="<?php echo esc_url( $vyntic_link ); ?>"><?php echo esc_html( $vyntic_label ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="footer-word" aria-hidden="true"><span><?php bloginfo( 'name' ); ?></span></div>
	<?php endif; ?>

	<div class="wrap footer-bottom">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'vyntic' ); ?></p>
		<?php if ( $vyntic_legal ) : ?>
			<ul class="footer-legal">
				<?php foreach ( $vyntic_legal as $vyntic_label => $vyntic_link ) : ?>
					<li><a href="<?php echo esc_url( $vyntic_link ); ?>"><?php echo esc_html( $vyntic_label ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<a class="footer-top" href="#main"><?php esc_html_e( 'Back to top', 'vyntic' ); ?></a>
	</div>
</footer>

<?php get_template_part( 'template-parts/audit-popup' ); ?>
<?php get_template_part( 'template-parts/cookie' ); ?>
<?php wp_footer(); ?>
</body>
</html>
