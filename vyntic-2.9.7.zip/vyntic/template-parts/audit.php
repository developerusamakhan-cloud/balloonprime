<?php
/**
 * Free audit section. Uses, in order: your own embed from Customize → Vyntic options → Free audit,
 * the Vyntic Site Audit plugin form when it is active, or the built-in request form.
 * Args: heading_level (h1|h2).
 *
 * @package Vyntic
 */

$vyntic_tag    = ( isset( $args['heading_level'] ) && 'h1' === $args['heading_level'] ) ? 'h1' : 'h2';
$vyntic_embed  = trim( (string) get_theme_mod( 'vyntic_audit_embed', '' ) );
$vyntic_notice = vyntic_audit_notice();
?>
<section class="audit" id="free-audit" aria-labelledby="audit-title">
	<div class="wrap audit__inner">
		<div class="audit__copy">
			<<?php echo esc_attr( $vyntic_tag ); ?> class="audit__title" id="audit-title"><?php echo esc_html( vyntic_mod( 'audit_title' ) ); ?></<?php echo esc_attr( $vyntic_tag ); ?>>
			<p class="audit__text"><?php echo esc_html( vyntic_mod( 'audit_text' ) ); ?></p>
			<?php $vyntic_points = vyntic_audit_points(); ?>
			<?php if ( $vyntic_points ) : ?>
				<ul class="audit__points">
					<?php foreach ( $vyntic_points as $vyntic_point ) : ?>
						<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $vyntic_point ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div class="audit__tool">
			<?php if ( $vyntic_embed ) : ?>
				<div class="audit__embed">
					<?php echo do_shortcode( $vyntic_embed ); // phpcs:ignore WordPress.Security.EscapeOutput -- admin-provided embed. ?>
				</div>
			<?php elseif ( shortcode_exists( 'vyntic_audit' ) ) : ?>
				<div class="audit__embed audit__embed--tool">
					<?php echo do_shortcode( '[vyntic_audit title="" subtitle="" button="' . esc_attr__( 'Get my free audit', 'vyntic' ) . '"]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- plugin output. ?>
				</div>
			<?php else : ?>
				<?php $vyntic_cap = vyntic_captcha(); ?>
				<form class="form audit__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php if ( $vyntic_notice ) : ?>
						<p class="notice notice--<?php echo esc_attr( $vyntic_notice['type'] ); ?>" role="<?php echo 'error' === $vyntic_notice['type'] ? 'alert' : 'status'; ?>"><?php echo esc_html( $vyntic_notice['text'] ); ?></p>
					<?php endif; ?>
					<input type="hidden" name="action" value="vyntic_audit">
					<input type="hidden" name="_back" value="<?php echo esc_url( get_permalink() ? get_permalink() : home_url( '/' ) ); ?>">
					<?php wp_nonce_field( 'vyntic_audit', 'vyntic_audit_nonce' ); ?>
					<div class="form__hp" aria-hidden="true"><label for="audit-hp">Leave this empty</label><input type="text" id="audit-hp" name="vf_extra_note" tabindex="-1" autocomplete="off" data-lpignore="true" data-1p-ignore="true" data-bwignore="true" data-form-type="other"></div>
					<div class="field">
						<label for="audit-site"><?php esc_html_e( 'Your website', 'vyntic' ); ?></label>
						<input id="audit-site" name="site" type="url" inputmode="url" placeholder="https://yourbusiness.com" required>
					</div>
					<div class="field">
						<label for="audit-email"><?php esc_html_e( 'Where should we send the report?', 'vyntic' ); ?></label>
						<input id="audit-email" name="email" type="email" autocomplete="email" placeholder="you@company.com" required>
					</div>
					<div class="field">
						<label for="audit-captcha"><?php echo esc_html( $vyntic_cap['question'] ); ?></label>
						<input id="audit-captcha" name="captcha" type="text" inputmode="numeric" autocomplete="off" maxlength="3" required>
						<input type="hidden" name="captcha_token" value="<?php echo esc_attr( $vyntic_cap['token'] ); ?>">
					</div>
					<button class="btn btn--primary btn--lg" type="submit"><?php esc_html_e( 'Get my free audit', 'vyntic' ); ?></button>
				</form>
			<?php endif; ?>
			<p class="audit__note"><?php echo esc_html( vyntic_mod( 'audit_note' ) ); ?></p>
		</div>
	</div>
</section>
