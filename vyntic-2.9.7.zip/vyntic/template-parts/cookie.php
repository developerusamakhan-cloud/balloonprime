<?php
/**
 * Cookie consent panel with Essential (always on), Analytics and Marketing choices.
 * Choices are stored in the browser for 12 months. Analytics and Marketing start off.
 * Fires a "vyntic:consent" event (detail: all, essential or custom; window.vynticConsent holds
 * { analytics, marketing }) and updates Google Consent Mode when gtag is present.
 *
 * @package Vyntic
 */

$vyntic_policy = vyntic_page_url( 'cookie-policy' );
$vyntic_policy = $vyntic_policy ? $vyntic_policy : vyntic_privacy_url();
?>
<div class="cookie" data-cookie hidden role="dialog" aria-live="polite" aria-labelledby="cookie-title" aria-describedby="cookie-text">
	<div class="cookie__head">
		<div class="cookie__icon" aria-hidden="true">
			<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="19" fill="#e9b949"/><path d="M24 5a19 19 0 1 0 19 19 6 6 0 0 1-7-6 6 6 0 0 1-6-7 6 6 0 0 1-6-6z" fill="#d49a2e"/><circle cx="17" cy="19" r="2.6" fill="#6b3e1f"/><circle cx="27" cy="30" r="3" fill="#6b3e1f"/><circle cx="16" cy="31" r="2" fill="#6b3e1f"/><circle cx="31" cy="21" r="1.8" fill="#6b3e1f"/></svg>
		</div>
		<div>
			<p class="cookie__title" id="cookie-title"><?php esc_html_e( 'A few cookies, if that is okay?', 'vyntic' ); ?></p>
			<p class="cookie__text" id="cookie-text">
				<?php esc_html_e( 'We use cookies to keep this site running smoothly and, with your okay, to see which pages help people most. You choose what is on.', 'vyntic' ); ?>
				<?php if ( $vyntic_policy ) : ?>
					<a href="<?php echo esc_url( $vyntic_policy ); ?>"><?php esc_html_e( 'Cookie policy', 'vyntic' ); ?></a>
				<?php endif; ?>
			</p>
		</div>
	</div>

	<ul class="cookie__options">
		<li class="cookie__option">
			<div>
				<p class="cookie__name"><?php esc_html_e( 'Essential', 'vyntic' ); ?></p>
				<p class="cookie__desc"><?php esc_html_e( 'Keep the site, forms and your choices working.', 'vyntic' ); ?></p>
			</div>
			<span class="cookie__always"><?php esc_html_e( 'Always on', 'vyntic' ); ?></span>
		</li>
		<li class="cookie__option">
			<label for="cookie-analytics">
				<span class="cookie__name"><?php esc_html_e( 'Analytics', 'vyntic' ); ?></span>
				<span class="cookie__desc"><?php esc_html_e( 'Anonymous stats that show which pages help people most.', 'vyntic' ); ?></span>
			</label>
			<input class="cookie__switch" type="checkbox" role="switch" id="cookie-analytics" data-cookie-cat="analytics">
		</li>
		<li class="cookie__option">
			<label for="cookie-marketing">
				<span class="cookie__name"><?php esc_html_e( 'Marketing', 'vyntic' ); ?></span>
				<span class="cookie__desc"><?php esc_html_e( 'Measure ads and show more relevant offers.', 'vyntic' ); ?></span>
			</label>
			<input class="cookie__switch" type="checkbox" role="switch" id="cookie-marketing" data-cookie-cat="marketing">
		</li>
	</ul>

	<div class="cookie__actions">
		<button type="button" class="cookie__btn cookie__btn--primary" data-cookie-choice="all"><?php esc_html_e( 'Accept all', 'vyntic' ); ?></button>
		<button type="button" class="cookie__btn" data-cookie-choice="essential"><?php esc_html_e( 'Essential only', 'vyntic' ); ?></button>
		<button type="button" class="cookie__btn" data-cookie-choice="custom"><?php esc_html_e( 'Save choices', 'vyntic' ); ?></button>
	</div>
</div>
<button type="button" class="cookie-reopen" data-cookie-reopen hidden aria-label="<?php esc_attr_e( 'Cookie settings', 'vyntic' ); ?>">
	<svg viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="19" fill="#e9b949"/><circle cx="17" cy="19" r="2.6" fill="#6b3e1f"/><circle cx="27" cy="30" r="3" fill="#6b3e1f"/><circle cx="31" cy="21" r="1.8" fill="#6b3e1f"/></svg>
</button>
