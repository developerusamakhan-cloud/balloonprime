<?php
/**
 * FAQ using native details/summary, so it works without JavaScript.
 * Questions come from inc/data/faq.json for the current page (or the "key" argument),
 * falling back to the general questions in vyntic_faq().
 *
 * Args: key (string), title (string).
 *
 * @package Vyntic
 */

$vyntic_key   = isset( $args['key'] ) ? $args['key'] : vyntic_page_key();
$vyntic_page  = vyntic_page_faq( $vyntic_key );
$vyntic_title = isset( $args['title'] ) ? $args['title'] : ( $vyntic_page ? $vyntic_page['title'] : __( 'Questions clients ask first', 'vyntic' ) );
$vyntic_items = array();
if ( $vyntic_page ) {
	foreach ( $vyntic_page['items'] as $vyntic_q ) {
		$vyntic_items[] = array( 'q' => $vyntic_q[0], 'a' => $vyntic_q[1] );
	}
} else {
	$vyntic_items = vyntic_faq();
}
$vyntic_id = 'faq-title-' . sanitize_html_class( $vyntic_key ? $vyntic_key : 'general' );
?>
<section class="section" aria-labelledby="<?php echo esc_attr( $vyntic_id ); ?>">
	<div class="wrap faq">
		<h2 class="section__title" id="<?php echo esc_attr( $vyntic_id ); ?>"><?php echo esc_html( $vyntic_title ); ?></h2>
		<div class="faq__list">
			<?php foreach ( $vyntic_items as $vyntic_item ) : ?>
				<details class="faq__item">
					<summary><?php echo esc_html( $vyntic_item['q'] ); ?><span class="faq__icon"><?php echo vyntic_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></summary>
					<p><?php echo esc_html( $vyntic_item['a'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map( function ( $item ) { return array( '@type' => 'Question', 'name' => $item['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $item['a'] ) ); }, $vyntic_items ) ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?></script>
