<?php
/**
 * Free audit popup. Opens once the visitor has scrolled part of the page
 * (Customize → Vyntic options → Audit popup). Closing it hides it for a set
 * number of hours. The form sends the visitor to the Free audit page with
 * their website filled in.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vyntic_audit_url = vyntic_template_url( 'page-templates/free-audit.php' );
if ( ! vyntic_mod( 'popup_on' ) || ! $vyntic_audit_url || is_page_template( 'page-templates/free-audit.php' ) || is_page_template( 'page-templates/landing.php' ) || is_404() ) {
	return;
}
$vyntic_popup_wa = preg_replace( '/\D+/', '', (string) vyntic_mod( 'whatsapp' ) );
$vyntic_bars     = array(
	__( 'Speed', 'vyntic' )    => 44,
	__( 'SEO', 'vyntic' )      => 71,
	__( 'Mobile', 'vyntic' )   => 82,
	__( 'Vitals', 'vyntic' )   => 58,
);
?>
<div class="apop" data-apop data-apop-scroll="<?php echo esc_attr( max( 0, min( 100, (int) vyntic_mod( 'popup_scroll' ) ) ) ); ?>" data-apop-hours="<?php echo esc_attr( max( 1, (int) vyntic_mod( 'popup_hours' ) ) ); ?>" hidden>
	<div class="apop__backdrop" data-apop-close></div>
	<div class="apop__dialog" role="dialog" aria-modal="true" aria-labelledby="apop-title" aria-describedby="apop-text" data-lenis-prevent>
		<button type="button" class="apop__close" data-apop-close aria-label="<?php esc_attr_e( 'Close', 'vyntic' ); ?>"><?php echo vyntic_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>

		<div class="apop__art" aria-hidden="true">
			<div class="apop__ring">
				<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" class="apop__ring-track"/><circle cx="60" cy="60" r="50" class="apop__ring-bar" pathLength="100"/></svg>
				<span class="apop__ring-q">?</span>
				<span class="apop__ring-of">/100</span>
			</div>
			<ul class="apop__bars">
				<?php foreach ( $vyntic_bars as $vyntic_label => $vyntic_val ) : ?>
					<li><span><?php echo esc_html( $vyntic_label ); ?></span><i><b style="--w:<?php echo esc_attr( $vyntic_val ); ?>%"></b></i></li>
				<?php endforeach; ?>
			</ul>
			<p class="apop__pill"><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'PDF report with every fix', 'vyntic' ); ?></p>
		</div>

		<div class="apop__body">
			<p class="apop__badge"><?php echo vyntic_icon( 'spark' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Free website audit', 'vyntic' ); ?></p>
			<h2 class="apop__title" id="apop-title"><?php echo esc_html( vyntic_mod( 'popup_title' ) ); ?></h2>
			<p class="apop__text" id="apop-text"><?php echo esc_html( vyntic_mod( 'popup_text' ) ); ?></p>

			<form class="apop__form" action="<?php echo esc_url( $vyntic_audit_url ); ?>" method="get" data-apop-form>
				<label class="screen-reader-text" for="apop-site"><?php esc_html_e( 'Your website address', 'vyntic' ); ?></label>
				<div class="apop__field">
					<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><rect x="2.5" y="3.5" width="15" height="13" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M2.5 7.5h15M7.5 7.5v9" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>
					<input id="apop-site" name="site" type="text" inputmode="url" autocomplete="url" placeholder="yourwebsite.com" required>
				</div>
				<button type="submit" class="apop__btn"><?php esc_html_e( 'Check my website', 'vyntic' ); ?> <?php echo vyntic_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
			</form>

			<ul class="apop__ticks">
				<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( '100% free', 'vyntic' ); ?></li>
				<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'No sign up', 'vyntic' ); ?></li>
				<li><?php echo vyntic_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Results in 60 seconds', 'vyntic' ); ?></li>
			</ul>

			<?php if ( $vyntic_popup_wa ) : ?>
				<p class="apop__human"><?php esc_html_e( 'Rather talk to a human?', 'vyntic' ); ?> <a href="<?php echo esc_url( 'https://wa.me/' . $vyntic_popup_wa ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Message us on WhatsApp', 'vyntic' ); ?></a></p>
			<?php else : ?>
				<p class="apop__human"><?php esc_html_e( 'Rather talk to a human?', 'vyntic' ); ?> <a href="<?php echo esc_url( vyntic_template_url( 'page-templates/contact.php' ) ? vyntic_template_url( 'page-templates/contact.php' ) : home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Send us a message', 'vyntic' ); ?></a></p>
			<?php endif; ?>
		</div>
	</div>
</div>
