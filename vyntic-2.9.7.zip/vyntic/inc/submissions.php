<?php
/**
 * Form submissions and settings.
 *
 * Every contact and audit form entry is saved under Inquiries in the dashboard.
 * Inquiries → Settings controls the notification email, which fields the contact form
 * shows, the budget and timeline options, the thank-you message and an optional auto-reply.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Form settings with defaults. */
function vyntic_form_settings() {
	$defaults = array(
		'notify'            => 1,
		'notify_to'         => '',
		'save'              => 1,
		'retention'         => 0,
		'button_label'      => __( 'Send inquiry', 'vyntic' ),
		'show_services'     => 1,
		'show_phone'        => 1,
		'show_website'      => 1,
		'show_budget'       => 1,
		'show_timeline'     => 1,
		'budgets'           => implode( "\n", array( __( 'Under $3k', 'vyntic' ), __( '$3k to $7.5k', 'vyntic' ), __( '$7.5k to $15k', 'vyntic' ), __( '$15k+', 'vyntic' ), __( 'Not sure yet', 'vyntic' ) ) ),
		'timelines'         => implode( "\n", array( __( 'As soon as possible', 'vyntic' ), __( 'In 1 to 3 months', 'vyntic' ), __( 'In 3 to 6 months', 'vyntic' ), __( 'Just exploring', 'vyntic' ) ) ),
		'thanks_title'      => __( 'Thank you, {name}!', 'vyntic' ),
		'thanks_text'       => __( 'Your message is on its way. We read every inquiry ourselves and will reply within one business day.', 'vyntic' ),
		'autoreply'         => 0,
		'autoreply_subject' => __( 'Thanks for getting in touch', 'vyntic' ),
		'autoreply_body'    => __( "Hi {name},\n\nThanks for your message. We have received it and will reply within one business day.\n\nBest wishes,\nVyntic Studio", 'vyntic' ),
	);
	return wp_parse_args( (array) get_option( 'vyntic_forms', array() ), $defaults );
}

/** One setting value. */
function vyntic_form_setting( $key ) {
	$s = vyntic_form_settings();
	return isset( $s[ $key ] ) ? $s[ $key ] : '';
}

/** Lines of a textarea setting as a clean list. */
function vyntic_form_lines( $key ) {
	return array_values( array_filter( array_map( 'trim', explode( "\n", (string) vyntic_form_setting( $key ) ) ) ) );
}

/** Where notification emails go. */
function vyntic_form_recipient() {
	$to = trim( (string) vyntic_form_setting( 'notify_to' ) );
	if ( ! $to ) {
		$to = vyntic_mod( 'form_to' ) ? vyntic_mod( 'form_to' ) : vyntic_mod( 'email' );
	}
	$list = array_filter( array_map( 'trim', explode( ',', $to ) ), 'is_email' );
	return $list ? $list : array( get_option( 'admin_email' ) );
}

/** Replace {name} in a message; drops it neatly when the name is unknown. */
function vyntic_form_personalise( $text, $name = '' ) {
	$first = $name ? trim( strtok( $name, ' ' ) ) : '';
	if ( '' === $first ) {
		$text = preg_replace( '/[,\s]*\{name\}/', '', $text );
	}
	return str_replace( '{name}', $first, $text );
}

/*
 * Post type.
 */
add_action( 'init', function () {
	register_post_type(
		'vyntic_inquiry',
		array(
			'labels'          => array(
				'name'               => __( 'Inquiries', 'vyntic' ),
				'singular_name'      => __( 'Inquiry', 'vyntic' ),
				'menu_name'          => __( 'Inquiries', 'vyntic' ),
				'all_items'          => __( 'Submissions', 'vyntic' ),
				'edit_item'          => __( 'Inquiry', 'vyntic' ),
				'search_items'       => __( 'Search inquiries', 'vyntic' ),
				'not_found'          => __( 'No inquiries yet. New form submissions will appear here.', 'vyntic' ),
				'not_found_in_trash' => __( 'No inquiries in the trash.', 'vyntic' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => false,
			'menu_icon'       => 'dashicons-email-alt',
			'menu_position'   => 26,
			'supports'        => array( 'title' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);
} );

/**
 * Save a submission.
 *
 * @param string $type   contact or audit.
 * @param array  $fields label => value.
 * @param array  $meta   name, email, page.
 * @return int Post ID or 0.
 */
function vyntic_save_inquiry( $type, $fields, $meta ) {
	if ( ! vyntic_form_setting( 'save' ) ) {
		return 0;
	}
	$title = trim( $meta['name'] . ( $meta['email'] ? ' (' . $meta['email'] . ')' : '' ) );
	$id    = wp_insert_post(
		array(
			'post_type'   => 'vyntic_inquiry',
			'post_status' => 'publish',
			'post_title'  => $title ? $title : $meta['email'],
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_post_meta( $id, '_vyntic_type', $type );
	update_post_meta( $id, '_vyntic_fields', $fields );
	update_post_meta( $id, '_vyntic_email', $meta['email'] );
	update_post_meta( $id, '_vyntic_page', $meta['page'] );
	update_post_meta( $id, '_vyntic_unread', 1 );
	if ( ! empty( $meta['flags'] ) ) {
		update_post_meta( $id, '_vyntic_flags', array_values( (array) $meta['flags'] ) );
	}
	return $id;
}

/** Send the optional auto-reply to the visitor. */
function vyntic_send_autoreply( $email, $name ) {
	if ( ! vyntic_form_setting( 'autoreply' ) || ! is_email( $email ) ) {
		return;
	}
	wp_mail(
		$email,
		vyntic_form_personalise( vyntic_form_setting( 'autoreply_subject' ), $name ),
		vyntic_form_personalise( vyntic_form_setting( 'autoreply_body' ), $name ),
		array( 'Reply-To: ' . get_bloginfo( 'name' ) . ' <' . vyntic_form_recipient()[0] . '>' )
	);
}

/*
 * Dashboard list.
 */
add_filter( 'manage_vyntic_inquiry_posts_columns', function () {
	return array(
		'cb'       => '<input type="checkbox" />',
		'title'    => __( 'From', 'vyntic' ),
		'vf_about' => __( 'About', 'vyntic' ),
		'vf_type'  => __( 'Form', 'vyntic' ),
		'vf_page'  => __( 'Page', 'vyntic' ),
		'date'     => __( 'Received', 'vyntic' ),
	);
} );

add_action( 'manage_vyntic_inquiry_posts_custom_column', function ( $column, $post_id ) {
	$fields = (array) get_post_meta( $post_id, '_vyntic_fields', true );
	if ( 'vf_about' === $column ) {
		$bits = array();
		foreach ( array( __( 'Services', 'vyntic' ), __( 'Website', 'vyntic' ), __( 'Budget', 'vyntic' ) ) as $label ) {
			if ( ! empty( $fields[ $label ] ) ) {
				$bits[] = $fields[ $label ];
			}
		}
		$msg = isset( $fields[ __( 'Message', 'vyntic' ) ] ) ? wp_trim_words( $fields[ __( 'Message', 'vyntic' ) ], 14 ) : '';
		echo esc_html( implode( ' · ', $bits ) );
		if ( $msg ) {
			echo '<br><span style="color:#646970">' . esc_html( $msg ) . '</span>';
		}
	} elseif ( 'vf_type' === $column ) {
		echo 'audit' === get_post_meta( $post_id, '_vyntic_type', true ) ? esc_html__( 'Free audit', 'vyntic' ) : esc_html__( 'Contact', 'vyntic' );
		$flags = (array) get_post_meta( $post_id, '_vyntic_flags', true );
		if ( array_filter( $flags ) ) {
			echo '<br><span title="' . esc_attr( implode( '; ', $flags ) ) . '" style="display:inline-block;margin-top:4px;padding:1px 8px;border-radius:999px;background:#fcf0f1;color:#b32d2e;font-size:12px;font-weight:600">' . esc_html__( 'Possible spam', 'vyntic' ) . '</span>';
		}
	} elseif ( 'vf_page' === $column ) {
		$page = get_post_meta( $post_id, '_vyntic_page', true );
		if ( $page ) {
			echo '<a href="' . esc_url( $page ) . '" target="_blank" rel="noopener">' . esc_html( wp_make_link_relative( $page ) ) . '</a>';
		}
	}
}, 10, 2 );

/** "New" label on unread inquiries. */
add_filter( 'display_post_states', function ( $states, $post ) {
	if ( 'vyntic_inquiry' === $post->post_type && get_post_meta( $post->ID, '_vyntic_unread', true ) ) {
		$states['vyntic_new'] = __( 'New', 'vyntic' );
	}
	return $states;
}, 10, 2 );

/** Keep list actions simple: view and trash. */
add_filter( 'post_row_actions', function ( $actions, $post ) {
	if ( 'vyntic_inquiry' !== $post->post_type ) {
		return $actions;
	}
	$keep = array();
	if ( isset( $actions['edit'] ) ) {
		$keep['edit'] = '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'View', 'vyntic' ) . '</a>';
	}
	if ( isset( $actions['trash'] ) ) {
		$keep['trash'] = $actions['trash'];
	}
	return $keep;
}, 10, 2 );

add_filter( 'bulk_actions-edit-vyntic_inquiry', function ( $actions ) {
	unset( $actions['edit'] );
	return $actions;
} );

/** Export button above the list. */
add_action( 'restrict_manage_posts', function ( $post_type ) {
	if ( 'vyntic_inquiry' !== $post_type ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=vyntic_export_inquiries' ), 'vyntic_export_inquiries' );
	echo '<a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Export CSV', 'vyntic' ) . '</a>';
} );

add_action( 'admin_post_vyntic_export_inquiries', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'vyntic_export_inquiries' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'vyntic' ) );
	}
	$posts  = get_posts( array( 'post_type' => 'vyntic_inquiry', 'numberposts' => -1, 'post_status' => 'publish' ) );
	$labels = array();
	foreach ( $posts as $p ) {
		$labels = array_unique( array_merge( $labels, array_keys( (array) get_post_meta( $p->ID, '_vyntic_fields', true ) ) ) );
	}
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=inquiries-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	fputcsv( $out, array_merge( array( 'Date', 'Form', 'Page' ), $labels ) );
	foreach ( $posts as $p ) {
		$fields = (array) get_post_meta( $p->ID, '_vyntic_fields', true );
		$row    = array( get_the_date( 'Y-m-d H:i', $p ), get_post_meta( $p->ID, '_vyntic_type', true ), get_post_meta( $p->ID, '_vyntic_page', true ) );
		foreach ( $labels as $label ) {
			$value = isset( $fields[ $label ] ) ? (string) $fields[ $label ] : '';
			// Stop spreadsheet apps from running values that start like a formula.
			$row[] = preg_match( '/^[=+\-@]/', $value ) ? "'" . $value : $value;
		}
		fputcsv( $out, $row );
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/** Unread count bubble on the menu. */
add_action( 'admin_menu', function () {
	global $menu;
	$unread = (int) ( new WP_Query(
		array(
			'post_type'      => 'vyntic_inquiry',
			'post_status'    => 'publish',
			'meta_key'       => '_vyntic_unread', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => 1, // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'         => 'ids',
			'posts_per_page' => 1,
		)
	) )->found_posts;
	if ( ! $unread || ! is_array( $menu ) ) {
		return;
	}
	foreach ( $menu as $i => $item ) {
		if ( isset( $item[2] ) && 'edit.php?post_type=vyntic_inquiry' === $item[2] ) {
			$menu[ $i ][0] .= ' <span class="awaiting-mod"><span class="pending-count">' . $unread . '</span></span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		}
	}
}, 99 );

/*
 * Single inquiry screen: read-only details, marked as read when opened.
 */
add_action( 'add_meta_boxes_vyntic_inquiry', function ( $post ) {
	delete_post_meta( $post->ID, '_vyntic_unread' );
	remove_meta_box( 'submitdiv', 'vyntic_inquiry', 'side' );
	add_meta_box( 'vyntic_inquiry_details', __( 'Inquiry details', 'vyntic' ), 'vyntic_inquiry_details_box', 'vyntic_inquiry', 'normal', 'high' );
	add_meta_box( 'vyntic_inquiry_actions', __( 'Reply', 'vyntic' ), 'vyntic_inquiry_actions_box', 'vyntic_inquiry', 'side', 'high' );
} );

function vyntic_inquiry_details_box( $post ) {
	$fields = (array) get_post_meta( $post->ID, '_vyntic_fields', true );
	$page   = get_post_meta( $post->ID, '_vyntic_page', true );
	$flags  = array_filter( (array) get_post_meta( $post->ID, '_vyntic_flags', true ) );
	if ( $flags ) {
		echo '<div class="notice notice-warning inline" style="margin:0 0 12px"><p><strong>' . esc_html__( 'Possible spam.', 'vyntic' ) . '</strong> ' . esc_html( implode( '; ', $flags ) ) . '. ' . esc_html__( 'It was saved anyway so no real message is lost. Check it before replying.', 'vyntic' ) . '</p></div>';
	}
	echo '<table class="widefat striped" style="border:0"><tbody>';
	foreach ( $fields as $label => $value ) {
		echo '<tr><th style="width:170px">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( (string) $value ) ) . '</td></tr>';
	}
	echo '<tr><th>' . esc_html__( 'Sent from', 'vyntic' ) . '</th><td>' . ( $page ? '<a href="' . esc_url( $page ) . '" target="_blank" rel="noopener">' . esc_html( $page ) . '</a>' : '-' ) . '</td></tr>';
	echo '<tr><th>' . esc_html__( 'Received', 'vyntic' ) . '</th><td>' . esc_html( get_the_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $post ) ) . '</td></tr>';
	echo '</tbody></table>';
}

function vyntic_inquiry_actions_box( $post ) {
	$email = get_post_meta( $post->ID, '_vyntic_email', true );
	if ( $email ) {
		echo '<p><a class="button button-primary" href="mailto:' . esc_attr( $email ) . '">' . esc_html__( 'Reply by email', 'vyntic' ) . '</a></p>';
	}
	echo '<p><a class="submitdelete" style="color:#b32d2e" href="' . esc_url( get_delete_post_link( $post->ID ) ) . '">' . esc_html__( 'Move to trash', 'vyntic' ) . '</a></p>';
}

/** Hide the title field on the inquiry screen; the details box shows everything. */
add_action( 'admin_head', function () {
	$screen = get_current_screen();
	if ( $screen && 'vyntic_inquiry' === $screen->post_type ) {
		echo '<style>#titlediv,.page-title-action,#screen-meta-links{display:none}#post-body-content{margin-bottom:0}</style>';
	}
} );

/*
 * Settings screen.
 */
add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=vyntic_inquiry', __( 'Form settings', 'vyntic' ), __( 'Settings', 'vyntic' ), 'manage_options', 'vyntic-form-settings', 'vyntic_form_settings_screen' );
} );

add_action( 'admin_init', function () {
	register_setting(
		'vyntic_forms',
		'vyntic_forms',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'vyntic_form_settings_sanitize',
		)
	);
} );

function vyntic_form_settings_sanitize( $in ) {
	$in  = (array) $in;
	$out = array();
	foreach ( array( 'notify', 'save', 'show_services', 'show_phone', 'show_website', 'show_budget', 'show_timeline', 'autoreply' ) as $k ) {
		$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
	}
	$emails            = array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', isset( $in['notify_to'] ) ? $in['notify_to'] : '' ) ) ), 'is_email' );
	$out['notify_to']  = implode( ', ', $emails );
	$out['retention']  = isset( $in['retention'] ) ? absint( $in['retention'] ) : 0;
	foreach ( array( 'button_label', 'thanks_title', 'autoreply_subject' ) as $k ) {
		$out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : '';
	}
	foreach ( array( 'budgets', 'timelines', 'thanks_text', 'autoreply_body' ) as $k ) {
		$out[ $k ] = isset( $in[ $k ] ) ? sanitize_textarea_field( $in[ $k ] ) : '';
	}
	return $out;
}

function vyntic_form_settings_screen() {
	$s    = vyntic_form_settings();
	$name = function ( $k ) {
		return 'vyntic_forms[' . $k . ']';
	};
	$check = function ( $k, $label ) use ( $s, $name ) {
		echo '<label style="display:block;margin:.25rem 0"><input type="checkbox" name="' . esc_attr( $name( $k ) ) . '" value="1" ' . checked( 1, (int) $s[ $k ], false ) . '> ' . esc_html( $label ) . '</label>';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Form settings', 'vyntic' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'vyntic_forms' ); ?>

			<h2 class="title"><?php esc_html_e( 'Notifications and storage', 'vyntic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="vf-to"><?php esc_html_e( 'Send new inquiries to', 'vyntic' ); ?></label></th>
					<td>
						<input id="vf-to" class="regular-text" type="text" name="<?php echo esc_attr( $name( 'notify_to' ) ); ?>" value="<?php echo esc_attr( $s['notify_to'] ); ?>" placeholder="<?php echo esc_attr( implode( ', ', vyntic_form_recipient() ) ); ?>">
						<p class="description"><?php esc_html_e( 'One or more emails, separated by commas. Leave empty to use the email in Customize.', 'vyntic' ); ?></p>
						<?php $check( 'notify', __( 'Email me when a new inquiry arrives', 'vyntic' ) ); ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Save submissions', 'vyntic' ); ?></th>
					<td>
						<?php $check( 'save', __( 'Keep a copy of every submission under Inquiries', 'vyntic' ) ); ?>
						<label for="vf-ret"><?php esc_html_e( 'Delete submissions older than', 'vyntic' ); ?></label>
						<input id="vf-ret" type="number" min="0" step="1" style="width:5rem" name="<?php echo esc_attr( $name( 'retention' ) ); ?>" value="<?php echo esc_attr( $s['retention'] ); ?>"> <?php esc_html_e( 'months (0 keeps them)', 'vyntic' ); ?>
						<p class="description"><?php esc_html_e( 'Privacy rules expect you not to keep personal data longer than you need it.', 'vyntic' ); ?></p>
					</td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Contact form', 'vyntic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Fields to show', 'vyntic' ); ?></th>
					<td>
						<p class="description" style="margin-top:0"><?php esc_html_e( 'Name, email, message and consent are always shown.', 'vyntic' ); ?></p>
						<?php
						$check( 'show_services', __( 'Services (pick any)', 'vyntic' ) );
						$check( 'show_phone', __( 'Phone or WhatsApp', 'vyntic' ) );
						$check( 'show_website', __( 'Current website', 'vyntic' ) );
						$check( 'show_budget', __( 'Budget', 'vyntic' ) );
						$check( 'show_timeline', __( 'Launch timeline', 'vyntic' ) );
						?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-budgets"><?php esc_html_e( 'Budget options', 'vyntic' ); ?></label></th>
					<td><textarea id="vf-budgets" class="large-text" rows="5" name="<?php echo esc_attr( $name( 'budgets' ) ); ?>"><?php echo esc_textarea( $s['budgets'] ); ?></textarea><p class="description"><?php esc_html_e( 'One per line. The last one is selected by default.', 'vyntic' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-times"><?php esc_html_e( 'Timeline options', 'vyntic' ); ?></label></th>
					<td><textarea id="vf-times" class="large-text" rows="4" name="<?php echo esc_attr( $name( 'timelines' ) ); ?>"><?php echo esc_textarea( $s['timelines'] ); ?></textarea><p class="description"><?php esc_html_e( 'One per line.', 'vyntic' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-btn"><?php esc_html_e( 'Button text', 'vyntic' ); ?></label></th>
					<td><input id="vf-btn" class="regular-text" type="text" name="<?php echo esc_attr( $name( 'button_label' ) ); ?>" value="<?php echo esc_attr( $s['button_label'] ); ?>"></td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Thank-you message', 'vyntic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="vf-tt"><?php esc_html_e( 'Heading', 'vyntic' ); ?></label></th>
					<td><input id="vf-tt" class="regular-text" type="text" name="<?php echo esc_attr( $name( 'thanks_title' ) ); ?>" value="<?php echo esc_attr( $s['thanks_title'] ); ?>"><p class="description"><?php esc_html_e( '{name} is replaced with the visitor\'s first name.', 'vyntic' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-tx"><?php esc_html_e( 'Message', 'vyntic' ); ?></label></th>
					<td><textarea id="vf-tx" class="large-text" rows="3" name="<?php echo esc_attr( $name( 'thanks_text' ) ); ?>"><?php echo esc_textarea( $s['thanks_text'] ); ?></textarea></td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Auto-reply to the visitor', 'vyntic' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Auto-reply', 'vyntic' ); ?></th>
					<td><?php $check( 'autoreply', __( 'Send a confirmation email to the visitor', 'vyntic' ) ); ?></td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-as"><?php esc_html_e( 'Subject', 'vyntic' ); ?></label></th>
					<td><input id="vf-as" class="regular-text" type="text" name="<?php echo esc_attr( $name( 'autoreply_subject' ) ); ?>" value="<?php echo esc_attr( $s['autoreply_subject'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="vf-ab"><?php esc_html_e( 'Email text', 'vyntic' ); ?></label></th>
					<td><textarea id="vf-ab" class="large-text" rows="7" name="<?php echo esc_attr( $name( 'autoreply_body' ) ); ?>"><?php echo esc_textarea( $s['autoreply_body'] ); ?></textarea><p class="description"><?php esc_html_e( 'Use {name} for the visitor\'s first name. Install an SMTP plugin so emails arrive reliably.', 'vyntic' ); ?></p></td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/*
 * Delete old submissions once a day when a retention period is set.
 */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'vyntic_inquiry_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'vyntic_inquiry_cleanup' );
	}
} );

add_action( 'vyntic_inquiry_cleanup', function () {
	$months = (int) vyntic_form_setting( 'retention' );
	if ( $months < 1 ) {
		return;
	}
	$old = get_posts(
		array(
			'post_type'   => 'vyntic_inquiry',
			'post_status' => 'any',
			'numberposts' => 200,
			'fields'      => 'ids',
			'date_query'  => array( array( 'before' => $months . ' months ago' ) ),
		)
	);
	foreach ( $old as $id ) {
		wp_delete_post( $id, true );
	}
} );
