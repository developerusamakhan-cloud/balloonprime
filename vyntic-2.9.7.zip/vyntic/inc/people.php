<?php
/**
 * Team and authors: profile fields, initials avatars and author helpers.
 *
 * @package Vyntic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Extra profile fields: job title, photo URL, show on About page. */
function vyntic_user_fields( $user ) {
	?>
	<h2><?php esc_html_e( 'Vyntic profile', 'vyntic' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr><th><label for="vyntic_job"><?php esc_html_e( 'Job title', 'vyntic' ); ?></label></th>
			<td><input type="text" class="regular-text" id="vyntic_job" name="vyntic_job" value="<?php echo esc_attr( get_user_meta( $user->ID, 'vyntic_job', true ) ); ?>" placeholder="<?php esc_attr_e( 'e.g. SEO Lead', 'vyntic' ); ?>"></td></tr>
		<tr><th><label for="vyntic_photo"><?php esc_html_e( 'Photo URL', 'vyntic' ); ?></label></th>
			<td><input type="url" class="regular-text" id="vyntic_photo" name="vyntic_photo" value="<?php echo esc_attr( get_user_meta( $user->ID, 'vyntic_photo', true ) ); ?>">
			<p class="description"><?php esc_html_e( 'Upload a square photo to the Media Library and paste its URL. Without a photo, coloured initials are shown.', 'vyntic' ); ?></p></td></tr>
		<tr><th><?php esc_html_e( 'About page', 'vyntic' ); ?></th>
			<td><label><input type="checkbox" name="vyntic_hide_team" value="1" <?php checked( get_user_meta( $user->ID, 'vyntic_hide_team', true ), '1' ); ?>> <?php esc_html_e( 'Hide this person from the team section', 'vyntic' ); ?></label></td></tr>
	</table>
	<?php
}
add_action( 'show_user_profile', 'vyntic_user_fields' );
add_action( 'edit_user_profile', 'vyntic_user_fields' );

function vyntic_save_user_fields( $user_id ) {
	if ( ! current_user_can( 'edit_user', $user_id ) || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'update-user_' . $user_id ) ) {
		return;
	}
	update_user_meta( $user_id, 'vyntic_job', isset( $_POST['vyntic_job'] ) ? sanitize_text_field( wp_unslash( $_POST['vyntic_job'] ) ) : '' );
	update_user_meta( $user_id, 'vyntic_photo', isset( $_POST['vyntic_photo'] ) ? esc_url_raw( wp_unslash( $_POST['vyntic_photo'] ) ) : '' );
	update_user_meta( $user_id, 'vyntic_hide_team', empty( $_POST['vyntic_hide_team'] ) ? '' : '1' );
}
add_action( 'personal_options_update', 'vyntic_save_user_fields' );
add_action( 'edit_user_profile_update', 'vyntic_save_user_fields' );

/**
 * Avatar: profile photo if set, otherwise coloured initials. No Gravatar lookups.
 *
 * @param int    $user_id User ID.
 * @param int    $size    Pixels.
 * @param string $class   Extra class.
 * @return string HTML.
 */
function vyntic_avatar( $user_id, $size = 40, $class = '' ) {
	$user  = get_userdata( (int) $user_id );
	$name  = $user ? ( $user->display_name ? $user->display_name : $user->user_login ) : get_bloginfo( 'name' );
	$photo = $user ? get_user_meta( $user->ID, 'vyntic_photo', true ) : '';
	if ( $photo ) {
		return sprintf( '<img class="avatar-img %1$s" src="%2$s" alt="%3$s" width="%4$d" height="%4$d" loading="lazy">', esc_attr( $class ), esc_url( $photo ), esc_attr( $name ), (int) $size );
	}
	if ( false !== strpos( $name, '@' ) ) {
		$name = strstr( $name, '@', true );
	}
	$parts    = preg_split( '/[\s._-]+/', trim( $name ) );
	$initials = mb_strtoupper( mb_substr( $parts[0], 0, 1 ) . ( isset( $parts[1] ) ? mb_substr( $parts[1], 0, 1 ) : '' ) );
	$palette  = array( '#c7431f', '#0f2b2e', '#0e9f6a', '#1f5a5e', '#b7791f', '#6b4fa3', '#2b6cb0' );
	$bg       = $palette[ abs( crc32( $name ) ) % count( $palette ) ];
	return sprintf(
		'<span class="avatar-initials %1$s" style="--av-bg:%2$s;--av-size:%3$dpx" role="img" aria-label="%4$s">%5$s</span>',
		esc_attr( $class ),
		esc_attr( $bg ),
		(int) $size,
		esc_attr( $name ),
		esc_html( $initials )
	);
}

/** Readable author name (falls back to the site name for email-style usernames). */
function vyntic_author_name( $user_id ) {
	$user = get_userdata( (int) $user_id );
	if ( ! $user ) {
		return get_bloginfo( 'name' );
	}
	$name = $user->display_name;
	return ( ! $name || false !== strpos( $name, '@' ) ) ? get_bloginfo( 'name' ) : $name;
}

/** Team members for the About page: authors, editors and named admins. */
function vyntic_team() {
	$users = get_users( array( 'role__in' => array( 'administrator', 'editor', 'author' ), 'orderby' => 'display_name' ) );
	return array_values(
		array_filter(
			$users,
			function ( $u ) {
				// The studio's own account (named like the site) is not a team member.
				return ! get_user_meta( $u->ID, 'vyntic_hide_team', true ) && strtolower( trim( $u->display_name ) ) !== strtolower( trim( get_bloginfo( 'name' ) ) ) && $u->display_name && false === strpos( $u->display_name, '@' ) && strtolower( $u->display_name ) !== strtolower( $u->user_login ) . ( in_array( 'administrator', (array) $u->roles, true ) ? '' : 'x' );
			}
		)
	);
}

/**
 * Breadcrumbs (Rank Math's when available, otherwise simple theme breadcrumbs).
 */
function vyntic_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}
	if ( function_exists( 'rank_math_get_breadcrumbs' ) ) {
		$html = rank_math_get_breadcrumbs();
		if ( $html ) {
			echo '<div class="crumbs">' . wp_kses_post( $html ) . '</div>';
			return;
		}
	}
	$items = array( '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'vyntic' ) . '</a>' );
	if ( is_singular( 'post' ) && get_option( 'page_for_posts' ) ) {
		$items[] = '<a href="' . esc_url( get_permalink( get_option( 'page_for_posts' ) ) ) . '">' . esc_html( get_the_title( get_option( 'page_for_posts' ) ) ) . '</a>';
	} elseif ( is_singular( 'work' ) ) {
		$work = vyntic_template_url( 'page-templates/work.php' );
		if ( $work ) {
			$items[] = '<a href="' . esc_url( $work ) . '">' . esc_html__( 'Work', 'vyntic' ) . '</a>';
		}
	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $anc ) {
			$items[] = '<a href="' . esc_url( get_permalink( $anc ) ) . '">' . esc_html( get_the_title( $anc ) ) . '</a>';
		}
	}
	$items[] = '<span aria-current="page">' . esc_html( is_home() ? single_post_title( '', false ) : ( is_archive() ? wp_strip_all_tags( get_the_archive_title() ) : get_the_title() ) ) . '</span>';
	echo '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'vyntic' ) . '">' . implode( '<span class="crumbs__sep" aria-hidden="true">/</span>', $items ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
