BALLOON PRIME — REDESIGNED HOMEPAGE (v6)
=======================================

LATEST CHANGES (v6)
  • Re-themed to the bright PRIMARY palette from the Balloon World storefront:
    red (#E63329), yellow (#FFC61E), and blue (#1B9DE8) — happy, high-energy,
    attention-grabbing. Removed all the dark plum/purple tones.
  • Blue category nav bar, red call-to-action buttons, yellow trust strip &
    accents, blue service-area band, blue-tinted hero overlay, navy-blue
    footer & text for contrast. Logo balloon now blends red-to-blue.

HOW TO PREVIEW
  Double-click index.html to open it in any web browser.

LATEST CHANGES (v5)
  • Removed Wishlist from the header (desktop + mobile drawer).
  • Category modal now uses one consistent balloon icon on every tile.

PREVIOUS (v4)
  • HERO is now a full-width SLIDER — 3 slides, full background images,
    smooth cross-fade + slow zoom, auto-play (6s), prev/next arrows, and
    clickable dots. Pauses on hover; respects reduced-motion settings.
  • FAQ section rebuilt as a 66 / 34 layout — accordion on the left (66%),
    a relevant image + "Still have questions?" CTA card on the right (34%).
    Fully responsive: stacks to one column on tablet/mobile.
  • Category filter REMOVED from the search bar (clean search input only).
  • "All Categories" now opens a clean POPUP / MODAL (18 category tiles with
    icons + counts, Shop-all / Custom-order footer) instead of showing the
    full list on the page. Opens on click; closes via ✕, overlay, or Escape.

CARRIED OVER
  • 1340px content width; professional 3-row eCommerce header (utility bar,
    logo + prominent 56px search + Account/Wishlist/Cart, category nav with
    hover flyouts + Sale); mobile hamburger + slide-out drawer.
  • SEO: optimized title/description/keywords, LocalBusiness JSON-LD, FAQ,
    Northern NJ service-area content, descriptive alt text.

CUSTOMIZE
  • Slider images: search the file for `slide_6.png`, `slide_5.png`,
    `Balloon-Prime3.png` and swap the URLs / edit the slide copy.
  • Category modal tiles, counts, and links are all editable in the
    `#catModal` block.
  • Cart total / wishlist count / prices are static placeholders — a
    developer binds them to live WooCommerce data on the site.

NOTES
  • Fonts (Baloo 2 + Nunito Sans) load from Google Fonts; images load from
    balloonprime.com — both appear once opened online / hosted.
  • Homepage only, as requested.
