<?php
/**
 * Admin bar shortcuts: clear cache, clear this page, test speed.
 *
 * @package VynticSpeedOptimizer
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin bar menu (front end + back end).
 */
add_action(
	'admin_bar_menu',
	static function ( $bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'vso',
				// The Vyntic V mark, drawn in the admin bar's own text colour so it matches hover states.
				'title' => '<span class="ab-icon" aria-hidden="true" style="top:2px"><svg viewBox="0 0 20 20" width="20" height="20" style="display:block;fill:currentColor" focusable="false"><path d="M2 3h3.6L10 13.4 14.4 3H18l-6.6 14H8.6z"/></svg></span>' . esc_html__( 'Vyntic', 'vyntic-speed-optimizer' ),
				'href'  => admin_url( 'admin.php?page=vyntic-speed' ),
			)
		);
		$bar->add_node(
			array(
				'parent' => 'vso',
				'id'     => 'vso-clear',
				'title'  => esc_html__( 'Clear all cache', 'vyntic-speed-optimizer' ),
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=vso_clear' ), 'vso_clear' ),
			)
		);
		if ( ! is_admin() ) {
			$host    = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : (string) wp_parse_url( home_url(), PHP_URL_HOST );
			$uri     = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
			$current = ( is_ssl() ? 'https://' : 'http://' ) . $host . $uri;
			$bar->add_node(
				array(
					'parent' => 'vso',
					'id'     => 'vso-clear-page',
					'title'  => esc_html__( 'Clear this page', 'vyntic-speed-optimizer' ),
					'href'   => wp_nonce_url( add_query_arg( 'vso_url', rawurlencode( $current ), admin_url( 'admin-post.php?action=vso_clear' ) ), 'vso_clear' ),
				)
			);
			$bar->add_node(
				array(
					'parent' => 'vso',
					'id'     => 'vso-preview',
					'title'  => esc_html__( 'Preview optimized page', 'vyntic-speed-optimizer' ),
					'href'   => add_query_arg( 'vso_preview', 1, $current ),
				)
			);
			$bar->add_node(
				array(
					'parent' => 'vso',
					'id'     => 'vso-psi',
					'title'  => esc_html__( 'Test on PageSpeed Insights', 'vyntic-speed-optimizer' ),
					'href'   => 'https://pagespeed.web.dev/analysis?url=' . rawurlencode( $current ),
					'meta'   => array( 'target' => '_blank' ),
				)
			);
		}
	},
	100
);
