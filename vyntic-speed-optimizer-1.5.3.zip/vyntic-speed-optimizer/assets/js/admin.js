/* Vyntic Speed Optimizer: admin */
(function () {
	'use strict';
	var cfg = window.vsoAdmin || {};
	var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', cfg.nonce);
		Object.keys(data || {}).forEach(function (k) { body.append(k, data[k]); });
		return fetch(cfg.ajax, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (r) { return r.json(); })
			.then(function (json) {
				if (!json || !json.success) {
					var err = new Error((json && json.data && json.data.message) || 'Request failed');
					err.code = json && json.data && json.data.code;
					throw err;
				}
				return json.data;
			});
	}

	function esc(s) {
		var d = document.createElement('div');
		d.textContent = String(s);
		return d.innerHTML;
	}

	/* ---------- PageSpeed ---------- */
	var T = (cfg.i18n && cfg.i18n.psi) || {};
	function grade(score) {
		return score >= 0.9 ? 'good' : (score >= 0.5 ? 'avg' : 'poor');
	}
	function band(score) {
		return score >= 90 ? 'good' : (score >= 50 ? 'avg' : 'poor');
	}
	function fmtDate(ts) {
		try {
			return new Date(ts * 1000).toLocaleString(cfg.locale || undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
		} catch (e) {
			return new Date(ts * 1000).toLocaleString();
		}
	}
	function ago(ts) {
		var s = Math.max(1, Math.round(Date.now() / 1000 - ts));
		var units = [['year', 31536000], ['month', 2592000], ['week', 604800], ['day', 86400], ['hour', 3600], ['minute', 60], ['second', 1]];
		for (var i = 0; i < units.length; i++) {
			if (s >= units[i][1] || i === units.length - 1) {
				var n = Math.round(s / units[i][1]);
				try {
					return new Intl.RelativeTimeFormat(cfg.locale || undefined, { numeric: 'auto' }).format(-n, units[i][0]);
				} catch (e) {
					return n + ' ' + units[i][0] + (n > 1 ? 's' : '') + ' ago';
				}
			}
		}
	}
	var icons = {
		mobile: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="2.5" width="10" height="19" rx="2.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M11 18.2h2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		desktop: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="4" width="19" height="12.5" rx="1.8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8.5 20.5h7M12 16.5v4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
	};
	function gauge(score, size) {
		var r = size / 2 - 7, c = 2 * Math.PI * r, mid = size / 2;
		return '<div class="vso-gauge vso-gauge--' + band(score) + '" style="width:' + size + 'px;height:' + size + 'px"><svg width="' + size + '" height="' + size + '" aria-hidden="true">' +
			'<circle cx="' + mid + '" cy="' + mid + '" r="' + r + '" class="vso-gauge-track"/>' +
			'<circle cx="' + mid + '" cy="' + mid + '" r="' + r + '" class="vso-gauge-bar" stroke-dasharray="' + c.toFixed(2) + '" stroke-dashoffset="' + (c * (1 - score / 100)).toFixed(2) + '"/></svg>' +
			'<b>' + score + '</b></div>';
	}
	function scoreCard(key, result, loading) {
		if (loading) {
			return '<div class="vso-score is-loading"><div class="vso-score-top"><div class="vso-gauge vso-gauge--wait" style="width:112px;height:112px"><span class="vso-spin"></span></div>' +
				'<div><h4>' + icons[key] + esc(T[key] || key) + '</h4><p class="vso-muted">' + esc(key === 'mobile' ? T.testingM : T.testingD) + '</p></div></div></div>';
		}
		if (!result) { return ''; }
		var names = T.names || {};
		var tiles = Object.keys(result.metrics || {}).map(function (k) {
			var m = result.metrics[k];
			return '<div class="vso-metric vso-metric--' + grade(m.score) + '" title="' + esc(names[k] || k) + '"><span class="vso-metric-name"><i></i>' + esc(k) + '</span><strong>' + esc(m.value) + '</strong><small>' + esc(names[k] || '') + '</small></div>';
		}).join('');
		return '<div class="vso-score"><div class="vso-score-top">' + gauge(result.score, 112) +
			'<div><h4>' + icons[key] + esc(T[key] || key) + '</h4><p class="vso-score-word vso-' + band(result.score) + '">' + esc(T[band(result.score)] || '') + '</p></div></div>' +
			'<div class="vso-metrics">' + tiles + '</div></div>';
	}
	function historyTable(rows) {
		if (!rows || rows.length < 1) { return ''; }
		var chip = function (v) {
			return typeof v === 'number' ? '<span class="vso-chip vso-chip--' + band(v) + '">' + v + '</span>' : '<span class="vso-muted">-</span>';
		};
		var trend = rows.slice().reverse().filter(function (r) { return typeof r.mobile === 'number'; });
		var bars = trend.length > 1 ? '<div class="vso-trend" aria-hidden="true">' + trend.map(function (r) {
			return '<span class="vso-trend-' + band(r.mobile) + '" style="height:' + Math.max(6, r.mobile) + '%" title="' + esc(fmtDate(r.time)) + ': ' + r.mobile + '"></span>';
		}).join('') + '</div>' : '';
		var body = rows.map(function (r) {
			var path = '';
			try { path = new URL(r.url).pathname; } catch (e) { path = r.url || ''; }
			return '<tr><td>' + esc(fmtDate(r.time)) + '</td><td class="vso-hide-sm"><code>' + esc(path) + '</code></td><td>' + chip(r.mobile) + '</td><td>' + chip(r.desktop) + '</td><td class="vso-hide-sm">' + esc(r.source === 'auto' ? T.auto : T.manual) + '</td></tr>';
		}).join('');
		return '<div class="vso-history"><div class="vso-history-head"><h3>' + esc(T.history) + '</h3>' + bars + '</div>' +
			'<table class="vso-history-table"><thead><tr><th>' + esc(T.date) + '</th><th class="vso-hide-sm">' + esc(T.page) + '</th><th>' + esc(T.mobile) + '</th><th>' + esc(T.desktop) + '</th><th class="vso-hide-sm">' + esc(T.source) + '</th></tr></thead><tbody>' + body + '</tbody></table></div>';
	}
	function fixesList(result) {
		if (!result || !result.fixes || !result.fixes.length) { return ''; }
		return '<div class="vso-fixes"><h3>' + esc(T.fixes) + '</h3><ul>' + result.fixes.map(function (f) {
			return '<li><span>' + esc(f.title) + '</span><b>' + esc(T.save) + ' ' + esc(f.save) + ' s</b></li>';
		}).join('') + '</ul></div>';
	}

	var results = $('#vso-psi-results');
	var status = $('#vso-psi-status');
	var state = { last: {}, history: [], next: 0 };
	function meta() {
		var last = state.last || {};
		var parts = [];
		if (last.time) {
			parts.push('<span><strong>' + esc(T.last) + ':</strong> ' + esc(fmtDate(last.time)) + ' <span class="vso-muted">(' + esc(ago(last.time)) + (last.source === 'auto' ? ', ' + esc(T.auto).toLowerCase() : '') + ')</span></span>');
		}
		parts.push(state.next ? '<span><strong>' + esc(T.next) + ':</strong> ' + esc(fmtDate(state.next)) + '</span>' : '<span class="vso-muted">' + esc(T.off) + '</span>');
		return '<div class="vso-psi-meta">' + parts.join('') + '<span class="vso-legend"><i class="vso-l-good"></i><i class="vso-l-avg"></i><i class="vso-l-poor"></i>' + esc(T.legend) + '</span></div>';
	}
	function render(loading) {
		var last = state.last || {};
		loading = loading || {};
		if (!loading.mobile && !loading.desktop && !last.mobile && !last.desktop) {
			results.innerHTML = '<div class="vso-psi-empty">' + icons.mobile + icons.desktop + '<p>' + esc(T.empty) + '</p></div>' + meta();
			return;
		}
		results.innerHTML = '<div class="vso-scores">' + scoreCard('mobile', last.mobile, loading.mobile) + scoreCard('desktop', last.desktop, loading.desktop) + '</div>' +
			meta() + '<div class="vso-psi-bottom">' + fixesList(last.mobile) + historyTable(state.history) + '</div>';
	}
	if (results) {
		try {
			var initial = JSON.parse(results.getAttribute('data-state') || '{}');
			if (initial) { state = initial; }
		} catch (e) {}
		render();
	}
	var runBtn = $('#vso-psi-run');
	function runTest() {
		var url = $('#vso-psi-url').value || cfg.home;
		var run = 'r' + Date.now();
		runBtn.disabled = true;
		status.className = 'vso-psi-status';
		status.textContent = '';
		render({ mobile: true, desktop: true });
		post('vso_psi', { url: url, strategy: 'mobile', run: run })
			.then(function (m) { state = m.state; render({ desktop: true }); return post('vso_psi', { url: url, strategy: 'desktop', run: run }); })
			.then(function (d) { state = d.state; render(); status.className = 'vso-psi-status is-ok'; status.textContent = T.saved; })
			.catch(function (err) { render(); status.className = 'vso-psi-status is-error'; status.textContent = ('vso_psi_quota' === err.code ? '' : cfg.i18n.error + ' ') + err.message; })
			.then(function () { runBtn.disabled = false; });
	}
	if (runBtn) {
		runBtn.addEventListener('click', runTest);
		if (/[?&]vso_psi_run=1/.test(window.location.search)) {
			if (window.history && window.history.replaceState) {
				window.history.replaceState(null, '', window.location.href.replace(/([?&])vso_psi_run=1&?/, '$1').replace(/[?&](#|$)/, '$1'));
			}
			runTest();
		}
	}

	/* ---------- API key ---------- */
	var keyBtn = $('#vso-key-change');
	if (keyBtn) {
		keyBtn.addEventListener('click', function () {
			var edit = $('#vso-key-edit');
			edit.hidden = false;
			$('#vso-key').hidden = true;
			edit.querySelector('input').focus();
		});
	}

	/* ---------- WebP bulk ---------- */
	var webpBtn = $('#vso-webp-run');
	if (webpBtn) {
		var w = cfg.i18n.webp || {};
		var box = $('#vso-webp-bulk');
		var stopBtn = $('#vso-webp-stop');
		var live = $('#vso-webp-live');
		var liveText = $('#vso-webp-live-text');
		var stopAsked = false;
		var running = false;
		var fill = function (tpl, a, b) { return String(tpl).replace('%1$s', a).replace('%2$s', b).replace('%s', a); };
		var size = function (bytes) {
			var u = ['B', 'KB', 'MB', 'GB'], i = 0;
			while (bytes >= 1024 && i < u.length - 1) { bytes /= 1024; i++; }
			return (i ? bytes.toFixed(1) : bytes) + ' ' + u[i];
		};
		var show = function (s) {
			var pct = s.total ? Math.floor(s.converted / s.total * 100) : 100;
			box.querySelector('.vso-progress span').style.width = pct + '%';
			box.querySelector('.vso-progress').setAttribute('aria-valuenow', pct);
			$('#vso-webp-pct').textContent = pct + '%';
			var line = fill(w.progress, s.converted.toLocaleString(), s.total.toLocaleString());
			if (s.bytes) { line += ' · ' + fill(w.saved, size(s.bytes)); }
			$('#vso-webp-text').textContent = line;
		};
		var finish = function (label, message) {
			running = false;
			box.classList.remove('is-running');
			stopBtn.hidden = true;
			webpBtn.disabled = false;
			webpBtn.textContent = label;
			if (message) { liveText.textContent = message; live.hidden = false; live.classList.add('is-idle'); } else { live.hidden = true; }
		};
		window.addEventListener('beforeunload', function (e) {
			if (running) { e.preventDefault(); e.returnValue = w.leave; return w.leave; }
		});
		stopBtn.addEventListener('click', function () {
			stopAsked = true;
			stopBtn.disabled = true;
			liveText.textContent = w.stopping;
		});
		webpBtn.addEventListener('click', function () {
			if (running) { return; }
			running = true;
			stopAsked = false;
			box.classList.add('is-running');
			box.classList.remove('is-done');
			live.classList.remove('is-idle');
			live.hidden = false;
			liveText.textContent = w.keepOpen;
			webpBtn.disabled = true;
			webpBtn.innerHTML = '<span class="vso-spin vso-spin--sm" aria-hidden="true"></span>' + w.running;
			stopBtn.hidden = false;
			stopBtn.disabled = false;
			var started = Date.now(), firstDone = null;
			(function loop() {
				post('vso_webp_batch', {}).then(function (s) {
					show(s);
					if (firstDone === null) { firstDone = s.converted; }
					if (s.done || !s.remaining) {
						box.classList.add('is-done');
						finish(w.allDone, cfg.i18n.done);
						webpBtn.disabled = true;
						return;
					}
					if (stopAsked) { finish(w['continue'], w.stopped); return; }
					var did = s.converted - firstDone;
					if (did > 0) {
						var mins = (Date.now() - started) / did * s.remaining / 60000;
						liveText.textContent = w.keepOpen + ' ' + (mins < 1 ? w.etaSoon : fill(w.etaMin, Math.ceil(mins)));
					}
					loop();
				}).catch(function (err) {
					finish(w['continue'], cfg.i18n.error + ' ' + err.message);
				});
			})();
		});
	}

	/* ---------- Database ---------- */
	document.querySelectorAll('.vso-db-clean').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var item = btn.getAttribute('data-item');
			btn.disabled = true;
			post('vso_db_clean', { item: item }).then(function (r) {
				var cell = document.querySelector('.vso-db-count[data-item="' + item + '"]');
				if (cell && item !== 'optimize') { cell.textContent = r.count; }
				btn.textContent = cfg.i18n.cleaned + ' ✓';
			}).catch(function (err) {
				alert(cfg.i18n.error + ' ' + err.message);
				btn.disabled = false;
			});
		});
	});
})();
