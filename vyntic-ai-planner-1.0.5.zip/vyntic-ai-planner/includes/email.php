<?php
/**
 * Email templates: the plan sent to the visitor and the lead alert for the studio.
 *
 * Built for inboxes: tables and inline styles, no web fonts, no hidden preview text,
 * and a plain-text part next to the HTML, which keeps them out of spam folders.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Brand colours and fonts for the emails. */
function vap_mail_style() {
	return apply_filters(
		'vap_mail_style',
		array(
			'ink'     => '#0f2b2e',
			'soft'    => '#4a6266',
			'mist'    => '#eef3f1',
			'line'    => '#d5e0dd',
			'on_dark' => '#d3e2df',
			'accent'  => '#c7431f',
			'blush'   => '#fdf1ec',
			'pass'    => '#0e9f6a',
			'head'    => "'Bricolage Grotesque','Segoe UI',Helvetica,Arial,sans-serif",
			'body'    => "Figtree,'Segoe UI',Helvetica,Arial,sans-serif",
			'logo'    => VAP_URL . 'assets/logo-light.png',
		)
	);
}

/** Escape for email HTML. */
function vap_e( $s ) {
	return esc_html( (string) $s );
}

/**
 * Outer layout: soft green page, white card, dark header with logo, footer.
 *
 * @param string $label   Small label in the header, e.g. "Homepage plan".
 * @param string $rows    Inner table rows.
 * @param string $footer  Footer note.
 * @return string
 */
function vap_mail_layout( $label, $rows, $footer ) {
	$c     = vap_mail_style();
	$brand = vap_opt( 'from_name' ) ? vap_opt( 'from_name' ) : get_bloginfo( 'name' );
	$home  = home_url( '/' );
	$site  = preg_replace( '#^https?://#', '', untrailingslashit( $home ) );
	$logo  = $c['logo']
		? '<img src="' . esc_url( $c['logo'] ) . '" width="128" alt="' . esc_attr( $brand ) . '" style="display:block;width:128px;max-width:128px;height:auto;border:0">'
		: '<span style="font-family:' . $c['head'] . ';font-size:22px;font-weight:800;color:#ffffff">' . vap_e( $brand ) . '</span>';

	return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light only"><title>' . vap_e( $brand ) . '</title>'
		. '<style>body{margin:0;padding:0}a{color:' . $c['accent'] . '}@media (max-width:620px){.vap-pad{padding-left:22px!important;padding-right:22px!important}.vap-h1{font-size:26px!important}.vap-stack{display:block!important;width:100%!important;padding:0 0 10px!important}}</style></head>'
		. '<body style="margin:0;padding:0;background:' . $c['mist'] . '">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . $c['mist'] . '"><tr><td align="center" style="padding:28px 12px">'
		. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:22px;overflow:hidden;border:1px solid ' . $c['line'] . '">'
		// Header.
		. '<tr><td class="vap-pad" style="background:' . $c['ink'] . ';padding:26px 36px">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
		. '<td style="vertical-align:middle"><a href="' . esc_url( $home ) . '" style="text-decoration:none">' . $logo . '</a></td>'
		. '<td align="right" style="vertical-align:middle;font-family:' . $c['body'] . ';font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#f0a58f">' . vap_e( $label ) . '</td>'
		. '</tr></table></td></tr>'
		. '<tr><td style="height:4px;line-height:4px;font-size:0;background:' . $c['accent'] . '">&nbsp;</td></tr>'
		. $rows
		// Footer.
		. '<tr><td class="vap-pad" style="padding:22px 36px 30px;border-top:1px solid ' . $c['line'] . ';font-family:' . $c['body'] . ';font-size:12px;line-height:1.6;color:' . $c['soft'] . '">'
		. '<strong style="color:' . $c['ink'] . '">' . vap_e( $brand ) . '</strong> &middot; <a href="' . esc_url( $home ) . '" style="color:' . $c['accent'] . ';text-decoration:none">' . vap_e( $site ) . '</a>'
		. ( $footer ? '<br>' . vap_e( $footer ) : '' )
		. '</td></tr>'
		. '</table></td></tr></table></body></html>';
}

/** Pill button that also works in Outlook. */
function vap_mail_button( $label, $url ) {
	$c = vap_mail_style();
	return '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td style="border-radius:999px;background:' . $c['accent'] . '">'
		. '<a href="' . esc_url( $url ) . '" style="display:inline-block;padding:15px 30px;font-family:' . $c['body'] . ';font-size:16px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:999px">' . vap_e( $label ) . ' &rarr;</a>'
		. '</td></tr></table>';
}

/**
 * The plan itself: a browser-style preview of the hero, the section layout,
 * the features and the quick win.
 *
 * @param array $p Plan.
 * @return string Table rows.
 */
function vap_mail_plan_rows( $p ) {
	$c    = vap_mail_style();
	$b    = $c['body'];
	$h    = $c['head'];
	$rows = '';

	// Hero preview in a little browser window.
	$rows .= '<tr><td class="vap-pad" style="padding:6px 36px 8px">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid ' . $c['line'] . ';border-radius:16px;overflow:hidden">'
		. '<tr><td style="background:' . $c['mist'] . ';padding:10px 14px;border-bottom:1px solid ' . $c['line'] . ';font-size:0;line-height:0">'
		. '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:#e0765a;margin-right:6px"></span>'
		. '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:#e8b44a;margin-right:6px"></span>'
		. '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:#5cbf8a"></span>'
		. '</td></tr>'
		. '<tr><td style="background:' . $c['ink'] . ';padding:30px 28px 32px">'
		. '<p style="margin:0 0 10px;font-family:' . $b . ';font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#f0a58f">' . vap_e( __( 'Your new homepage', 'vyntic-ai-planner' ) ) . '</p>'
		. '<h1 class="vap-h1" style="margin:0 0 10px;font-family:' . $h . ';font-size:30px;line-height:1.15;font-weight:800;letter-spacing:-0.5px;color:#ffffff">' . vap_e( $p['headline'] ) . '</h1>'
		. ( ! empty( $p['subheadline'] ) ? '<p style="margin:0 0 20px;font-family:' . $b . ';font-size:16px;line-height:1.55;color:' . $c['on_dark'] . '">' . vap_e( $p['subheadline'] ) . '</p>' : '' )
		. '<span style="display:inline-block;padding:10px 20px;border-radius:999px;background:' . $c['accent'] . ';font-family:' . $b . ';font-size:14px;font-weight:700;color:#ffffff">' . vap_e( __( 'Get in touch', 'vyntic-ai-planner' ) ) . '</span>'
		. '</td></tr></table></td></tr>';

	// Sections, top to bottom.
	$list = '';
	$n    = 0;
	foreach ( (array) $p['sections'] as $s ) {
		++$n;
		$list .= '<tr>'
			. '<td width="44" valign="top" style="padding:14px 0;border-top:' . ( 1 === $n ? '0' : '1px solid ' . $c['line'] ) . '">'
			. '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" style="width:30px;height:30px;border-radius:50%;background:' . $c['blush'] . ';font-family:' . $b . ';font-size:14px;font-weight:800;color:' . $c['accent'] . '">' . $n . '</td></tr></table></td>'
			. '<td valign="top" style="padding:14px 0;border-top:' . ( 1 === $n ? '0' : '1px solid ' . $c['line'] ) . ';font-family:' . $b . '">'
			. '<p style="margin:0 0 3px;font-size:16px;font-weight:700;color:' . $c['ink'] . '">' . vap_e( $s['name'] ) . '</p>'
			. '<p style="margin:0;font-size:14px;line-height:1.5;color:' . $c['soft'] . '">' . vap_e( $s['why'] ) . '</p>'
			. '</td></tr>';
	}
	$rows .= '<tr><td class="vap-pad" style="padding:26px 36px 6px">'
		. '<h2 style="margin:0 0 4px;font-family:' . $h . ';font-size:20px;font-weight:800;color:' . $c['ink'] . '">' . vap_e( __( 'Homepage sections', 'vyntic-ai-planner' ) ) . '</h2>'
		. '<p style="margin:0 0 6px;font-family:' . $b . ';font-size:14px;color:' . $c['soft'] . '">' . vap_e( __( 'From the top of the page to the bottom.', 'vyntic-ai-planner' ) ) . '</p>'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">' . $list . '</table>'
		. '</td></tr>';

	// Features as cards.
	if ( ! empty( $p['features'] ) ) {
		$cells = '';
		$feats = array_slice( (array) $p['features'], 0, 3 );
		$w     = (int) floor( 100 / max( 1, count( $feats ) ) );
		$i     = 0;
		foreach ( $feats as $f ) {
			$pad    = ++$i < count( $feats ) ? 'padding:0 10px 0 0' : 'padding:0';
			$cells .= '<td class="vap-stack" width="' . $w . '%" valign="top" style="' . $pad . '">'
				. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . $c['mist'] . ';border-radius:14px"><tr><td style="padding:16px 16px 18px;font-family:' . $b . '">'
				. '<p style="margin:0 0 8px;font-size:16px;line-height:1;font-weight:800;color:' . $c['pass'] . '">&#10003;</p>'
				. '<p style="margin:0;font-size:14px;line-height:1.45;font-weight:700;color:' . $c['ink'] . '">' . vap_e( $f ) . '</p>'
				. '</td></tr></table></td>';
		}
		$rows .= '<tr><td class="vap-pad" style="padding:22px 36px 6px">'
			. '<h2 style="margin:0 0 14px;font-family:' . $h . ';font-size:20px;font-weight:800;color:' . $c['ink'] . '">' . vap_e( __( 'Must-have features', 'vyntic-ai-planner' ) ) . '</h2>'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>' . $cells . '</tr></table>'
			. '</td></tr>';
	}

	// Quick win.
	if ( ! empty( $p['quick_win'] ) ) {
		$rows .= '<tr><td class="vap-pad" style="padding:22px 36px 8px">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . $c['blush'] . ';border-radius:14px;border-left:4px solid ' . $c['accent'] . '"><tr><td style="padding:18px 20px;font-family:' . $b . '">'
			. '<p style="margin:0 0 6px;font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:' . $c['accent'] . '">' . vap_e( __( 'Quick win you can do today', 'vyntic-ai-planner' ) ) . '</p>'
			. '<p style="margin:0;font-size:15px;line-height:1.55;color:' . $c['ink'] . '">' . vap_e( $p['quick_win'] ) . '</p>'
			. '</td></tr></table></td></tr>';
	}
	return $rows;
}

/**
 * Email to the visitor with their plan.
 *
 * @param array $lead Lead.
 * @param array $p    Plan.
 * @return string
 */
function vap_mail_visitor_html( $lead, $p ) {
	$c     = vap_mail_style();
	$b     = $c['body'];
	$first = $lead['name'] ? $lead['name'] : __( 'there', 'vyntic-ai-planner' );
	$cta   = vap_opt( 'cta_url' ) ? vap_opt( 'cta_url' ) : home_url( '/contact/' );
	$brand = vap_opt( 'from_name' ) ? vap_opt( 'from_name' ) : get_bloginfo( 'name' );

	$rows = '<tr><td class="vap-pad" style="padding:32px 36px 18px;font-family:' . $b . '">'
		/* translators: %s visitor name */
		. '<p style="margin:0 0 10px;font-size:17px;font-weight:700;color:' . $c['ink'] . '">' . vap_e( sprintf( __( 'Hi %s,', 'vyntic-ai-planner' ), $first ) ) . '</p>'
		. '<p style="margin:0;font-size:15px;line-height:1.6;color:' . $c['soft'] . '">' . vap_e( __( 'Here is the homepage plan you asked for. It was written by AI from your description, so treat it as a starting point to shape, not a final brief.', 'vyntic-ai-planner' ) ) . '</p>'
		. '</td></tr>';

	$rows .= vap_mail_plan_rows( $p );

	// Call to action.
	$rows .= '<tr><td class="vap-pad" style="padding:22px 36px 10px">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . $c['ink'] . ';border-radius:18px"><tr><td style="padding:28px 28px 30px">'
		. '<h2 style="margin:0 0 8px;font-family:' . $c['head'] . ';font-size:22px;line-height:1.25;font-weight:800;color:#ffffff">' . vap_e( __( 'Want this built for real?', 'vyntic-ai-planner' ) ) . '</h2>'
		. '<p style="margin:0 0 20px;font-family:' . $b . ';font-size:15px;line-height:1.6;color:' . $c['on_dark'] . '">' . vap_e( __( 'Book a free call. We will go through your plan, suggest what to add, and give you a clear, fixed quote.', 'vyntic-ai-planner' ) ) . '</p>'
		. vap_mail_button( vap_opt( 'cta_label' ), $cta )
		. '<p style="margin:16px 0 0;font-family:' . $b . ';font-size:13px;color:' . $c['on_dark'] . '">' . vap_e( __( 'Or simply reply to this email.', 'vyntic-ai-planner' ) ) . '</p>'
		. '</td></tr></table></td></tr>';

	// Sign-off.
	$rows .= '<tr><td class="vap-pad" style="padding:18px 36px 28px;font-family:' . $b . ';font-size:15px;line-height:1.6;color:' . $c['ink'] . '">'
		/* translators: %s brand */
		. vap_e( __( 'Best wishes,', 'vyntic-ai-planner' ) ) . '<br><strong>' . vap_e( sprintf( __( 'The %s team', 'vyntic-ai-planner' ), $brand ) ) . '</strong></td></tr>';

	return vap_mail_layout( __( 'Homepage plan', 'vyntic-ai-planner' ), $rows, __( 'You are receiving this because you asked for a homepage plan on our website. We do not add you to any mailing list.', 'vyntic-ai-planner' ) );
}

/** Plain-text version of the visitor email. */
function vap_mail_visitor_text( $lead, $p ) {
	$first = $lead['name'] ? $lead['name'] : __( 'there', 'vyntic-ai-planner' );
	$cta   = vap_opt( 'cta_url' ) ? vap_opt( 'cta_url' ) : home_url( '/contact/' );
	$brand = vap_opt( 'from_name' ) ? vap_opt( 'from_name' ) : get_bloginfo( 'name' );
	/* translators: %s visitor name */
	$t  = sprintf( __( 'Hi %s,', 'vyntic-ai-planner' ), $first ) . "\n\n";
	$t .= __( 'Here is the homepage plan you asked for. It was written by AI from your description, so treat it as a starting point to shape, not a final brief.', 'vyntic-ai-planner' ) . "\n\n";
	$t .= strtoupper( $p['headline'] ) . "\n" . ( ! empty( $p['subheadline'] ) ? $p['subheadline'] . "\n" : '' ) . "\n";
	$t .= __( 'Homepage sections', 'vyntic-ai-planner' ) . ":\n";
	$n  = 0;
	foreach ( (array) $p['sections'] as $s ) {
		$t .= ( ++$n ) . '. ' . $s['name'] . ': ' . $s['why'] . "\n";
	}
	if ( ! empty( $p['features'] ) ) {
		$t .= "\n" . __( 'Must-have features', 'vyntic-ai-planner' ) . ":\n- " . implode( "\n- ", (array) $p['features'] ) . "\n";
	}
	if ( ! empty( $p['quick_win'] ) ) {
		$t .= "\n" . __( 'Quick win:', 'vyntic-ai-planner' ) . ' ' . $p['quick_win'] . "\n";
	}
	$t .= "\n" . __( 'Want this built for real? Book a free call:', 'vyntic-ai-planner' ) . ' ' . $cta . "\n" . __( 'Or simply reply to this email.', 'vyntic-ai-planner' ) . "\n\n";
	/* translators: %s brand */
	$t .= __( 'Best wishes,', 'vyntic-ai-planner' ) . "\n" . sprintf( __( 'The %s team', 'vyntic-ai-planner' ), $brand ) . "\n" . home_url( '/' ) . "\n";
	return $t;
}

/**
 * Lead alert for the studio.
 *
 * @param array      $lead Lead.
 * @param array|null $p    Plan or null.
 * @return string
 */
function vap_mail_owner_html( $lead, $p ) {
	$c    = vap_mail_style();
	$b    = $c['body'];
	$line = function ( $k, $v ) use ( $c, $b ) {
		return '<tr><td width="90" valign="top" style="padding:8px 0;border-top:1px solid ' . $c['line'] . ';font-family:' . $b . ';font-size:13px;font-weight:700;color:' . $c['soft'] . '">' . vap_e( $k ) . '</td>'
			. '<td valign="top" style="padding:8px 0;border-top:1px solid ' . $c['line'] . ';font-family:' . $b . ';font-size:15px;color:' . $c['ink'] . '">' . $v . '</td></tr>';
	};
	$rows = '<tr><td class="vap-pad" style="padding:30px 36px 10px;font-family:' . $b . '">'
		. '<h1 style="margin:0 0 6px;font-family:' . $c['head'] . ';font-size:24px;font-weight:800;color:' . $c['ink'] . '">' . vap_e( __( 'New lead from the AI planner', 'vyntic-ai-planner' ) ) . '</h1>'
		. ( $p
			? '<p style="margin:0 0 16px;font-size:14px;color:' . $c['pass'] . ';font-weight:700">&#10003; ' . vap_e( __( 'Their plan was emailed to them.', 'vyntic-ai-planner' ) ) . '</p>'
			: '<p style="margin:0 0 16px;font-size:14px;color:#d6322e;font-weight:700">' . vap_e( __( 'The AI could not create a plan, so reply to this lead personally.', 'vyntic-ai-planner' ) ) . '</p>' )
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'
		. $line( __( 'Name', 'vyntic-ai-planner' ), vap_e( $lead['name'] ? $lead['name'] : '-' ) )
		. $line( __( 'Email', 'vyntic-ai-planner' ), '<a href="mailto:' . esc_attr( $lead['email'] ) . '" style="color:' . $c['accent'] . '">' . vap_e( $lead['email'] ) . '</a>' )
		. $line( __( 'Goal', 'vyntic-ai-planner' ), vap_e( $lead['goal'] ) )
		. $line( __( 'Business', 'vyntic-ai-planner' ), nl2br( vap_e( $lead['business'] ) ) )
		. ( ! empty( $lead['page'] ) ? $line( __( 'Page', 'vyntic-ai-planner' ), '<a href="' . esc_url( $lead['page'] ) . '" style="color:' . $c['accent'] . '">' . vap_e( preg_replace( '#^https?://#', '', $lead['page'] ) ) . '</a>' ) : '' )
		. '</table></td></tr>'
		. '<tr><td class="vap-pad" style="padding:14px 36px 8px">'
		/* translators: %s name or email */
		. vap_mail_button( sprintf( __( 'Reply to %s', 'vyntic-ai-planner' ), $lead['name'] ? $lead['name'] : $lead['email'] ), 'mailto:' . $lead['email'] )
		. '<p style="margin:12px 0 0;font-family:' . $b . ';font-size:13px"><a href="' . esc_url( admin_url( 'edit.php?post_type=vap_lead' ) ) . '" style="color:' . $c['accent'] . '">' . vap_e( __( 'See all leads', 'vyntic-ai-planner' ) ) . '</a></p>'
		. '</td></tr>';
	if ( $p ) {
		$rows .= '<tr><td class="vap-pad" style="padding:22px 36px 4px;font-family:' . $b . ';font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:' . $c['soft'] . '">' . vap_e( __( 'The plan they received', 'vyntic-ai-planner' ) ) . '</td></tr>'
			. vap_mail_plan_rows( $p )
			. '<tr><td style="height:20px;line-height:20px;font-size:0">&nbsp;</td></tr>';
	}
	return vap_mail_layout( __( 'New lead', 'vyntic-ai-planner' ), $rows, __( 'Sent by the Vyntic AI Planner plugin.', 'vyntic-ai-planner' ) );
}

/** Plain-text version of the lead alert. */
function vap_mail_owner_text( $lead, $p ) {
	$t  = __( 'New lead from the AI planner', 'vyntic-ai-planner' ) . "\n\n";
	$t .= __( 'Name', 'vyntic-ai-planner' ) . ': ' . ( $lead['name'] ? $lead['name'] : '-' ) . "\n";
	$t .= __( 'Email', 'vyntic-ai-planner' ) . ': ' . $lead['email'] . "\n";
	$t .= __( 'Goal', 'vyntic-ai-planner' ) . ': ' . $lead['goal'] . "\n";
	$t .= __( 'Business', 'vyntic-ai-planner' ) . ': ' . $lead['business'] . "\n\n";
	$t .= $p ? __( 'Their plan was emailed to them.', 'vyntic-ai-planner' ) . ' ' . __( 'Headline', 'vyntic-ai-planner' ) . ': ' . $p['headline'] . "\n" : __( 'The AI could not create a plan, so reply to this lead personally.', 'vyntic-ai-planner' ) . "\n";
	$t .= "\n" . __( 'All leads', 'vyntic-ai-planner' ) . ': ' . admin_url( 'edit.php?post_type=vap_lead' ) . "\n";
	return $t;
}

/**
 * Send an HTML email with a plain-text part.
 *
 * @param string $to      Recipient.
 * @param string $subject Subject.
 * @param string $html    HTML body.
 * @param string $text    Text body.
 * @param array  $headers Extra headers.
 * @return bool
 */
function vap_mail( $to, $subject, $html, $text, $headers = array() ) {
	$alt = function ( $phpmailer ) use ( $text ) {
		$phpmailer->AltBody = $text; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
	};
	add_action( 'phpmailer_init', $alt );
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	$ok        = wp_mail( $to, $subject, $html, $headers );
	remove_action( 'phpmailer_init', $alt );
	return $ok;
}
