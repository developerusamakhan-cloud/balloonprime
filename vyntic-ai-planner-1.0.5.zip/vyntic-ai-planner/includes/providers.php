<?php
/**
 * AI providers. All calls run on the server, so API keys never reach the browser.
 *
 * @package VynticAIPlanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate text with the main provider, then the backup if it fails.
 *
 * @param string $system System instruction.
 * @param string $prompt User prompt.
 * @return string|WP_Error
 */
function vap_generate( $system, $prompt ) {
	// Lets tests or other plugins supply an answer.
	$pre = apply_filters( 'vap_pre_generate', null, $system, $prompt );
	if ( null !== $pre ) {
		return $pre;
	}

	$main  = vap_opt( 'provider' );
	$order = array( $main );
	if ( vap_opt( 'fallback' ) ) {
		foreach ( array( 'gemini', 'openai', 'wp' ) as $p ) {
			if ( $p !== $main ) {
				$order[] = $p;
			}
		}
	}

	$errors = array();
	foreach ( $order as $provider ) {
		if ( ! vap_provider_ready( $provider ) ) {
			continue;
		}
		$fn  = 'vap_call_' . $provider;
		$res = $fn( $system, $prompt );
		if ( ! is_wp_error( $res ) && '' !== trim( (string) $res ) ) {
			return $res;
		}
		$errors[] = vap_provider_label( $provider ) . ': ' . ( is_wp_error( $res ) ? $res->get_error_message() : __( 'empty answer', 'vyntic-ai-planner' ) );
	}
	if ( ! $errors ) {
		return new WP_Error( 'vap_no_provider', __( 'No AI provider is set up yet. Add an API key under AI Planner, Settings.', 'vyntic-ai-planner' ) );
	}
	// Show every provider's error, so the real cause is not hidden behind the last one.
	return new WP_Error( 'vap_failed', implode( ' | ', $errors ) );
}

/** Human name of a provider. */
function vap_provider_label( $provider ) {
	$labels = array(
		'gemini' => 'Gemini',
		'openai' => __( 'Backup API', 'vyntic-ai-planner' ),
		'wp'     => __( 'WordPress AI Client', 'vyntic-ai-planner' ),
	);
	return isset( $labels[ $provider ] ) ? $labels[ $provider ] : $provider;
}

/** Whether a provider has what it needs. */
function vap_provider_ready( $provider ) {
	switch ( $provider ) {
		case 'gemini':
			return (bool) vap_opt( 'gemini_key' );
		case 'openai':
			return vap_opt( 'oa_key' ) && vap_opt( 'oa_base' ) && vap_opt( 'oa_model' );
		case 'wp':
			return vap_wp_ai_ready();
	}
	return false;
}

/** Friendly error from an HTTP response. */
function vap_http_error( $res, $name ) {
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	$msg  = '';
	if ( isset( $body['error']['message'] ) ) {
		$msg = $body['error']['message'];
	} elseif ( isset( $body['message'] ) ) {
		$msg = $body['message'];
	}
	if ( 429 === (int) $code ) {
		$msg = __( 'free limit reached for now', 'vyntic-ai-planner' ) . ( $msg ? ' (' . $msg . ')' : '' );
	}
	/* translators: 1: provider, 2: HTTP code, 3: message */
	return new WP_Error( 'vap_http', sprintf( __( '%1$s error %2$s: %3$s', 'vyntic-ai-planner' ), $name, $code, wp_strip_all_tags( $msg ) ), array( 'status' => $code ) );
}

/**
 * Whether the WordPress AI Client has a provider set up (Settings, Connectors).
 * WordPress 7 always has the function, even when nothing is connected.
 */
function vap_wp_ai_ready() {
	if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
		return false;
	}
	try {
		$b = wp_ai_client_prompt( 'Test' );
		if ( is_callable( array( $b, 'is_supported_for_text_generation' ) ) ) {
			return (bool) $b->is_supported_for_text_generation();
		}
	} catch ( \Throwable $e ) {
		return false;
	}
	return 'wp' === vap_opt( 'provider' );
}

/**
 * One Gemini request, trying each way of sending the key.
 * Tries the key in the header, then as ?key= (needed by some newer "AQ." keys),
 * then the Vertex AI express endpoint, which also accepts "AQ." keys.
 *
 * @param string $key   API key.
 * @param string $model Model name.
 * @param string $body  JSON body.
 * @return string|WP_Error Text, or an error with the HTTP code in its data.
 */
function vap_gemini_request( $key, $model, $body ) {
	$model    = rawurlencode( preg_replace( '#^models/#', '', trim( (string) $model ) ) );
	$gl       = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';
	$attempts = array(
		array( $gl, array( 'x-goog-api-key' => $key ) ),
		array( add_query_arg( 'key', rawurlencode( $key ), $gl ), array() ),
	);
	if ( 0 === strpos( $key, 'AQ.' ) ) {
		$attempts[] = array( add_query_arg( 'key', rawurlencode( $key ), 'https://aiplatform.googleapis.com/v1/publishers/google/models/' . $model . ':generateContent' ), array() );
	}

	$first = null;
	foreach ( $attempts as $a ) {
		$res  = wp_remote_post(
			$a[0],
			array(
				'timeout' => 45,
				'headers' => array( 'Content-Type' => 'application/json' ) + $a[1],
				'body'    => $body,
			)
		);
		$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
		if ( 200 === $code ) {
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			$text = '';
			if ( ! empty( $data['candidates'][0]['content']['parts'] ) ) {
				foreach ( $data['candidates'][0]['content']['parts'] as $part ) {
					if ( isset( $part['text'] ) && empty( $part['thought'] ) ) {
						$text .= $part['text'];
					}
				}
			}
			return $text ? $text : new WP_Error( 'vap_empty', __( 'Gemini returned no text.', 'vyntic-ai-planner' ) );
		}
		if ( null === $first ) {
			$first = vap_http_error( $res, 'Gemini' );
		}
		// Only a rejected key is worth another way of sending it. Limits, model errors and
		// network errors come back the same every time.
		if ( ! in_array( $code, array( 400, 401, 403 ), true ) ) {
			break;
		}
	}
	return $first;
}

/**
 * Whether an error means the model name is wrong or retired.
 *
 * @param WP_Error $err Error.
 * @return bool
 */
function vap_is_model_error( $err ) {
	if ( ! is_wp_error( $err ) ) {
		return false;
	}
	$data = $err->get_error_data();
	$code = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
	$msg  = strtolower( $err->get_error_message() );
	return 404 === $code || ( 400 === $code && false !== strpos( $msg, 'model' ) && ( false !== strpos( $msg, 'not' ) || false !== strpos( $msg, 'decommission' ) ) );
}

/**
 * Save a model the plugin picked by itself, so the next request uses it straight away.
 *
 * @param string $field Setting key.
 * @param string $model Model name.
 */
function vap_save_model( $field, $model ) {
	$all           = (array) get_option( 'vap_settings', array() );
	$all[ $field ] = $model;
	remove_all_filters( 'sanitize_option_vap_settings' );
	update_option( 'vap_settings', $all );
	update_option( 'vap_model_note', array( 'field' => $field, 'model' => $model, 'time' => time() ), false );
}

/**
 * Pick a working Gemini model from the models this key can use.
 * Prefers the name Google suggests in its error, then the newest Flash model.
 *
 * @param string $key       API key.
 * @param string $suggested Model name from Google's error message.
 * @return string Empty when nothing suitable is found.
 */
function vap_gemini_pick_model( $key, $suggested = '' ) {
	$res = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', array( 'timeout' => 20, 'headers' => array( 'x-goog-api-key' => $key ) ) );
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		$res = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=' . rawurlencode( $key ), array( 'timeout' => 20 ) );
	}
	$names = array();
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		foreach ( (array) ( isset( $data['models'] ) ? $data['models'] : array() ) as $m ) {
			$name = isset( $m['name'] ) ? preg_replace( '#^models/#', '', $m['name'] ) : '';
			if ( $name && in_array( 'generateContent', (array) ( isset( $m['supportedGenerationMethods'] ) ? $m['supportedGenerationMethods'] : array() ), true ) ) {
				$names[] = $name;
			}
		}
	}
	if ( $suggested && ( ! $names || in_array( $suggested, $names, true ) ) ) {
		return $suggested;
	}
	$best  = '';
	$score = -1;
	foreach ( $names as $n ) {
		if ( false === strpos( $n, 'flash' ) || preg_match( '/image|tts|audio|live|embed|thinking|exp|computer|robotics/', $n ) ) {
			continue;
		}
		preg_match( '/gemini-(\d+(?:\.\d+)?)/', $n, $v );
		$s = ( isset( $v[1] ) ? (float) $v[1] * 100 : 0 )
			+ ( false === strpos( $n, 'lite' ) ? 5 : 0 )
			+ ( false === strpos( $n, 'preview' ) ? 3 : 0 )
			+ ( preg_match( '/-\d{3}$|-\d{2}-\d{4}$/', $n ) ? 0 : 1 );
		if ( $s > $score ) {
			$score = $s;
			$best  = $n;
		}
	}
	return $best;
}

/** Google Gemini (Google AI Studio key, free tier on Flash models). */
function vap_call_gemini( $system, $prompt ) {
	$key  = trim( (string) vap_opt( 'gemini_key' ) );
	$body = wp_json_encode(
		array(
			'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
			'contents'          => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $prompt ) ) ) ),
			'generationConfig'  => array(
				'temperature'      => 0.7,
				'maxOutputTokens'  => 4096,
				'responseMimeType' => 'application/json',
			),
		)
	);
	$res = vap_gemini_request( $key, vap_opt( 'gemini_model' ), $body );

	// Model retired or renamed: pick a current one from the key's model list and retry once.
	if ( vap_is_model_error( $res ) ) {
		$suggested = preg_match( '#use (?:models/)?([a-z0-9.\-]+)#i', $res->get_error_message(), $m ) ? rtrim( $m[1], '.' ) : '';
		$model     = vap_gemini_pick_model( $key, $suggested );
		if ( $model && $model !== vap_opt( 'gemini_model' ) ) {
			$retry = vap_gemini_request( $key, $model, $body );
			if ( ! is_wp_error( $retry ) ) {
				vap_save_model( 'gemini_model', $model );
				return $retry;
			}
			$res = $retry;
		}
	}

	if ( is_wp_error( $res ) && false !== strpos( $res->get_error_message(), 'OAuth 2' ) ) {
		return new WP_Error( 'vap_http', __( 'Gemini did not accept this key. In Google AI Studio open "Get API key", click "Create API key", copy the whole key and paste it again. Check the Gemini API is enabled for that project.', 'vyntic-ai-planner' ) . ' (' . $res->get_error_message() . ')' );
	}
	return $res;
}

/**
 * Pick a chat model from an OpenAI-compatible /models list (Groq, OpenRouter, OpenAI).
 *
 * @return string Empty when nothing suitable is found.
 */
function vap_openai_pick_model() {
	$res = wp_remote_get(
		trailingslashit( vap_opt( 'oa_base' ) ) . 'models',
		array(
			'timeout' => 20,
			'headers' => array( 'Authorization' => 'Bearer ' . vap_opt( 'oa_key' ) ),
		)
	);
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return '';
	}
	$data  = json_decode( wp_remote_retrieve_body( $res ), true );
	$best  = '';
	$score = -1;
	foreach ( (array) ( isset( $data['data'] ) ? $data['data'] : array() ) as $m ) {
		$id = isset( $m['id'] ) ? (string) $m['id'] : '';
		if ( '' === $id || ( isset( $m['active'] ) && ! $m['active'] ) || preg_match( '/whisper|tts|audio|guard|embed|vision|image|moderation|transcri|speech|compound|search|realtime|dall-e|playai|orpheus/i', $id ) ) {
			continue;
		}
		$s = 0;
		foreach ( array( 'versatile' => 40, '70b' => 30, '120b' => 35, 'gpt-oss' => 25, 'llama' => 20, 'qwen' => 15, 'mini' => 10, 'instruct' => 5, ':free' => 50 ) as $needle => $pts ) {
			if ( false !== stripos( $id, $needle ) ) {
				$s += $pts;
			}
		}
		if ( $s > $score ) {
			$score = $s;
			$best  = $id;
		}
	}
	return $best;
}

/** One request to an OpenAI-compatible chat API. */
function vap_openai_request( $system, $prompt, $model ) {
	$payload = array(
		'model'           => $model,
		'temperature'     => 0.7,
		'max_tokens'      => 1500,
		'messages'        => array(
			array( 'role' => 'system', 'content' => $system ),
			array( 'role' => 'user', 'content' => $prompt ),
		),
		'response_format' => array( 'type' => 'json_object' ),
	);
	$args = array(
		'timeout' => 45,
		'headers' => array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . vap_opt( 'oa_key' ),
			'HTTP-Referer'  => home_url( '/' ),
			'X-Title'       => get_bloginfo( 'name' ),
		),
	);
	$url = trailingslashit( vap_opt( 'oa_base' ) ) . 'chat/completions';
	$res = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );

	// Some models do not support JSON mode. Retry once without it.
	if ( ! is_wp_error( $res ) && 400 === (int) wp_remote_retrieve_response_code( $res ) && false !== stripos( wp_remote_retrieve_body( $res ), 'response_format' ) ) {
		unset( $payload['response_format'] );
		$res = wp_remote_post( $url, $args + array( 'body' => wp_json_encode( $payload ) ) );
	}
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return vap_http_error( $res, 'API' );
	}
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	return isset( $body['choices'][0]['message']['content'] ) ? (string) $body['choices'][0]['message']['content'] : new WP_Error( 'vap_empty', __( 'The API returned no text.', 'vyntic-ai-planner' ) );
}

/** Any OpenAI-compatible chat API (Groq, OpenRouter, OpenAI, Together and more). */
function vap_call_openai( $system, $prompt ) {
	$res = vap_openai_request( $system, $prompt, vap_opt( 'oa_model' ) );
	// Model retired or renamed: pick a current one from the provider's model list and retry once.
	if ( vap_is_model_error( $res ) ) {
		$model = vap_openai_pick_model();
		if ( $model && $model !== vap_opt( 'oa_model' ) ) {
			$retry = vap_openai_request( $system, $prompt, $model );
			if ( ! is_wp_error( $retry ) ) {
				vap_save_model( 'oa_model', $model );
				return $retry;
			}
			$res = $retry;
		}
	}
	return $res;
}

/** WordPress AI Client (WordPress 7.0+, provider set in Settings, Connectors). */
function vap_call_wp( $system, $prompt ) {
	try {
		$builder = wp_ai_client_prompt( $prompt );
		if ( is_callable( array( $builder, 'using_system_instruction' ) ) ) {
			$builder = $builder->using_system_instruction( $system );
		} else {
			$builder = wp_ai_client_prompt( $system . "\n\n" . $prompt );
		}
		if ( is_callable( array( $builder, 'using_max_tokens' ) ) ) {
			$builder = $builder->using_max_tokens( 1500 );
		}
		$text = $builder->generate_text();
		return is_string( $text ) ? $text : ( is_wp_error( $text ) ? $text : new WP_Error( 'vap_empty', 'Empty answer' ) );
	} catch ( \Throwable $e ) {
		return new WP_Error( 'vap_wp_ai', $e->getMessage() );
	}
}

/**
 * Pull the JSON object out of a model answer.
 *
 * @param string $text Raw answer.
 * @return array|null
 */
function vap_parse_json( $text ) {
	$text  = trim( preg_replace( '/^```(?:json)?|```$/m', '', (string) $text ) );
	$start = strpos( $text, '{' );
	$end   = strrpos( $text, '}' );
	if ( false === $start || false === $end ) {
		return null;
	}
	$data = json_decode( substr( $text, $start, $end - $start + 1 ), true );
	return is_array( $data ) ? $data : null;
}
