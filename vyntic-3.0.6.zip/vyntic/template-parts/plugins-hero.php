<?php
/**
 * Animated illustration for the plugins page intro: a WordPress dashboard
 * where a plugin is switched on, the PageSpeed gauge climbs into the green
 * and an update arrives. Pure HTML, SVG and CSS; decorative only.
 *
 * @package Vyntic
 */

?>
<div class="phero" aria-hidden="true">
	<div class="phero__glow"></div>

	<div class="phero__win">
		<div class="phero__bar">
			<i></i><i></i><i></i>
			<span class="phero__url">yoursite.com/wp-admin</span>
		</div>
		<div class="phero__body">
			<div class="phero__side">
				<span class="phero__logo"><svg viewBox="0 0 108 108"><polygon points="2,12 30,12 62,96 34,96" fill="#ffffff"/><polygon points="76,12 104,12 82,64 56,64" fill="#c7431f"/></svg></span>
				<span class="phero__nav"></span>
				<span class="phero__nav"></span>
				<span class="phero__nav is-on"><svg viewBox="0 0 20 20"><path fill="currentColor" d="M10 3a8 8 0 0 0-7.7 10.2 1 1 0 0 0 1 .8h13.4a1 1 0 0 0 1-.8A8 8 0 0 0 10 3zm0 2a6 6 0 0 1 5.9 7H4.1A6 6 0 0 1 10 5z"/><path fill="currentColor" d="M13.6 6.7l-3 4a1.4 1.4 0 1 1-1.2-.9l3.4-3.7z"/></svg></span>
				<span class="phero__nav"></span>
				<span class="phero__nav"></span>
			</div>
			<div class="phero__main">
				<div class="phero__plugin">
					<span class="phero__picon"><svg viewBox="0 0 20 20"><path fill="currentColor" d="M10 3a8 8 0 0 0-7.7 10.2 1 1 0 0 0 1 .8h13.4a1 1 0 0 0 1-.8A8 8 0 0 0 10 3zm0 2a6 6 0 0 1 5.9 7H4.1A6 6 0 0 1 10 5z"/><path fill="currentColor" d="M13.6 6.7l-3 4a1.4 1.4 0 1 1-1.2-.9l3.4-3.7z"/></svg></span>
					<span class="phero__pname"><b>Speed Optimizer</b><small>by Vyntic Studio</small></span>
					<span class="phero__toggle"><i></i></span>
				</div>
				<div class="phero__score">
					<div class="phero__gauge">
						<svg viewBox="0 0 120 120">
							<circle cx="60" cy="60" r="50" class="phero__track"/>
							<circle cx="60" cy="60" r="50" class="phero__arc" pathLength="100"/>
						</svg>
						<span class="phero__num"></span>
					</div>
					<div class="phero__metrics">
						<span><em>LCP</em><i style="--w:88%"></i></span>
						<span><em>TBT</em><i style="--w:96%"></i></span>
						<span><em>CLS</em><i style="--w:92%"></i></span>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="phero__chip phero__chip--update">
		<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3M18 3v4h-4M6 21v-4h4" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
		<span><b>Update installed</b><small>Automatically</small></span>
	</div>

	<div class="phero__chip phero__chip--zip">
		<span class="phero__zip"><svg viewBox="0 0 24 24"><path d="M12 4v11M7 10l5 5 5-5M5 20h14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
		<span><b>plugin.zip</b><small>Free download</small></span>
	</div>

	<span class="phero__spark phero__spark--a"></span>
	<span class="phero__spark phero__spark--b"></span>
</div>
