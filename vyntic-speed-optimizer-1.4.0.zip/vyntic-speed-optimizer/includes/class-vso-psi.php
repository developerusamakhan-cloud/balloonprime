<?php
/**
 * PageSpeed Insights: running a test, saving every report, the weekly
 * automatic check and the WordPress Dashboard widget.
 *
 * @package VynticSpeedOptimizer
 */

defined( 'ABSPATH' ) || exit;

class VSO_PSI {

	const HOOK    = 'vso_psi_weekly';
	const LAST    = 'vso_psi_last';
	const HISTORY = 'vso_psi_history';
	const KEEP    = 12;

	/**
	 * Lighthouse audit id => short label.
	 */
	const METRICS = array(
		'first-contentful-paint'   => 'FCP',
		'largest-contentful-paint' => 'LCP',
		'total-blocking-time'      => 'TBT',
		'cumulative-layout-shift'  => 'CLS',
		'speed-index'              => 'SI',
	);

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'scheduled' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget' ) );
		add_action( 'vso_settings_updated', array( __CLASS__, 'schedule' ) );
	}

	/**
	 * Weekly check on (setting on) or off.
	 */
	public static function schedule() {
		$next = wp_next_scheduled( self::HOOK );
		if ( ! VSO_Settings::enabled( 'psi_weekly' ) ) {
			if ( $next ) {
				wp_clear_scheduled_hook( self::HOOK );
			}
			return;
		}
		if ( ! $next ) {
			// No report yet: run soon so the widget has data. Otherwise a week after the last one.
			$last  = self::last();
			$start = empty( $last['time'] ) ? time() + 10 * MINUTE_IN_SECONDS : max( time() + HOUR_IN_SECONDS, (int) $last['time'] + WEEK_IN_SECONDS );
			wp_schedule_event( $start, 'weekly', self::HOOK );
		}
	}

	/**
	 * One test. Returns the result array or WP_Error.
	 */
	public static function run( $url, $strategy ) {
		$args = array(
			'url'      => $url,
			'strategy' => 'desktop' === $strategy ? 'desktop' : 'mobile',
			'category' => 'performance',
		);
		$key = trim( (string) VSO_Settings::get( 'psi_api_key' ) );
		if ( '' !== $key ) {
			$args['key'] = $key;
		}
		$response = wp_remote_get( add_query_arg( $args, 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed' ), array( 'timeout' => 90 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['lighthouseResult']['categories']['performance'] ) ) {
			$message = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'PageSpeed Insights did not return a result.', 'vyntic-speed-optimizer' );
			return new WP_Error( 'vso_psi', $message );
		}
		return self::parse( $body['lighthouseResult'] );
	}

	/**
	 * Keeps only what the screens need: score, five metrics and the top fixes.
	 */
	public static function parse( array $lh ) {
		$audits  = isset( $lh['audits'] ) ? $lh['audits'] : array();
		$metrics = array();
		foreach ( self::METRICS as $audit => $label ) {
			if ( isset( $audits[ $audit ] ) ) {
				$metrics[ $label ] = array(
					'value' => isset( $audits[ $audit ]['displayValue'] ) ? str_replace( "\xc2\xa0", ' ', $audits[ $audit ]['displayValue'] ) : '',
					'score' => isset( $audits[ $audit ]['score'] ) ? (float) $audits[ $audit ]['score'] : 0,
				);
			}
		}

		// Opportunities with the biggest time savings first.
		$fixes = array();
		foreach ( $audits as $audit ) {
			if ( empty( $audit['details']['type'] ) || 'opportunity' !== $audit['details']['type'] || ! isset( $audit['score'] ) || $audit['score'] >= 0.9 ) {
				continue;
			}
			$ms = isset( $audit['details']['overallSavingsMs'] ) ? (float) $audit['details']['overallSavingsMs'] : 0;
			if ( $ms < 100 ) {
				continue;
			}
			$fixes[] = array(
				'title' => isset( $audit['title'] ) ? wp_strip_all_tags( $audit['title'] ) : '',
				'save'  => round( $ms / 1000, 1 ),
			);
		}
		usort(
			$fixes,
			static function ( $a, $b ) {
				return $b['save'] <=> $a['save'];
			}
		);

		return array(
			'score'   => (int) round( 100 * (float) $lh['categories']['performance']['score'] ),
			'metrics' => $metrics,
			'fixes'   => array_slice( $fixes, 0, 4 ),
		);
	}

	/**
	 * Saves one strategy's result. Mobile and desktop from the same run share
	 * one history row, matched by $run (any id the caller keeps for both).
	 */
	public static function save( $url, $strategy, array $result, $run, $source = 'manual' ) {
		$time = time();

		$last              = self::last();
		$last[ $strategy ] = $result;
		$last['time']      = $time;
		$last['url']       = $url;
		$last['source']    = $source;
		update_option( self::LAST, $last, false );

		$history = self::history();
		$found   = false;
		foreach ( $history as $i => $row ) {
			if ( isset( $row['run'] ) && (string) $row['run'] === (string) $run ) {
				$history[ $i ][ $strategy ] = $result['score'];
				$history[ $i ]['time']      = $time;
				$found                      = true;
				break;
			}
		}
		if ( ! $found ) {
			array_unshift(
				$history,
				array(
					'run'     => (string) $run,
					'time'    => $time,
					'url'     => $url,
					'source'  => $source,
					$strategy => $result['score'],
				)
			);
		}
		update_option( self::HISTORY, array_slice( $history, 0, self::KEEP ), false );
	}

	public static function last() {
		$last = get_option( self::LAST, array() );
		return is_array( $last ) ? $last : array();
	}

	public static function history() {
		$history = get_option( self::HISTORY, array() );
		return is_array( $history ) ? array_values( $history ) : array();
	}

	/**
	 * Everything the dashboard tab draws.
	 */
	public static function state() {
		$next = wp_next_scheduled( self::HOOK );
		return array(
			'last'    => (object) self::last(),
			'history' => self::history(),
			'next'    => $next ? (int) $next : 0,
		);
	}

	/**
	 * The weekly check: the home page, mobile then desktop.
	 */
	public static function scheduled() {
		if ( ! VSO_Settings::enabled( 'psi_weekly' ) ) {
			return;
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore -- two PageSpeed runs.
		}
		$url = home_url( '/' );
		$run = 'auto-' . time();
		foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
			$result = self::run( $url, $strategy );
			if ( is_wp_error( $result ) ) {
				update_option( 'vso_psi_error', array( 'time' => time(), 'message' => $result->get_error_message() ), false );
				return;
			}
			self::save( $url, $strategy, $result, $run, 'auto' );
		}
		delete_option( 'vso_psi_error' );
	}

	/* ---------------------------------------------------------------------
	 * Dashboard widget
	 * ------------------------------------------------------------------- */

	public static function widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_add_dashboard_widget( 'vso_psi_widget', __( 'PageSpeed score', 'vyntic-speed-optimizer' ) . ' <span class="vso-w-by">Vyntic</span>', array( __CLASS__, 'render_widget' ) );
	}

	public static function color( $score ) {
		return $score >= 90 ? '#0e9f6a' : ( $score >= 50 ? '#c77c00' : '#d6322e' );
	}

	private static function gauge( $score, $size ) {
		$r   = $size / 2 - 5;
		$c   = 2 * M_PI * $r;
		$off = $c * ( 1 - $score / 100 );
		$mid = $size / 2;
		return '<span class="vso-w-gauge" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px"><svg width="' . (int) $size . '" height="' . (int) $size . '" aria-hidden="true">'
			. '<circle cx="' . $mid . '" cy="' . $mid . '" r="' . $r . '" fill="none" stroke="#eef3f1" stroke-width="7"/>'
			. '<circle cx="' . $mid . '" cy="' . $mid . '" r="' . $r . '" fill="none" stroke="' . self::color( $score ) . '" stroke-width="7" stroke-linecap="round" stroke-dasharray="' . round( $c, 2 ) . '" stroke-dashoffset="' . round( $off, 2 ) . '" transform="rotate(-90 ' . $mid . ' ' . $mid . ')"/>'
			. '</svg><b style="color:' . self::color( $score ) . '">' . (int) $score . '</b></span>';
	}

	public static function render_widget() {
		$last    = self::last();
		$history = self::history();
		$page    = VSO_Admin::url( 'dashboard' );
		$run     = add_query_arg( 'vso_psi_run', 1, $page ) . '#vso-psi';
		$next    = wp_next_scheduled( self::HOOK );
		$error   = get_option( 'vso_psi_error' );

		echo '<style>
			#vso_psi_widget .vso-w-by{margin-left:6px;padding:1px 7px;border-radius:99px;background:#0f2b2e;color:#fff;font-size:10px;font-weight:600;vertical-align:middle}
			.vso-w{color:#0f2b2e}
			.vso-w-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
			.vso-w-card{display:flex;align-items:center;gap:12px;padding:12px;border:1px solid #d5e0dd;border-radius:12px}
			.vso-w-gauge{position:relative;flex:none}
			.vso-w-gauge b{position:absolute;inset:0;display:grid;place-items:center;font-size:20px}
			.vso-w-card h4{margin:0 0 4px;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#4a6266}
			.vso-w-card p{margin:0;font-size:12px;line-height:1.5;color:#4a6266}
			.vso-w-card p strong{color:#0f2b2e}
			.vso-w-meta{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin:12px 0 0;color:#4a6266;font-size:12px}
			.vso-w-trend{display:flex;align-items:flex-end;gap:4px;height:38px;margin:12px 0 0;padding:6px 8px;border-radius:10px;background:#eef3f1}
			.vso-w-trend span{flex:1;min-width:6px;border-radius:3px 3px 0 0}
			.vso-w-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
			.vso-w-actions .button-primary{background:#c7431f;border-color:#c7431f;border-radius:99px}
			.vso-w-actions .button-primary:hover{background:#a8361a;border-color:#a8361a}
			.vso-w-actions .button:not(.button-primary){border-radius:99px;border-color:#0f2b2e;color:#0f2b2e}
			.vso-w-err{margin:10px 0 0;padding:8px 10px;border-radius:8px;background:#fdebe5;color:#a8361a;font-size:12px}
			@media (max-width:480px){.vso-w-row{grid-template-columns:1fr}}
		</style>';

		echo '<div class="vso-w">';
		if ( empty( $last['mobile'] ) && empty( $last['desktop'] ) ) {
			echo '<p>' . esc_html__( 'No PageSpeed report yet. Run the first test now, after that the site is checked automatically once a week.', 'vyntic-speed-optimizer' ) . '</p>';
		} else {
			echo '<div class="vso-w-row">';
			foreach ( array( 'mobile' => __( 'Mobile', 'vyntic-speed-optimizer' ), 'desktop' => __( 'Desktop', 'vyntic-speed-optimizer' ) ) as $key => $label ) {
				if ( empty( $last[ $key ] ) ) {
					continue;
				}
				$r = $last[ $key ];
				echo '<div class="vso-w-card">' . self::gauge( (int) $r['score'], 64 ) . '<div><h4>' . esc_html( $label ) . '</h4><p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				foreach ( array( 'LCP', 'TBT', 'CLS' ) as $m ) {
					if ( isset( $r['metrics'][ $m ] ) ) {
						echo esc_html( $m ) . ' <strong>' . esc_html( $r['metrics'][ $m ]['value'] ) . '</strong><br>';
					}
				}
				echo '</p></div></div>';
			}
			echo '</div>';

			// Mobile trend, oldest to newest.
			$points = array_reverse( array_filter( $history, static function ( $row ) {
				return isset( $row['mobile'] );
			} ) );
			if ( count( $points ) > 1 ) {
				echo '<div class="vso-w-trend" title="' . esc_attr__( 'Mobile score, last tests', 'vyntic-speed-optimizer' ) . '">';
				foreach ( $points as $row ) {
					echo '<span style="height:' . max( 6, (int) $row['mobile'] ) . '%;background:' . esc_attr( self::color( (int) $row['mobile'] ) ) . '" title="' . esc_attr( wp_date( get_option( 'date_format' ), (int) $row['time'] ) . ': ' . (int) $row['mobile'] ) . '"></span>';
				}
				echo '</div>';
			}

			echo '<p class="vso-w-meta"><span>';
			/* translators: %s: time ago */
			printf( esc_html__( 'Last test %s ago', 'vyntic-speed-optimizer' ), esc_html( human_time_diff( (int) $last['time'] ) ) );
			if ( isset( $last['source'] ) && 'auto' === $last['source'] ) {
				echo ' (' . esc_html__( 'weekly check', 'vyntic-speed-optimizer' ) . ')';
			}
			echo '</span>';
			if ( $next ) {
				/* translators: %s: date */
				echo '<span>' . esc_html( sprintf( __( 'Next check: %s', 'vyntic-speed-optimizer' ), wp_date( get_option( 'date_format' ), $next ) ) ) . '</span>';
			}
			echo '</p>';
		}
		if ( is_array( $error ) && ! empty( $error['message'] ) && ( empty( $last['time'] ) || $error['time'] > $last['time'] ) ) {
			echo '<p class="vso-w-err">' . esc_html__( 'The last weekly check failed:', 'vyntic-speed-optimizer' ) . ' ' . esc_html( $error['message'] ) . '</p>';
		}
		echo '<div class="vso-w-actions"><a class="button button-primary" href="' . esc_url( $run ) . '">' . esc_html__( 'Test now', 'vyntic-speed-optimizer' ) . '</a>';
		echo '<a class="button" href="' . esc_url( $page ) . '#vso-psi">' . esc_html__( 'Full report', 'vyntic-speed-optimizer' ) . '</a></div>';
		echo '</div>';
	}
}
