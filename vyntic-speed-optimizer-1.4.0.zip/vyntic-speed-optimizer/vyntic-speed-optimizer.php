<?php
/**
 * Plugin Name:       Vyntic Speed Optimizer
 * Plugin URI:        https://vyntic.studio/plugins/vyntic-speed-optimizer/
 * Description:       All-in-one speed optimizer that runs 100% on your own server. No account, no login, no connect. Page cache, delay JavaScript until user interaction, remove unused CSS, lazy load, WebP, font optimization and more to push PageSpeed scores into the green.
 * Version:           1.4.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vyntic Studio
 * Author URI:        https://vyntic.studio/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vyntic-speed-optimizer
 * Domain Path:       /languages
 *
 * @package VynticSpeedOptimizer
 */

defined( 'ABSPATH' ) || exit;

define( 'VSO_VERSION', '1.4.0' );
define( 'VSO_FILE', __FILE__ );
define( 'VSO_PATH', plugin_dir_path( __FILE__ ) );
define( 'VSO_URL', plugin_dir_url( __FILE__ ) );
define( 'VSO_CACHE_DIR', WP_CONTENT_DIR . '/cache/vyntic/' );
define( 'VSO_CACHE_URL', content_url( '/cache/vyntic/' ) );

// Shared Vyntic menu + automatic updates from the Vyntic Hub (vyntic.studio).
require_once VSO_PATH . 'vendor/vyntic-client/loader.php';
vyntic_client_register(
	array(
		'file' => __FILE__,
		'slug' => 'vyntic-speed-optimizer',
		'name' => 'Vyntic Speed Optimizer',
		'page' => 'vyntic-speed',
		// Menu icon when this is the only Vyntic plugin: a speed gauge.
		'icon' => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M10 3a8 8 0 0 0-7.7 10.2 1 1 0 0 0 1 .8h13.4a1 1 0 0 0 1-.8A8 8 0 0 0 10 3zm0 2a6 6 0 0 1 5.9 7H4.1A6 6 0 0 1 10 5z"/><path fill="#a7aaad" d="M13.6 6.7l-3 4a1.4 1.4 0 1 1-1.2-.9l3.4-3.7z"/></svg>' ), // phpcs:ignore
	)
);

// Bundled MIT-licensed minifier (matthiasmullie/minify + path-converter).
spl_autoload_register(
	static function ( $class ) {
		$map = array(
			'MatthiasMullie\\Minify\\'        => VSO_PATH . 'vendor/minify/src/',
			'MatthiasMullie\\PathConverter\\' => VSO_PATH . 'vendor/path-converter/src/',
		);
		foreach ( $map as $prefix => $dir ) {
			if ( 0 === strpos( $class, $prefix ) ) {
				$file = $dir . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
				if ( file_exists( $file ) ) {
					require_once $file;
				}
				return;
			}
		}
	}
);

require_once VSO_PATH . 'includes/class-vso-settings.php';
require_once VSO_PATH . 'includes/class-vso-utils.php';
require_once VSO_PATH . 'includes/class-vso-page-cache.php';
require_once VSO_PATH . 'includes/class-vso-css.php';
require_once VSO_PATH . 'includes/class-vso-compat.php';
require_once VSO_PATH . 'includes/class-vso-js.php';
require_once VSO_PATH . 'includes/class-vso-media.php';
require_once VSO_PATH . 'includes/class-vso-fonts.php';
require_once VSO_PATH . 'includes/class-vso-optimizer.php';
require_once VSO_PATH . 'includes/class-vso-tweaks.php';
require_once VSO_PATH . 'includes/class-vso-webp.php';
require_once VSO_PATH . 'includes/class-vso-database.php';
require_once VSO_PATH . 'includes/class-vso-preload.php';
require_once VSO_PATH . 'includes/class-vso-psi.php';
require_once VSO_PATH . 'includes/class-vso-install.php';
require_once VSO_PATH . 'includes/class-vso-adminbar.php';

if ( is_admin() ) {
	require_once VSO_PATH . 'includes/class-vso-admin.php';
}

register_activation_hook( __FILE__, array( 'VSO_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'VSO_Install', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'vyntic-speed-optimizer', false, dirname( plugin_basename( VSO_FILE ) ) . '/languages' );

		VSO_Install::maybe_upgrade();
		VSO_Optimizer::init();
		VSO_Page_Cache::init();
		VSO_Tweaks::init();
		VSO_WebP::init();
		VSO_Database::init();
		VSO_Preload::init();
		VSO_PSI::init();

		if ( is_admin() ) {
			VSO_Admin::init();
		}
	}
);
