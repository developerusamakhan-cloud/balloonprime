<?php
/**
 * Tracked URLs: syncing posts into the table, choosing what to check next, storing results.
 *
 * @package SafeIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * URL repository.
 *
 * Statuses: pending (not checked yet), indexed, not_indexed, error,
 * excluded (noindex / password protected, never sent to Google).
 */
class SIA_Urls {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 10, 3 );
		add_action( 'post_updated', array( __CLASS__, 'on_update' ), 10, 3 );
		add_action( 'deleted_post', array( __CLASS__, 'forget' ) );
	}

	/**
	 * UTC "now" in MySQL format, optionally shifted.
	 *
	 * @param int $offset Seconds.
	 * @return string
	 */
	public static function now( $offset = 0 ) {
		return gmdate( 'Y-m-d H:i:s', time() + $offset );
	}

	/**
	 * Whether a post should be tracked at all.
	 *
	 * @param WP_Post $post Post.
	 * @return bool
	 */
	public static function is_tracked( $post ) {
		return $post instanceof WP_Post
			&& 'publish' === $post->post_status
			&& in_array( $post->post_type, SIA_Settings::post_types(), true );
	}

	/**
	 * Whether the site itself tells Google not to index this post (so checking it would waste quota).
	 *
	 * @param WP_Post $post Post.
	 * @return bool
	 */
	public static function is_excluded( $post ) {
		if ( '' !== $post->post_password ) {
			return true;
		}
		if ( '1' === (string) get_post_meta( $post->ID, '_yoast_wpseo_meta-robots-noindex', true ) ) {
			return true;
		}
		$rank_math = get_post_meta( $post->ID, 'rank_math_robots', true );
		if ( is_array( $rank_math ) && in_array( 'noindex', $rank_math, true ) ) {
			return true;
		}
		if ( '1' === (string) get_post_meta( $post->ID, '_seopress_robots_index', true ) || 'yes' === get_post_meta( $post->ID, '_seopress_robots_index', true ) ) {
			return true;
		}
		return ! get_option( 'blog_public' );
	}

	/**
	 * Add or refresh a post's row.
	 *
	 * @param WP_Post $post       Post.
	 * @param int     $check_in   Seconds until the first / next check.
	 */
	public static function upsert( $post, $check_in ) {
		global $wpdb;
		$table    = SIA_Install::table();
		$url      = get_permalink( $post );
		$excluded = self::is_excluded( $post );
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id, url, status FROM {$table} WHERE post_id = %d", $post->ID ) ); // phpcs:ignore WordPress.DB

		if ( ! $existing ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$table,
				array(
					'post_id'       => $post->ID,
					'url'           => $url,
					'status'        => $excluded ? 'excluded' : 'pending',
					'next_check_at' => self::now( $check_in ),
					'created_at'    => self::now(),
				)
			);
			return;
		}

		$data = array(
			'url'    => $url,
			'status' => $excluded ? 'excluded' : ( 'excluded' === $existing->status ? 'pending' : $existing->status ),
		);
		if ( $existing->url !== $url || 'excluded' === $existing->status ) {
			$data['next_check_at'] = self::now( $check_in );
		}
		$wpdb->update( $table, $data, array( 'id' => $existing->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Track newly published posts, forget unpublished ones.
	 *
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post.
	 */
	public static function on_status_change( $new_status, $old_status, $post ) {
		if ( wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return;
		}
		if ( 'publish' === $new_status && self::is_tracked( $post ) ) {
			self::upsert( $post, self::check_delay( $post ) );
			if ( 'publish' !== $old_status ) {
				SIA_IndexNow::queue( $post->ID );
			}
		} elseif ( 'publish' === $old_status ) {
			self::forget( $post->ID );
		}
	}

	/**
	 * Content updates on already-published posts: notify IndexNow, check again a bit sooner.
	 *
	 * @param int     $post_id     Post ID.
	 * @param WP_Post $post_after  After.
	 * @param WP_Post $post_before Before.
	 */
	public static function on_update( $post_id, $post_after, $post_before ) {
		if ( 'publish' !== $post_before->post_status || ! self::is_tracked( $post_after ) ) {
			return;
		}
		if ( $post_after->post_content === $post_before->post_content && $post_after->post_title === $post_before->post_title && $post_after->post_name === $post_before->post_name ) {
			return;
		}
		SIA_IndexNow::queue( $post_id );

		global $wpdb;
		$table = SIA_Install::table();
		// Not indexed yet and the content improved: re-check after the normal first-check delay (not immediately).
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$table} SET next_check_at = LEAST(next_check_at, %s) WHERE post_id = %d AND status IN ('not_indexed','error')", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::now( self::first_check_delay() ),
				$post_id
			)
		);
	}

	/**
	 * Remove a post's row.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function forget( $post_id ) {
		global $wpdb;
		$wpdb->delete( SIA_Install::table(), array( 'post_id' => (int) $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Seconds to wait after publishing before the first check (Google needs time to discover a page).
	 *
	 * @return int
	 */
	public static function first_check_delay() {
		return absint( SIA_Settings::get( 'first_check_days', 3 ) ) * DAY_IN_SECONDS;
	}

	/**
	 * Seconds until a post's first check: recent posts wait until they are first_check_days old,
	 * older ones (e.g. imported or back-dated) can be checked straight away.
	 *
	 * @param WP_Post $post Post.
	 * @return int
	 */
	public static function check_delay( $post ) {
		$age = time() - (int) get_post_time( 'U', true, $post );
		return max( 0, self::first_check_delay() - $age );
	}

	/**
	 * Add published posts that are not tracked yet (in chunks) and drop rows of untracked post types.
	 *
	 * @param int $limit Max posts to add in one go.
	 * @return int Number added.
	 */
	public static function sync( $limit = 500 ) {
		global $wpdb;
		$table = SIA_Install::table();
		$types = SIA_Settings::post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		// phpcs:disable WordPress.DB
		$wpdb->query( $wpdb->prepare( "DELETE t FROM {$table} t LEFT JOIN {$wpdb->posts} p ON p.ID = t.post_id WHERE p.ID IS NULL OR p.post_status <> 'publish' OR p.post_type NOT IN ({$in})", $types ) );

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$table} t ON t.post_id = p.ID
				WHERE p.post_status = 'publish' AND p.post_type IN ({$in}) AND t.id IS NULL
				ORDER BY p.post_date_gmt DESC LIMIT %d",
				array_merge( $types, array( $limit ) )
			)
		);
		// phpcs:enable

		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				self::upsert( $post, self::check_delay( $post ) );
			}
		}
		return count( $ids );
	}

	/**
	 * Rows due for a check: never-checked first, then the longest-waiting.
	 *
	 * @param int $limit Max rows.
	 * @return object[]
	 */
	public static function due( $limit ) {
		global $wpdb;
		$table = SIA_Install::table();
		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status <> 'excluded' AND next_check_at <= %s
				ORDER BY (inspected_at IS NULL) DESC, next_check_at ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::now(),
				$limit
			)
		);
	}

	/**
	 * Store an inspection result and schedule the next check.
	 *
	 * @param object $row    Table row.
	 * @param array  $result Google `inspectionResult`.
	 */
	public static function save_result( $row, $result ) {
		global $wpdb;
		$index   = isset( $result['indexStatusResult'] ) ? $result['indexStatusResult'] : array();
		$verdict = isset( $index['verdict'] ) ? $index['verdict'] : '';
		$indexed = 'PASS' === $verdict;
		$days    = $indexed ? SIA_Settings::get( 'recheck_indexed_days', 30 ) : SIA_Settings::get( 'recheck_unindexed_days', 7 );

		$data = array(
			'status'           => $indexed ? 'indexed' : 'not_indexed',
			'verdict'          => substr( $verdict, 0, 30 ),
			'coverage_state'   => substr( isset( $index['coverageState'] ) ? $index['coverageState'] : '', 0, 190 ),
			'indexing_state'   => substr( isset( $index['indexingState'] ) ? $index['indexingState'] : '', 0, 40 ),
			'robots_state'     => substr( isset( $index['robotsTxtState'] ) ? $index['robotsTxtState'] : '', 0, 40 ),
			'fetch_state'      => substr( isset( $index['pageFetchState'] ) ? $index['pageFetchState'] : '', 0, 40 ),
			'google_canonical' => substr( isset( $index['googleCanonical'] ) ? $index['googleCanonical'] : '', 0, 500 ),
			'user_canonical'   => substr( isset( $index['userCanonical'] ) ? $index['userCanonical'] : '', 0, 500 ),
			'inspect_link'     => substr( isset( $result['inspectionResultLink'] ) ? $result['inspectionResultLink'] : '', 0, 700 ),
			'last_crawl'       => ! empty( $index['lastCrawlTime'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $index['lastCrawlTime'] ) ) : null,
			'error'            => null,
			'inspected_at'     => self::now(),
			'next_check_at'    => self::now( absint( $days ) * DAY_IN_SECONDS ),
		);

		if ( ! $indexed ) {
			$data['word_count']    = SIA_Diagnosis::word_count( $row->post_id );
			$data['inbound_links'] = SIA_Diagnosis::inbound_links( $row->post_id, $row->url );
		}

		$wpdb->update( SIA_Install::table(), $data, array( 'id' => $row->id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Store a per-URL error (e.g. URL not inside the property).
	 *
	 * @param object $row     Row.
	 * @param string $message Error.
	 * @param int    $retry   Seconds until retry.
	 */
	public static function save_error( $row, $message, $retry ) {
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			SIA_Install::table(),
			array(
				'status'        => 'error',
				'error'         => $message,
				'inspected_at'  => self::now(),
				'next_check_at' => self::now( $retry ),
			),
			array( 'id' => $row->id )
		);
	}

	/**
	 * Counts per status.
	 *
	 * @return array
	 */
	public static function counts() {
		global $wpdb;
		$table = SIA_Install::table();
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) AS n FROM {$table} GROUP BY status" ); // phpcs:ignore WordPress.DB
		$out   = array(
			'pending'     => 0,
			'indexed'     => 0,
			'not_indexed' => 0,
			'error'       => 0,
			'excluded'    => 0,
		);
		foreach ( $rows as $r ) {
			$out[ $r->status ] = (int) $r->n;
		}
		$out['total'] = array_sum( $out );
		return $out;
	}

	/**
	 * Paged list for the dashboard.
	 *
	 * @param string $status Filter ('' = all).
	 * @param int    $page   1-based page.
	 * @param int    $per    Per page.
	 * @return array{rows:object[],total:int}
	 */
	public static function page( $status, $page, $per = 50 ) {
		global $wpdb;
		$table = SIA_Install::table();
		$where = $status ? $wpdb->prepare( 'WHERE status = %s', $status ) : '';
		// phpcs:disable WordPress.DB
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$where}" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} {$where} ORDER BY FIELD(status,'not_indexed','error','pending','indexed','excluded'), inspected_at DESC, id DESC LIMIT %d OFFSET %d", $per, ( max( 1, $page ) - 1 ) * $per ) );
		// phpcs:enable
		return array(
			'rows'  => $rows,
			'total' => $total,
		);
	}

	/**
	 * Today's manual "Request indexing" list: not indexed (including URLs Google has never seen,
	 * whose states come back as *_UNSPECIFIED), nothing technically blocking it,
	 * and not requested in the last 30 days.
	 *
	 * @param int $limit Max rows.
	 * @return object[]
	 */
	public static function manual_candidates( $limit ) {
		global $wpdb;
		$table = SIA_Install::table();
		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT t.* FROM {$table} t JOIN {$wpdb->posts} p ON p.ID = t.post_id
				WHERE t.status = 'not_indexed'
				AND t.indexing_state IN ('', 'INDEXING_ALLOWED', 'INDEXING_STATE_UNSPECIFIED')
				AND t.robots_state IN ('', 'ALLOWED', 'ROBOTS_TXT_STATE_UNSPECIFIED')
				AND t.fetch_state IN ('', 'SUCCESSFUL', 'PAGE_FETCH_STATE_UNSPECIFIED')
				AND (t.manual_requested_at IS NULL OR t.manual_requested_at < %s)
				ORDER BY p.post_date_gmt DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::now( -30 * DAY_IN_SECONDS ),
				$limit
			)
		);
	}

	/**
	 * Mark a row as manually requested in Search Console; check it again in 3 days.
	 *
	 * @param int $id Row ID.
	 */
	public static function mark_requested( $id ) {
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			SIA_Install::table(),
			array(
				'manual_requested_at' => self::now(),
				'next_check_at'       => self::now( 3 * DAY_IN_SECONDS ),
			),
			array( 'id' => (int) $id )
		);
	}

	/**
	 * Queue a row for the next run (still subject to the daily limit).
	 *
	 * @param int $id Row ID.
	 */
	public static function recheck( $id ) {
		global $wpdb;
		$wpdb->update( SIA_Install::table(), array( 'next_check_at' => self::now() ), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Row by post ID.
	 *
	 * @param int $post_id Post ID.
	 * @return object|null
	 */
	public static function by_post( $post_id ) {
		global $wpdb;
		$table = SIA_Install::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id = %d", $post_id ) ); // phpcs:ignore WordPress.DB
	}
}
