<?php
/**
 * Plugin Name:       Vyntic Index Assistant
 * Plugin URI:        https://vyntic.studio/plugins/vyntic-index-assistant/
 * Description:       Finds which posts and pages Google has not indexed yet (Search Console URL Inspection API), explains why, and helps get them indexed only in ways Google allows: sitemap resubmission, IndexNow for Bing and Yandex, and a short daily "Request indexing" list. Every action stays well under Google's limits.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vyntic Studio
 * Author URI:        https://vyntic.studio/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vyntic-index-assistant
 * Domain Path:       /languages
 *
 * @package VynticIndexAssistant
 */

defined( 'ABSPATH' ) || exit;

// The older "Safe Index Assistant" uses the same code. Running both would clash, so stop here until it is deactivated.
if ( class_exists( 'SIA_Admin' ) ) {
	add_action(
		'admin_notices',
		static function () {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Vyntic Index Assistant replaces "Safe Index Assistant". Deactivate and delete the old plugin; your Google connection, settings and index data carry over.', 'vyntic-index-assistant' ) . '</p></div>';
		}
	);
	return;
}

define( 'SIA_VERSION', '1.1.0' );
define( 'SIA_DB_VERSION', '1.0.0' );
define( 'SIA_FILE', __FILE__ );
define( 'SIA_PATH', plugin_dir_path( __FILE__ ) );
define( 'SIA_URL', plugin_dir_url( __FILE__ ) );

// Shared Vyntic menu + automatic updates from the Vyntic Hub (vyntic.studio).
require_once SIA_PATH . 'vendor/vyntic-client/loader.php';
vyntic_client_register(
	array(
		'file' => __FILE__,
		'slug' => 'vyntic-index-assistant',
		'name' => 'Vyntic Index Assistant',
		'page' => 'vyntic-index-assistant',
		// Menu icon when this is the only Vyntic plugin: a magnifier with a check.
		'icon' => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M8.5 2a6.5 6.5 0 0 1 5.2 10.4l4 4-1.4 1.4-4-4A6.5 6.5 0 1 1 8.5 2zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9z"/><path fill="#a7aaad" d="M6.3 8.3l1.6 1.6 3-3 1 1-4 4-2.6-2.6z"/></svg>' ), // phpcs:ignore
	)
);

require_once SIA_PATH . 'includes/class-sia-settings.php';
require_once SIA_PATH . 'includes/class-sia-install.php';
require_once SIA_PATH . 'includes/class-sia-quota.php';
require_once SIA_PATH . 'includes/class-sia-google.php';
require_once SIA_PATH . 'includes/class-sia-urls.php';
require_once SIA_PATH . 'includes/class-sia-diagnosis.php';
require_once SIA_PATH . 'includes/class-sia-indexnow.php';
require_once SIA_PATH . 'includes/class-sia-cron.php';
require_once SIA_PATH . 'includes/class-sia-admin.php';

register_activation_hook( __FILE__, array( 'SIA_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SIA_Install', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'vyntic-index-assistant', false, dirname( plugin_basename( SIA_FILE ) ) . '/languages' );

		SIA_Install::maybe_upgrade();
		SIA_Urls::init();
		SIA_IndexNow::init();
		SIA_Cron::init();

		if ( is_admin() ) {
			SIA_Admin::init();
		}
	}
);
